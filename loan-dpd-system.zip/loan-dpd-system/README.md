# Loan Collections & DPD Management System

A working loan servicing and collections system for an NBFC: customers, loans, EMI schedules, payments with an allocation waterfall, bounces, reversals, a PostgreSQL DPD engine that runs every night, collections workflow, dashboards and 18 exportable reports.

Most of the financial logic lives **in the database** as stored functions, views and triggers, so every number on every screen comes from one definition and can be traced back to the rows that produced it.

- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS, shadcn/ui-style components (Radix), TanStack Query, React Hook Form + Zod, Recharts, Lucide
- **Backend:** Node.js 22, Express, TypeScript, Zod validation, JWT + rotating refresh tokens, RBAC, OpenAPI/Swagger
- **Database:** PostgreSQL 16 (31 tables, 32 stored functions/procedures, 9 views, 38 triggers)
- **Ops:** Docker Compose, node-cron scheduler, pino logging

---

## 1. Quick start (Docker)

```bash
cp .env.example .env          # optional: defaults work for local use
docker compose up --build
```

| What | URL |
|---|---|
| Application | http://localhost:8080 |
| API documentation (Swagger) | http://localhost:8080/api/docs |
| OpenAPI JSON | http://localhost:8080/api/openapi.json |
| Health check | http://localhost:8080/api/health |

On first start the `backend` container applies all migrations and the one-shot `seed` container loads about 11 months of demo history (≈20 seconds). Set `SEED_DEMO_DATA=false` in `.env` to start empty.

### Demo logins (local development only)

Password for every account: **`Demo@12345`**

| Email | Role | What they can do |
|---|---|---|
| superadmin@demo.local | Super Admin | Everything, including editing role permissions |
| admin@demo.local | Admin | Everything except role permissions |
| manager@demo.local | Collection Manager | Assign accounts, set targets, collections, payments, reports |
| exec1@demo.local … exec4@demo.local | Collection Executive | Only their assigned accounts: log calls, promises, payments |
| finance@demo.local | Finance User | Loans, disbursement, payments, reversals, waivers, DPD runs |
| analyst@demo.local | Read-Only Analyst | Read and export; PII is masked |

> Change `JWT_SECRET` and database passwords before deploying anywhere shared. The demo users are created only by the seed.

---

## 2. Local development (without Docker)

Requirements: Node.js ≥ 20.19, PostgreSQL ≥ 15.

```bash
# database
createdb collections_db

# backend
cd backend
cp .env.example .env            # set DATABASE_URL and JWT_SECRET
npm install
npm run seed -- --reset         # migrate + demo data (drops existing data!)
npm run dev                     # http://localhost:4000, docs at /api/docs

# frontend (new terminal)
cd frontend
npm install
npm run dev                     # http://localhost:5173 (proxies /api to :4000)
```

Useful backend commands:

| Command | Purpose |
|---|---|
| `npm run migrate` | Apply pending SQL migrations (also runs automatically on server start) |
| `npm run seed` | Load demo data into an empty database (no-op if users exist) |
| `npm run seed -- --reset` | Drop everything, re-migrate, reseed (development only) |
| `npm run dpd:run [-- 2026-11-04]` | Run the daily DPD job from the command line (exit code 1 on failure) |
| `npm run build && npm start` | Production build |

---

## 3. Project structure

```
loan-dpd-system/
├── docker-compose.yml          db, backend, one-shot seed, frontend (nginx)
├── .env.example
├── backend/
│   ├── db/migrations/          ← the database: run in order, checksummed
│   │   ├── 001_schema.sql        31 tables, constraints, indexes
│   │   ├── 002_functions.sql     EMI generation, payment waterfall, reversal, bounce,
│   │   │                         DPD engine, daily procedure, portfolio summary
│   │   ├── 003_views.sql         reporting views
│   │   ├── 004_triggers.sql      audit trail, immutability, state machines
│   │   ├── 005_reference_data.sql roles, permissions, buckets, settings, products
│   │   ├── 006_ledger.sql        loan ledger function
│   │   └── 007_executive_scope.sql
│   ├── src/
│   │   ├── modules/            auth, customers, loans, emi, payments, bounces, dpd,
│   │   │                       collections, dashboard, reports, admin
│   │   ├── lib/                emi + dpd (TS mirrors for tests), exports, masking, SQL builder
│   │   ├── middleware/         auth/RBAC, idempotency, errors
│   │   ├── jobs/               DPD scheduler + CLI
│   │   ├── seed/               day-by-day simulation seed
│   │   └── openapi.ts          Swagger generated from the route definitions
│   └── tests/                  unit + integration (Vitest, real PostgreSQL)
└── frontend/
    ├── src/
    │   ├── pages/              25+ screens
    │   ├── components/         DataTable, DPD ladder, charts, ui kit, layout
    │   ├── hooks/ lib/         API client, auth, formatting
    └── e2e/                    Playwright end-to-end journey
```

---

## 4. Business definitions

These are implemented once in SQL and reused by the dashboard, reports and APIs.

**Business date.** Every position is "as of" the business date stored in `system_settings`. Only the daily DPD job moves it forward; the server clock is never used directly. The business timezone (default `Asia/Kolkata`) decides what "today" is.

**DPD (days past due)** — `fn_compute_dpd`, `fn_calc_dpd`
`DPD = business date − due date of the oldest installment that still has an unpaid amount and is past its due date.`
- Due today is not past due. Future installments never count.
- Partial payments reduce the overdue amount but an installment only stops counting when its remaining amount is exactly zero.
- An optional grace period (`dpd_grace_days`) keeps DPD at 0 for the first N days.
- The **same function** computes the nightly batch and the instant refresh after every payment, so the two can never disagree.

**Buckets** (configurable in the UI, validated for gaps/overlaps): Current (0), 1–30, 31–60, 61–89, 90+.

**Outstanding principal (POS)** = principal − principal repaid.

**Portfolio at Risk.** PAR-N = POS of accounts with DPD **> N** ÷ total POS of the live book. Note that the "90+" bucket uses DPD **≥ 90**, so PAR 90 and the 90+ bucket differ by accounts at exactly 90 days.

**Collection efficiency** — `fn_collection_efficiency(from, to)`
= amount collected against installments due in the period ÷ EMI demand due in the period. Bounced, failed and reversed money is never counted.

**Payment allocation waterfall** — `fn_allocate_payment`, configurable:
- `EMI_ORDER` (default): oldest installment first, interest then principal; then charges
- `CHARGES_FIRST`: open charges first, then installments
- `INTEREST_FIRST`: all due interest, then all due principal, then charges

In every mode any remainder is applied to future installments as an **advance**. Payments larger than the total outstanding are rejected.

**EMI** — reducing balance `EMI = P·r·(1+r)^n / ((1+r)^n − 1)` with `r = annual rate / 12 / 100`, rounded to the rupee (configurable). Interest is rounded to paise each month and the **last installment absorbs every rounding residue**, so principal components sum to the loan amount exactly. Zero-interest and flat-rate loans are supported. Due dates falling on holidays move per the configured rule.

**Bounces and reversals** undo exactly the allocations the payment made (`fn_unwind_allocations`), so balances return to their prior state with no double counting. A bounce also adds the configured bounce charge as a separate charge, and its recovery status updates automatically as the customer pays.

**Promises to pay** are evaluated nightly: kept, partly kept, or broken, from payments received between the promise date and the promised date.

---

## 5. Database design

### Entity relationships (core)

```mermaid
erDiagram
  customers ||--o{ loans : borrows
  loan_products ||--o{ loans : "priced by"
  branches ||--o{ loans : books
  loans ||--|{ emi_schedules : "repaid by"
  loans ||--o{ payments : receives
  payments ||--o{ payment_allocations : "split into"
  emi_schedules ||--o{ payment_allocations : "paid by"
  loan_charges ||--o{ payment_allocations : "paid by"
  payments ||--o| payment_reversals : "undone by"
  payments ||--o| payment_bounces : "returned as"
  payment_bounces ||--o| loan_charges : "charged as"
  loans ||--o{ loan_charges : carries
  loans ||--|| dpd_current : "live position"
  loans ||--o{ dpd_daily_snapshots : "history"
  loans ||--o{ collection_assignments : "worked by"
  users ||--o{ collection_assignments : executive
  loans ||--o{ collection_activities : logs
  collection_activities ||--o| promise_to_pay : creates
  roles ||--o{ users : has
  roles ||--o{ role_permissions : grants
  permissions ||--o{ role_permissions : in
```

**Tables (31):** users, roles, permissions, role_permissions, user_sessions, password_resets, login_history, branches, customers, loan_products, loans, emi_schedules, payments, payment_allocations, payment_reversals, payment_bounces, loan_charges, collection_activities, collection_assignments, promise_to_pay, collection_targets, dpd_current, dpd_daily_snapshots, dpd_bucket_config, portfolio_daily_summary, job_execution_logs, audit_logs, system_settings, holidays, notifications, idempotency_keys.

### Where each DBMS concept is used

| Concept | Where |
|---|---|
| **Normalisation (3NF)** | `customer_id` is *not* stored on payments, bounces or activities: it depends on `loan_id`, so storing it again would be a transitive dependency. Views join it in. Charges live in their own table instead of columns on installments. |
| **Integrity constraints** | `CHECK` on every money column (no negatives, `emi = principal + interest`, `paid ≤ component`), regex checks on PAN/mobile/PIN, unique business keys, foreign keys everywhere |
| **Partial unique indexes** | one live payment per bank reference (`WHERE status <> 'FAILED'`); one active collector per loan (`WHERE is_active`) |
| **Generated columns** | `amount_paid`, `remaining_amount` on installments and charges — never out of sync |
| **Stored procedures/functions** | `sp_generate_emi_schedule`, `sp_disburse_loan`, `sp_process_payment`, `sp_reverse_payment`, `sp_record_payment_bounce`, `sp_realize_payment`, `sp_waive`, `sp_close_loan`, `sp_write_off_loan`, `sp_update_daily_dpd`, `sp_generate_portfolio_summary`, `fn_compute_dpd`, `fn_allocate_payment`, `fn_loan_ledger`, `fn_collection_efficiency`… |
| **Transactions & rollback** | every payment is one atomic transaction; `sp_update_daily_dpd` is a `PROCEDURE` that `COMMIT`s its "RUNNING" log first, does all work in a sub-block, and on any error rolls the work back but keeps and marks the log `FAILED` |
| **Concurrency control** | `SELECT … FOR UPDATE` on the loan serialises payments per loan (tested with two simultaneous payments: exactly one succeeds); advisory lock prevents two DPD runs at once |
| **Idempotency** | `ON CONFLICT DO NOTHING` on `(business_date, loan_id)` snapshots; `Idempotency-Key` table for payment APIs |
| **Triggers** | generic audit trigger records only changed columns with user/IP/request id; immutability triggers on snapshots, allocations, reversals and the audit log; state-machine triggers on loan and payment status; frozen contractual columns after disbursement |
| **Views** | `vw_loan_register`, `vw_active_loans`, `vw_emi_overdue`, `vw_loan_outstanding`, `vw_dpd_bucket_portfolio`, `vw_daily_collection_summary`, `vw_bounce_summary`, `vw_collection_performance`, `vw_par_summary` |
| **Indexing** | composite indexes for the DPD engine (`loan_id, due_date`), a partial index on unpaid installments only, trigram index for name search, date/status indexes for reports |
| **Set-based SQL & window functions** | DPD for the whole book in one pass with `FILTER` aggregates; running ledger balance with `SUM() OVER (ORDER BY …)` |
| **Session variables** | the API sets `app.user_id` / `app.request_id` with `set_config(…, true)` so triggers know who acted |

---

## 6. Daily DPD processing

`sp_update_daily_dpd(business_date)` runs at **00:30 Asia/Kolkata** by default (`dpd_job_cron`, editable in Configuration). In one transaction it:

1. refreshes every installment's status and DPD,
2. recomputes `dpd_current` for all live loans and syncs loan status (Active ⇄ Overdue),
3. inserts that day's immutable snapshot for every loan (`ON CONFLICT DO NOTHING`),
4. evaluates promises to pay and notifies executives of broken ones,
5. rebuilds the portfolio summary from the snapshots,
6. logs rows processed, duration and any error.

Guarantees: re-running a date changes nothing that already exists; a date earlier than the last successful run or later than today is refused and logged; if the server was down, the scheduler catches up day by day. Admins can run, retry and inspect runs on **Scheduled jobs**. For an external scheduler use `npm run dpd:run`.

---

## 7. API

Swagger UI at `/api/docs` documents all 100 operations with request schemas and required permissions (generated from the same Zod schemas that validate requests).

- List endpoints accept `page`, `pageSize`, `sort`, `order`, `search`, filters, and `format=csv|xlsx|pdf` to export.
- Errors always look like `{ "error": { "code", "message", "details", "requestId" } }`.
- `POST /api/payments` honours an `Idempotency-Key` header: a retry returns the original response instead of posting twice.
- Spec paths implemented as requested, plus extras such as `/api/payments/preview` (dry-run allocation), `/api/loans/:id/ledger`, `/api/dpd/movement`, `/api/bounces/:id/reattempt`, `/api/collections/assignments/auto`.

---

## 8. Tests

```bash
cd backend
npm test                     # unit + integration (needs PostgreSQL; recreates collections_test each run)
npm run test:unit            # no database needed

cd frontend                  # with the app running and demo data loaded
npx playwright install chromium     # once (or set CHROME_PATH to an installed Chrome)
E2E_BASE_URL=http://localhost:8080 npm run test:e2e
```

| Suite | Count | Covers |
|---|---|---|
| Unit | 30 | EMI formula and schedules (incl. zero/flat interest, rounding residue verified independently), DPD rules, grace, buckets and bucket validation, PAR, CSV injection guard, PII masking, SQL binding/sort whitelisting |
| Integration | 26 | auth, refresh-token rotation and theft detection, RBAC, PII masking, customer validation, loan lifecycle, DB↔TypeScript EMI parity, partial/advance/duplicate/idempotent payments, bounce and reversal restoration, ledger reconciliation, concurrent payments, closure and waivers, DPD idempotency/immutability/date guards, portfolio and report reconciliation, executive scoping, exports |
| End-to-end | 8 | login, create customer, create/approve/disburse loan, schedule, payment with preview, bounce, run DPD, DPD dashboard drill-down, report export, role scoping |

---

## 9. Production deployment

1. Set strong values for `JWT_SECRET` (32+ random chars) and `POSTGRES_PASSWORD`; set `APP_URL` to your HTTPS origin.
2. Set `SEED_DEMO_DATA=false` and create the first admin user (temporarily run the seed in a staging copy, or insert one user via SQL with a bcrypt hash, then create the rest in **Users**).
3. Terminate TLS in front of the `frontend` container (refresh cookies are `Secure` in production).
4. Configure SMTP so password-reset email works.
5. Run a single backend replica for the scheduler, or set `SCHEDULER_ENABLED=false` on extra replicas and trigger `npm run dpd:run` from one place. The database advisory lock prevents overlapping runs either way.

### Backup and restore

```bash
# backup (compressed, consistent snapshot)
docker compose exec -T db pg_dump -U postgres -Fc collections_db > backup_$(date +%F).dump

# restore into a fresh database
docker compose exec -T db dropdb -U postgres --if-exists collections_db
docker compose exec -T db createdb -U postgres collections_db
docker compose exec -T db pg_restore -U postgres -d collections_db < backup_2026-11-04.dump
```

Snapshots, allocations and the audit log are append-only, so point-in-time backups fully reproduce historical reports.

---

## 10. Security

bcrypt password hashing (cost 12) · 15-minute access JWT in memory + rotating httpOnly refresh cookie with reuse detection · account lock after 5 failed sign-ins · tokens invalidated on password change · RBAC on every endpoint plus row-level scoping for collection executives · Zod validation on every input · parameterised SQL only (sort columns via whitelist) · rate limiting · Helmet security headers · CORS allow-list · PII masked for roles without `customers.pii` (also in exports) · only the last 4 Aadhaar digits stored · spreadsheet formula-injection guard on exports · exports require a permission and are audited · secrets, tokens, PAN and mobile redacted from logs · immutable financial history.

---

## 11. Known limitations

Stated plainly so nothing is presented as more complete than it is:

- **Prisma was replaced by node-postgres + plain SQL migrations.** The build environment could not download Prisma's engine binaries, and since this project's logic lives in stored procedures, raw SQL keeps it visible and testable. Everything the spec asked Prisma for (schema, migrations, data access) is covered.
- **Docker images were not built in the development environment** (registry access was blocked). The compose file validates, and the exact container commands were run against a fresh database with the compiled production build; still, run `docker compose up --build` once and report any issue.
- **Monthly repayment only.** The `repayment_frequency` column exists but only `MONTHLY` is allowed.
- **No automatic penal interest** on overdue amounts. Bounce charges are automatic; the `loan_charges` table supports `PENAL`/`OTHER` charge types but nothing accrues them yet.
- **No broken-period interest** for the first installment, and no part-prepayment with schedule re-amortisation (prepayments are applied as advance installments; full foreclosure works).
- **Payment gateways / NACH files are not integrated.** Presentations are recorded manually or by CSV import; realise/bounce actions stand in for bank responses.
- **Email** needs SMTP configuration; in development reset links are written to `backend/.dev-outbox/`.
- **Reopening a closed loan** is not supported, so payments on closed loans can't be reversed.
- **PDF exports** are plain tabular layouts; Excel is the better format for large reports.
- The **seed is demo data**: names come from Faker and do not represent real people.
