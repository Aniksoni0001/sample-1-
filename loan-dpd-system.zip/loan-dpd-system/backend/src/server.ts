import { env } from './config/env.js';
import { createApp } from './app.js';
import { logger } from './lib/logger.js';
import { pool } from './db/pool.js';
import { migrate } from './db/migrate.js';
import { startScheduler, stopScheduler } from './jobs/scheduler.js';

async function main() {
  // apply pending migrations on boot so `docker compose up` is enough
  await migrate((m) => logger.info(m));
  const app = createApp();
  const server = app.listen(env.PORT, () => logger.info(`API listening on :${env.PORT} (docs at /api/docs)`));
  if (env.SCHEDULER_ENABLED) await startScheduler();

  const shutdown = (sig: string) => {
    logger.info(`${sig} received, shutting down`);
    stopScheduler();
    server.close(() => pool.end().then(() => process.exit(0)));
    setTimeout(() => process.exit(1), 10_000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch((e) => {
  logger.error({ err: e }, 'Failed to start');
  process.exit(1);
});
