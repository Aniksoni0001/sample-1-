import { Decimal } from 'decimal.js';

/**
 * TypeScript mirror of sp_generate_emi_schedule (used for the loan-creation
 * preview and unit tests; the database function is the system of record and an
 * integration test asserts both produce identical schedules).
 *
 *   EMI = P · r · (1 + r)^n / ((1 + r)^n − 1),   r = annualRate / 12 / 100
 *
 * Interest per installment is rounded to paise, the EMI to `roundingPlaces`
 * (0 = nearest rupee) and the last installment absorbs every rounding residue
 * so that Σ principal = P exactly.
 */
const D = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

export type InterestMethod = 'REDUCING' | 'FLAT';

export interface EmiInput {
  principal: number | string;
  annualRate: number | string;
  tenureMonths: number;
  method?: InterestMethod;
  roundingPlaces?: number;
  firstEmiDate?: string; // YYYY-MM-DD (nominal; holiday shifting happens at disbursement)
}

export interface ScheduleRow {
  installmentNo: number;
  dueDate: string | null;
  openingPrincipal: string;
  principal: string;
  interest: string;
  emi: string;
  closingPrincipal: string;
}

export interface Schedule {
  emi: string;
  totalInterest: string;
  totalPayable: string;
  rows: ScheduleRow[];
}

function validate(i: EmiInput) {
  const p = new D(i.principal);
  const rate = new D(i.annualRate);
  if (!p.isFinite() || p.lte(0)) throw new Error('Principal must be greater than zero');
  if (!rate.isFinite() || rate.lt(0) || rate.gte(100)) throw new Error('Annual rate must be between 0 and 100');
  if (!Number.isInteger(i.tenureMonths) || i.tenureMonths < 1 || i.tenureMonths > 360)
    throw new Error('Tenure must be 1–360 months');
  return { p, rate };
}

export function calculateEmi(input: EmiInput): string {
  const { p, rate } = validate(input);
  const n = input.tenureMonths;
  const places = input.roundingPlaces ?? 0;
  if ((input.method ?? 'REDUCING') === 'FLAT') {
    const totalInterest = p.mul(rate).mul(n).div(1200).toDecimalPlaces(2);
    return p.plus(totalInterest).div(n).toDecimalPlaces(places).toFixed(2);
  }
  const r = rate.div(1200);
  if (r.isZero()) return p.div(n).toDecimalPlaces(places).toFixed(2);
  const f = r.plus(1).pow(n);
  return p.mul(r).mul(f).div(f.minus(1)).toDecimalPlaces(places).toFixed(2);
}

export function addMonths(isoDate: string, months: number): string {
  const [y, m, d] = isoDate.split('-').map(Number);
  const total = y * 12 + (m - 1) + months;
  const ny = Math.floor(total / 12);
  const nm = (total % 12) + 1;
  const lastDay = new Date(Date.UTC(ny, nm, 0)).getUTCDate();
  return `${ny}-${String(nm).padStart(2, '0')}-${String(Math.min(d, lastDay)).padStart(2, '0')}`;
}

export function buildSchedule(input: EmiInput): Schedule {
  const { p, rate } = validate(input);
  const n = input.tenureMonths;
  const method = input.method ?? 'REDUCING';
  const r = rate.div(1200);
  const emi = new D(calculateEmi(input));
  const flatInterest = method === 'FLAT' ? p.mul(rate).mul(n).div(1200).toDecimalPlaces(2) : new D(0);

  const rows: ScheduleRow[] = [];
  let open = p;
  let interestSum = new D(0);
  for (let k = 1; k <= n; k++) {
    let interest: Decimal;
    if (method === 'FLAT') {
      interest = k === n ? flatInterest.minus(interestSum) : flatInterest.div(n).toDecimalPlaces(2);
    } else {
      interest = open.mul(r).toDecimalPlaces(2);
    }
    let principal: Decimal;
    if (k === n) principal = open;
    else principal = D.min(D.max(emi.minus(interest), 0), open);

    rows.push({
      installmentNo: k,
      dueDate: input.firstEmiDate ? addMonths(input.firstEmiDate, k - 1) : null,
      openingPrincipal: open.toFixed(2),
      principal: principal.toFixed(2),
      interest: interest.toFixed(2),
      emi: principal.plus(interest).toFixed(2),
      closingPrincipal: open.minus(principal).toFixed(2),
    });
    interestSum = interestSum.plus(interest);
    open = open.minus(principal);
  }
  return {
    emi: emi.toFixed(2),
    totalInterest: interestSum.toFixed(2),
    totalPayable: p.plus(interestSum).toFixed(2),
    rows,
  };
}
