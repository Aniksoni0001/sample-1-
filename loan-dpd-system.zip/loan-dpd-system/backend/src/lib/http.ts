import type { NextFunction, Request, Response, Router } from 'express';
import { z, type ZodType } from 'zod';
import { forbidden, unauthorized } from './errors.js';
import type { AuthUser } from '../middleware/auth.js';
import { authenticate } from '../middleware/auth.js';
import { idempotency } from '../middleware/idempotency.js';
import type { DbContext } from '../db/pool.js';

type Method = 'get' | 'post' | 'put' | 'patch' | 'delete';

export interface Ctx<B, Q, P> {
  req: Request;
  res: Response;
  user: AuthUser;
  body: B;
  query: Q;
  params: P;
  db: DbContext;
  can: (perm: string) => boolean;
}

export interface RouteDef<B = any, Q = any, P = any> {
  method: Method;
  path: string;
  tag: string;
  summary: string;
  /** any one of these permissions grants access */
  permission?: string | string[];
  public?: boolean;
  body?: ZodType<B>;
  query?: ZodType<Q>;
  params?: ZodType<P>;
  /** honour the Idempotency-Key header (payments) */
  idempotent?: boolean;
  status?: number;
  /** handler writes the response itself (files, cookies) */
  raw?: boolean;
  middlewares?: ((req: Request, res: Response, next: NextFunction) => void)[];
  handler: (ctx: Ctx<B, Q, P>) => Promise<unknown>;
}

/** Everything registered here also appears in the OpenAPI document. */
export const registry: { def: RouteDef; fullPath: string }[] = [];

export function route<B = any, Q = any, P = any>(router: Router, base: string, def: RouteDef<B, Q, P>) {
  registry.push({ def: def as RouteDef, fullPath: base + def.path });
  const chain: any[] = [];
  if (!def.public) chain.push(authenticate);
  chain.push(...(def.middlewares ?? []));
  if (def.idempotent) chain.push(idempotency);

  chain.push(async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = (req as any).user as AuthUser;
      const can = (perm: string) => !!user?.permissions.has(perm);
      if (!def.public) {
        if (!user) throw unauthorized();
        const perms = def.permission ? (Array.isArray(def.permission) ? def.permission : [def.permission]) : [];
        if (perms.length && !perms.some(can)) throw forbidden();
      }
      const body = def.body ? def.body.parse(req.body ?? {}) : (req.body as B);
      const query = def.query ? def.query.parse(req.query) : (req.query as unknown as Q);
      const params = def.params ? def.params.parse(req.params) : (req.params as unknown as P);
      const ctx: Ctx<B, Q, P> = {
        req,
        res,
        user,
        body,
        query,
        params,
        can,
        db: { userId: user?.id, requestId: (req as any).id, ip: req.ip },
      };
      const result = await def.handler(ctx);
      if (def.raw || res.headersSent) return;
      res.status(def.status ?? (def.method === 'post' ? 201 : 200)).json(result ?? { ok: true });
    } catch (e) {
      next(e);
    }
  });
  (router as any)[def.method](base + def.path, ...chain);
}

export const zodToJson = (schema: ZodType) => {
  try {
    return z.toJSONSchema(schema, { io: 'input', unrepresentable: 'any' });
  } catch {
    return { type: 'object' };
  }
};
