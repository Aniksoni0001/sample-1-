export function maskMobile(m?: string | null): string | null {
  if (!m) return m ?? null;
  return m.length <= 4 ? '****' : `${m.slice(0, 2)}${'X'.repeat(m.length - 4)}${m.slice(-2)}`;
}

export function maskPan(p?: string | null): string | null {
  if (!p) return p ?? null;
  return `XXXXX${p.slice(5, 9)}X`;
}

export function maskEmail(e?: string | null): string | null {
  if (!e) return e ?? null;
  const [user, domain] = e.split('@');
  if (!domain) return '***';
  return `${user.slice(0, 1)}***@${domain}`;
}

/** Strip/mask PII fields on a row unless the caller may see them. */
export function maskRow<T extends Record<string, any>>(row: T, canSeePii: boolean): T {
  if (canSeePii) return row;
  const out: Record<string, any> = { ...row };
  if ('mobile' in out) out.mobile = maskMobile(out.mobile);
  if ('pan' in out) out.pan = maskPan(out.pan);
  if ('email' in out) out.email = maskEmail(out.email);
  if ('dateOfBirth' in out && out.dateOfBirth) out.dateOfBirth = `${String(out.dateOfBirth).slice(0, 4)}-XX-XX`;
  if ('addressLine' in out && out.addressLine) out.addressLine = '[masked]';
  return out as T;
}
