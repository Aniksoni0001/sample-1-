export class AppError extends Error {
  constructor(
    public status: number,
    message: string,
    public code = 'ERROR',
    public details?: unknown,
  ) {
    super(message);
  }
}

export const badRequest = (msg: string, details?: unknown) => new AppError(400, msg, 'BAD_REQUEST', details);
export const unauthorized = (msg = 'Authentication required') => new AppError(401, msg, 'UNAUTHORIZED');
export const forbidden = (msg = 'You do not have permission to do this') => new AppError(403, msg, 'FORBIDDEN');
export const notFound = (what = 'Resource') => new AppError(404, `${what} not found`, 'NOT_FOUND');
export const conflict = (msg: string) => new AppError(409, msg, 'CONFLICT');

/** Maps PostgreSQL errors (incl. our custom CWxxx SQLSTATEs) to HTTP errors. */
export function fromPgError(err: any): AppError | null {
  if (!err || typeof err.code !== 'string') return null;
  const msg: string = err.message ?? 'Database error';
  switch (err.code) {
    case 'CW400':
      return new AppError(400, msg, 'VALIDATION');
    case 'CW404':
      return new AppError(404, msg, 'NOT_FOUND');
    case 'CW409':
      return new AppError(409, msg, 'CONFLICT');
    case '23505': {
      const c = String(err.constraint ?? '');
      const friendly: Record<string, string> = {
        ux_payments_txn_ref: 'A payment with this transaction reference already exists',
        ux_customers_pan: 'A customer with this PAN already exists',
        ux_users_email: 'A user with this email already exists',
        ux_assignment_active: 'This loan is already assigned to an executive',
      };
      return new AppError(409, friendly[c] ?? 'Duplicate record', 'DUPLICATE', { constraint: c });
    }
    case '23503':
      return new AppError(400, 'Referenced record does not exist or is still in use', 'FOREIGN_KEY', {
        constraint: err.constraint,
      });
    case '23514':
      return new AppError(400, `Value violates rule ${err.constraint ?? ''}`.trim(), 'CHECK', {
        constraint: err.constraint,
      });
    case '22P02':
    case '22007':
    case '22008':
      return new AppError(400, 'Invalid value format', 'INVALID_FORMAT');
    case '40001':
    case '40P01':
    case '55P03':
      return new AppError(503, 'The record is busy, please retry', 'RETRY');
    default:
      return null;
  }
}
