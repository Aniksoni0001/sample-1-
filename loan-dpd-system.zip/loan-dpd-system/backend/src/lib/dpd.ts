/**
 * Pure DPD rules — a TypeScript mirror of fn_calc_dpd / fn_dpd_bucket / vw_par_summary
 * used by unit tests and documentation. The database is the system of record.
 */

export function daysBetween(fromIso: string, toIso: string): number {
  const a = Date.UTC(+fromIso.slice(0, 4), +fromIso.slice(5, 7) - 1, +fromIso.slice(8, 10));
  const b = Date.UTC(+toIso.slice(0, 4), +toIso.slice(5, 7) - 1, +toIso.slice(8, 10));
  return Math.round((b - a) / 86_400_000);
}

/** DPD = business date − due date of the oldest unpaid installment (0 within grace / when nothing is past due). */
export function calcDpd(businessDate: string, oldestUnpaidDue: string | null, graceDays = 0): number {
  if (!oldestUnpaidDue || oldestUnpaidDue >= businessDate) return 0;
  const raw = daysBetween(oldestUnpaidDue, businessDate);
  return raw <= graceDays ? 0 : raw;
}

export interface InstallmentState {
  dueDate: string;
  remaining: number; // emi − paid − waived
}

/** Oldest installment that is past due and not fully paid. Future installments never count. */
export function oldestUnpaidDue(installments: InstallmentState[], businessDate: string): string | null {
  let oldest: string | null = null;
  for (const i of installments) {
    if (i.remaining > 0 && i.dueDate < businessDate && (oldest === null || i.dueDate < oldest)) oldest = i.dueDate;
  }
  return oldest;
}

export function accountDpd(installments: InstallmentState[], businessDate: string, graceDays = 0): number {
  return calcDpd(businessDate, oldestUnpaidDue(installments, businessDate), graceDays);
}

export interface BucketDef {
  code: string;
  minDpd: number;
  maxDpd: number | null;
  sortOrder: number;
}

export const DEFAULT_BUCKETS: BucketDef[] = [
  { code: 'CURRENT', minDpd: 0, maxDpd: 0, sortOrder: 1 },
  { code: 'B1_30', minDpd: 1, maxDpd: 30, sortOrder: 2 },
  { code: 'B31_60', minDpd: 31, maxDpd: 60, sortOrder: 3 },
  { code: 'B61_89', minDpd: 61, maxDpd: 89, sortOrder: 4 },
  { code: 'B90P', minDpd: 90, maxDpd: null, sortOrder: 5 },
];

export function bucketFor(dpd: number, buckets: BucketDef[] = DEFAULT_BUCKETS): BucketDef {
  const b = [...buckets]
    .sort((x, y) => x.sortOrder - y.sortOrder)
    .find((k) => dpd >= k.minDpd && (k.maxDpd === null || dpd <= k.maxDpd));
  if (!b) throw new Error(`No DPD bucket configured for DPD ${dpd}`);
  return b;
}

/** Validates a bucket configuration: contiguous from 0, no gaps/overlaps, last bucket open-ended. */
export function validateBuckets(buckets: BucketDef[]): string | null {
  const s = [...buckets].sort((a, b) => a.minDpd - b.minDpd);
  if (!s.length) return 'At least one bucket is required';
  if (s[0].minDpd !== 0) return 'The first bucket must start at 0 DPD';
  for (let i = 0; i < s.length; i++) {
    const cur = s[i];
    if (cur.maxDpd !== null && cur.maxDpd < cur.minDpd) return `Bucket ${cur.code}: max is below min`;
    if (i < s.length - 1) {
      if (cur.maxDpd === null) return `Only the last bucket may be open-ended (${cur.code})`;
      if (s[i + 1].minDpd !== cur.maxDpd + 1) return `Gap or overlap between ${cur.code} and ${s[i + 1].code}`;
    } else if (cur.maxDpd !== null) return 'The last bucket must be open-ended (no max DPD)';
  }
  return null;
}

/** PAR-N = POS of accounts with DPD > N ÷ total POS (percent, 2 dp). */
export function parPct(accounts: { dpd: number; pos: number }[], n: number): number {
  const total = accounts.reduce((s, a) => s + a.pos, 0);
  if (total === 0) return 0;
  const risk = accounts.filter((a) => a.dpd > n).reduce((s, a) => s + a.pos, 0);
  return Math.round((risk * 10000) / total) / 100;
}
