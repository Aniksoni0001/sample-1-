import type { Ctx } from './http.js';
import { forbidden } from './errors.js';
import { paginate, type ListQuery, type Sql } from './sql.js';
import { sendExport, type Column } from './export.js';
import { maskRow } from './mask.js';
import { query, type DbContext } from '../db/pool.js';

export async function audit(db: DbContext, action: string, entityType: string, entityId: string | number | null, values?: unknown) {
  await query(
    `INSERT INTO audit_logs (user_id, action, entity_type, entity_id, new_values, ip, request_id) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [db.userId ?? null, action, entityType, entityId === null ? null : String(entityId), values ? JSON.stringify(values) : null, db.ip ?? null, db.requestId ?? null],
  );
}

/**
 * Standard list response: paginated JSON, or (format=csv|xlsx|pdf) a file of
 * every matching row. Exports need reports.export, are audited, and PII is
 * masked for users without customers.pii.
 */
export async function respondList(
  ctx: Ctx<any, ListQuery & Record<string, any>, any>,
  opts: { select: string; from: string; sql: Sql; order: string; columns: Column[]; title: string; pii?: boolean },
) {
  const q = ctx.query;
  const canPii = !opts.pii || ctx.can('customers.pii');
  if (q.format && q.format !== 'json') {
    if (!ctx.can('reports.export')) throw forbidden('Export permission required');
    const page = await paginate({ ...opts, page: 1, pageSize: q.pageSize, all: true });
    const rows = page.data.map((r) => maskRow(r, canPii));
    const { page: _p, pageSize: _s, format: _f, ...filters } = q;
    await audit(ctx.db, 'EXPORT', opts.title, null, { format: q.format, rows: rows.length, filters });
    const stamp = new Date().toISOString().slice(0, 10);
    await sendExport(ctx.res, q.format, `${opts.title}_${stamp}`, opts.title, opts.columns, rows, [
      `Generated ${new Date().toISOString().replace('T', ' ').slice(0, 19)} UTC by ${ctx.user.fullName}`,
      Object.keys(filters).length ? `Filters: ${JSON.stringify(filters)}` : 'Filters: none',
    ]);
    return;
  }
  const page = await paginate({ ...opts, page: q.page, pageSize: q.pageSize });
  ctx.res.json({ ...page, data: page.data.map((r) => maskRow(r, canPii)) });
}
