import { z } from 'zod';
import type { Db } from '../db/pool.js';
import { query } from '../db/pool.js';

/** Parameterised WHERE builder — values are always bound, never concatenated. */
export class Sql {
  clauses: string[] = [];
  params: unknown[] = [];
  constructor(initial: unknown[] = []) {
    this.params = [...initial];
  }
  /** register a bind value and return its placeholder */
  p(v: unknown): string {
    this.params.push(v);
    return `$${this.params.length}`;
  }
  and(clause: string): this {
    this.clauses.push(clause);
    return this;
  }
  get where(): string {
    return this.clauses.length ? `WHERE ${this.clauses.join(' AND ')}` : '';
  }
}

export const listQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(500).default(25),
  sort: z.string().max(64).optional(),
  order: z.enum(['asc', 'desc']).default('desc'),
  search: z.string().trim().max(100).optional(),
  format: z.enum(['json', 'csv', 'xlsx', 'pdf']).default('json'),
});
export type ListQuery = z.infer<typeof listQuerySchema>;

/** Sort columns come from a whitelist map → SQL injection through ORDER BY is impossible. */
export function orderBy(q: { sort?: string; order?: 'asc' | 'desc' }, allowed: Record<string, string>, fallback: string) {
  const col = q.sort && allowed[q.sort];
  if (!col) return `ORDER BY ${fallback}`;
  return `ORDER BY ${col} ${q.order === 'asc' ? 'ASC' : 'DESC'} NULLS LAST, 1`;
}

export interface Page<T> {
  data: T[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export const EXPORT_ROW_LIMIT = 50_000;

export async function paginate<T = any>(
  opts: { select: string; from: string; sql: Sql; order: string; page: number; pageSize: number; all?: boolean },
  db?: Db,
): Promise<Page<T>> {
  const { select, from, sql, order } = opts;
  const countRow = await query<{ n: number }>(`SELECT count(*)::int AS n FROM ${from} ${sql.where}`, sql.params, db);
  const total = countRow[0]?.n ?? 0;
  const pageSize = opts.all ? EXPORT_ROW_LIMIT : opts.pageSize;
  const page = opts.all ? 1 : opts.page;
  const limitP = `$${sql.params.length + 1}`;
  const offsetP = `$${sql.params.length + 2}`;
  const data = await query<T>(
    `SELECT ${select} FROM ${from} ${sql.where} ${order} LIMIT ${limitP} OFFSET ${offsetP}`,
    [...sql.params, pageSize, (page - 1) * pageSize],
    db,
  );
  return { data, page, pageSize, total, totalPages: Math.max(1, Math.ceil(total / pageSize)) };
}

export const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD');
export const money = z.coerce
  .number()
  .positive()
  .refine((v) => Math.round(v * 100) === Number((v * 100).toFixed(6)), 'At most 2 decimal places');
export const idParam = z.object({ id: z.coerce.number().int().positive() });
