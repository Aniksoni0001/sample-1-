import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import type { Response } from 'express';

export type ColType = 'text' | 'money' | 'number' | 'date' | 'pct';
export interface Column {
  key: string;
  label: string;
  type?: ColType;
}

/**
 * Neutralise spreadsheet formula injection: cells starting with = + - @ (or tab/CR)
 * are prefixed with an apostrophe so Excel/Sheets treat them as text.
 */
export function safeCell(v: unknown): string {
  if (v === null || v === undefined) return '';
  const s = v instanceof Date ? v.toISOString() : String(v);
  return /^[=+\-@\t\r]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s) ? `'${s}` : s;
}

export function toCsv(columns: Column[], rows: Record<string, unknown>[]): string {
  const esc = (v: unknown) => {
    const s = safeCell(v);
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [columns.map((c) => esc(c.label)).join(',')];
  for (const r of rows) lines.push(columns.map((c) => esc(r[c.key])).join(','));
  return '﻿' + lines.join('\r\n'); // BOM so Excel opens UTF-8 (₹, names) correctly
}

export async function toXlsx(title: string, columns: Column[], rows: Record<string, unknown>[], meta: string[] = []) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Loan Collections & DPD System';
  const ws = wb.addWorksheet(title.slice(0, 31));
  ws.addRow([title]).font = { bold: true, size: 14 };
  for (const m of meta) ws.addRow([m]).font = { italic: true, color: { argb: 'FF64748B' } };
  ws.addRow([]);
  const header = ws.addRow(columns.map((c) => c.label));
  header.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  header.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A8A' } };
  });
  const headerRowNo = header.number;
  for (const r of rows) {
    ws.addRow(
      columns.map((c) => {
        const v = r[c.key];
        if (v === null || v === undefined) return null;
        if (c.type === 'money' || c.type === 'number' || c.type === 'pct') return typeof v === 'number' ? v : Number(v);
        return safeCell(v);
      }),
    );
  }
  columns.forEach((c, i) => {
    const col = ws.getColumn(i + 1);
    col.width = Math.min(40, Math.max(c.label.length + 2, 12));
    if (c.type === 'money') col.numFmt = '#,##,##0.00';
    if (c.type === 'pct') col.numFmt = '0.00"%"';
  });
  ws.views = [{ state: 'frozen', ySplit: headerRowNo }];
  ws.autoFilter = { from: { row: headerRowNo, column: 1 }, to: { row: headerRowNo, column: columns.length } };
  return Buffer.from(await wb.xlsx.writeBuffer());
}

const fmt = (v: unknown, t?: ColType) => {
  if (v === null || v === undefined || v === '') return '';
  if (t === 'money') return Number(v).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (t === 'pct') return `${Number(v).toFixed(2)}%`;
  if (v instanceof Date) return v.toISOString().slice(0, 19).replace('T', ' ');
  return String(v);
};

export function toPdf(title: string, columns: Column[], rows: Record<string, unknown>[], meta: string[] = []) {
  return new Promise<Buffer>((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', layout: 'landscape', margin: 30 });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const usable = doc.page.width - 60;
    const width = usable / columns.length;
    const fontSize = columns.length > 10 ? 6 : columns.length > 7 ? 7 : 8;

    doc.fontSize(14).fillColor('#1e3a8a').text(title);
    doc.fontSize(8).fillColor('#64748b');
    for (const m of meta) doc.text(m);
    doc.moveDown(0.5);

    const drawHeader = () => {
      const y = doc.y;
      doc.rect(30, y - 2, usable, fontSize + 8).fill('#1e3a8a');
      doc.fillColor('#ffffff').fontSize(fontSize);
      columns.forEach((c, i) => doc.text(c.label, 32 + i * width, y + 1, { width: width - 4, lineBreak: false, ellipsis: true }));
      doc.y = y + fontSize + 8;
    };
    drawHeader();
    rows.forEach((r, idx) => {
      if (doc.y > doc.page.height - 45) {
        doc.addPage();
        drawHeader();
      }
      const y = doc.y;
      if (idx % 2 === 0) doc.rect(30, y - 1, usable, fontSize + 5).fill('#f1f5f9');
      doc.fillColor('#0f172a').fontSize(fontSize);
      columns.forEach((c, i) => {
        const right = c.type === 'money' || c.type === 'number' || c.type === 'pct';
        doc.text(fmt(r[c.key], c.type), 32 + i * width, y + 1, {
          width: width - 6,
          lineBreak: false,
          ellipsis: true,
          align: right ? 'right' : 'left',
        });
      });
      doc.y = y + fontSize + 5;
    });
    doc.moveDown().fontSize(7).fillColor('#64748b').text(`${rows.length} row(s). Confidential — internal use only.`, 30);
    doc.end();
  });
}

export async function sendExport(
  res: Response,
  format: 'csv' | 'xlsx' | 'pdf',
  fileBase: string,
  title: string,
  columns: Column[],
  rows: Record<string, unknown>[],
  meta: string[] = [],
) {
  const safeName = fileBase.replace(/[^a-z0-9_-]+/gi, '_');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  if (format === 'csv') {
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}.csv"`);
    res.send(toCsv(columns, rows));
  } else if (format === 'xlsx') {
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}.xlsx"`);
    res.send(await toXlsx(title, columns, rows, meta));
  } else {
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}.pdf"`);
    res.send(await toPdf(title, columns, rows, meta));
  }
}
