import { pino } from 'pino';
import { env, isProd } from '../config/env.js';

// Secrets and customer PII are redacted from every log line.
export const logger = pino({
  level: env.NODE_ENV === 'test' ? 'silent' : env.LOG_LEVEL,
  redact: {
    paths: [
      'req.headers.authorization',
      'req.headers.cookie',
      'res.headers["set-cookie"]',
      '*.password',
      '*.newPassword',
      '*.currentPassword',
      '*.token',
      '*.refreshToken',
      '*.pan',
      '*.aadhaar',
      '*.aadhaarLast4',
      '*.mobile',
      '*.email',
      'password',
      'token',
    ],
    censor: '[REDACTED]',
  },
  transport: isProd || env.NODE_ENV === 'test' ? undefined : { target: 'pino-pretty', options: { singleLine: true } },
});
