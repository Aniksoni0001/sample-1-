import nodemailer from 'nodemailer';
import { mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { env, isProd } from '../config/env.js';
import { logger } from './logger.js';

/**
 * With SMTP configured, mail is sent normally. Without it (local development only),
 * messages are written to ./.dev-outbox so the reset flow can be tested; nothing
 * sensitive is ever written to the logs.
 */
export async function sendMail(to: string, subject: string, text: string) {
  if (env.SMTP_HOST) {
    const transport = nodemailer.createTransport({
      host: env.SMTP_HOST,
      port: env.SMTP_PORT ?? 587,
      auth: env.SMTP_USER ? { user: env.SMTP_USER, pass: env.SMTP_PASS } : undefined,
    });
    await transport.sendMail({ from: env.MAIL_FROM, to, subject, text });
    return;
  }
  if (isProd) {
    logger.error('SMTP is not configured; email was not sent');
    return;
  }
  const dir = path.resolve(process.cwd(), '.dev-outbox');
  mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${Date.now()}-${subject.replace(/\W+/g, '_')}.txt`);
  writeFileSync(file, `To: ${to}\nSubject: ${subject}\n\n${text}\n`, { mode: 0o600 });
  logger.info({ file: path.basename(file) }, 'Dev mail written to .dev-outbox');
}
