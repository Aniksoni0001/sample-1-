/**
 * CLI for ops / external schedulers (e.g. Kubernetes CronJob, systemd timer):
 *   npm run dpd:run                 → today in the business timezone
 *   npm run dpd:run -- 2026-11-04   → a specific business date
 * Exit code 0 on success, 1 on failure.
 */
import { pool } from '../db/pool.js';
import { runDailyDpd } from '../modules/dpd.js';

const date = process.argv[2] ?? null;
if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
  console.error('Usage: dpd:run [YYYY-MM-DD]');
  process.exit(2);
}
runDailyDpd(date, 'MANUAL', null)
  .then(async (r) => {
    console.log(JSON.stringify({ jobId: r.jobId, status: r.status, job: r.job }, null, 2));
    await pool.end();
    process.exit(r.status === 'SUCCESS' ? 0 : 1);
  })
  .catch(async (e) => {
    console.error(e.message);
    await pool.end();
    process.exit(1);
  });
