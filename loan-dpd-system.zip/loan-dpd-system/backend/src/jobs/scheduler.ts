import cron, { type ScheduledTask } from 'node-cron';
import { one, query } from '../db/pool.js';
import { logger } from '../lib/logger.js';

let task: ScheduledTask | null = null;
let running = false;

const addDays = (iso: string, n: number) => {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};

/**
 * Scheduled run: processes every business date from the day after the last
 * successful run up to today (business timezone), so a server that was down
 * catches up instead of leaving gaps in the snapshot history. Stops at the first failure.
 */
export async function scheduledDpdRun() {
  if (running) return;
  running = true;
  try {
    const { runDailyDpd } = await import('../modules/dpd.js');
    const meta = await one<{ today: string; last: string | null }>(
      `SELECT fn_calendar_today()::text AS today,
              (SELECT max(business_date)::text FROM job_execution_logs WHERE job_name='DAILY_DPD' AND status='SUCCESS') AS last`,
    );
    if (!meta) return;
    let date = meta.last ? addDays(meta.last, 1) : meta.today;
    if (meta.last && meta.last >= meta.today) date = meta.today; // already ran today → idempotent re-run is harmless
    let guard = 0;
    while (date <= meta.today && guard++ < 62) {
      const r = await runDailyDpd(date, 'SCHEDULED', null);
      logger.info({ businessDate: date, status: r.status, jobId: r.jobId }, 'Scheduled DPD run');
      if (r.status !== 'SUCCESS') break;
      await notifyDueToday(date);
      date = addDays(date, 1);
    }
  } catch (e) {
    logger.error({ err: e }, 'Scheduled DPD run crashed');
  } finally {
    running = false;
  }
}

/** Tell executives about follow-ups and promises falling due on the business date. */
export async function notifyDueToday(businessDate: string) {
  await query(
    `INSERT INTO notifications (user_id, type, title, message, link)
     SELECT x.executive_id, 'FOLLOW_UP', 'Follow-ups due today',
            x.n || ' follow-up(s) / promise(s) due on ' || $1, '/collections'
       FROM (SELECT executive_id, count(*) AS n FROM (
               SELECT executive_id FROM collection_activities WHERE next_follow_up_date = $1::date
               UNION ALL
               SELECT executive_id FROM promise_to_pay WHERE promised_date = $1::date AND status = 'PENDING') q
             GROUP BY executive_id) x`,
    [businessDate],
  );
}

export async function startScheduler() {
  const s = await one<{ cron: string; enabled: string; tz: string }>(
    `SELECT fn_setting('dpd_job_cron') AS cron, fn_setting('dpd_job_enabled') AS enabled, fn_setting('business_timezone') AS tz`,
  );
  task?.stop();
  task = null;
  if (!s || s.enabled !== 'true') {
    logger.info('Daily DPD scheduler is disabled');
    return;
  }
  if (!cron.validate(s.cron)) {
    logger.error({ cron: s.cron }, 'Invalid dpd_job_cron; scheduler not started');
    return;
  }
  task = cron.schedule(s.cron, () => void scheduledDpdRun(), { timezone: s.tz || 'Asia/Kolkata', name: 'daily-dpd', noOverlap: true });
  logger.info({ cron: s.cron, tz: s.tz }, 'Daily DPD scheduler started');
}

export function stopScheduler() {
  task?.stop();
  task = null;
}

export function nextScheduledRun(): string | null {
  try {
    const d = (task as any)?.getNextRun?.();
    return d ? new Date(d).toISOString() : null;
  } catch {
    return null;
  }
}
