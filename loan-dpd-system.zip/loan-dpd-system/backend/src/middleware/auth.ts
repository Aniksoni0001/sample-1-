import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { one, query } from '../db/pool.js';
import { unauthorized } from '../lib/errors.js';

export interface AuthUser {
  id: number;
  email: string;
  fullName: string;
  role: string;
  roleName: string;
  branchId: number | null;
  permissions: Set<string>;
}

interface TokenClaims {
  sub: string;
  sid: number;
  iat: number;
}

// Tiny cache so every request doesn't re-read the role/permission tables.
// Short TTL keeps deactivation and permission edits effective within seconds.
const cache = new Map<number, { user: AuthUser; pwdChanged: number; at: number }>();
const CACHE_MS = 10_000;
export const invalidateUserCache = (id?: number) => (id ? cache.delete(id) : cache.clear());

export async function loadUser(id: number) {
  const hit = cache.get(id);
  if (hit && Date.now() - hit.at < CACHE_MS) return hit;
  const row = await one<any>(
    `SELECT u.id, u.email, u.full_name, u.branch_id, u.is_active, u.deleted_at, u.password_changed_at,
            r.code AS role, r.name AS role_name
       FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1`,
    [id],
  );
  if (!row || !row.isActive || row.deletedAt) {
    cache.delete(id);
    return null;
  }
  const perms = await query<{ code: string }>(
    `SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id
       JOIN users u ON u.role_id = rp.role_id WHERE u.id = $1`,
    [id],
  );
  const entry = {
    user: {
      id: row.id,
      email: row.email,
      fullName: row.fullName,
      role: row.role,
      roleName: row.roleName,
      branchId: row.branchId,
      permissions: new Set(perms.map((p) => p.code)),
    },
    pwdChanged: Math.floor(new Date(row.passwordChangedAt).getTime() / 1000),
    at: Date.now(),
  };
  cache.set(id, entry);
  return entry;
}

export function signAccessToken(userId: number, sessionId: number) {
  return jwt.sign({ sid: sessionId }, env.JWT_SECRET, {
    subject: String(userId),
    expiresIn: env.JWT_ACCESS_TTL as jwt.SignOptions['expiresIn'],
    algorithm: 'HS256',
  });
}

export async function authenticate(req: Request, _res: Response, next: NextFunction) {
  try {
    const header = req.headers.authorization;
    if (!header?.startsWith('Bearer ')) throw unauthorized();
    let claims: TokenClaims;
    try {
      claims = jwt.verify(header.slice(7), env.JWT_SECRET, { algorithms: ['HS256'] }) as unknown as TokenClaims;
    } catch (e) {
      throw unauthorized((e as Error).name === 'TokenExpiredError' ? 'Session expired' : 'Invalid token');
    }
    const entry = await loadUser(Number(claims.sub));
    if (!entry) throw unauthorized('Account is inactive');
    // tokens issued before a password change are no longer valid
    if (claims.iat + 1 < entry.pwdChanged) throw unauthorized('Session expired');
    (req as any).user = entry.user;
    (req as any).sessionId = claims.sid;
    next();
  } catch (e) {
    next(e);
  }
}

/** Collection executives only see loans assigned to them. Returns null when unrestricted. */
export function executiveScope(user: AuthUser): number | null {
  return user.role === 'COLLECTION_EXECUTIVE' ? user.id : null;
}
