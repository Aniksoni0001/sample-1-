import type { NextFunction, Request, Response } from 'express';
import { createHash } from 'node:crypto';
import { one, query } from '../db/pool.js';
import { AppError } from '../lib/errors.js';

/**
 * Idempotency-Key support for state-changing financial endpoints.
 *  - first request with a key: processed normally; the response is stored
 *  - repeat with same key + same payload: the stored response is replayed
 *  - same key + different payload: 422
 *  - repeat while the first is still running: 409
 * Failed (non-2xx) attempts release the key so a corrected retry is possible.
 */
export async function idempotency(req: Request, res: Response, next: NextFunction) {
  const header = req.header('Idempotency-Key');
  if (!header) return next();
  try {
    if (!/^[A-Za-z0-9_\-:.]{8,128}$/.test(header)) throw new AppError(400, 'Invalid Idempotency-Key header');
    const userId = (req as any).user?.id ?? 0;
    const key = `${userId}:${req.method}:${req.baseUrl}${req.path}:${header}`;
    const hash = createHash('sha256').update(JSON.stringify(req.body ?? {})).digest('hex');
    (req as any).idempotencyKey = header;

    const inserted = await one(
      `INSERT INTO idempotency_keys (key, user_id, request_hash) VALUES ($1, $2, $3)
       ON CONFLICT (key) DO NOTHING RETURNING key`,
      [key, userId, hash],
    );
    if (!inserted) {
      const prev = await one<any>('SELECT request_hash, status_code, response_body FROM idempotency_keys WHERE key = $1', [key]);
      if (prev?.requestHash !== hash) throw new AppError(422, 'Idempotency-Key was already used with a different request');
      if (prev?.statusCode == null) throw new AppError(409, 'An identical request is still being processed');
      res.setHeader('Idempotent-Replayed', 'true');
      res.status(prev.statusCode).json(prev.responseBody);
      return;
    }

    let body: unknown;
    const json = res.json.bind(res);
    res.json = (b: unknown) => {
      body = b;
      return json(b);
    };
    res.on('finish', () => {
      const ok = res.statusCode >= 200 && res.statusCode < 300;
      const op = ok
        ? query('UPDATE idempotency_keys SET status_code = $2, response_body = $3 WHERE key = $1', [key, res.statusCode, JSON.stringify(body ?? null)])
        : query('DELETE FROM idempotency_keys WHERE key = $1', [key]);
      op.catch(() => undefined);
    });
    next();
  } catch (e) {
    next(e);
  }
}
