import type { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import { AppError, fromPgError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';

/** One error shape for every endpoint: { error: { code, message, details?, requestId } } */
export function errorHandler(err: any, req: Request, res: Response, _next: NextFunction) {
  const requestId = (req as any).id;
  let appErr: AppError;
  if (err instanceof AppError) appErr = err;
  else if (err instanceof ZodError) {
    appErr = new AppError(
      400,
      'Validation failed',
      'VALIDATION',
      err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
    );
  } else if (err?.type === 'entity.parse.failed') appErr = new AppError(400, 'Malformed JSON body', 'BAD_JSON');
  else if (err?.type === 'entity.too.large') appErr = new AppError(413, 'Request body too large', 'TOO_LARGE');
  else if (err?.code === 'LIMIT_FILE_SIZE') appErr = new AppError(413, 'File too large', 'TOO_LARGE');
  else appErr = fromPgError(err) ?? new AppError(500, 'Internal server error', 'INTERNAL');

  if (appErr.status >= 500) logger.error({ err, requestId, path: req.path }, 'Unhandled error');
  else logger.debug({ requestId, code: appErr.code, msg: appErr.message }, 'Request error');

  if (res.headersSent) return;
  res.status(appErr.status).json({
    error: { code: appErr.code, message: appErr.message, details: appErr.details, requestId },
  });
}

export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({ error: { code: 'NOT_FOUND', message: `No route ${req.method} ${req.path}` } });
}
