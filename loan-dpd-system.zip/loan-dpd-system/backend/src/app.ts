import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { rateLimit } from 'express-rate-limit';
import { pinoHttp } from 'pino-http';
import swaggerUi from 'swagger-ui-express';
import { randomUUID } from 'node:crypto';
import { env } from './config/env.js';
import { logger } from './lib/logger.js';
import { pool } from './db/pool.js';
import { errorHandler, notFoundHandler } from './middleware/error.js';
import { router as auth } from './modules/auth.js';
import { router as customers } from './modules/customers.js';
import { router as loans } from './modules/loans.js';
import { router as emi } from './modules/emi.js';
import { router as payments } from './modules/payments.js';
import { router as bounces } from './modules/bounces.js';
import { router as dpd } from './modules/dpd.js';
import { router as collections } from './modules/collections.js';
import { router as dashboard } from './modules/dashboard.js';
import { router as reports } from './modules/reports.js';
import { router as admin } from './modules/admin.js';
import { buildOpenApi } from './openapi.js';

export function createApp() {
  const app = express();
  app.set('trust proxy', env.TRUST_PROXY);
  app.disable('x-powered-by');

  app.use((req, res, next) => {
    const id = (req.header('x-request-id') ?? '').slice(0, 64) || randomUUID();
    (req as any).id = id;
    res.setHeader('X-Request-Id', id);
    next();
  });
  app.use(
    pinoHttp({
      logger,
      genReqId: (req) => (req as any).id,
      autoLogging: { ignore: (req) => req.url === '/api/health' },
      serializers: { req: (r) => ({ id: r.id, method: r.method, url: r.url }), res: (r) => ({ statusCode: r.statusCode }) },
    }),
  );
  app.use(
    helmet({
      contentSecurityPolicy: {
        // swagger-ui needs inline styles/scripts on /api/docs only
        directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'"], styleSrc: ["'self'", "'unsafe-inline'"], imgSrc: ["'self'", 'data:'] },
      },
      crossOriginEmbedderPolicy: false,
    }),
  );
  app.use(
    cors({
      origin: env.CORS_ORIGIN.split(',').map((s) => s.trim()),
      credentials: true,
      exposedHeaders: ['Content-Disposition', 'X-Request-Id', 'Idempotent-Replayed'],
    }),
  );
  app.use(express.json({ limit: '1mb' }));
  app.use(cookieParser());
  app.use(
    '/api',
    rateLimit({
      windowMs: 60_000,
      limit: env.NODE_ENV === 'test' ? 100_000 : 600,
      standardHeaders: 'draft-7',
      legacyHeaders: false,
      message: { error: { code: 'RATE_LIMITED', message: 'Too many requests' } },
    }),
  );

  app.get('/api/health', async (_req, res) => {
    try {
      const r = await pool.query(`SELECT fn_business_date()::text AS business_date`);
      res.json({ status: 'ok', db: 'up', businessDate: r.rows[0].business_date });
    } catch {
      res.status(503).json({ status: 'degraded', db: 'down' });
    }
  });

  for (const r of [auth, customers, loans, emi, payments, bounces, dpd, collections, dashboard, reports, admin]) app.use(r);

  const spec = buildOpenApi();
  app.get('/api/openapi.json', (_req, res) => res.json(spec));
  app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(spec, { customSiteTitle: 'Loan DPD API' }));

  app.use('/api', notFoundHandler);
  app.use(errorHandler);
  return app;
}
