import { Router } from 'express';
import multer from 'multer';
import { parse } from 'csv-parse/sync';
import PDFDocument from 'pdfkit';
import { z } from 'zod';
import { dryRun, one, query, tx } from '../db/pool.js';
import { badRequest, fromPgError, notFound } from '../lib/errors.js';
import { route } from '../lib/http.js';
import { audit, respondList } from '../lib/listing.js';
import { idParam, isoDate, listQuerySchema, money, orderBy, Sql } from '../lib/sql.js';
import { executiveScope } from '../middleware/auth.js';
import { assertLoanAccess } from './loans.js';

export const router = Router();
const BASE = '/api/payments';
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024, files: 1 } });

const MODES = ['UPI', 'NEFT', 'RTGS', 'IMPS', 'CASH', 'CHEQUE', 'NACH', 'OTHER'] as const;
const STATUSES = ['INITIATED', 'PENDING', 'SUCCESSFUL', 'FAILED', 'REVERSED'] as const;

const listQuery = listQuerySchema.extend({
  status: z.enum(STATUSES).optional(),
  mode: z.enum(MODES).optional(),
  dateFrom: isoDate.optional(),
  dateTo: isoDate.optional(),
  loanId: z.coerce.number().int().optional(),
  collectedBy: z.coerce.number().int().optional(),
  source: z.enum(['MANUAL', 'CSV_IMPORT', 'SYSTEM']).optional(),
});

const SELECT = `p.id, p.payment_number, p.loan_id, l.loan_number, l.customer_id, c.customer_code, c.full_name AS customer_name,
  p.emi_schedule_id, p.payment_date, p.amount, p.payment_mode, p.transaction_reference, p.status, p.collected_by,
  u.full_name AS collected_by_name, p.remarks, p.source, p.created_at`;
const FROM = `payments p JOIN loans l ON l.id = p.loan_id JOIN customers c ON c.id = l.customer_id LEFT JOIN users u ON u.id = p.collected_by`;

route(router, BASE, {
  method: 'get',
  path: '',
  tag: 'Payments',
  summary: 'Payment register (format=csv|xlsx|pdf to export)',
  permission: 'payments.read',
  query: listQuery,
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    if (q.search) {
      const s = sql.p(`%${q.search}%`);
      sql.and(`(p.payment_number ILIKE ${s} OR p.transaction_reference ILIKE ${s} OR l.loan_number ILIKE ${s} OR c.full_name ILIKE ${s})`);
    }
    if (q.status) sql.and(`p.status = ${sql.p(q.status)}`);
    if (q.mode) sql.and(`p.payment_mode = ${sql.p(q.mode)}`);
    if (q.dateFrom) sql.and(`p.payment_date >= ${sql.p(q.dateFrom)}`);
    if (q.dateTo) sql.and(`p.payment_date <= ${sql.p(q.dateTo)}`);
    if (q.loanId) sql.and(`p.loan_id = ${sql.p(q.loanId)}`);
    if (q.collectedBy) sql.and(`p.collected_by = ${sql.p(q.collectedBy)}`);
    if (q.source) sql.and(`p.source = ${sql.p(q.source)}`);
    const exec = executiveScope(ctx.user);
    if (exec)
      sql.and(`EXISTS (SELECT 1 FROM collection_assignments a WHERE a.loan_id = p.loan_id AND a.is_active AND a.executive_id = ${sql.p(exec)})`);
    await respondList(ctx, {
      select: SELECT,
      from: FROM,
      sql,
      order: orderBy(
        q,
        { paymentNumber: 'p.payment_number', paymentDate: 'p.payment_date', amount: 'p.amount', status: 'p.status', paymentMode: 'p.payment_mode', loanNumber: 'l.loan_number', customerName: 'c.full_name', createdAt: 'p.created_at' },
        'p.payment_date DESC, p.id DESC',
      ),
      title: 'Payment Transactions',
      columns: [
        { key: 'paymentNumber', label: 'Payment ID' },
        { key: 'paymentDate', label: 'Date', type: 'date' },
        { key: 'loanNumber', label: 'Loan ID' },
        { key: 'customerName', label: 'Customer' },
        { key: 'amount', label: 'Amount', type: 'money' },
        { key: 'paymentMode', label: 'Mode' },
        { key: 'transactionReference', label: 'Txn Ref' },
        { key: 'status', label: 'Status' },
        { key: 'collectedByName', label: 'Collected By' },
        { key: 'source', label: 'Source' },
      ],
    });
  },
});

const paymentBody = z
  .object({
    loanId: z.coerce.number().int().positive(),
    amount: money,
    paymentDate: isoDate,
    paymentMode: z.enum(MODES),
    transactionReference: z.string().trim().max(64).optional().nullable(),
    status: z.enum(['SUCCESSFUL', 'PENDING', 'INITIATED']).default('SUCCESSFUL'),
    collectedBy: z.coerce.number().int().positive().optional().nullable(),
    emiScheduleId: z.coerce.number().int().positive().optional().nullable(),
    remarks: z.string().trim().max(500).optional().nullable(),
  })
  .refine((b) => b.paymentMode === 'CASH' || !!b.transactionReference, {
    message: 'Transaction reference is required for non-cash payments',
    path: ['transactionReference'],
  });

route(router, BASE, {
  method: 'post',
  path: '/preview',
  tag: 'Payments',
  summary: 'Dry run: shows exactly how a payment would be allocated (runs the real procedure and rolls back)',
  permission: 'payments.write',
  status: 200,
  body: paymentBody,
  handler: async ({ body, user, db }) => {
    await assertLoanAccess(user, body.loanId);
    try {
      return await dryRun(db, async (c) => {
        const r = await one<{ id: number }>(
          `SELECT sp_process_payment($1, $2, $3::date, $4, NULL, 'SUCCESSFUL', NULL, NULL, $5, NULL, 'MANUAL', $6) AS id`,
          [body.loanId, body.amount, body.paymentDate, body.paymentMode, body.emiScheduleId ?? null, user.id],
          c,
        );
        const allocations = await query(
          `SELECT a.component, a.amount, a.is_advance, e.installment_no, e.due_date, ch.charge_type
             FROM payment_allocations a LEFT JOIN emi_schedules e ON e.id = a.emi_schedule_id
             LEFT JOIN loan_charges ch ON ch.id = a.charge_id WHERE a.payment_id = $1 ORDER BY a.id`,
          [r!.id],
          c,
        );
        const after = await one(`SELECT dpd, bucket_code, overdue_amount, overdue_charges, outstanding_principal FROM dpd_current WHERE loan_id = $1`, [body.loanId], c);
        return { valid: true, allocations, after };
      });
    } catch (e) {
      const mapped = fromPgError(e);
      if (mapped && mapped.status < 500) return { valid: false, message: mapped.message };
      throw e;
    }
  },
});

route(router, BASE, {
  method: 'post',
  path: '',
  tag: 'Payments',
  summary: 'Record a payment (atomic allocation + DPD refresh). Send an Idempotency-Key header.',
  permission: 'payments.write',
  idempotent: true,
  body: paymentBody,
  handler: async ({ body, user, db, req }) => {
    await assertLoanAccess(user, body.loanId);
    const collectedBy = body.collectedBy ?? (executiveScope(user) ? user.id : null);
    const id = await tx(db, async (c) => {
      const r = await one<{ id: number }>(
        `SELECT sp_process_payment($1, $2, $3::date, $4, $5, $6, $7, $8, $9, $10, 'MANUAL', $11) AS id`,
        [body.loanId, body.amount, body.paymentDate, body.paymentMode, body.transactionReference ?? null, body.status,
         collectedBy, body.remarks ?? null, body.emiScheduleId ?? null,
         (req as any).idempotencyKey ? `${user.id}:${(req as any).idempotencyKey}` : null, user.id],
        c,
      );
      return r!.id;
    });
    return getPayment(id);
  },
});

async function getPayment(id: number) {
  const p = await one<any>(
    `SELECT ${SELECT}, p.unallocated_amount, p.realized_at, p.idempotency_key IS NOT NULL AS idempotent,
            r.reason AS reversal_reason, r.reversal_date, r.reversed_amount, ru.full_name AS reversed_by_name,
            b.id AS bounce_id, b.bounce_number, b.bounce_reason, cb.full_name AS created_by_name
       FROM ${FROM}
       LEFT JOIN payment_reversals r ON r.payment_id = p.id LEFT JOIN users ru ON ru.id = r.reversed_by
       LEFT JOIN payment_bounces b ON b.payment_id = p.id LEFT JOIN users cb ON cb.id = p.created_by
      WHERE p.id = $1`,
    [id],
  );
  if (!p) throw notFound('Payment');
  p.allocations = await query(
    `SELECT a.id, a.component, a.amount, a.is_advance, a.emi_schedule_id, e.installment_no, e.due_date, a.charge_id, ch.charge_type
       FROM payment_allocations a LEFT JOIN emi_schedules e ON e.id = a.emi_schedule_id
       LEFT JOIN loan_charges ch ON ch.id = a.charge_id WHERE a.payment_id = $1 ORDER BY a.id`,
    [id],
  );
  return p;
}

route(router, BASE, {
  method: 'get',
  path: '/import/template',
  tag: 'Payments',
  summary: 'CSV template for bulk payment import',
  permission: 'payments.import',
  raw: true,
  handler: async ({ res }) => {
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="payment_import_template.csv"');
    res.send('loan_number,amount,payment_date,payment_mode,transaction_reference,status,remarks\nLN00000001,5000.00,2026-11-01,UPI,UTR1234567890,SUCCESSFUL,Collected via UPI\n');
  },
});

const importRow = z.object({
  loan_number: z.string().trim().min(1),
  amount: money,
  payment_date: isoDate,
  payment_mode: z.string().trim().toUpperCase().pipe(z.enum(MODES)),
  transaction_reference: z.string().trim().max(64).optional().default(''),
  status: z.string().trim().toUpperCase().pipe(z.enum(['SUCCESSFUL', 'PENDING'])).optional().default('SUCCESSFUL'),
  remarks: z.string().trim().max(500).optional().default(''),
});

route(router, BASE, {
  method: 'post',
  path: '/import',
  tag: 'Payments',
  summary: 'Bulk import payments from CSV (multipart field "file"; ?dryRun=true validates only). Each row is atomic.',
  permission: 'payments.import',
  status: 200,
  middlewares: [upload.single('file') as any],
  query: z.object({ dryRun: z.enum(['true', 'false']).default('false') }),
  handler: async ({ req, user, db, query: q }) => {
    const file = (req as any).file as Express.Multer.File | undefined;
    if (!file) throw badRequest('Attach a CSV file in the "file" field');
    let records: Record<string, string>[];
    try {
      records = parse(file.buffer, { columns: (h: string[]) => h.map((x) => x.trim().toLowerCase()), skip_empty_lines: true, bom: true, trim: true, to: 2001 });
    } catch (e) {
      throw badRequest(`Could not read CSV: ${(e as Error).message}`);
    }
    if (records.length > 2000) throw badRequest('Maximum 2,000 rows per file');
    const dry = q.dryRun === 'true';
    const results: { row: number; loanNumber?: string; status: 'OK' | 'ERROR'; paymentNumber?: string; message?: string }[] = [];
    const seen = new Set<string>();
    for (let i = 0; i < records.length; i++) {
      const rowNo = i + 2; // header is row 1
      const parsed = importRow.safeParse(records[i]);
      if (!parsed.success) {
        results.push({ row: rowNo, loanNumber: records[i].loan_number, status: 'ERROR', message: parsed.error.issues.map((x) => `${x.path.join('.')}: ${x.message}`).join('; ') });
        continue;
      }
      const r = parsed.data;
      if (r.payment_mode !== 'CASH' && !r.transaction_reference) {
        results.push({ row: rowNo, loanNumber: r.loan_number, status: 'ERROR', message: 'transaction_reference is required for non-cash rows' });
        continue;
      }
      const refKey = r.transaction_reference.toUpperCase();
      if (refKey && seen.has(refKey)) {
        results.push({ row: rowNo, loanNumber: r.loan_number, status: 'ERROR', message: 'Duplicate transaction_reference within the file' });
        continue;
      }
      if (refKey) seen.add(refKey);
      const run = dry ? dryRun : tx;
      try {
        const out = await run(db, async (c) => {
          const loan = await one<{ id: number }>(`SELECT id FROM loans WHERE loan_number = $1`, [r.loan_number], c);
          if (!loan) throw badRequest(`Loan ${r.loan_number} not found`);
          const p = await one<{ id: number }>(
            `SELECT sp_process_payment($1, $2, $3::date, $4, $5, $6, NULL, $7, NULL, NULL, 'CSV_IMPORT', $8) AS id`,
            [loan.id, r.amount, r.payment_date, r.payment_mode, r.transaction_reference || null, r.status, r.remarks || null, user.id],
            c,
          );
          return one<{ paymentNumber: string }>(`SELECT payment_number FROM payments WHERE id = $1`, [p!.id], c);
        });
        results.push({ row: rowNo, loanNumber: r.loan_number, status: 'OK', paymentNumber: dry ? undefined : out?.paymentNumber });
      } catch (e: any) {
        results.push({ row: rowNo, loanNumber: r.loan_number, status: 'ERROR', message: fromPgError(e)?.message ?? e.message });
      }
    }
    const ok = results.filter((r) => r.status === 'OK').length;
    if (!dry) await audit(db, 'PAYMENT_IMPORT', 'payments', null, { file: file.originalname, rows: records.length, imported: ok });
    return { dryRun: dry, total: records.length, succeeded: ok, failed: results.length - ok, results };
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id',
  tag: 'Payments',
  summary: 'Payment with allocations, reversal and bounce info',
  permission: 'payments.read',
  params: idParam,
  handler: async ({ params, user }) => {
    const p = await getPayment(params.id);
    await assertLoanAccess(user, p.loanId);
    return p;
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id/receipt',
  tag: 'Payments',
  summary: 'PDF receipt for a successful payment',
  permission: 'payments.read',
  params: idParam,
  raw: true,
  handler: async ({ params, user, res }) => {
    const p = await getPayment(params.id);
    await assertLoanAccess(user, p.loanId);
    if (!['SUCCESSFUL', 'REVERSED'].includes(p.status) && !p.realizedAt) throw badRequest('Receipts are issued only for realised payments');
    const company = await one<{ v: string }>(`SELECT fn_setting('company_name') AS v`);
    const doc = new PDFDocument({ size: 'A5', margin: 36 });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="receipt_${p.paymentNumber}.pdf"`);
    res.setHeader('Cache-Control', 'no-store');
    doc.pipe(res);
    const inr = (n: number) => `Rs. ${Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
    doc.fontSize(16).fillColor('#1e3a8a').text(company?.v ?? 'Receipt', { align: 'center' });
    doc.fontSize(11).fillColor('#0f172a').text('PAYMENT RECEIPT', { align: 'center' }).moveDown();
    if (p.status !== 'SUCCESSFUL') doc.fontSize(12).fillColor('#dc2626').text(`STATUS: ${p.status}`, { align: 'center' }).moveDown(0.5);
    const line = (k: string, v: string) => {
      doc.fontSize(9).fillColor('#64748b').text(k, { continued: true }).fillColor('#0f172a').text(`  ${v}`);
    };
    line('Receipt No:', p.paymentNumber);
    line('Date:', p.paymentDate);
    line('Loan ID:', p.loanNumber);
    line('Customer:', `${p.customerName} (${p.customerCode})`);
    line('Mode:', p.paymentMode);
    if (p.transactionReference) line('Reference:', p.transactionReference);
    line('Amount:', inr(p.amount));
    doc.moveDown().fontSize(10).fillColor('#1e3a8a').text('Allocation');
    for (const a of p.allocations)
      line(`  ${a.component}${a.installmentNo ? ` (EMI #${a.installmentNo})` : a.chargeType ? ` (${a.chargeType})` : ''}${a.isAdvance ? ' – advance' : ''}:`, inr(a.amount));
    doc.moveDown(2).fontSize(7).fillColor('#64748b').text('This is a computer-generated receipt and does not require a signature.', { align: 'center' });
    doc.end();
  },
});

route(router, BASE, {
  method: 'post',
  path: '/:id/reverse',
  tag: 'Payments',
  summary: 'Reverse a successful payment (restores the installments it had cleared)',
  permission: 'payments.reverse',
  params: idParam,
  status: 200,
  body: z.object({ reason: z.string().trim().min(3).max(500), reversalDate: isoDate.optional() }),
  handler: async ({ params, body, db, user }) => {
    await tx(db, (c) => c.query('SELECT sp_reverse_payment($1, $2, $3::date, $4)', [params.id, body.reason, body.reversalDate ?? null, user.id]));
    return getPayment(params.id);
  },
});

route(router, BASE, {
  method: 'post',
  path: '/:id/realize',
  tag: 'Payments',
  summary: 'Mark a PENDING/INITIATED payment as realised (allocates it)',
  permission: 'payments.reverse',
  params: idParam,
  status: 200,
  handler: async ({ params, db, user }) => {
    await tx(db, (c) => c.query('SELECT sp_realize_payment($1, $2)', [params.id, user.id]));
    return getPayment(params.id);
  },
});

route(router, BASE, {
  method: 'post',
  path: '/:id/fail',
  tag: 'Payments',
  summary: 'Mark a PENDING/INITIATED payment as failed (no bounce charge)',
  permission: 'payments.reverse',
  params: idParam,
  status: 200,
  body: z.object({ reason: z.string().trim().min(3).max(300) }),
  handler: async ({ params, body, db, user }) => {
    await tx(db, (c) => c.query('SELECT sp_fail_payment($1, $2, $3)', [params.id, body.reason, user.id]));
    return getPayment(params.id);
  },
});
