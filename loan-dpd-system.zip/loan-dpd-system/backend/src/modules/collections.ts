import { Router } from 'express';
import { z } from 'zod';
import { one, query, tx } from '../db/pool.js';
import { badRequest, forbidden, notFound } from '../lib/errors.js';
import { route } from '../lib/http.js';
import { respondList } from '../lib/listing.js';
import { idParam, isoDate, listQuerySchema, money, orderBy, Sql } from '../lib/sql.js';
import { executiveScope, type AuthUser } from '../middleware/auth.js';
import { assertLoanAccess, loanFilters, loanListQuery, LOAN_SORT } from './loans.js';

export const router = Router();
const BASE = '/api/collections';

const ACTIVITY_TYPES = ['PHONE_CALL', 'SMS', 'EMAIL', 'FIELD_VISIT', 'WHATSAPP', 'OTHER'] as const;
const RESULTS = ['CONTACTED', 'NOT_REACHABLE', 'WRONG_NUMBER', 'PROMISE_TO_PAY', 'PAID', 'REFUSED_TO_PAY', 'CALLBACK_REQUESTED', 'CUSTOMER_NOT_AVAILABLE', 'OTHER'] as const;

/** executives act only for themselves; managers may pass any executive */
function effectiveExecutive(user: AuthUser, requested?: number | null) {
  const exec = executiveScope(user);
  if (exec) return exec;
  return requested ?? null;
}

route(router, BASE, {
  method: 'get',
  path: '/overdue',
  tag: 'Collections',
  summary: 'Overdue account worklist with assignment, last activity, next follow-up and open PTP',
  permission: 'collections.read',
  query: loanListQuery.extend({ assigned: z.enum(['true', 'false']).optional(), followUpDue: z.enum(['true']).optional() }),
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = loanFilters({ ...q, status: q.status ?? 'LIVE' }, ctx.user);
    sql.and(`(v.overdue_amount > 0 OR v.overdue_charges > 0)`);
    if (q.assigned === 'true') sql.and('v.executive_id IS NOT NULL');
    if (q.assigned === 'false') sql.and('v.executive_id IS NULL');
    if (q.followUpDue === 'true') sql.and(`la.next_follow_up_date <= fn_business_date()`);
    await respondList(ctx, {
      select: `v.*, la.activity_date AS last_activity_date, la.activity_type AS last_activity_type, la.contact_result AS last_contact_result,
               la.next_follow_up_date, ptp.promised_date AS ptp_date, ptp.promised_amount AS ptp_amount`,
      from: `vw_active_loans v
             LEFT JOIN LATERAL (SELECT activity_date, activity_type, contact_result, next_follow_up_date FROM collection_activities
                                 WHERE loan_id = v.id ORDER BY activity_date DESC, id DESC LIMIT 1) la ON TRUE
             LEFT JOIN LATERAL (SELECT promised_date, promised_amount FROM promise_to_pay
                                 WHERE loan_id = v.id AND status = 'PENDING' ORDER BY promised_date LIMIT 1) ptp ON TRUE`,
      sql,
      pii: true,
      order: orderBy(q, { ...LOAN_SORT, lastActivityDate: 'la.activity_date', nextFollowUpDate: 'la.next_follow_up_date', ptpDate: 'ptp.promised_date' }, 'v.dpd DESC, v.overdue_amount DESC'),
      title: 'Overdue Accounts',
      columns: [
        { key: 'loanNumber', label: 'Loan ID' },
        { key: 'customerName', label: 'Customer' },
        { key: 'mobile', label: 'Mobile' },
        { key: 'city', label: 'City' },
        { key: 'productName', label: 'Product' },
        { key: 'dpd', label: 'DPD', type: 'number' },
        { key: 'bucketCode', label: 'Bucket' },
        { key: 'overdueEmiCount', label: 'Overdue EMIs', type: 'number' },
        { key: 'overdueAmount', label: 'Overdue', type: 'money' },
        { key: 'overdueCharges', label: 'Charges', type: 'money' },
        { key: 'outstandingPrincipal', label: 'POS', type: 'money' },
        { key: 'executiveName', label: 'Executive' },
        { key: 'lastActivityDate', label: 'Last Activity', type: 'date' },
        { key: 'lastContactResult', label: 'Last Result' },
        { key: 'nextFollowUpDate', label: 'Next Follow-up', type: 'date' },
        { key: 'ptpDate', label: 'PTP Date', type: 'date' },
        { key: 'ptpAmount', label: 'PTP Amount', type: 'money' },
      ],
    });
  },
});

route(router, BASE, {
  method: 'get',
  path: '/activities',
  tag: 'Collections',
  summary: 'Collection activities (format=csv|xlsx|pdf exports)',
  permission: 'collections.read',
  query: listQuerySchema.extend({
    loanId: z.coerce.number().int().optional(),
    executiveId: z.coerce.number().int().optional(),
    activityType: z.enum(ACTIVITY_TYPES).optional(),
    contactResult: z.enum(RESULTS).optional(),
    dateFrom: isoDate.optional(),
    dateTo: isoDate.optional(),
    followUpOn: isoDate.optional(),
  }),
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    if (q.loanId) sql.and(`a.loan_id = ${sql.p(q.loanId)}`);
    const exec = effectiveExecutive(ctx.user, q.executiveId);
    if (exec) sql.and(`a.executive_id = ${sql.p(exec)}`);
    if (q.activityType) sql.and(`a.activity_type = ${sql.p(q.activityType)}`);
    if (q.contactResult) sql.and(`a.contact_result = ${sql.p(q.contactResult)}`);
    if (q.dateFrom) sql.and(`a.activity_date >= ${sql.p(q.dateFrom)}`);
    if (q.dateTo) sql.and(`a.activity_date <= ${sql.p(q.dateTo)}`);
    if (q.followUpOn) sql.and(`a.next_follow_up_date = ${sql.p(q.followUpOn)}`);
    if (q.search) {
      const s = sql.p(`%${q.search}%`);
      sql.and(`(l.loan_number ILIKE ${s} OR c.full_name ILIKE ${s} OR a.notes ILIKE ${s})`);
    }
    await respondList(ctx, {
      select: `a.*, l.loan_number, l.customer_id, c.customer_code, c.full_name AS customer_name, u.full_name AS executive_name`,
      from: `collection_activities a JOIN loans l ON l.id = a.loan_id JOIN customers c ON c.id = l.customer_id JOIN users u ON u.id = a.executive_id`,
      sql,
      order: orderBy(q, { activityDate: 'a.activity_date', loanNumber: 'l.loan_number', executiveName: 'u.full_name', nextFollowUpDate: 'a.next_follow_up_date', createdAt: 'a.created_at' }, 'a.activity_date DESC, a.id DESC'),
      title: 'Collection Activities',
      columns: [
        { key: 'activityDate', label: 'Date', type: 'date' },
        { key: 'loanNumber', label: 'Loan ID' },
        { key: 'customerName', label: 'Customer' },
        { key: 'executiveName', label: 'Executive' },
        { key: 'activityType', label: 'Type' },
        { key: 'contactResult', label: 'Result' },
        { key: 'ptpDate', label: 'PTP Date', type: 'date' },
        { key: 'ptpAmount', label: 'PTP Amount', type: 'money' },
        { key: 'nextFollowUpDate', label: 'Next Follow-up', type: 'date' },
        { key: 'notes', label: 'Notes' },
      ],
    });
  },
});

route(router, BASE, {
  method: 'post',
  path: '/activities',
  tag: 'Collections',
  summary: 'Log a collection activity (a PROMISE_TO_PAY result also creates a promise record)',
  permission: 'collections.write',
  body: z
    .object({
      loanId: z.coerce.number().int().positive(),
      activityDate: isoDate,
      activityType: z.enum(ACTIVITY_TYPES),
      contactResult: z.enum(RESULTS),
      ptpDate: isoDate.optional().nullable(),
      ptpAmount: money.optional().nullable(),
      notes: z.string().trim().max(1000).optional().nullable(),
      nextFollowUpDate: isoDate.optional().nullable(),
    })
    .refine((b) => b.contactResult !== 'PROMISE_TO_PAY' || (b.ptpDate && b.ptpAmount), {
      message: 'Promise date and amount are required for a promise to pay',
      path: ['ptpDate'],
    })
    .refine((b) => !b.ptpDate || b.ptpDate >= b.activityDate, { message: 'Promise date cannot be before the activity date', path: ['ptpDate'] })
    .refine((b) => !b.nextFollowUpDate || b.nextFollowUpDate >= b.activityDate, { message: 'Follow-up cannot be in the past', path: ['nextFollowUpDate'] }),
  handler: async ({ body, user, db }) => {
    await assertLoanAccess(user, body.loanId);
    const bd = (await one<{ d: string }>(`SELECT fn_business_date()::text AS d`))!.d;
    if (body.activityDate > bd) throw badRequest('Activity date cannot be after the business date');
    const loan = await one<any>(`SELECT status FROM loans WHERE id = $1`, [body.loanId]);
    if (!loan) throw notFound('Loan');
    if (!['DISBURSED', 'ACTIVE', 'OVERDUE', 'WRITTEN_OFF'].includes(loan.status)) throw badRequest(`Loan is ${loan.status}`);
    const isPtp = body.contactResult === 'PROMISE_TO_PAY';
    return tx(db, async (c) => {
      const a = await one<any>(
        `INSERT INTO collection_activities (loan_id, executive_id, activity_date, activity_type, contact_result, ptp_date, ptp_amount, notes, next_follow_up_date)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
        [body.loanId, user.id, body.activityDate, body.activityType, body.contactResult, isPtp ? body.ptpDate : null,
         isPtp ? body.ptpAmount : null, body.notes ?? null, body.nextFollowUpDate ?? (isPtp ? body.ptpDate : null)],
        c,
      );
      if (isPtp) {
        await c.query(
          `INSERT INTO promise_to_pay (loan_id, activity_id, executive_id, promised_on, promised_date, promised_amount)
           VALUES ($1,$2,$3,$4,$5,$6)`,
          [body.loanId, a.id, user.id, body.activityDate, body.ptpDate, body.ptpAmount],
        );
      }
      return a;
    });
  },
});

route(router, BASE, {
  method: 'get',
  path: '/assignments',
  tag: 'Collections',
  summary: 'Account assignments (active by default; history=true for all)',
  permission: 'collections.read',
  query: listQuerySchema.extend({
    executiveId: z.coerce.number().int().optional(),
    loanId: z.coerce.number().int().optional(),
    history: z.enum(['true', 'false']).default('false'),
  }),
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    if (q.history !== 'true') sql.and('a.is_active');
    const exec = effectiveExecutive(ctx.user, q.executiveId);
    if (exec) sql.and(`a.executive_id = ${sql.p(exec)}`);
    if (q.loanId) sql.and(`a.loan_id = ${sql.p(q.loanId)}`);
    if (q.search) {
      const s = sql.p(`%${q.search}%`);
      sql.and(`(v.loan_number ILIKE ${s} OR v.customer_name ILIKE ${s} OR u.full_name ILIKE ${s})`);
    }
    await respondList(ctx, {
      select: `a.id, a.loan_id, a.executive_id, u.full_name AS executive_name, a.assigned_at, a.unassigned_at, a.is_active, a.remarks,
               ab.full_name AS assigned_by_name, v.loan_number, v.customer_name, v.dpd, v.bucket_code, v.overdue_amount, v.outstanding_principal, v.status`,
      from: `collection_assignments a JOIN users u ON u.id = a.executive_id LEFT JOIN users ab ON ab.id = a.assigned_by
             JOIN vw_loan_register v ON v.id = a.loan_id`,
      sql,
      order: orderBy(q, { assignedAt: 'a.assigned_at', dpd: 'v.dpd', executiveName: 'u.full_name', loanNumber: 'v.loan_number', overdueAmount: 'v.overdue_amount' }, 'a.assigned_at DESC'),
      title: 'Collection Assignments',
      columns: [
        { key: 'loanNumber', label: 'Loan ID' },
        { key: 'customerName', label: 'Customer' },
        { key: 'executiveName', label: 'Executive' },
        { key: 'dpd', label: 'DPD', type: 'number' },
        { key: 'overdueAmount', label: 'Overdue', type: 'money' },
        { key: 'assignedAt', label: 'Assigned At' },
        { key: 'assignedByName', label: 'Assigned By' },
        { key: 'isActive', label: 'Active' },
      ],
    });
  },
});

async function assertExecutive(id: number) {
  const ok = await one(
    `SELECT 1 FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1 AND r.code = 'COLLECTION_EXECUTIVE' AND u.is_active AND u.deleted_at IS NULL`,
    [id],
  );
  if (!ok) throw badRequest('Assignee must be an active collection executive');
}

route(router, BASE, {
  method: 'post',
  path: '/assignments',
  tag: 'Collections',
  summary: 'Assign or reassign loans to a collection executive (bulk)',
  permission: 'collections.assign',
  body: z.object({
    loanIds: z.array(z.coerce.number().int().positive()).min(1).max(1000),
    executiveId: z.coerce.number().int().positive(),
    remarks: z.string().trim().max(300).optional(),
  }),
  handler: async ({ body, user, db }) => {
    await assertExecutive(body.executiveId);
    const res = await tx(db, async (c) => {
      const live = await query<{ id: number }>(
        `SELECT id FROM loans WHERE id = ANY($1::bigint[]) AND status IN ('DISBURSED','ACTIVE','OVERDUE','WRITTEN_OFF') FOR UPDATE`,
        [body.loanIds],
        c,
      );
      const ids = live.map((l) => l.id);
      if (!ids.length) throw badRequest('None of the selected loans can be assigned');
      await c.query(
        `UPDATE collection_assignments SET is_active = FALSE, unassigned_at = now(), remarks = COALESCE(remarks, 'Reassigned')
          WHERE loan_id = ANY($1::bigint[]) AND is_active AND executive_id <> $2`,
        [ids, body.executiveId],
      );
      const ins = await query(
        `INSERT INTO collection_assignments (loan_id, executive_id, assigned_by, remarks)
         SELECT x, $2, $3, $4 FROM unnest($1::bigint[]) x
          WHERE NOT EXISTS (SELECT 1 FROM collection_assignments a WHERE a.loan_id = x AND a.is_active)
         RETURNING id`,
        [ids, body.executiveId, user.id, body.remarks ?? null],
        c,
      );
      if (ins.length)
        await c.query(
          `INSERT INTO notifications (user_id, type, title, message, link) VALUES ($1, 'ASSIGNMENT', 'New accounts assigned', $2, '/collections')`,
          [body.executiveId, `${ins.length} account(s) were assigned to you by ${user.fullName}`],
        );
      return { requested: body.loanIds.length, assigned: ins.length, skipped: body.loanIds.length - ids.length };
    });
    return res;
  },
});

route(router, BASE, {
  method: 'post',
  path: '/assignments/unassign',
  tag: 'Collections',
  summary: 'Remove the active assignment from loans',
  permission: 'collections.assign',
  status: 200,
  body: z.object({ loanIds: z.array(z.coerce.number().int().positive()).min(1).max(1000) }),
  handler: async ({ body, db }) => {
    const r = await tx(db, (c) =>
      c.query(`UPDATE collection_assignments SET is_active = FALSE, unassigned_at = now(), remarks = 'Unassigned' WHERE loan_id = ANY($1::bigint[]) AND is_active`, [body.loanIds]),
    );
    return { unassigned: r.rowCount };
  },
});

route(router, BASE, {
  method: 'post',
  path: '/assignments/auto',
  tag: 'Collections',
  summary: 'Auto-allocate unassigned overdue accounts across executives (highest DPD first, least-loaded executive)',
  permission: 'collections.assign',
  status: 200,
  body: z.object({ executiveIds: z.array(z.coerce.number().int().positive()).optional(), minDpd: z.coerce.number().int().min(1).default(1) }),
  handler: async ({ body, user, db }) => {
    return tx(db, async (c) => {
      const execs = await query<{ id: number; load: number }>(
        `SELECT u.id, (SELECT count(*) FROM collection_assignments a WHERE a.executive_id = u.id AND a.is_active)::int AS load
           FROM users u JOIN roles r ON r.id = u.role_id
          WHERE r.code = 'COLLECTION_EXECUTIVE' AND u.is_active AND u.deleted_at IS NULL
            AND ($1::int[] IS NULL OR u.id = ANY($1::int[]))`,
        [body.executiveIds?.length ? body.executiveIds : null],
        c,
      );
      if (!execs.length) throw badRequest('No active collection executives');
      const loans = await query<{ id: number }>(
        `SELECT d.loan_id AS id FROM dpd_current d
          WHERE d.dpd >= $1 AND d.account_status = 'OVERDUE'
            AND NOT EXISTS (SELECT 1 FROM collection_assignments a WHERE a.loan_id = d.loan_id AND a.is_active)
          ORDER BY d.dpd DESC, d.overdue_amount DESC`,
        [body.minDpd],
        c,
      );
      const counts = new Map<number, number>();
      for (const l of loans) {
        execs.sort((a, b) => a.load - b.load);
        const e = execs[0];
        await c.query(`INSERT INTO collection_assignments (loan_id, executive_id, assigned_by, remarks) VALUES ($1,$2,$3,'Auto-allocation')`, [l.id, e.id, user.id]);
        e.load++;
        counts.set(e.id, (counts.get(e.id) ?? 0) + 1);
      }
      for (const [id, n] of counts)
        await c.query(`INSERT INTO notifications (user_id, type, title, message, link) VALUES ($1,'ASSIGNMENT','New accounts assigned',$2,'/collections')`, [id, `${n} overdue account(s) auto-allocated to you`]);
      return { assigned: loans.length, perExecutive: Object.fromEntries(counts) };
    });
  },
});

route(router, BASE, {
  method: 'get',
  path: '/ptp',
  tag: 'Collections',
  summary: 'Promise-to-pay register (format=csv|xlsx|pdf exports)',
  permission: 'collections.read',
  query: listQuerySchema.extend({
    status: z.enum(['PENDING', 'KEPT', 'PARTIALLY_KEPT', 'BROKEN', 'CANCELLED']).optional(),
    executiveId: z.coerce.number().int().optional(),
    dueFrom: isoDate.optional(),
    dueTo: isoDate.optional(),
    loanId: z.coerce.number().int().optional(),
  }),
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    if (q.status) sql.and(`t.status = ${sql.p(q.status)}`);
    const exec = effectiveExecutive(ctx.user, q.executiveId);
    if (exec) sql.and(`t.executive_id = ${sql.p(exec)}`);
    if (q.dueFrom) sql.and(`t.promised_date >= ${sql.p(q.dueFrom)}`);
    if (q.dueTo) sql.and(`t.promised_date <= ${sql.p(q.dueTo)}`);
    if (q.loanId) sql.and(`t.loan_id = ${sql.p(q.loanId)}`);
    if (q.search) {
      const s = sql.p(`%${q.search}%`);
      sql.and(`(l.loan_number ILIKE ${s} OR c.full_name ILIKE ${s})`);
    }
    await respondList(ctx, {
      select: `t.*, l.loan_number, c.full_name AS customer_name, c.mobile, u.full_name AS executive_name, d.dpd, d.overdue_amount`,
      from: `promise_to_pay t JOIN loans l ON l.id = t.loan_id JOIN customers c ON c.id = l.customer_id JOIN users u ON u.id = t.executive_id
             LEFT JOIN dpd_current d ON d.loan_id = t.loan_id`,
      sql,
      pii: true,
      order: orderBy(q, { promisedDate: 't.promised_date', promisedAmount: 't.promised_amount', status: 't.status', loanNumber: 'l.loan_number', executiveName: 'u.full_name' }, 't.promised_date DESC'),
      title: 'Promise to Pay',
      columns: [
        { key: 'loanNumber', label: 'Loan ID' },
        { key: 'customerName', label: 'Customer' },
        { key: 'executiveName', label: 'Executive' },
        { key: 'promisedOn', label: 'Promised On', type: 'date' },
        { key: 'promisedDate', label: 'Pay By', type: 'date' },
        { key: 'promisedAmount', label: 'Promised', type: 'money' },
        { key: 'keptAmount', label: 'Paid', type: 'money' },
        { key: 'status', label: 'Status' },
        { key: 'resolvedOn', label: 'Resolved', type: 'date' },
      ],
    });
  },
});

route(router, BASE, {
  method: 'post',
  path: '/ptp/:id/cancel',
  tag: 'Collections',
  summary: 'Cancel a pending promise to pay',
  permission: 'collections.write',
  params: idParam,
  status: 200,
  handler: async ({ params, user, db }) => {
    const t = await one<any>(`SELECT * FROM promise_to_pay WHERE id = $1`, [params.id]);
    if (!t) throw notFound('Promise');
    if (executiveScope(user) && t.executiveId !== user.id) throw forbidden();
    if (t.status !== 'PENDING') throw badRequest('Only pending promises can be cancelled');
    await tx(db, (c) => c.query(`UPDATE promise_to_pay SET status = 'CANCELLED', resolved_on = fn_business_date() WHERE id = $1`, [params.id]));
    return { ok: true };
  },
});

route(router, BASE, {
  method: 'get',
  path: '/dashboard',
  tag: 'Collections',
  summary: 'Collection executive dashboard (own figures for executives; any executive or the whole team for managers)',
  permission: 'collections.read',
  query: z.object({ executiveId: z.coerce.number().int().optional() }),
  handler: async ({ user, query: q }) => {
    const exec = effectiveExecutive(user, q.executiveId);
    const bd = (await one<{ d: string }>(`SELECT fn_business_date()::text AS d`))!.d;
    const perf = exec
      ? await query(`SELECT * FROM vw_collection_performance WHERE executive_id = $1`, [exec])
      : await query(`SELECT * FROM vw_collection_performance ORDER BY collected_mtd DESC`);
    const sum = (k: string) => Math.round(perf.reduce((s: number, r: any) => s + Number(r[k] ?? 0), 0) * 100) / 100;
    const target = sum('targetAmount');
    const kpis = {
      assignedAccounts: sum('assignedAccounts'),
      overdueAccounts: sum('overdueAccounts'),
      totalOverdue: sum('totalOverdue'),
      collectedMtd: sum('collectedMtd'),
      targetAmount: target,
      achievementPct: target > 0 ? Math.round((sum('collectedMtd') * 10000) / target) / 100 : null,
      ptpPending: sum('ptpPending'),
      ptpPendingAmount: sum('ptpPendingAmount'),
      ptpKeptMtd: sum('ptpKeptMtd'),
      brokenPtpMtd: sum('ptpBrokenMtd'),
      followUpsToday: sum('followUpsToday'),
    };
    const execFilter = exec ? 'AND x.executive_id = $2' : '';
    const params = exec ? [bd, exec] : [bd];
    const followUps = await query(
      `SELECT x.loan_id, l.loan_number, c.full_name AS customer_name, d.dpd, d.overdue_amount, x.kind, x.due_on, x.amount, u.full_name AS executive_name
         FROM (SELECT DISTINCT ON (loan_id) loan_id, executive_id, 'FOLLOW_UP' AS kind, next_follow_up_date AS due_on, NULL::numeric AS amount
                 FROM collection_activities WHERE next_follow_up_date = $1::date ORDER BY loan_id, id DESC) x
         JOIN loans l ON l.id = x.loan_id JOIN customers c ON c.id = l.customer_id JOIN users u ON u.id = x.executive_id
         LEFT JOIN dpd_current d ON d.loan_id = x.loan_id
        WHERE TRUE ${execFilter}
       UNION ALL
       SELECT x.loan_id, l.loan_number, c.full_name, d.dpd, d.overdue_amount, 'PTP', x.promised_date, x.promised_amount, u.full_name
         FROM promise_to_pay x JOIN loans l ON l.id = x.loan_id JOIN customers c ON c.id = l.customer_id JOIN users u ON u.id = x.executive_id
         LEFT JOIN dpd_current d ON d.loan_id = x.loan_id
        WHERE x.status = 'PENDING' AND x.promised_date <= $1::date ${execFilter}
        ORDER BY 6, 4 DESC NULLS LAST LIMIT 100`,
      params,
    );
    const trend = await query(
      `SELECT g.d::date::text AS date, COALESCE(sum(p.amount), 0) AS collected
         FROM generate_series($1::date - 29, $1::date, interval '1 day') g(d)
         LEFT JOIN payments p ON p.payment_date = g.d::date AND p.status = 'SUCCESSFUL'
              ${exec ? 'AND EXISTS (SELECT 1 FROM collection_assignments a WHERE a.loan_id = p.loan_id AND a.is_active AND a.executive_id = $2)' : ''}
        GROUP BY g.d ORDER BY g.d`,
      params,
    );
    return { businessDate: bd, executiveId: exec, kpis, team: perf, followUps, trend };
  },
});

route(router, BASE, {
  method: 'get',
  path: '/performance',
  tag: 'Collections',
  summary: 'Executive performance scorecard (business month to date)',
  permission: 'collections.read',
  handler: async ({ user }) => {
    const exec = executiveScope(user);
    return exec
      ? query(`SELECT * FROM vw_collection_performance WHERE executive_id = $1`, [exec])
      : query(`SELECT * FROM vw_collection_performance ORDER BY achievement_pct DESC NULLS LAST`);
  },
});

route(router, BASE, {
  method: 'get',
  path: '/targets',
  tag: 'Collections',
  summary: 'Monthly collection targets',
  permission: 'collections.read',
  query: z.object({ month: isoDate.optional() }),
  handler: async ({ query: q }) =>
    query(
      `SELECT t.*, u.full_name AS executive_name FROM collection_targets t JOIN users u ON u.id = t.executive_id
        WHERE t.target_month = date_trunc('month', COALESCE($1::date, fn_business_date()))::date ORDER BY u.full_name`,
      [q.month ?? null],
    ),
});

route(router, BASE, {
  method: 'put',
  path: '/targets',
  tag: 'Collections',
  summary: 'Set (upsert) a monthly collection target for an executive',
  permission: 'collections.targets',
  body: z.object({ executiveId: z.coerce.number().int().positive(), month: isoDate, targetAmount: money }),
  handler: async ({ body, user, db }) => {
    await assertExecutive(body.executiveId);
    return tx(db, (c) =>
      one(
        `INSERT INTO collection_targets (executive_id, target_month, target_amount, created_by)
         VALUES ($1, date_trunc('month', $2::date)::date, $3, $4)
         ON CONFLICT (executive_id, target_month) DO UPDATE SET target_amount = EXCLUDED.target_amount RETURNING *`,
        [body.executiveId, body.month, body.targetAmount, user.id],
        c,
      ),
    );
  },
});
