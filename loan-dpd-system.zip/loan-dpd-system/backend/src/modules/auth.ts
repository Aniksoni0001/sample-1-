import { Router, type Request, type Response } from 'express';
import bcrypt from 'bcryptjs';
import { createHash, randomBytes } from 'node:crypto';
import { rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import { env, isProd } from '../config/env.js';
import { one, query, tx } from '../db/pool.js';
import { AppError, badRequest, unauthorized } from '../lib/errors.js';
import { route } from '../lib/http.js';
import { sendMail } from '../lib/mailer.js';
import { invalidateUserCache, loadUser, signAccessToken } from '../middleware/auth.js';

export const router = Router();
const BASE = '/api/auth';
const COOKIE = 'rt';
const MAX_FAILED = 5;
const LOCK_MINUTES = 15;

export const passwordSchema = z
  .string()
  .min(8, 'At least 8 characters')
  .max(128)
  .regex(/[A-Za-z]/, 'Must contain a letter')
  .regex(/\d/, 'Must contain a digit');

const DUMMY_HASH = bcrypt.hashSync(randomBytes(16).toString('hex'), 10);
const sha256 = (s: string) => createHash('sha256').update(s).digest('hex');

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: env.NODE_ENV === 'test' ? 1000 : 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: { code: 'RATE_LIMITED', message: 'Too many attempts, try again later' } },
});

function setRefreshCookie(res: Response, token: string) {
  res.cookie(COOKIE, token, {
    httpOnly: true,
    secure: isProd,
    sameSite: 'strict',
    path: BASE,
    maxAge: env.REFRESH_TOKEN_TTL_DAYS * 86_400_000,
  });
}

async function createSession(userId: number, req: Request) {
  const token = randomBytes(48).toString('base64url');
  const row = await one<{ id: number }>(
    `INSERT INTO user_sessions (user_id, token_hash, expires_at, ip, user_agent)
     VALUES ($1, $2, now() + make_interval(days => $3), $4, $5) RETURNING id`,
    [userId, sha256(token), env.REFRESH_TOKEN_TTL_DAYS, req.ip, req.get('user-agent')?.slice(0, 300) ?? null],
  );
  return { token, sessionId: row!.id };
}

async function profile(userId: number) {
  const entry = await loadUser(userId);
  if (!entry) throw unauthorized('Account is inactive');
  const bd = await one<{ businessDate: string; company: string }>(
    `SELECT fn_business_date()::text AS business_date, fn_setting('company_name') AS company`,
  );
  return {
    id: entry.user.id,
    email: entry.user.email,
    fullName: entry.user.fullName,
    role: entry.user.role,
    roleName: entry.user.roleName,
    branchId: entry.user.branchId,
    permissions: [...entry.user.permissions].sort(),
    businessDate: bd?.businessDate,
    companyName: bd?.company,
  };
}

route(router, BASE, {
  method: 'post',
  path: '/login',
  tag: 'Auth',
  summary: 'Log in with email + password; sets an httpOnly refresh cookie',
  public: true,
  raw: true,
  middlewares: [loginLimiter],
  body: z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1).max(128) }),
  handler: async ({ req, res, body }) => {
    const u = await one<any>(
      `SELECT id, password_hash, is_active, locked_until, failed_login_count FROM users
        WHERE lower(email) = $1 AND deleted_at IS NULL`,
      [body.email],
    );
    const log = (userId: number | null, success: boolean, reason?: string) =>
      query(
        `INSERT INTO login_history (user_id, email, success, reason, ip, user_agent) VALUES ($1,$2,$3,$4,$5,$6)`,
        [userId, body.email, success, reason ?? null, req.ip, req.get('user-agent')?.slice(0, 300) ?? null],
      );

    // constant-ish time: always run a bcrypt compare
    const hash = u?.passwordHash ?? DUMMY_HASH;
    const ok = await bcrypt.compare(body.password, hash);

    if (!u) {
      await log(null, false, 'unknown email');
      throw unauthorized('Invalid email or password');
    }
    if (u.lockedUntil && new Date(u.lockedUntil) > new Date()) {
      await log(u.id, false, 'locked');
      throw new AppError(423, `Account locked after repeated failures. Try again after ${LOCK_MINUTES} minutes.`, 'LOCKED');
    }
    if (!ok) {
      await query(
        `UPDATE users SET failed_login_count = failed_login_count + 1,
                locked_until = CASE WHEN failed_login_count + 1 >= $2 THEN now() + make_interval(mins => $3) END
          WHERE id = $1`,
        [u.id, MAX_FAILED, LOCK_MINUTES],
      );
      await log(u.id, false, 'bad password');
      throw unauthorized('Invalid email or password');
    }
    if (!u.isActive) {
      await log(u.id, false, 'inactive');
      throw unauthorized('Account is deactivated');
    }
    await query(`UPDATE users SET failed_login_count = 0, locked_until = NULL, last_login_at = now() WHERE id = $1`, [u.id]);
    await log(u.id, true);
    const { token, sessionId } = await createSession(u.id, req);
    setRefreshCookie(res, token);
    res.json({ accessToken: signAccessToken(u.id, sessionId), user: await profile(u.id) });
  },
});

route(router, BASE, {
  method: 'post',
  path: '/refresh',
  tag: 'Auth',
  summary: 'Rotate the refresh cookie and issue a new access token',
  public: true,
  raw: true,
  handler: async ({ req, res }) => {
    const token = req.cookies?.[COOKIE];
    if (!token) throw unauthorized('No session');
    const s = await one<any>(`SELECT id, user_id, expires_at, revoked_at, replaced_by FROM user_sessions WHERE token_hash = $1`, [
      sha256(token),
    ]);
    if (!s) throw unauthorized('Invalid session');
    if (s.revokedAt) {
      // a rotated token was presented again → likely stolen; kill every session of that user
      if (s.replacedBy) await query(`UPDATE user_sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL`, [s.userId]);
      res.clearCookie(COOKIE, { path: BASE });
      throw unauthorized('Session revoked');
    }
    if (new Date(s.expiresAt) < new Date()) throw unauthorized('Session expired');
    const next = await createSession(s.userId, req);
    await query(`UPDATE user_sessions SET revoked_at = now(), replaced_by = $2 WHERE id = $1`, [s.id, next.sessionId]);
    setRefreshCookie(res, next.token);
    res.json({ accessToken: signAccessToken(s.userId, next.sessionId), user: await profile(s.userId) });
  },
});

route(router, BASE, {
  method: 'post',
  path: '/logout',
  tag: 'Auth',
  summary: 'Revoke the current session',
  public: true,
  raw: true,
  handler: async ({ req, res }) => {
    const token = req.cookies?.[COOKIE];
    if (token) await query(`UPDATE user_sessions SET revoked_at = now() WHERE token_hash = $1 AND revoked_at IS NULL`, [sha256(token)]);
    res.clearCookie(COOKIE, { path: BASE });
    res.json({ ok: true });
  },
});

route(router, BASE, {
  method: 'get',
  path: '/me',
  tag: 'Auth',
  summary: 'Current user, permissions and business date',
  handler: async ({ user }) => profile(user.id),
});

route(router, BASE, {
  method: 'post',
  path: '/forgot-password',
  tag: 'Auth',
  summary: 'Email a one-time reset link (always returns 200)',
  public: true,
  status: 200,
  middlewares: [loginLimiter],
  body: z.object({ email: z.string().trim().toLowerCase().email() }),
  handler: async ({ body }) => {
    const u = await one<any>(`SELECT id, email FROM users WHERE lower(email) = $1 AND is_active AND deleted_at IS NULL`, [body.email]);
    if (u) {
      const token = randomBytes(32).toString('base64url');
      await query(`INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES ($1, $2, now() + interval '30 minutes')`, [
        u.id,
        sha256(token),
      ]);
      await sendMail(
        u.email,
        'Reset your password',
        `A password reset was requested for your account.\n\nOpen this link within 30 minutes:\n${env.APP_URL}/reset-password?token=${token}\n\nIf you did not request this, ignore this email.`,
      );
    }
    return { ok: true, message: 'If the email is registered, a reset link has been sent.' };
  },
});

route(router, BASE, {
  method: 'post',
  path: '/reset-password',
  tag: 'Auth',
  summary: 'Set a new password with a reset token; ends all sessions',
  public: true,
  status: 200,
  middlewares: [loginLimiter],
  body: z.object({ token: z.string().min(20).max(200), password: passwordSchema }),
  handler: async ({ body }) => {
    const r = await one<any>(
      `SELECT id, user_id FROM password_resets WHERE token_hash = $1 AND used_at IS NULL AND expires_at > now()`,
      [sha256(body.token)],
    );
    if (!r) throw badRequest('This reset link is invalid or has expired');
    const hash = await bcrypt.hash(body.password, 12);
    await tx({ userId: r.userId }, async (c) => {
      await c.query(`UPDATE users SET password_hash = $2, password_changed_at = now(), failed_login_count = 0, locked_until = NULL WHERE id = $1`, [
        r.userId,
        hash,
      ]);
      await c.query(`UPDATE password_resets SET used_at = now() WHERE id = $1`, [r.id]);
      await c.query(`UPDATE user_sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL`, [r.userId]);
    });
    invalidateUserCache(r.userId);
    return { ok: true };
  },
});

route(router, BASE, {
  method: 'post',
  path: '/change-password',
  tag: 'Auth',
  summary: 'Change own password',
  status: 200,
  body: z.object({ currentPassword: z.string().min(1), newPassword: passwordSchema }),
  handler: async ({ user, body, db }) => {
    const u = await one<any>(`SELECT password_hash FROM users WHERE id = $1`, [user.id]);
    if (!u || !(await bcrypt.compare(body.currentPassword, u.passwordHash))) throw badRequest('Current password is incorrect');
    const hash = await bcrypt.hash(body.newPassword, 12);
    await tx(db, (c) => c.query(`UPDATE users SET password_hash = $2, password_changed_at = now() WHERE id = $1`, [user.id, hash]));
    invalidateUserCache(user.id);
    return { ok: true, message: 'Password changed. Please sign in again.' };
  },
});
