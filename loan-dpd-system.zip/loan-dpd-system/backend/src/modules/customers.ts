import { Router } from 'express';
import { z } from 'zod';
import { one, query, tx } from '../db/pool.js';
import { forbidden, notFound } from '../lib/errors.js';
import { route } from '../lib/http.js';
import { respondList } from '../lib/listing.js';
import { maskRow } from '../lib/mask.js';
import { idParam, isoDate, listQuerySchema, orderBy, Sql } from '../lib/sql.js';
import { executiveScope, type AuthUser } from '../middleware/auth.js';

export const router = Router();
const BASE = '/api/customers';

const customerBody = z.object({
  fullName: z.string().trim().min(2).max(120),
  mobile: z.string().trim().regex(/^[6-9]\d{9}$/, '10-digit Indian mobile number'),
  email: z.string().trim().toLowerCase().email().max(120).optional().nullable().or(z.literal('').transform(() => null)),
  dateOfBirth: isoDate
    .optional()
    .nullable()
    .refine((d) => {
      if (!d) return true;
      const age = (Date.now() - Date.parse(d)) / (365.25 * 86_400_000);
      return age >= 18 && age <= 80;
    }, 'Customer must be 18–80 years old'),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER']).optional().nullable(),
  pan: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z]{5}\d{4}[A-Z]$/, 'Invalid PAN format')
    .optional()
    .nullable()
    .or(z.literal('').transform(() => null)),
  // Accept a full 12-digit Aadhaar or its last 4 — only the last 4 are ever stored.
  aadhaar: z
    .string()
    .trim()
    .regex(/^(\d{12}|\d{4})$/, 'Enter 12 digits (only the last 4 are stored)')
    .optional()
    .nullable()
    .or(z.literal('').transform(() => null)),
  addressLine: z.string().trim().max(250).optional().nullable(),
  city: z.string().trim().max(80).optional().nullable(),
  state: z.string().trim().max(80).optional().nullable(),
  pincode: z
    .string()
    .trim()
    .regex(/^[1-9]\d{5}$/, '6-digit PIN code')
    .optional()
    .nullable()
    .or(z.literal('').transform(() => null)),
  occupation: z.string().trim().max(80).optional().nullable(),
  monthlyIncome: z.coerce.number().min(0).max(1e9).optional().nullable(),
  status: z.enum(['ACTIVE', 'INACTIVE', 'BLOCKED']).default('ACTIVE'),
});

const listQuery = listQuerySchema.extend({
  status: z.enum(['ACTIVE', 'INACTIVE', 'BLOCKED']).optional(),
  state: z.string().max(80).optional(),
  city: z.string().max(80).optional(),
  hasOverdue: z.enum(['true', 'false']).optional(),
});

const SELECT = `c.id, c.customer_code, c.full_name, c.mobile, c.email, c.pan, c.city, c.state, c.pincode, c.occupation,
  c.monthly_income, c.status, c.created_at,
  (SELECT count(*) FROM loans l WHERE l.customer_id = c.id AND l.status NOT IN ('CANCELLED'))::int AS loan_count,
  (SELECT COALESCE(sum(d.overdue_amount + d.overdue_charges), 0) FROM dpd_current d JOIN loans l ON l.id = d.loan_id
    WHERE l.customer_id = c.id AND d.account_status IN ('DISBURSED','ACTIVE','OVERDUE')) AS total_overdue,
  (SELECT COALESCE(max(d.dpd), 0) FROM dpd_current d JOIN loans l ON l.id = d.loan_id
    WHERE l.customer_id = c.id AND d.account_status IN ('DISBURSED','ACTIVE','OVERDUE')) AS max_dpd`;

/** executives may only open customers that have a loan assigned to them */
export async function assertCustomerAccess(user: AuthUser, customerId: number) {
  const exec = executiveScope(user);
  if (!exec) return;
  const ok = await one(
    `SELECT 1 FROM loans l JOIN collection_assignments a ON a.loan_id = l.id AND a.is_active
      WHERE l.customer_id = $1 AND a.executive_id = $2`,
    [customerId, exec],
  );
  if (!ok) throw forbidden('This customer is not in your portfolio');
}

route(router, BASE, {
  method: 'get',
  path: '',
  tag: 'Customers',
  summary: 'List/search customers (format=csv|xlsx|pdf to export)',
  permission: 'customers.read',
  query: listQuery,
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    sql.and('c.deleted_at IS NULL');
    if (q.search) {
      const s = sql.p(`%${q.search}%`);
      sql.and(`(c.full_name ILIKE ${s} OR c.customer_code ILIKE ${s} OR c.mobile LIKE ${s} OR c.pan ILIKE ${s})`);
    }
    if (q.status) sql.and(`c.status = ${sql.p(q.status)}`);
    if (q.state) sql.and(`c.state = ${sql.p(q.state)}`);
    if (q.city) sql.and(`c.city ILIKE ${sql.p(q.city)}`);
    if (q.hasOverdue === 'true')
      sql.and(`EXISTS (SELECT 1 FROM dpd_current d JOIN loans l ON l.id = d.loan_id WHERE l.customer_id = c.id AND d.dpd > 0)`);
    const exec = executiveScope(ctx.user);
    if (exec)
      sql.and(`EXISTS (SELECT 1 FROM loans l JOIN collection_assignments a ON a.loan_id = l.id AND a.is_active
                        WHERE l.customer_id = c.id AND a.executive_id = ${sql.p(exec)})`);
    await respondList(ctx, {
      select: SELECT,
      from: 'customers c',
      sql,
      pii: true,
      order: orderBy(
        q,
        { customerCode: 'c.customer_code', fullName: 'c.full_name', city: 'c.city', state: 'c.state', createdAt: 'c.created_at', status: 'c.status', totalOverdue: 'total_overdue', maxDpd: 'max_dpd', monthlyIncome: 'c.monthly_income' },
        'c.id DESC',
      ),
      title: 'Customers',
      columns: [
        { key: 'customerCode', label: 'Customer ID' },
        { key: 'fullName', label: 'Name' },
        { key: 'mobile', label: 'Mobile' },
        { key: 'city', label: 'City' },
        { key: 'state', label: 'State' },
        { key: 'status', label: 'Status' },
        { key: 'loanCount', label: 'Loans', type: 'number' },
        { key: 'totalOverdue', label: 'Total Overdue', type: 'money' },
        { key: 'maxDpd', label: 'Max DPD', type: 'number' },
      ],
    });
  },
});

route(router, BASE, {
  method: 'post',
  path: '',
  tag: 'Customers',
  summary: 'Create customer',
  permission: 'customers.write',
  body: customerBody,
  handler: async ({ body, db, user }) => {
    const row = await tx(db, async (c) =>
      one(
        `INSERT INTO customers (full_name, mobile, email, date_of_birth, gender, pan, aadhaar_last4, address_line, city, state,
                                pincode, occupation, monthly_income, status, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) RETURNING id, customer_code`,
        [
          body.fullName, body.mobile, body.email ?? null, body.dateOfBirth ?? null, body.gender ?? null, body.pan ?? null,
          body.aadhaar ? body.aadhaar.slice(-4) : null, body.addressLine ?? null, body.city ?? null, body.state ?? null,
          body.pincode ?? null, body.occupation ?? null, body.monthlyIncome ?? null, body.status, user.id,
        ],
        c,
      ),
    );
    return row;
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id',
  tag: 'Customers',
  summary: 'Customer profile with loans and overdue position',
  permission: 'customers.read',
  params: idParam,
  handler: async ({ params, user, can }) => {
    await assertCustomerAccess(user, params.id);
    const c = await one<any>(
      `SELECT c.*, u.full_name AS created_by_name FROM customers c LEFT JOIN users u ON u.id = c.created_by
        WHERE c.id = $1 AND c.deleted_at IS NULL`,
      [params.id],
    );
    if (!c) throw notFound('Customer');
    const loans = await query(
      `SELECT id, loan_number, product_name, principal_amount, emi_amount, status, disbursement_date, dpd, bucket_code,
              outstanding_principal, overdue_amount, overdue_charges, next_emi_due_date, executive_name
         FROM vw_loan_register WHERE customer_id = $1 ORDER BY id DESC`,
      [params.id],
    );
    const active = loans.filter((l: any) => ['DISBURSED', 'ACTIVE', 'OVERDUE'].includes(l.status));
    const summary = {
      totalLoans: loans.length,
      activeLoans: active.length,
      outstandingPrincipal: active.reduce((s: number, l: any) => s + Number(l.outstandingPrincipal), 0),
      totalOverdue: active.reduce((s: number, l: any) => s + Number(l.overdueAmount) + Number(l.overdueCharges), 0),
      maxDpd: active.reduce((m: number, l: any) => Math.max(m, l.dpd), 0),
    };
    const { aadhaarLast4, ...rest } = c;
    return {
      ...maskRow(rest, can('customers.pii')),
      aadhaarMasked: aadhaarLast4 ? `XXXX-XXXX-${aadhaarLast4}` : null,
      loans,
      summary: { ...summary, outstandingPrincipal: Math.round(summary.outstandingPrincipal * 100) / 100, totalOverdue: Math.round(summary.totalOverdue * 100) / 100 },
    };
  },
});

route(router, BASE, {
  method: 'put',
  path: '/:id',
  tag: 'Customers',
  summary: 'Update customer',
  permission: 'customers.write',
  params: idParam,
  body: customerBody.partial().extend({ aadhaar: customerBody.shape.aadhaar }),
  handler: async ({ params, body, db }) => {
    const map: Record<string, string> = {
      fullName: 'full_name', mobile: 'mobile', email: 'email', dateOfBirth: 'date_of_birth', gender: 'gender', pan: 'pan',
      addressLine: 'address_line', city: 'city', state: 'state', pincode: 'pincode', occupation: 'occupation',
      monthlyIncome: 'monthly_income', status: 'status',
    };
    const sets: string[] = [];
    const vals: unknown[] = [params.id];
    for (const [k, col] of Object.entries(map)) {
      if ((body as any)[k] !== undefined) {
        vals.push((body as any)[k]);
        sets.push(`${col} = $${vals.length}`);
      }
    }
    if (body.aadhaar !== undefined) {
      vals.push(body.aadhaar ? body.aadhaar.slice(-4) : null);
      sets.push(`aadhaar_last4 = $${vals.length}`);
    }
    if (!sets.length) return { ok: true };
    const row = await tx(db, (c) =>
      one(`UPDATE customers SET ${sets.join(', ')} WHERE id = $1 AND deleted_at IS NULL RETURNING id, customer_code`, vals, c),
    );
    if (!row) throw notFound('Customer');
    return row;
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id/payments',
  tag: 'Customers',
  summary: 'Payment history across all of the customer’s loans',
  permission: 'payments.read',
  params: idParam,
  handler: async ({ params, user }) => {
    await assertCustomerAccess(user, params.id);
    return query(
      `SELECT p.id, p.payment_number, p.payment_date, p.amount, p.payment_mode, p.transaction_reference, p.status,
              l.loan_number, l.id AS loan_id, u.full_name AS collected_by_name
         FROM payments p JOIN loans l ON l.id = p.loan_id LEFT JOIN users u ON u.id = p.collected_by
        WHERE l.customer_id = $1 ORDER BY p.payment_date DESC, p.id DESC LIMIT 500`,
      [params.id],
    );
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id/collections',
  tag: 'Customers',
  summary: 'Collection activity history for the customer',
  permission: 'collections.read',
  params: idParam,
  handler: async ({ params, user }) => {
    await assertCustomerAccess(user, params.id);
    return query(
      `SELECT a.*, l.loan_number, u.full_name AS executive_name
         FROM collection_activities a JOIN loans l ON l.id = a.loan_id JOIN users u ON u.id = a.executive_id
        WHERE l.customer_id = $1 ORDER BY a.activity_date DESC, a.id DESC LIMIT 500`,
      [params.id],
    );
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id/bounces',
  tag: 'Customers',
  summary: 'Bounce history for the customer',
  permission: 'bounces.read',
  params: idParam,
  handler: async ({ params, user }) => {
    await assertCustomerAccess(user, params.id);
    return query(
      `SELECT b.*, l.loan_number FROM payment_bounces b JOIN loans l ON l.id = b.loan_id
        WHERE l.customer_id = $1 ORDER BY b.bounce_date DESC`,
      [params.id],
    );
  },
});
