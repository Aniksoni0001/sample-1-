import { Router } from 'express';
import { z } from 'zod';
import { route } from '../lib/http.js';
import { respondList } from '../lib/listing.js';
import { isoDate, listQuerySchema, orderBy, Sql } from '../lib/sql.js';
import { executiveScope } from '../middleware/auth.js';

export const router = Router();

route(router, '/api/emi-schedules', {
  method: 'get',
  path: '',
  tag: 'EMI',
  summary: 'Installments across loans, filterable by loan, customer, due date and status',
  permission: 'loans.read',
  query: listQuerySchema.extend({
    loanId: z.coerce.number().int().optional(),
    customerId: z.coerce.number().int().optional(),
    dueFrom: isoDate.optional(),
    dueTo: isoDate.optional(),
    status: z.enum(['UPCOMING', 'DUE', 'PARTIALLY_PAID', 'PAID', 'OVERDUE', 'BOUNCED', 'WAIVED']).optional(),
    productId: z.coerce.number().int().optional(),
  }),
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    if (q.loanId) sql.and(`e.loan_id = ${sql.p(q.loanId)}`);
    if (q.customerId) sql.and(`l.customer_id = ${sql.p(q.customerId)}`);
    if (q.dueFrom) sql.and(`e.due_date >= ${sql.p(q.dueFrom)}`);
    if (q.dueTo) sql.and(`e.due_date <= ${sql.p(q.dueTo)}`);
    if (q.status) sql.and(`e.status = ${sql.p(q.status)}`);
    if (q.productId) sql.and(`l.product_id = ${sql.p(q.productId)}`);
    if (q.search) {
      const s = sql.p(`%${q.search}%`);
      sql.and(`(l.loan_number ILIKE ${s} OR c.full_name ILIKE ${s} OR c.customer_code ILIKE ${s})`);
    }
    const exec = executiveScope(ctx.user);
    if (exec)
      sql.and(`EXISTS (SELECT 1 FROM collection_assignments a WHERE a.loan_id = e.loan_id AND a.is_active AND a.executive_id = ${sql.p(exec)})`);
    await respondList(ctx, {
      select: `e.*, l.loan_number, l.customer_id, c.customer_code, c.full_name AS customer_name, p.name AS product_name`,
      from: `emi_schedules e JOIN loans l ON l.id = e.loan_id JOIN customers c ON c.id = l.customer_id JOIN loan_products p ON p.id = l.product_id`,
      sql,
      order: orderBy(q, { dueDate: 'e.due_date', loanNumber: 'l.loan_number', emiAmount: 'e.emi_amount', remainingAmount: 'e.remaining_amount', status: 'e.status', dpd: 'e.dpd', customerName: 'c.full_name' }, 'e.due_date ASC, l.loan_number'),
      title: 'EMI Schedule',
      columns: [
        { key: 'loanNumber', label: 'Loan ID' },
        { key: 'customerName', label: 'Customer' },
        { key: 'installmentNo', label: 'EMI #', type: 'number' },
        { key: 'dueDate', label: 'Due Date', type: 'date' },
        { key: 'principalComponent', label: 'Principal', type: 'money' },
        { key: 'interestComponent', label: 'Interest', type: 'money' },
        { key: 'emiAmount', label: 'EMI', type: 'money' },
        { key: 'amountPaid', label: 'Paid', type: 'money' },
        { key: 'remainingAmount', label: 'Remaining', type: 'money' },
        { key: 'status', label: 'Status' },
        { key: 'dpd', label: 'DPD', type: 'number' },
      ],
    });
  },
});
