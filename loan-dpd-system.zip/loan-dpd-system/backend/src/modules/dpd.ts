import { Router } from 'express';
import { z } from 'zod';
import { one, pool, query, tx } from '../db/pool.js';
import { badRequest, conflict } from '../lib/errors.js';
import { route } from '../lib/http.js';
import { audit, respondList } from '../lib/listing.js';
import { isoDate, listQuerySchema, orderBy, Sql } from '../lib/sql.js';
import { validateBuckets } from '../lib/dpd.js';
import { executiveScope, type AuthUser } from '../middleware/auth.js';
import { nextScheduledRun } from '../jobs/scheduler.js';

export const router = Router();
const BASE = '/api/dpd';

export const portfolioFilters = z.object({
  businessDate: isoDate.optional(),
  productId: z.coerce.number().int().optional(),
  branchId: z.coerce.number().int().optional(),
  executiveId: z.coerce.number().int().optional(),
  state: z.string().max(80).optional(),
  bucket: z.string().max(20).optional(),
  status: z.enum(['DISBURSED', 'ACTIVE', 'OVERDUE']).optional(),
});
type PortfolioFilters = z.infer<typeof portfolioFilters>;

export async function currentBusinessDate(): Promise<string> {
  return (await one<{ d: string }>(`SELECT fn_business_date()::text AS d`))!.d;
}

/**
 * The live book (dpd_current) for the current business date, or the immutable
 * snapshot for any earlier date — same columns either way, so every query
 * below works on both.
 */
export async function portfolioSource(f: PortfolioFilters, user: AuthUser, sql: Sql) {
  const bd = await currentBusinessDate();
  const date = f.businessDate ?? bd;
  let source: string;
  if (date === bd) {
    source = `(SELECT d.loan_id, d.business_date, d.dpd, d.bucket_code, b.sort_order AS bucket_sort_order, d.overdue_emi_count,
                      d.overdue_amount, d.overdue_charges, d.oldest_overdue_date, d.outstanding_principal, d.last_payment_date,
                      d.next_emi_due_date, d.account_status, l.product_id, l.branch_id, a.executive_id, c.state
                 FROM dpd_current d JOIN loans l ON l.id = d.loan_id JOIN customers c ON c.id = l.customer_id
                 JOIN dpd_bucket_config b ON b.code = d.bucket_code
                 LEFT JOIN collection_assignments a ON a.loan_id = d.loan_id AND a.is_active
                WHERE d.account_status IN ('DISBURSED','ACTIVE','OVERDUE')) src`;
  } else {
    if (date > bd) throw badRequest(`No data after the current business date ${bd}`);
    source = `(SELECT * FROM dpd_daily_snapshots WHERE business_date = ${sql.p(date)}) src`;
  }
  if (f.productId) sql.and(`src.product_id = ${sql.p(f.productId)}`);
  if (f.branchId) sql.and(`src.branch_id = ${sql.p(f.branchId)}`);
  if (f.executiveId) sql.and(`src.executive_id = ${sql.p(f.executiveId)}`);
  if (f.state) sql.and(`src.state = ${sql.p(f.state)}`);
  if (f.bucket) sql.and(`src.bucket_code = ${sql.p(f.bucket)}`);
  if (f.status) sql.and(`src.account_status = ${sql.p(f.status)}`);
  const exec = executiveScope(user);
  if (exec) sql.and(`src.executive_id = ${sql.p(exec)}`);
  return { source, date, isLive: date === bd, currentBusinessDate: bd };
}

route(router, BASE, {
  method: 'get',
  path: '/current',
  tag: 'DPD',
  summary: 'Loan-level DPD positions (live or for a past business date). format=csv|xlsx|pdf exports.',
  permission: 'dpd.read',
  query: listQuerySchema.merge(portfolioFilters).extend({ dpdMin: z.coerce.number().int().optional(), dpdMax: z.coerce.number().int().optional() }),
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    const { source } = await portfolioSource(q, ctx.user, sql);
    if (q.dpdMin !== undefined) sql.and(`src.dpd >= ${sql.p(q.dpdMin)}`);
    if (q.dpdMax !== undefined) sql.and(`src.dpd <= ${sql.p(q.dpdMax)}`);
    if (q.search) {
      const s = sql.p(`%${q.search}%`);
      sql.and(`(l.loan_number ILIKE ${s} OR c.full_name ILIKE ${s} OR c.customer_code ILIKE ${s})`);
    }
    await respondList(ctx, {
      select: `src.*, l.loan_number, l.emi_amount, c.id AS customer_id, c.customer_code, c.full_name AS customer_name, c.mobile,
               p.name AS product_name, br.name AS branch_name, u.full_name AS executive_name`,
      from: `${source} JOIN loans l ON l.id = src.loan_id JOIN customers c ON c.id = l.customer_id
             JOIN loan_products p ON p.id = src.product_id LEFT JOIN branches br ON br.id = src.branch_id
             LEFT JOIN users u ON u.id = src.executive_id`,
      sql,
      pii: true,
      order: orderBy(
        q,
        { dpd: 'src.dpd', overdueAmount: 'src.overdue_amount', outstandingPrincipal: 'src.outstanding_principal', loanNumber: 'l.loan_number', customerName: 'c.full_name', oldestOverdueDate: 'src.oldest_overdue_date', lastPaymentDate: 'src.last_payment_date', nextEmiDueDate: 'src.next_emi_due_date' },
        'src.dpd DESC, src.overdue_amount DESC',
      ),
      title: 'DPD Accounts',
      columns: [
        { key: 'businessDate', label: 'Business Date', type: 'date' },
        { key: 'loanNumber', label: 'Loan ID' },
        { key: 'customerName', label: 'Customer' },
        { key: 'productName', label: 'Product' },
        { key: 'state', label: 'State' },
        { key: 'dpd', label: 'DPD', type: 'number' },
        { key: 'bucketCode', label: 'Bucket' },
        { key: 'overdueEmiCount', label: 'Overdue EMIs', type: 'number' },
        { key: 'overdueAmount', label: 'Overdue', type: 'money' },
        { key: 'overdueCharges', label: 'Charges', type: 'money' },
        { key: 'outstandingPrincipal', label: 'POS', type: 'money' },
        { key: 'oldestOverdueDate', label: 'Oldest Overdue', type: 'date' },
        { key: 'lastPaymentDate', label: 'Last Payment', type: 'date' },
        { key: 'executiveName', label: 'Executive' },
      ],
    });
  },
});

/** Bucket table + PAR for a date and filter set. Totals are summed from the same rows, so they always reconcile. */
export async function bucketPortfolio(f: PortfolioFilters, user: AuthUser) {
  const sql = new Sql();
  const { source, date, isLive, currentBusinessDate: bd } = await portfolioSource({ ...f, bucket: undefined }, user, sql);
  const rows = await query(
    `SELECT b.code AS bucket_code, b.label, b.sort_order, b.color, b.min_dpd, b.max_dpd,
            count(src.loan_id)::int AS account_count,
            COALESCE(sum(src.outstanding_principal), 0) AS outstanding_principal,
            COALESCE(sum(src.overdue_amount), 0) AS overdue_amount
       FROM dpd_bucket_config b
       LEFT JOIN (SELECT src.* FROM ${source} ${sql.where}) src ON src.bucket_code = b.code
      WHERE b.is_active
      GROUP BY b.code, b.label, b.sort_order, b.color, b.min_dpd, b.max_dpd
      ORDER BY b.sort_order`,
    sql.params,
  );
  const par = await one(
    `SELECT count(*)::int AS total_accounts, COALESCE(sum(outstanding_principal), 0) AS total_pos,
            COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 0), 0)  AS par0_pos,
            COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 30), 0) AS par30_pos,
            COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 60), 0) AS par60_pos,
            COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 90), 0) AS par90_pos,
            count(*) FILTER (WHERE dpd > 30)::int AS par30_accounts,
            count(*) FILTER (WHERE dpd > 60)::int AS par60_accounts,
            count(*) FILTER (WHERE dpd > 90)::int AS par90_accounts,
            count(*) FILTER (WHERE dpd >= 90)::int AS npa_accounts
       FROM ${source} ${sql.where}`,
    sql.params,
  );
  const pct = (x: number) => (par.totalPos > 0 ? Math.round((x * 10000) / par.totalPos) / 100 : 0);
  const totals = rows.reduce(
    (t: any, r: any) => ({
      accountCount: t.accountCount + r.accountCount,
      outstandingPrincipal: Math.round((t.outstandingPrincipal + r.outstandingPrincipal) * 100) / 100,
      overdueAmount: Math.round((t.overdueAmount + r.overdueAmount) * 100) / 100,
    }),
    { accountCount: 0, outstandingPrincipal: 0, overdueAmount: 0 },
  );
  return {
    businessDate: date,
    isLive,
    currentBusinessDate: bd,
    buckets: rows.map((r: any) => ({ ...r, pctOfPos: pct(r.outstandingPrincipal), pctOfAccounts: totals.accountCount ? Math.round((r.accountCount * 10000) / totals.accountCount) / 100 : 0 })),
    totals,
    par: { ...par, par0Pct: pct(par.par0Pos), par30Pct: pct(par.par30Pos), par60Pct: pct(par.par60Pos), par90Pct: pct(par.par90Pos) },
  };
}

route(router, BASE, {
  method: 'get',
  path: '/buckets',
  tag: 'DPD',
  summary: 'DPD bucket portfolio table with PAR 30/60/90 for a business date and filters',
  permission: 'dpd.read',
  query: portfolioFilters,
  handler: async ({ query: q, user }) => bucketPortfolio(q, user),
});

export async function movement(from: string, to: string, f: Omit<PortfolioFilters, 'businessDate'>, user: AuthUser) {
  if (from >= to) throw badRequest('"from" must be before "to"');
  const have = await query<{ businessDate: string }>(
    `SELECT DISTINCT business_date::text AS business_date FROM dpd_daily_snapshots WHERE business_date IN ($1::date, $2::date)`,
    [from, to],
  );
  const missing = [from, to].filter((d) => !have.some((h) => h.businessDate === d));
  if (missing.length) throw badRequest(`No DPD snapshot for ${missing.join(', ')}. Pick dates on which the daily job ran.`);

  const sql = new Sql([from, to]);
  const cond = (alias: string) => {
    const parts: string[] = [];
    if (f.productId) parts.push(`${alias}.product_id = ${sql.p(f.productId)}`);
    if (f.branchId) parts.push(`${alias}.branch_id = ${sql.p(f.branchId)}`);
    if (f.executiveId) parts.push(`${alias}.executive_id = ${sql.p(f.executiveId)}`);
    if (f.state) parts.push(`${alias}.state = ${sql.p(f.state)}`);
    const exec = executiveScope(user);
    if (exec) parts.push(`${alias}.executive_id = ${sql.p(exec)}`);
    return parts.length ? ' AND ' + parts.join(' AND ') : '';
  };
  const base = `
    WITH a AS (SELECT * FROM dpd_daily_snapshots s WHERE s.business_date = $1 ${cond('s')}),
         b AS (SELECT * FROM dpd_daily_snapshots s WHERE s.business_date = $2 ${cond('s')}),
         j AS (SELECT COALESCE(a.loan_id, b.loan_id) AS loan_id, a.bucket_code AS from_bucket, a.bucket_sort_order AS from_ord,
                      b.bucket_code AS to_bucket, b.bucket_sort_order AS to_ord, a.outstanding_principal AS from_pos,
                      b.outstanding_principal AS to_pos, a.dpd AS from_dpd, b.dpd AS to_dpd
                 FROM a FULL JOIN b ON a.loan_id = b.loan_id)`;
  const matrix = await query(
    `${base} SELECT COALESCE(from_bucket, 'NEW') AS from_bucket, COALESCE(to_bucket, 'EXITED') AS to_bucket,
                    count(*)::int AS accounts, COALESCE(sum(COALESCE(to_pos, from_pos)), 0) AS pos
               FROM j GROUP BY 1, 2`,
    sql.params,
  );
  const summary = await one(
    `${base} SELECT
        count(*) FILTER (WHERE from_ord IS NOT NULL AND to_ord IS NOT NULL AND to_ord > from_ord)::int AS rolled_forward,
        count(*) FILTER (WHERE from_ord IS NOT NULL AND to_ord IS NOT NULL AND to_ord < from_ord)::int AS rolled_backward,
        count(*) FILTER (WHERE from_ord IS NOT NULL AND to_ord IS NOT NULL AND to_ord = from_ord)::int AS stable,
        count(*) FILTER (WHERE from_dpd > 0 AND to_dpd = 0)::int AS cured,
        count(*) FILTER (WHERE from_dpd = 0 AND to_dpd > 0)::int AS newly_overdue,
        count(*) FILTER (WHERE from_ord IS NULL)::int AS new_accounts,
        count(*) FILTER (WHERE to_ord IS NULL)::int AS exited_accounts,
        COALESCE(sum(to_pos) FILTER (WHERE to_ord > from_ord), 0) AS rolled_forward_pos,
        COALESCE(sum(to_pos) FILTER (WHERE from_dpd > 0 AND to_dpd = 0), 0) AS cured_pos
       FROM j`,
    sql.params,
  );
  const recovery = await query(
    `${base}
     SELECT bc.code AS bucket_code, bc.label, bc.sort_order,
            count(DISTINCT p.loan_id)::int AS paying_accounts,
            COALESCE(sum(p.amount), 0) AS recovered_amount
       FROM dpd_bucket_config bc
       LEFT JOIN a ON a.bucket_code = bc.code
       LEFT JOIN payments p ON p.loan_id = a.loan_id AND p.status = 'SUCCESSFUL' AND p.payment_date >= $1 AND p.payment_date < $2
      WHERE bc.is_active GROUP BY bc.code, bc.label, bc.sort_order ORDER BY bc.sort_order`,
    sql.params,
  );
  return { from, to, matrix, summary, recovery };
}

route(router, BASE, {
  method: 'get',
  path: '/movement',
  tag: 'DPD',
  summary: 'Bucket movement between two snapshot dates: roll forward/back, cured, newly overdue, recovery by bucket',
  permission: 'dpd.read',
  query: portfolioFilters.omit({ businessDate: true, bucket: true, status: true }).extend({ from: isoDate, to: isoDate }),
  handler: async ({ query: q, user }) => movement(q.from, q.to, q, user),
});

route(router, BASE, {
  method: 'get',
  path: '/trend',
  tag: 'DPD',
  summary: 'Daily portfolio bucket summary over a period',
  permission: 'dpd.read',
  query: z.object({ from: isoDate, to: isoDate }),
  handler: async ({ query: q }) =>
    query(
      `SELECT business_date, bucket_code, bucket_sort_order, account_count, outstanding_principal, overdue_amount
         FROM portfolio_daily_summary WHERE business_date BETWEEN $1 AND $2 ORDER BY business_date, bucket_sort_order`,
      [q.from, q.to],
    ),
});

route(router, BASE, {
  method: 'get',
  path: '/snapshots',
  tag: 'DPD',
  summary: 'Immutable daily DPD snapshots (format=csv|xlsx|pdf exports)',
  permission: 'dpd.read',
  query: listQuerySchema.extend({
    businessDate: isoDate.optional(),
    from: isoDate.optional(),
    to: isoDate.optional(),
    loanId: z.coerce.number().int().optional(),
    bucket: z.string().max(20).optional(),
  }),
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    if (q.businessDate) sql.and(`s.business_date = ${sql.p(q.businessDate)}`);
    if (q.from) sql.and(`s.business_date >= ${sql.p(q.from)}`);
    if (q.to) sql.and(`s.business_date <= ${sql.p(q.to)}`);
    if (q.loanId) sql.and(`s.loan_id = ${sql.p(q.loanId)}`);
    if (q.bucket) sql.and(`s.bucket_code = ${sql.p(q.bucket)}`);
    if (q.search) sql.and(`l.loan_number ILIKE ${sql.p(`%${q.search}%`)}`);
    if (!q.businessDate && !q.from && !q.loanId) sql.and(`s.business_date = (SELECT max(business_date) FROM dpd_daily_snapshots)`);
    const exec = executiveScope(ctx.user);
    if (exec) sql.and(`s.executive_id = ${sql.p(exec)}`);
    await respondList(ctx, {
      select: `s.*, l.loan_number, c.full_name AS customer_name`,
      from: `dpd_daily_snapshots s JOIN loans l ON l.id = s.loan_id JOIN customers c ON c.id = l.customer_id`,
      sql,
      order: orderBy(q, { businessDate: 's.business_date', dpd: 's.dpd', loanNumber: 'l.loan_number', outstandingPrincipal: 's.outstanding_principal', overdueAmount: 's.overdue_amount' }, 's.business_date DESC, s.dpd DESC'),
      title: 'Historical DPD Snapshots',
      columns: [
        { key: 'businessDate', label: 'Business Date', type: 'date' },
        { key: 'loanNumber', label: 'Loan ID' },
        { key: 'customerName', label: 'Customer' },
        { key: 'dpd', label: 'DPD', type: 'number' },
        { key: 'bucketCode', label: 'Bucket' },
        { key: 'overdueEmiCount', label: 'Overdue EMIs', type: 'number' },
        { key: 'overdueAmount', label: 'Overdue', type: 'money' },
        { key: 'outstandingPrincipal', label: 'POS', type: 'money' },
        { key: 'accountStatus', label: 'Status' },
      ],
    });
  },
});

/** CALL must run outside BEGIN/COMMIT because the procedure manages its own transactions. */
export async function runDailyDpd(businessDate: string | null, trigger: 'SCHEDULED' | 'MANUAL' | 'RETRY' | 'SEED', userId: number | null) {
  const client = await pool.connect();
  try {
    const date = businessDate ?? (await client.query(`SELECT fn_calendar_today()::text AS d`)).rows[0].d;
    const r = await client.query(`CALL sp_update_daily_dpd($1::date, $2, $3, NULL, NULL)`, [date, trigger, userId]);
    const { p_job_id, p_status } = r.rows[0];
    const job = await one(`SELECT * FROM job_execution_logs WHERE id = $1`, [p_job_id]);
    return { jobId: p_job_id as number, status: p_status as string, job };
  } finally {
    client.release();
  }
}

route(router, BASE, {
  method: 'post',
  path: '/run',
  tag: 'DPD',
  summary: 'Run (or retry) the daily DPD job for a business date (default: today in the business timezone)',
  permission: 'dpd.run',
  status: 200,
  body: z.object({ businessDate: isoDate.optional(), retry: z.boolean().default(false) }),
  handler: async ({ body, user, db }) => {
    const running = await one(`SELECT id FROM job_execution_logs WHERE job_name = 'DAILY_DPD' AND status = 'RUNNING' AND started_at > now() - interval '30 minutes'`);
    if (running) throw conflict('A DPD run is already in progress');
    const result = await runDailyDpd(body.businessDate ?? null, body.retry ? 'RETRY' : 'MANUAL', user.id);
    await audit(db, 'DPD_RUN', 'job_execution_logs', result.jobId, { businessDate: body.businessDate, status: result.status });
    return result;
  },
});

route(router, BASE, {
  method: 'get',
  path: '/jobs',
  tag: 'DPD',
  summary: 'Daily DPD job history and status',
  permission: 'jobs.read',
  query: listQuerySchema.extend({ status: z.enum(['RUNNING', 'SUCCESS', 'FAILED', 'SKIPPED']).optional() }),
  handler: async ({ query: q }) => {
    const sql = new Sql();
    sql.and(`j.job_name = 'DAILY_DPD'`);
    if (q.status) sql.and(`j.status = ${sql.p(q.status)}`);
    const rows = await query(
      `SELECT j.*, u.full_name AS triggered_by_name, EXTRACT(EPOCH FROM (j.finished_at - j.started_at)) * 1000 AS duration_ms
         FROM job_execution_logs j LEFT JOIN users u ON u.id = j.triggered_by ${sql.where}
        ORDER BY j.id DESC LIMIT ${sql.p(q.pageSize)} OFFSET ${sql.p((q.page - 1) * q.pageSize)}`,
      sql.params,
    );
    const total = await one<{ n: number }>(`SELECT count(*)::int AS n FROM job_execution_logs j ${sql.where}`, sql.params.slice(0, sql.params.length - 2));
    const meta = await one(
      `SELECT (SELECT max(business_date)::text FROM job_execution_logs WHERE job_name='DAILY_DPD' AND status='SUCCESS') AS last_successful_business_date,
              fn_business_date()::text AS business_date, fn_calendar_today()::text AS calendar_today,
              fn_setting('dpd_job_cron') AS cron, fn_setting('dpd_job_enabled') AS enabled,
              fn_setting('business_timezone') AS timezone,
              (SELECT count(*) FROM job_execution_logs WHERE job_name='DAILY_DPD' AND status='RUNNING')::int AS running`,
    );
    return { data: rows, total: total?.n ?? 0, page: q.page, pageSize: q.pageSize, meta: { ...meta, nextRun: nextScheduledRun() } };
  },
});

route(router, BASE, {
  method: 'get',
  path: '/bucket-config',
  tag: 'DPD',
  summary: 'Configured DPD buckets',
  permission: 'dpd.read',
  handler: async () => query(`SELECT * FROM dpd_bucket_config ORDER BY sort_order`),
});

route(router, BASE, {
  method: 'put',
  path: '/bucket-config',
  tag: 'DPD',
  summary: 'Replace the DPD bucket configuration (applies to live positions now and to future snapshots; history is untouched)',
  permission: 'config.manage',
  body: z.object({
    buckets: z
      .array(
        z.object({
          code: z.string().trim().regex(/^[A-Z0-9_]{2,20}$/),
          label: z.string().trim().min(1).max(40),
          minDpd: z.coerce.number().int().min(0),
          maxDpd: z.coerce.number().int().min(0).nullable(),
          color: z.string().regex(/^#[0-9a-fA-F]{6}$/).default('#64748b'),
        }),
      )
      .min(2)
      .max(12),
  }),
  handler: async ({ body, db }) => {
    const sorted = [...body.buckets].sort((a, b) => a.minDpd - b.minDpd).map((b, i) => ({ ...b, sortOrder: i + 1 }));
    const err = validateBuckets(sorted);
    if (err) throw badRequest(err);
    if (new Set(sorted.map((b) => b.code)).size !== sorted.length) throw badRequest('Bucket codes must be unique');
    await tx(db, async (c) => {
      // move existing sort orders out of the way (sort_order is UNIQUE)
      await c.query(`UPDATE dpd_bucket_config SET sort_order = sort_order + 100`);
      await c.query(`UPDATE dpd_bucket_config SET is_active = FALSE WHERE code <> ALL ($1::text[])`, [sorted.map((b) => b.code)]);
      let deactivatedOrder = 200;
      for (const r of await query<{ code: string }>(`SELECT code FROM dpd_bucket_config WHERE NOT is_active`, [], c))
        await c.query(`UPDATE dpd_bucket_config SET sort_order = $2 WHERE code = $1`, [r.code, deactivatedOrder++]);
      for (const b of sorted) {
        await c.query(
          `INSERT INTO dpd_bucket_config (code, label, min_dpd, max_dpd, sort_order, color, is_active)
           VALUES ($1,$2,$3,$4,$5,$6,TRUE)
           ON CONFLICT (code) DO UPDATE SET label=EXCLUDED.label, min_dpd=EXCLUDED.min_dpd, max_dpd=EXCLUDED.max_dpd,
             sort_order=EXCLUDED.sort_order, color=EXCLUDED.color, is_active=TRUE`,
          [b.code, b.label, b.minDpd, b.maxDpd, b.sortOrder, b.color],
        );
      }
      await c.query(`SELECT fn_upsert_dpd_current(fn_business_date(), NULL)`);
    });
    return query(`SELECT * FROM dpd_bucket_config WHERE is_active ORDER BY sort_order`);
  },
});
