import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import cron from 'node-cron';
import { one, query, tx } from '../db/pool.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { route } from '../lib/http.js';
import { respondList } from '../lib/listing.js';
import { idParam, isoDate, listQuerySchema, orderBy, Sql } from '../lib/sql.js';
import { invalidateUserCache } from '../middleware/auth.js';
import { passwordSchema } from './auth.js';
import { startScheduler } from '../jobs/scheduler.js';

export const router = Router();

// ------------------------------------------------------------------ users
route(router, '/api/users', {
  method: 'get',
  path: '',
  tag: 'Users',
  summary: 'List users',
  permission: 'users.read',
  query: listQuerySchema.extend({ roleId: z.coerce.number().int().optional(), active: z.enum(['true', 'false']).optional() }),
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    sql.and('u.deleted_at IS NULL');
    if (q.search) {
      const s = sql.p(`%${q.search}%`);
      sql.and(`(u.full_name ILIKE ${s} OR u.email ILIKE ${s})`);
    }
    if (q.roleId) sql.and(`u.role_id = ${sql.p(q.roleId)}`);
    if (q.active) sql.and(`u.is_active = ${sql.p(q.active === 'true')}`);
    await respondList(ctx, {
      select: `u.id, u.email, u.full_name, u.phone, u.role_id, r.code AS role_code, r.name AS role_name, u.branch_id, b.name AS branch_name,
               u.is_active, u.last_login_at, u.locked_until, u.created_at,
               (SELECT count(*) FROM collection_assignments a WHERE a.executive_id = u.id AND a.is_active)::int AS assigned_accounts`,
      from: 'users u JOIN roles r ON r.id = u.role_id LEFT JOIN branches b ON b.id = u.branch_id',
      sql,
      order: orderBy(q, { fullName: 'u.full_name', email: 'u.email', roleName: 'r.name', lastLoginAt: 'u.last_login_at', createdAt: 'u.created_at' }, 'u.full_name ASC'),
      title: 'Users',
      columns: [
        { key: 'fullName', label: 'Name' },
        { key: 'email', label: 'Email' },
        { key: 'roleName', label: 'Role' },
        { key: 'branchName', label: 'Branch' },
        { key: 'isActive', label: 'Active' },
        { key: 'lastLoginAt', label: 'Last Login' },
      ],
    });
  },
});

async function guardRole(actorRole: string, roleId: number) {
  const r = await one<{ code: string }>(`SELECT code FROM roles WHERE id = $1`, [roleId]);
  if (!r) throw badRequest('Unknown role');
  if (r.code === 'SUPER_ADMIN' && actorRole !== 'SUPER_ADMIN') throw forbidden('Only a Super Admin can grant Super Admin');
}

route(router, '/api/users', {
  method: 'post',
  path: '',
  tag: 'Users',
  summary: 'Create a user',
  permission: 'users.manage',
  body: z.object({
    email: z.string().trim().toLowerCase().email(),
    fullName: z.string().trim().min(2).max(120),
    phone: z.string().trim().max(15).optional().nullable(),
    roleId: z.coerce.number().int().positive(),
    branchId: z.coerce.number().int().positive().optional().nullable(),
    password: passwordSchema,
  }),
  handler: async ({ body, user, db }) => {
    await guardRole(user.role, body.roleId);
    const hash = await bcrypt.hash(body.password, 12);
    return tx(db, (c) =>
      one(
        `INSERT INTO users (email, full_name, phone, role_id, branch_id, password_hash) VALUES ($1,$2,$3,$4,$5,$6)
         RETURNING id, email, full_name, role_id, is_active`,
        [body.email, body.fullName, body.phone ?? null, body.roleId, body.branchId ?? null, hash],
        c,
      ),
    );
  },
});

route(router, '/api/users', {
  method: 'put',
  path: '/:id',
  tag: 'Users',
  summary: 'Edit a user / activate / deactivate / change role',
  permission: 'users.manage',
  params: idParam,
  body: z.object({
    fullName: z.string().trim().min(2).max(120).optional(),
    phone: z.string().trim().max(15).optional().nullable(),
    roleId: z.coerce.number().int().positive().optional(),
    branchId: z.coerce.number().int().positive().optional().nullable(),
    isActive: z.boolean().optional(),
  }),
  handler: async ({ params, body, user, db }) => {
    const target = await one<any>(`SELECT u.id, r.code AS role FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1 AND u.deleted_at IS NULL`, [params.id]);
    if (!target) throw notFound('User');
    if (target.role === 'SUPER_ADMIN' && user.role !== 'SUPER_ADMIN') throw forbidden('Only a Super Admin can edit a Super Admin');
    if (params.id === user.id && (body.isActive === false || (body.roleId && body.roleId !== undefined))) {
      const me = await one<{ roleId: number }>(`SELECT role_id FROM users WHERE id = $1`, [user.id]);
      if (body.isActive === false || body.roleId !== me?.roleId) throw badRequest('You cannot deactivate yourself or change your own role');
    }
    if (body.roleId) await guardRole(user.role, body.roleId);
    const sets: string[] = [];
    const vals: unknown[] = [params.id];
    const add = (col: string, v: unknown) => {
      vals.push(v);
      sets.push(`${col} = $${vals.length}`);
    };
    if (body.fullName !== undefined) add('full_name', body.fullName);
    if (body.phone !== undefined) add('phone', body.phone);
    if (body.roleId !== undefined) add('role_id', body.roleId);
    if (body.branchId !== undefined) add('branch_id', body.branchId);
    if (body.isActive !== undefined) add('is_active', body.isActive);
    if (!sets.length) return { ok: true };
    const row = await tx(db, async (c) => {
      const r = await one(`UPDATE users SET ${sets.join(', ')} WHERE id = $1 RETURNING id, email, full_name, role_id, is_active`, vals, c);
      if (body.isActive === false) {
        await c.query(`UPDATE user_sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL`, [params.id]);
        await c.query(`UPDATE collection_assignments SET is_active = FALSE, unassigned_at = now(), remarks = 'Executive deactivated' WHERE executive_id = $1 AND is_active`, [params.id]);
      }
      return r;
    });
    invalidateUserCache(params.id);
    return row;
  },
});

route(router, '/api/users', {
  method: 'post',
  path: '/:id/reset-password',
  tag: 'Users',
  summary: 'Set a temporary password for a user (ends their sessions)',
  permission: 'users.manage',
  params: idParam,
  status: 200,
  body: z.object({ password: passwordSchema }),
  handler: async ({ params, body, user, db }) => {
    const target = await one<any>(`SELECT r.code AS role FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1`, [params.id]);
    if (!target) throw notFound('User');
    if (target.role === 'SUPER_ADMIN' && user.role !== 'SUPER_ADMIN') throw forbidden();
    const hash = await bcrypt.hash(body.password, 12);
    await tx(db, async (c) => {
      await c.query(`UPDATE users SET password_hash = $2, password_changed_at = now(), failed_login_count = 0, locked_until = NULL WHERE id = $1`, [params.id, hash]);
      await c.query(`UPDATE user_sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL`, [params.id]);
    });
    invalidateUserCache(params.id);
    return { ok: true };
  },
});

route(router, '/api/users', {
  method: 'get',
  path: '/:id/activity',
  tag: 'Users',
  summary: 'Login history and recent actions of a user',
  permission: 'users.read',
  params: idParam,
  handler: async ({ params }) => ({
    logins: await query(`SELECT id, success, reason, ip, user_agent, created_at FROM login_history WHERE user_id = $1 ORDER BY id DESC LIMIT 100`, [params.id]),
    actions: await query(`SELECT id, action, entity_type, entity_id, created_at FROM audit_logs WHERE user_id = $1 ORDER BY id DESC LIMIT 200`, [params.id]),
  }),
});

// ------------------------------------------------------------------ roles & permissions
route(router, '/api/roles', {
  method: 'get',
  path: '',
  tag: 'Roles',
  summary: 'Roles with their permissions and user counts',
  permission: ['users.read', 'roles.manage'],
  handler: async () =>
    query(
      `SELECT r.*, (SELECT count(*) FROM users u WHERE u.role_id = r.id AND u.deleted_at IS NULL)::int AS user_count,
              COALESCE((SELECT json_agg(p.code ORDER BY p.code) FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = r.id), '[]') AS permissions
         FROM roles r ORDER BY r.id`,
    ),
});

route(router, '/api/roles', {
  method: 'get',
  path: '/permissions',
  tag: 'Roles',
  summary: 'All permissions',
  permission: ['users.read', 'roles.manage'],
  handler: async () => query(`SELECT * FROM permissions ORDER BY module, code`),
});

route(router, '/api/roles', {
  method: 'put',
  path: '/:id/permissions',
  tag: 'Roles',
  summary: 'Replace the permission set of a role',
  permission: 'roles.manage',
  params: idParam,
  body: z.object({ permissions: z.array(z.string().max(64)).max(100) }),
  handler: async ({ params, body, db }) => {
    const role = await one<{ code: string }>(`SELECT code FROM roles WHERE id = $1`, [params.id]);
    if (!role) throw notFound('Role');
    if (role.code === 'SUPER_ADMIN' && !body.permissions.includes('roles.manage')) throw badRequest('Super Admin must keep roles.manage');
    await tx(db, async (c) => {
      await c.query(`DELETE FROM role_permissions WHERE role_id = $1`, [params.id]);
      await c.query(`INSERT INTO role_permissions (role_id, permission_id) SELECT $1, id FROM permissions WHERE code = ANY($2::text[])`, [params.id, body.permissions]);
      await c.query(`INSERT INTO audit_logs (user_id, action, entity_type, entity_id, new_values) VALUES (NULLIF(current_setting('app.user_id', true), '')::int, 'PERMISSIONS', 'roles', $1, $2)`, [
        String(params.id),
        JSON.stringify({ permissions: body.permissions }),
      ]);
    });
    invalidateUserCache();
    return { ok: true };
  },
});

// ------------------------------------------------------------------ configuration
const SETTING_RULES: Record<string, z.ZodType<string>> = {
  business_timezone: z.string().refine((v) => {
    try {
      new Intl.DateTimeFormat('en', { timeZone: v });
      return true;
    } catch {
      return false;
    }
  }, 'Unknown IANA timezone'),
  company_name: z.string().min(2).max(100),
  dpd_grace_days: z.string().regex(/^\d{1,2}$/, '0–99'),
  emi_rounding_places: z.enum(['0', '1', '2']),
  allocation_waterfall: z.enum(['EMI_ORDER', 'CHARGES_FIRST', 'INTEREST_FIRST']),
  due_date_holiday_rule: z.enum(['NONE', 'NEXT_WORKING_DAY', 'PREVIOUS_WORKING_DAY']),
  sunday_is_holiday: z.enum(['true', 'false']),
  bounce_charge_override: z.string().regex(/^(\d{1,6}(\.\d{1,2})?)?$/, 'Amount or blank'),
  write_off_min_dpd: z.string().regex(/^\d{1,4}$/),
  dpd_job_enabled: z.enum(['true', 'false']),
  dpd_job_cron: z.string().refine((v) => cron.validate(v), 'Invalid cron expression'),
};

route(router, '/api/config', {
  method: 'get',
  path: '/settings',
  tag: 'Configuration',
  summary: 'System settings',
  handler: async () => query(`SELECT key, value, data_type, description, is_editable, updated_at FROM system_settings ORDER BY key`),
});

route(router, '/api/config', {
  method: 'put',
  path: '/settings',
  tag: 'Configuration',
  summary: 'Update one or more editable settings (validated per key)',
  permission: 'config.manage',
  body: z.object({ settings: z.record(z.string(), z.string().max(200)) }),
  handler: async ({ body, user, db }) => {
    const entries = Object.entries(body.settings);
    for (const [k, v] of entries) {
      const rule = SETTING_RULES[k];
      if (!rule) throw badRequest(`Setting ${k} is not editable`);
      const r = rule.safeParse(v);
      if (!r.success) throw badRequest(`${k}: ${r.error.issues[0].message}`);
    }
    await tx(db, async (c) => {
      for (const [k, v] of entries) await c.query(`UPDATE system_settings SET value = $2, updated_by = $3, updated_at = now() WHERE key = $1 AND is_editable`, [k, v, user.id]);
      if (entries.some(([k]) => ['dpd_grace_days', 'dpd_job_enabled'].includes(k))) await c.query(`SELECT fn_upsert_dpd_current(fn_business_date(), NULL)`);
    });
    if (entries.some(([k]) => k.startsWith('dpd_job') || k === 'business_timezone')) await startScheduler();
    return query(`SELECT key, value, data_type, description, is_editable, updated_at FROM system_settings ORDER BY key`);
  },
});

const productBody = z.object({
  code: z.string().trim().toUpperCase().regex(/^[A-Z0-9_]{2,10}$/),
  name: z.string().trim().min(2).max(80),
  minAmount: z.coerce.number().positive(),
  maxAmount: z.coerce.number().positive(),
  minTenureMonths: z.coerce.number().int().min(1),
  maxTenureMonths: z.coerce.number().int().max(360),
  defaultRate: z.coerce.number().min(0).max(60),
  processingFeePct: z.coerce.number().min(0).max(10),
  bounceCharge: z.coerce.number().min(0).max(10000),
  isActive: z.boolean().default(true),
});

route(router, '/api/config', {
  method: 'get',
  path: '/products',
  tag: 'Configuration',
  summary: 'Loan products',
  handler: async () => query(`SELECT p.*, (SELECT count(*) FROM loans l WHERE l.product_id = p.id)::int AS loan_count FROM loan_products p ORDER BY p.id`),
});

route(router, '/api/config', {
  method: 'post',
  path: '/products',
  tag: 'Configuration',
  summary: 'Create a loan product',
  permission: 'config.manage',
  body: productBody,
  handler: async ({ body, db }) => {
    if (body.maxAmount < body.minAmount || body.maxTenureMonths < body.minTenureMonths) throw badRequest('Max must be ≥ min');
    return tx(db, (c) =>
      one(
        `INSERT INTO loan_products (code, name, min_amount, max_amount, min_tenure_months, max_tenure_months, default_rate, processing_fee_pct, bounce_charge, is_active)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
        [body.code, body.name, body.minAmount, body.maxAmount, body.minTenureMonths, body.maxTenureMonths, body.defaultRate, body.processingFeePct, body.bounceCharge, body.isActive],
        c,
      ),
    );
  },
});

route(router, '/api/config', {
  method: 'put',
  path: '/products/:id',
  tag: 'Configuration',
  summary: 'Edit a loan product (affects new loans only)',
  permission: 'config.manage',
  params: idParam,
  body: productBody,
  handler: async ({ params, body, db }) => {
    if (body.maxAmount < body.minAmount || body.maxTenureMonths < body.minTenureMonths) throw badRequest('Max must be ≥ min');
    const r = await tx(db, (c) =>
      one(
        `UPDATE loan_products SET code=$2, name=$3, min_amount=$4, max_amount=$5, min_tenure_months=$6, max_tenure_months=$7, default_rate=$8,
                processing_fee_pct=$9, bounce_charge=$10, is_active=$11 WHERE id = $1 RETURNING *`,
        [params.id, body.code, body.name, body.minAmount, body.maxAmount, body.minTenureMonths, body.maxTenureMonths, body.defaultRate, body.processingFeePct, body.bounceCharge, body.isActive],
        c,
      ),
    );
    if (!r) throw notFound('Product');
    return r;
  },
});

const branchBody = z.object({
  code: z.string().trim().toUpperCase().regex(/^[A-Z0-9_]{2,10}$/),
  name: z.string().trim().min(2).max(80),
  city: z.string().trim().min(2).max(80),
  state: z.string().trim().min(2).max(80),
  isActive: z.boolean().default(true),
});

route(router, '/api/config', {
  method: 'get',
  path: '/branches',
  tag: 'Configuration',
  summary: 'Branches',
  handler: async () => query(`SELECT * FROM branches WHERE deleted_at IS NULL ORDER BY name`),
});

route(router, '/api/config', {
  method: 'post',
  path: '/branches',
  tag: 'Configuration',
  summary: 'Create a branch',
  permission: 'config.manage',
  body: branchBody,
  handler: async ({ body, db }) =>
    tx(db, (c) => one(`INSERT INTO branches (code, name, city, state, is_active) VALUES ($1,$2,$3,$4,$5) RETURNING *`, [body.code, body.name, body.city, body.state, body.isActive], c)),
});

route(router, '/api/config', {
  method: 'put',
  path: '/branches/:id',
  tag: 'Configuration',
  summary: 'Edit a branch',
  permission: 'config.manage',
  params: idParam,
  body: branchBody,
  handler: async ({ params, body, db }) => {
    const r = await tx(db, (c) =>
      one(`UPDATE branches SET code=$2, name=$3, city=$4, state=$5, is_active=$6 WHERE id = $1 AND deleted_at IS NULL RETURNING *`, [params.id, body.code, body.name, body.city, body.state, body.isActive], c),
    );
    if (!r) throw notFound('Branch');
    return r;
  },
});

route(router, '/api/config', {
  method: 'get',
  path: '/holidays',
  tag: 'Configuration',
  summary: 'Holiday calendar used for due-date adjustment',
  handler: async () => query(`SELECT * FROM holidays ORDER BY holiday_date DESC`),
});

route(router, '/api/config', {
  method: 'post',
  path: '/holidays',
  tag: 'Configuration',
  summary: 'Add a holiday (affects schedules generated afterwards)',
  permission: 'config.manage',
  body: z.object({ holidayDate: isoDate, name: z.string().trim().min(2).max(80) }),
  handler: async ({ body, db }) => {
    const exists = await one(`SELECT 1 FROM holidays WHERE holiday_date = $1`, [body.holidayDate]);
    if (exists) throw conflict('A holiday already exists on that date');
    return tx(db, (c) => one(`INSERT INTO holidays (holiday_date, name) VALUES ($1, $2) RETURNING *`, [body.holidayDate, body.name], c));
  },
});

route(router, '/api/config', {
  method: 'delete',
  path: '/holidays/:date',
  tag: 'Configuration',
  summary: 'Remove a holiday',
  permission: 'config.manage',
  params: z.object({ date: isoDate }),
  handler: async ({ params, db }) => {
    await tx(db, (c) => c.query(`DELETE FROM holidays WHERE holiday_date = $1`, [params.date]));
    return { ok: true };
  },
});

// ------------------------------------------------------------------ lookups (dropdown data)
route(router, '/api/lookups', {
  method: 'get',
  path: '',
  tag: 'Lookups',
  summary: 'Reference data for forms and filters',
  handler: async () => {
    const [products, branches, executives, roles, buckets, states, meta] = await Promise.all([
      query(`SELECT id, code, name, min_amount, max_amount, min_tenure_months, max_tenure_months, default_rate, processing_fee_pct, is_active FROM loan_products ORDER BY name`),
      query(`SELECT id, code, name, city, state FROM branches WHERE deleted_at IS NULL AND is_active ORDER BY name`),
      query(`SELECT u.id, u.full_name FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = 'COLLECTION_EXECUTIVE' AND u.is_active AND u.deleted_at IS NULL ORDER BY u.full_name`),
      query(`SELECT id, code, name FROM roles ORDER BY id`),
      query(`SELECT code, label, min_dpd, max_dpd, sort_order, color FROM dpd_bucket_config WHERE is_active ORDER BY sort_order`),
      query(`SELECT DISTINCT state FROM customers WHERE state IS NOT NULL ORDER BY state`),
      one(`SELECT fn_business_date()::text AS business_date, fn_setting('company_name') AS company_name`),
    ]);
    return { products, branches, executives, roles, buckets, states: states.map((s: any) => s.state), ...meta };
  },
});

// ------------------------------------------------------------------ audit logs
route(router, '/api/audit-logs', {
  method: 'get',
  path: '',
  tag: 'Audit',
  summary: 'Audit trail (format=csv|xlsx|pdf exports)',
  permission: 'audit.read',
  query: listQuerySchema.extend({
    entityType: z.string().max(40).optional(),
    entityId: z.string().max(40).optional(),
    userId: z.coerce.number().int().optional(),
    action: z.string().max(40).optional(),
    dateFrom: isoDate.optional(),
    dateTo: isoDate.optional(),
  }),
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    if (q.entityType) sql.and(`a.entity_type = ${sql.p(q.entityType)}`);
    if (q.entityId) sql.and(`a.entity_id = ${sql.p(q.entityId)}`);
    if (q.userId) sql.and(`a.user_id = ${sql.p(q.userId)}`);
    if (q.action) sql.and(`a.action = ${sql.p(q.action)}`);
    if (q.dateFrom) sql.and(`a.created_at >= ${sql.p(q.dateFrom)}::date`);
    if (q.dateTo) sql.and(`a.created_at < ${sql.p(q.dateTo)}::date + 1`);
    if (q.search) sql.and(`(a.new_values::text ILIKE ${sql.p(`%${q.search}%`)} OR a.old_values::text ILIKE $${sql.params.length})`);
    await respondList(ctx, {
      select: `a.*, u.full_name AS user_name`,
      from: `audit_logs a LEFT JOIN users u ON u.id = a.user_id`,
      sql,
      order: orderBy(q, { createdAt: 'a.created_at', action: 'a.action', entityType: 'a.entity_type' }, 'a.id DESC'),
      title: 'Audit Log',
      columns: [
        { key: 'createdAt', label: 'Time' },
        { key: 'userName', label: 'User' },
        { key: 'action', label: 'Action' },
        { key: 'entityType', label: 'Entity' },
        { key: 'entityId', label: 'ID' },
        { key: 'newValues', label: 'Changes' },
        { key: 'ip', label: 'IP' },
      ],
    });
  },
});

route(router, '/api/audit-logs', {
  method: 'get',
  path: '/entity-types',
  tag: 'Audit',
  summary: 'Distinct audited entity types and actions',
  permission: 'audit.read',
  handler: async () => ({
    entityTypes: (await query(`SELECT DISTINCT entity_type FROM audit_logs ORDER BY 1`)).map((r: any) => r.entityType),
    actions: (await query(`SELECT DISTINCT action FROM audit_logs ORDER BY 1`)).map((r: any) => r.action),
  }),
});

// ------------------------------------------------------------------ notifications
route(router, '/api/notifications', {
  method: 'get',
  path: '',
  tag: 'Notifications',
  summary: 'My notifications',
  query: z.object({ unreadOnly: z.enum(['true', 'false']).default('false') }),
  handler: async ({ user, query: q }) => ({
    unread: (await one<{ n: number }>(`SELECT count(*)::int AS n FROM notifications WHERE user_id = $1 AND NOT is_read`, [user.id]))!.n,
    items: await query(`SELECT * FROM notifications WHERE user_id = $1 ${q.unreadOnly === 'true' ? 'AND NOT is_read' : ''} ORDER BY id DESC LIMIT 50`, [user.id]),
  }),
});

route(router, '/api/notifications', {
  method: 'post',
  path: '/read-all',
  tag: 'Notifications',
  summary: 'Mark all my notifications as read',
  status: 200,
  handler: async ({ user }) => {
    await query(`UPDATE notifications SET is_read = TRUE WHERE user_id = $1 AND NOT is_read`, [user.id]);
    return { ok: true };
  },
});

route(router, '/api/notifications', {
  method: 'post',
  path: '/:id/read',
  tag: 'Notifications',
  summary: 'Mark one notification as read',
  params: idParam,
  status: 200,
  handler: async ({ user, params }) => {
    await query(`UPDATE notifications SET is_read = TRUE WHERE id = $1 AND user_id = $2`, [params.id, user.id]);
    return { ok: true };
  },
});
