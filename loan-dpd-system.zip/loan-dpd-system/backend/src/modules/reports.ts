import { Router } from 'express';
import { z } from 'zod';
import { one, query } from '../db/pool.js';
import { badRequest, forbidden, notFound } from '../lib/errors.js';
import { route, type Ctx } from '../lib/http.js';
import { audit } from '../lib/listing.js';
import { sendExport, type Column } from '../lib/export.js';
import { maskRow } from '../lib/mask.js';
import { isoDate, orderBy, paginate, Sql, EXPORT_ROW_LIMIT } from '../lib/sql.js';
import { executiveScope, type AuthUser } from '../middleware/auth.js';
import { loanFilters, LOAN_COLUMNS, LOAN_SORT } from './loans.js';
import { bucketPortfolio, currentBusinessDate, movement, portfolioSource } from './dpd.js';

export const router = Router();
const BASE = '/api/reports';

const reportQuery = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(500).default(25),
  sort: z.string().max(64).optional(),
  order: z.enum(['asc', 'desc']).default('desc'),
  search: z.string().trim().max(100).optional(),
  format: z.enum(['json', 'csv', 'xlsx', 'pdf']).default('json'),
  from: isoDate.optional(),
  to: isoDate.optional(),
  asOf: isoDate.optional(),
  productId: z.coerce.number().int().optional(),
  branchId: z.coerce.number().int().optional(),
  executiveId: z.coerce.number().int().optional(),
  state: z.string().max(80).optional(),
  bucket: z.string().max(20).optional(),
  status: z.string().max(20).optional(),
  loanId: z.coerce.number().int().optional(),
  customerId: z.coerce.number().int().optional(),
  mode: z.string().max(10).optional(),
});
type RQ = z.infer<typeof reportQuery>;

type Filter = 'dateRange' | 'asOf' | 'product' | 'branch' | 'executive' | 'state' | 'bucket' | 'loanStatus' | 'paymentStatus' | 'emiStatus' | 'loan' | 'customer' | 'mode';

interface SqlReport {
  kind: 'sql';
  build: (q: RQ, user: AuthUser) => Promise<{ select: string; from: string; sql: Sql; order: string }>;
}
interface RowsReport {
  kind: 'rows';
  rows: (q: RQ, user: AuthUser) => Promise<Record<string, any>[]>;
}
type ReportDef = {
  key: string;
  title: string;
  category: 'Portfolio' | 'Collections' | 'Ledgers' | 'Risk' | 'Transactions';
  description: string;
  filters: Filter[];
  columns: Column[];
  permission?: string;
  pii?: boolean;
  requires?: ('loanId' | 'customerId' | 'from' | 'to')[];
  totals?: string[]; // money/number keys summed into a footer row
} & (SqlReport | RowsReport);

const money = (key: string, label: string): Column => ({ key, label, type: 'money' });
const num = (key: string, label: string): Column => ({ key, label, type: 'number' });
const pct = (key: string, label: string): Column => ({ key, label, type: 'pct' });
const date = (key: string, label: string): Column => ({ key, label, type: 'date' });
const text = (key: string, label: string): Column => ({ key, label });

async function rangeOf(q: RQ) {
  const bd = await currentBusinessDate();
  const to = q.to ?? bd;
  const from = q.from ?? `${to.slice(0, 7)}-01`;
  if (from > to) throw badRequest('"from" must not be after "to"');
  return { from, to, bd };
}

/** report filters → portfolio filters */
const pf = (q: RQ) => ({ businessDate: q.asOf, productId: q.productId, branchId: q.branchId, executiveId: q.executiveId, state: q.state, bucket: q.bucket });

const scopeExec = (user: AuthUser, sql: Sql, col: string) => {
  const exec = executiveScope(user);
  if (exec) sql.and(`${col} = ${sql.p(exec)}`);
};

const REPORTS: ReportDef[] = [
  {
    key: 'loan-register',
    title: 'Loan Register',
    category: 'Portfolio',
    description: 'Every loan with terms, status, live DPD and outstanding.',
    filters: ['dateRange', 'product', 'branch', 'executive', 'state', 'bucket', 'loanStatus'],
    columns: LOAN_COLUMNS,
    totals: ['principalAmount', 'outstandingPrincipal', 'overdueAmount'],
    pii: true,
    kind: 'sql',
    build: async (q, user) => ({
      select: '*',
      from: 'vw_loan_register',
      sql: loanFilters({ ...q, status: q.status as any, disbursedFrom: q.from, disbursedTo: q.to } as any, user),
      order: orderBy(q, LOAN_SORT, 'id DESC'),
    }),
  },
  {
    key: 'emi-schedule',
    title: 'EMI Schedule Report',
    category: 'Portfolio',
    description: 'Installments due in a period with paid/remaining amounts and status.',
    filters: ['dateRange', 'loan', 'product', 'emiStatus'],
    columns: [text('loanNumber', 'Loan ID'), text('customerName', 'Customer'), num('installmentNo', 'EMI #'), date('dueDate', 'Due Date'),
      money('openingPrincipal', 'Opening Principal'), money('principalComponent', 'Principal'), money('interestComponent', 'Interest'),
      money('emiAmount', 'EMI'), money('amountPaid', 'Paid'), money('remainingAmount', 'Remaining'), text('status', 'Status'), num('dpd', 'DPD'),
      date('lastPaymentDate', 'Last Payment')],
    totals: ['principalComponent', 'interestComponent', 'emiAmount', 'amountPaid', 'remainingAmount'],
    kind: 'sql',
    build: async (q, user) => {
      const { from, to } = await rangeOf(q);
      const sql = new Sql();
      if (!q.loanId) {
        sql.and(`e.due_date >= ${sql.p(from)}`);
        sql.and(`e.due_date <= ${sql.p(to)}`);
      } else sql.and(`e.loan_id = ${sql.p(q.loanId)}`);
      if (q.status) sql.and(`e.status = ${sql.p(q.status)}`);
      if (q.productId) sql.and(`l.product_id = ${sql.p(q.productId)}`);
      if (q.search) sql.and(`(l.loan_number ILIKE ${sql.p(`%${q.search}%`)} OR c.full_name ILIKE $${sql.params.length})`);
      scopeExec(user, sql, `(SELECT executive_id FROM collection_assignments a WHERE a.loan_id = l.id AND a.is_active)`);
      return {
        select: `e.*, l.loan_number, c.full_name AS customer_name`,
        from: `emi_schedules e JOIN loans l ON l.id = e.loan_id JOIN customers c ON c.id = l.customer_id`,
        sql,
        order: orderBy(q, { dueDate: 'e.due_date', loanNumber: 'l.loan_number', remainingAmount: 'e.remaining_amount', dpd: 'e.dpd', emiAmount: 'e.emi_amount' }, 'e.due_date, l.loan_number'),
      };
    },
  },
  {
    key: 'collections',
    title: 'Daily Collection Report',
    category: 'Collections',
    description: 'Collections per day and mode; failed and reversed money shown separately, never counted as collected.',
    filters: ['dateRange', 'mode'],
    columns: [date('paymentDate', 'Date'), text('paymentMode', 'Mode'), num('successfulCount', 'Successful #'), money('successfulAmount', 'Collected'),
      num('pendingCount', 'Pending #'), num('failedCount', 'Failed #'), money('failedAmount', 'Failed'), num('reversedCount', 'Reversed #'), money('reversedAmount', 'Reversed')],
    totals: ['successfulCount', 'successfulAmount', 'pendingCount', 'failedCount', 'failedAmount', 'reversedCount', 'reversedAmount'],
    kind: 'rows',
    rows: async (q) => {
      const { from, to } = await rangeOf(q);
      return query(
        `SELECT * FROM vw_daily_collection_summary WHERE payment_date BETWEEN $1 AND $2 AND ($3::text IS NULL OR payment_mode = $3)
          ORDER BY payment_date DESC, payment_mode`,
        [from, to, q.mode ?? null],
      );
    },
  },
  {
    key: 'monthly-collection',
    title: 'Monthly Collection Report',
    category: 'Collections',
    description: 'Per month: EMI demand, collected against that demand, efficiency, and total receipts.',
    filters: ['dateRange'],
    columns: [text('month', 'Month'), money('emiDue', 'EMI Due (Demand)'), money('collectedAgainstDemand', 'Collected vs Demand'), pct('efficiencyPct', 'Efficiency %'),
      money('totalCollected', 'Total Receipts'), num('payments', 'Payments #'), num('bounces', 'Bounces #')],
    totals: ['emiDue', 'collectedAgainstDemand', 'totalCollected', 'payments', 'bounces'],
    kind: 'rows',
    rows: async (q) => {
      const { from, to } = await rangeOf({ ...q, from: q.from ?? undefined });
      const start = q.from ?? (await one<{ d: string }>(`SELECT (date_trunc('month', $1::date) - interval '11 months')::date::text AS d`, [to]))!.d;
      return query(
        `WITH m AS (SELECT generate_series(date_trunc('month', $1::date), date_trunc('month', $2::date), interval '1 month')::date AS m)
         SELECT to_char(m.m, 'YYYY-MM') AS month, ce.demand AS emi_due, ce.collected_against_demand, ce.efficiency_pct,
                (SELECT COALESCE(sum(amount), 0) FROM payments p WHERE p.status = 'SUCCESSFUL' AND p.payment_date BETWEEN m.m AND LEAST((m.m + interval '1 month - 1 day')::date, $2::date)) AS total_collected,
                (SELECT count(*) FROM payments p WHERE p.status = 'SUCCESSFUL' AND p.payment_date BETWEEN m.m AND LEAST((m.m + interval '1 month - 1 day')::date, $2::date))::int AS payments,
                (SELECT count(*) FROM payment_bounces b WHERE b.bounce_date BETWEEN m.m AND LEAST((m.m + interval '1 month - 1 day')::date, $2::date))::int AS bounces
           FROM m CROSS JOIN LATERAL fn_collection_efficiency(m.m, LEAST((m.m + interval '1 month - 1 day')::date, $2::date)) ce
          ORDER BY m.m DESC`,
        [start < from ? start : from, to],
      );
    },
  },
  {
    key: 'overdue',
    title: 'Overdue Accounts Report',
    category: 'Collections',
    description: 'Live accounts with unpaid installments past due, highest DPD first.',
    filters: ['product', 'branch', 'executive', 'state', 'bucket'],
    columns: [text('loanNumber', 'Loan ID'), text('customerName', 'Customer'), text('mobile', 'Mobile'), text('productName', 'Product'), text('state', 'State'),
      num('dpd', 'DPD'), text('bucketCode', 'Bucket'), num('overdueEmiCount', 'Overdue EMIs'), money('overdueAmount', 'Overdue'), money('overdueCharges', 'Charges'),
      money('outstandingPrincipal', 'POS'), date('oldestOverdueDate', 'Oldest Due'), date('lastPaymentDate', 'Last Payment'), text('executiveName', 'Executive')],
    totals: ['overdueAmount', 'overdueCharges', 'outstandingPrincipal'],
    pii: true,
    kind: 'sql',
    build: async (q, user) => {
      const sql = loanFilters({ ...q, status: 'LIVE' } as any, user);
      sql.and('(overdue_amount > 0 OR overdue_charges > 0)');
      return { select: '*', from: 'vw_active_loans', sql, order: orderBy(q, LOAN_SORT, 'dpd DESC, overdue_amount DESC') };
    },
  },
  {
    key: 'dpd',
    title: 'DPD Bucket Report',
    category: 'Risk',
    description: 'Accounts, POS and overdue by DPD bucket as of a business date (live or historical snapshot).',
    filters: ['asOf', 'product', 'branch', 'executive', 'state'],
    columns: [text('label', 'Bucket'), num('accountCount', 'Accounts'), pct('pctOfAccounts', '% Accounts'), money('outstandingPrincipal', 'POS'),
      pct('pctOfPos', '% POS'), money('overdueAmount', 'Overdue')],
    totals: ['accountCount', 'outstandingPrincipal', 'overdueAmount'],
    kind: 'rows',
    rows: async (q, user) => (await bucketPortfolio(pf(q), user)).buckets,
  },
  {
    key: 'bounces',
    title: 'Bounce Report',
    category: 'Transactions',
    description: 'Every bounce with reason, charge and recovery status.',
    filters: ['dateRange', 'product'],
    columns: [text('bounceNumber', 'Bounce ID'), date('bounceDate', 'Date'), text('loanNumber', 'Loan ID'), text('customerName', 'Customer'),
      num('installmentNo', 'EMI #'), text('paymentNumber', 'Payment'), text('bounceReason', 'Reason'), money('bounceAmount', 'Amount'),
      money('bounceCharges', 'Charges'), text('recoveryStatus', 'Recovery'), date('resolutionDate', 'Resolved'), num('reattemptCount', 'Re-presentations')],
    totals: ['bounceAmount', 'bounceCharges'],
    kind: 'sql',
    build: async (q, user) => {
      const { from, to } = await rangeOf(q);
      const sql = new Sql();
      sql.and(`b.bounce_date BETWEEN ${sql.p(from)} AND ${sql.p(to)}`);
      if (q.productId) sql.and(`l.product_id = ${sql.p(q.productId)}`);
      if (q.search) sql.and(`(l.loan_number ILIKE ${sql.p(`%${q.search}%`)} OR c.full_name ILIKE $${sql.params.length} OR b.bounce_number ILIKE $${sql.params.length})`);
      scopeExec(user, sql, `(SELECT executive_id FROM collection_assignments a WHERE a.loan_id = b.loan_id AND a.is_active)`);
      return {
        select: `b.*, l.loan_number, c.full_name AS customer_name, e.installment_no, p.payment_number`,
        from: `payment_bounces b JOIN loans l ON l.id = b.loan_id JOIN customers c ON c.id = l.customer_id
               LEFT JOIN emi_schedules e ON e.id = b.emi_schedule_id LEFT JOIN payments p ON p.id = b.payment_id`,
        sql,
        order: orderBy(q, { bounceDate: 'b.bounce_date', bounceAmount: 'b.bounce_amount', loanNumber: 'l.loan_number', bounceReason: 'b.bounce_reason', recoveryStatus: 'b.recovery_status' }, 'b.bounce_date DESC'),
      };
    },
  },
  {
    key: 'payments',
    title: 'Payment Transaction Report',
    category: 'Transactions',
    description: 'All payment transactions in a period, any status.',
    filters: ['dateRange', 'paymentStatus', 'mode', 'product'],
    columns: [text('paymentNumber', 'Payment ID'), date('paymentDate', 'Date'), text('loanNumber', 'Loan ID'), text('customerName', 'Customer'),
      money('amount', 'Amount'), text('paymentMode', 'Mode'), text('transactionReference', 'Reference'), text('status', 'Status'),
      text('collectedByName', 'Collected By'), text('source', 'Source')],
    totals: ['amount'],
    kind: 'sql',
    build: async (q, user) => {
      const { from, to } = await rangeOf(q);
      const sql = new Sql();
      sql.and(`p.payment_date BETWEEN ${sql.p(from)} AND ${sql.p(to)}`);
      if (q.status) sql.and(`p.status = ${sql.p(q.status)}`);
      if (q.mode) sql.and(`p.payment_mode = ${sql.p(q.mode)}`);
      if (q.productId) sql.and(`l.product_id = ${sql.p(q.productId)}`);
      if (q.search) sql.and(`(p.payment_number ILIKE ${sql.p(`%${q.search}%`)} OR l.loan_number ILIKE $${sql.params.length} OR p.transaction_reference ILIKE $${sql.params.length})`);
      scopeExec(user, sql, `(SELECT executive_id FROM collection_assignments a WHERE a.loan_id = p.loan_id AND a.is_active)`);
      return {
        select: `p.*, l.loan_number, c.full_name AS customer_name, u.full_name AS collected_by_name`,
        from: `payments p JOIN loans l ON l.id = p.loan_id JOIN customers c ON c.id = l.customer_id LEFT JOIN users u ON u.id = p.collected_by`,
        sql,
        order: orderBy(q, { paymentDate: 'p.payment_date', amount: 'p.amount', status: 'p.status', loanNumber: 'l.loan_number' }, 'p.payment_date DESC, p.id DESC'),
      };
    },
  },
  {
    key: 'customer-ledger',
    title: 'Customer Ledger',
    category: 'Ledgers',
    description: 'Dues and receipts across all loans of one customer, with running balance per loan.',
    filters: ['customer', 'asOf'],
    requires: ['customerId'],
    columns: [text('loanNumber', 'Loan ID'), date('entryDate', 'Date'), text('entryType', 'Type'), text('reference', 'Reference'),
      text('particulars', 'Particulars'), money('debit', 'Debit (Due)'), money('credit', 'Credit (Paid)'), money('balance', 'Balance')],
    totals: ['debit', 'credit'],
    kind: 'rows',
    rows: async (q, user) => {
      const exec = executiveScope(user);
      if (exec && !(await one(`SELECT 1 FROM loans l JOIN collection_assignments a ON a.loan_id = l.id AND a.is_active WHERE l.customer_id = $1 AND a.executive_id = $2`, [q.customerId, exec])))
        throw forbidden('This customer is not in your portfolio');
      return query(
        `SELECT l.loan_number, x.* FROM loans l CROSS JOIN LATERAL fn_loan_ledger(l.id, $2::date) x
          WHERE l.customer_id = $1 AND l.disbursement_date IS NOT NULL ORDER BY l.id, x.entry_date, x.seq`,
        [q.customerId, q.asOf ?? null],
      );
    },
  },
  {
    key: 'loan-ledger',
    title: 'Loan Ledger',
    category: 'Ledgers',
    description: 'Installments due, charges, receipts, reversals, bounces and waivers for one loan with running balance.',
    filters: ['loan', 'asOf'],
    requires: ['loanId'],
    columns: [date('entryDate', 'Date'), text('entryType', 'Type'), text('reference', 'Reference'), text('particulars', 'Particulars'),
      money('debit', 'Debit (Due)'), money('credit', 'Credit (Paid)'), money('balance', 'Balance')],
    totals: ['debit', 'credit'],
    kind: 'rows',
    rows: async (q, user) => {
      const exec = executiveScope(user);
      if (exec && !(await one(`SELECT 1 FROM collection_assignments WHERE loan_id = $1 AND executive_id = $2 AND is_active`, [q.loanId, exec])))
        throw forbidden('This loan is not assigned to you');
      return query(`SELECT * FROM fn_loan_ledger($1, $2::date)`, [q.loanId, q.asOf ?? null]);
    },
  },
  {
    key: 'executive-performance',
    title: 'Collection Executive Performance Report',
    category: 'Collections',
    description: 'Per executive: portfolio, collections in the period, PTPs and activity.',
    filters: ['dateRange'],
    columns: [text('executiveName', 'Executive'), num('assignedAccounts', 'Assigned'), num('overdueAccounts', 'Overdue A/c'), money('totalOverdue', 'Overdue'),
      money('collected', 'Collected (period)'), num('payments', 'Payments'), money('targetAmount', 'Target (month)'), pct('achievementPct', 'Achievement % (MTD)'),
      num('ptpMade', 'PTP Made'), num('ptpKept', 'PTP Kept'), num('ptpBroken', 'PTP Broken'), num('activities', 'Activities'), num('fieldVisits', 'Field Visits')],
    totals: ['assignedAccounts', 'overdueAccounts', 'totalOverdue', 'collected', 'payments', 'ptpMade', 'ptpKept', 'ptpBroken', 'activities', 'fieldVisits'],
    kind: 'rows',
    rows: async (q, user) => {
      const { from, to } = await rangeOf(q);
      const exec = executiveScope(user);
      return query(
        `SELECT v.executive_id, v.executive_name, v.assigned_accounts, v.overdue_accounts, v.total_overdue, v.target_amount, v.achievement_pct,
                COALESCE(col.collected, 0) AS collected, COALESCE(col.payments, 0) AS payments,
                COALESCE(t.made, 0) AS ptp_made, COALESCE(t.kept, 0) AS ptp_kept, COALESCE(t.broken, 0) AS ptp_broken,
                COALESCE(act.n, 0) AS activities, COALESCE(act.visits, 0) AS field_visits
           FROM vw_collection_performance v
           LEFT JOIN LATERAL (SELECT sum(p.amount) AS collected, count(*)::int AS payments FROM payments p
                               JOIN collection_assignments a ON a.loan_id = p.loan_id AND a.is_active AND a.executive_id = v.executive_id
                              WHERE p.status = 'SUCCESSFUL' AND p.payment_date BETWEEN $1 AND $2) col ON TRUE
           LEFT JOIN LATERAL (SELECT count(*) FILTER (WHERE promised_on BETWEEN $1 AND $2)::int AS made,
                                     count(*) FILTER (WHERE status = 'KEPT' AND resolved_on BETWEEN $1 AND $2)::int AS kept,
                                     count(*) FILTER (WHERE status = 'BROKEN' AND resolved_on BETWEEN $1 AND $2)::int AS broken
                                FROM promise_to_pay WHERE executive_id = v.executive_id) t ON TRUE
           LEFT JOIN LATERAL (SELECT count(*)::int AS n, count(*) FILTER (WHERE activity_type = 'FIELD_VISIT')::int AS visits
                                FROM collection_activities WHERE executive_id = v.executive_id AND activity_date BETWEEN $1 AND $2) act ON TRUE
          WHERE ($3::int IS NULL OR v.executive_id = $3) ORDER BY collected DESC`,
        [from, to, exec ?? q.executiveId ?? null],
      );
    },
  },
  {
    key: 'par',
    title: 'PAR Report',
    category: 'Risk',
    description: 'Portfolio at Risk (POS with DPD > 30 / 60 / 90) by product, as of a business date.',
    filters: ['asOf', 'branch', 'state', 'executive'],
    columns: [text('productName', 'Product'), num('accounts', 'Accounts'), money('totalPos', 'POS'), money('par30Pos', 'PAR30 POS'), pct('par30Pct', 'PAR30 %'),
      money('par60Pos', 'PAR60 POS'), pct('par60Pct', 'PAR60 %'), money('par90Pos', 'PAR90 POS'), pct('par90Pct', 'PAR90 %')],
    totals: ['accounts', 'totalPos', 'par30Pos', 'par60Pos', 'par90Pos'],
    kind: 'rows',
    rows: async (q, user) => {
      const sql = new Sql();
      const { source } = await portfolioSource({ ...pf(q), productId: undefined, bucket: undefined }, user, sql);
      const rows = await query(
        `SELECT p.name AS product_name, count(src.loan_id)::int AS accounts,
                COALESCE(sum(src.outstanding_principal), 0) AS total_pos,
                COALESCE(sum(src.outstanding_principal) FILTER (WHERE src.dpd > 30), 0) AS par30_pos,
                COALESCE(sum(src.outstanding_principal) FILTER (WHERE src.dpd > 60), 0) AS par60_pos,
                COALESCE(sum(src.outstanding_principal) FILTER (WHERE src.dpd > 90), 0) AS par90_pos
           FROM loan_products p LEFT JOIN (SELECT src.* FROM ${source} ${sql.where}) src ON src.product_id = p.id
          GROUP BY p.id, p.name ORDER BY total_pos DESC`,
        sql.params,
      );
      const pctOf = (a: number, b: number) => (b > 0 ? Math.round((a * 10000) / b) / 100 : 0);
      return rows.map((r: any) => ({ ...r, par30Pct: pctOf(r.par30Pos, r.totalPos), par60Pct: pctOf(r.par60Pos, r.totalPos), par90Pct: pctOf(r.par90Pos, r.totalPos) }));
    },
  },
  {
    key: 'dpd-movement',
    title: 'Daily DPD Movement Report',
    category: 'Risk',
    description: 'Bucket-to-bucket transition matrix between two snapshot dates (default: previous day → business date).',
    filters: ['dateRange', 'product', 'branch', 'executive', 'state'],
    columns: [text('fromBucket', 'From Bucket'), text('toBucket', 'To Bucket'), num('accounts', 'Accounts'), money('pos', 'POS')],
    totals: ['accounts', 'pos'],
    kind: 'rows',
    rows: async (q, user) => {
      const { from, to } = await movementRange(q);
      return (await movement(from, to, pf(q), user)).matrix;
    },
  },
  {
    key: 'roll-forward',
    title: 'Roll Forward Report',
    category: 'Risk',
    description: 'Accounts that moved to a worse DPD bucket between two snapshot dates.',
    filters: ['dateRange', 'product', 'branch', 'executive', 'state'],
    columns: [text('loanNumber', 'Loan ID'), text('customerName', 'Customer'), text('fromBucket', 'From'), num('fromDpd', 'From DPD'), text('toBucket', 'To'),
      num('toDpd', 'To DPD'), money('toPos', 'POS'), money('toOverdue', 'Overdue'), text('executiveName', 'Executive')],
    totals: ['toPos', 'toOverdue'],
    kind: 'rows',
    rows: async (q, user) => rollRows(q, user, '>'),
  },
  {
    key: 'roll-backward',
    title: 'Roll Backward Report',
    category: 'Risk',
    description: 'Accounts that improved to a better DPD bucket (incl. cures) between two snapshot dates.',
    filters: ['dateRange', 'product', 'branch', 'executive', 'state'],
    columns: [text('loanNumber', 'Loan ID'), text('customerName', 'Customer'), text('fromBucket', 'From'), num('fromDpd', 'From DPD'), text('toBucket', 'To'),
      num('toDpd', 'To DPD'), money('toPos', 'POS'), money('collectedBetween', 'Paid in Period'), text('executiveName', 'Executive')],
    totals: ['toPos', 'collectedBetween'],
    kind: 'rows',
    rows: async (q, user) => rollRows(q, user, '<'),
  },
  {
    key: 'collection-efficiency',
    title: 'Collection Efficiency Report',
    category: 'Collections',
    description: 'Demand due in the period vs amount collected against it, by product (same formula as the dashboard).',
    filters: ['dateRange'],
    columns: [text('productName', 'Product'), money('demand', 'EMI Demand'), money('collectedAgainstDemand', 'Collected vs Demand'), pct('efficiencyPct', 'Efficiency %')],
    // no footer totals: the "All products" row already is the total
    kind: 'rows',
    rows: async (q) => {
      const { from, to } = await rangeOf(q);
      const rows = await query(
        `SELECT p.name AS product_name, ce.* FROM loan_products p CROSS JOIN LATERAL fn_collection_efficiency($1, $2, p.id) ce
          UNION ALL SELECT 'All products', ce.* FROM fn_collection_efficiency($1, $2) ce`,
        [from, to],
      );
      return rows;
    },
  },
  {
    key: 'npa',
    title: 'NPA / 90+ DPD Report',
    category: 'Risk',
    description: 'Accounts 90+ days past due as of a business date, with days since last payment.',
    filters: ['asOf', 'product', 'branch', 'executive', 'state'],
    columns: [text('loanNumber', 'Loan ID'), text('customerName', 'Customer'), text('productName', 'Product'), text('state', 'State'), num('dpd', 'DPD'),
      money('outstandingPrincipal', 'POS'), money('overdueAmount', 'Overdue'), num('overdueEmiCount', 'Overdue EMIs'), date('oldestOverdueDate', 'Oldest Due'),
      date('lastPaymentDate', 'Last Payment'), num('daysSinceLastPayment', 'Days Since Payment'), text('executiveName', 'Executive')],
    totals: ['outstandingPrincipal', 'overdueAmount'],
    pii: true,
    kind: 'sql',
    build: async (q, user) => {
      const sql = new Sql();
      const { source } = await portfolioSource({ ...pf(q), bucket: undefined }, user, sql);
      sql.and('src.dpd >= 90');
      if (q.search) sql.and(`(l.loan_number ILIKE ${sql.p(`%${q.search}%`)} OR c.full_name ILIKE $${sql.params.length})`);
      return {
        select: `src.*, l.loan_number, c.full_name AS customer_name, c.mobile, p.name AS product_name, u.full_name AS executive_name,
                 (src.business_date - src.last_payment_date) AS days_since_last_payment`,
        from: `${source} JOIN loans l ON l.id = src.loan_id JOIN customers c ON c.id = l.customer_id JOIN loan_products p ON p.id = src.product_id
               LEFT JOIN users u ON u.id = src.executive_id`,
        sql,
        order: orderBy(q, { dpd: 'src.dpd', outstandingPrincipal: 'src.outstanding_principal', loanNumber: 'l.loan_number' }, 'src.dpd DESC'),
      };
    },
  },
  {
    key: 'portfolio-snapshot',
    title: 'Historical Portfolio Snapshot Report',
    category: 'Portfolio',
    description: 'Daily bucket-wise position (accounts, POS, overdue) from immutable snapshots.',
    filters: ['dateRange', 'bucket'],
    columns: [date('businessDate', 'Business Date'), text('bucketCode', 'Bucket'), num('accountCount', 'Accounts'), money('outstandingPrincipal', 'POS'), money('overdueAmount', 'Overdue')],
    kind: 'rows',
    rows: async (q) => {
      const { from, to } = await rangeOf(q);
      return query(
        `SELECT business_date, bucket_code, bucket_sort_order, account_count, outstanding_principal, overdue_amount FROM portfolio_daily_summary
          WHERE business_date BETWEEN $1 AND $2 AND ($3::text IS NULL OR bucket_code = $3) ORDER BY business_date DESC, bucket_sort_order`,
        [from, to, q.bucket ?? null],
      );
    },
  },
];

async function movementRange(q: RQ) {
  const bd = await currentBusinessDate();
  const to = q.to ?? bd;
  const from = q.from ?? (await one<{ d: string }>(`SELECT max(business_date)::text AS d FROM dpd_daily_snapshots WHERE business_date < $1`, [to]))?.d;
  if (!from) throw badRequest('Not enough snapshot history for a movement report');
  return { from, to };
}

async function rollRows(q: RQ, user: AuthUser, op: '>' | '<') {
  const { from, to } = await movementRange(q);
  const sql = new Sql([from, to]);
  const extra: string[] = [];
  if (q.productId) extra.push(`b.product_id = ${sql.p(q.productId)}`);
  if (q.branchId) extra.push(`b.branch_id = ${sql.p(q.branchId)}`);
  if (q.executiveId) extra.push(`b.executive_id = ${sql.p(q.executiveId)}`);
  if (q.state) extra.push(`b.state = ${sql.p(q.state)}`);
  const exec = executiveScope(user);
  if (exec) extra.push(`b.executive_id = ${sql.p(exec)}`);
  return query(
    `SELECT l.loan_number, c.full_name AS customer_name, a.bucket_code AS from_bucket, a.dpd AS from_dpd, b.bucket_code AS to_bucket, b.dpd AS to_dpd,
            b.outstanding_principal AS to_pos, b.overdue_amount AS to_overdue, u.full_name AS executive_name,
            (SELECT COALESCE(sum(amount), 0) FROM payments p WHERE p.loan_id = a.loan_id AND p.status = 'SUCCESSFUL' AND p.payment_date >= $1 AND p.payment_date < $2) AS collected_between
       FROM dpd_daily_snapshots a JOIN dpd_daily_snapshots b ON b.loan_id = a.loan_id AND b.business_date = $2
       JOIN loans l ON l.id = a.loan_id JOIN customers c ON c.id = l.customer_id LEFT JOIN users u ON u.id = b.executive_id
      WHERE a.business_date = $1 AND b.bucket_sort_order ${op} a.bucket_sort_order ${extra.length ? 'AND ' + extra.join(' AND ') : ''}
      ORDER BY b.dpd DESC`,
    sql.params,
  );
}

const byKey = new Map(REPORTS.map((r) => [r.key, r]));

route(router, BASE, {
  method: 'get',
  path: '',
  tag: 'Reports',
  summary: 'Catalogue of available reports with their filters and columns',
  permission: 'reports.read',
  handler: async () =>
    REPORTS.map(({ key, title, category, description, filters, columns, requires, kind }) => ({ key, title, category, description, filters, columns, requires: requires ?? [], paginated: kind === 'sql' })),
});

function sumTotals(def: ReportDef, rows: Record<string, any>[]) {
  if (!def.totals?.length) return null;
  const t: Record<string, number> = {};
  for (const k of def.totals) t[k] = Math.round(rows.reduce((s, r) => s + Number(r[k] ?? 0), 0) * 100) / 100;
  return t;
}

async function runReport(ctx: Ctx<any, RQ, { key: string }>) {
  const def = byKey.get(ctx.params.key);
  if (!def) throw notFound('Report');
  const q = ctx.query;
  for (const r of def.requires ?? []) if (!q[r]) throw badRequest(`This report needs ${r}`);
  const canPii = !def.pii || ctx.can('customers.pii');
  const exporting = q.format !== 'json';
  if (exporting && !ctx.can('reports.export')) throw forbidden('Export permission required');

  let rows: Record<string, any>[];
  let total: number;
  let totals: Record<string, number> | null = null;
  if (def.kind === 'sql') {
    const b = await def.build(q, ctx.user);
    const page = await paginate({ ...b, page: q.page, pageSize: q.pageSize, all: exporting });
    rows = page.data;
    total = page.total;
    if (def.totals?.length) {
      // footer totals over ALL matching rows (not just this page) so the report reconciles
      const agg = await one(`SELECT ${def.totals.map((k) => `COALESCE(sum(${k.replace(/[A-Z]/g, (m) => '_' + m.toLowerCase())}), 0) AS "${k}"`).join(', ')} FROM (SELECT ${b.select} FROM ${b.from} ${b.sql.where}) t`, b.sql.params);
      totals = agg;
    }
  } else {
    let all = await def.rows(q, ctx.user);
    if (q.search) {
      const s = q.search.toLowerCase();
      all = all.filter((r) => def.columns.some((c) => String(r[c.key] ?? '').toLowerCase().includes(s)));
    }
    if (q.sort && def.columns.some((c) => c.key === q.sort)) {
      const k = q.sort;
      const dir = q.order === 'asc' ? 1 : -1;
      all = [...all].sort((a, b) => (a[k] === b[k] ? 0 : a[k] === null ? 1 : b[k] === null ? -1 : a[k] > b[k] ? dir : -dir));
    }
    totals = sumTotals(def, all);
    total = all.length;
    rows = exporting ? all.slice(0, EXPORT_ROW_LIMIT) : all.slice((q.page - 1) * q.pageSize, q.page * q.pageSize);
  }
  rows = rows.map((r) => maskRow(r, canPii));

  if (exporting) {
    const { page: _p, pageSize: _s, format: _f, sort: _o, order: _d, ...filters } = q;
    await audit(ctx.db, 'EXPORT', `report:${def.key}`, null, { format: q.format, rows: rows.length, filters });
    const outRows = totals ? [...rows, { ...Object.fromEntries(def.columns.map((c) => [c.key, null])), [def.columns[0].key]: 'TOTAL', ...totals }] : rows;
    const bd = await currentBusinessDate();
    await sendExport(ctx.res, q.format as 'csv' | 'xlsx' | 'pdf', `${def.key}_${bd}`, def.title, def.columns, outRows, [
      `Business date ${bd}. Generated ${new Date().toISOString().replace('T', ' ').slice(0, 19)} UTC by ${ctx.user.fullName}.`,
      Object.keys(filters).length ? `Filters: ${JSON.stringify(filters)}` : 'Filters: none',
    ]);
    return;
  }
  ctx.res.json({ report: { key: def.key, title: def.title, columns: def.columns }, data: rows, total, page: q.page, pageSize: q.pageSize, totalPages: Math.max(1, Math.ceil(total / q.pageSize)), totals });
}

route(router, BASE, {
  method: 'get',
  path: '/:key',
  tag: 'Reports',
  summary: 'Run a report (loan-register, overdue, dpd, collections, bounces, par, …). format=csv|xlsx|pdf to export.',
  permission: 'reports.read',
  params: z.object({ key: z.string().regex(/^[a-z0-9-]+$/) }),
  query: reportQuery,
  raw: true,
  handler: runReport,
});
