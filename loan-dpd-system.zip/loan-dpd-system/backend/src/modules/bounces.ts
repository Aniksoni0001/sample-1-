import { Router } from 'express';
import { z } from 'zod';
import { one, query, tx } from '../db/pool.js';
import { badRequest, notFound } from '../lib/errors.js';
import { route } from '../lib/http.js';
import { respondList } from '../lib/listing.js';
import { idParam, isoDate, listQuerySchema, money, orderBy, Sql } from '../lib/sql.js';
import { executiveScope } from '../middleware/auth.js';
import { assertLoanAccess } from './loans.js';

export const router = Router();
const BASE = '/api/bounces';

export const BOUNCE_REASONS = ['INSUFFICIENT_FUNDS', 'ACCOUNT_CLOSED', 'PAYMENT_STOPPED', 'INVALID_ACCOUNT', 'MANDATE_FAILURE', 'TECHNICAL_FAILURE', 'OTHER'] as const;

const listQuery = listQuerySchema.extend({
  reason: z.enum(BOUNCE_REASONS).optional(),
  recoveryStatus: z.enum(['PENDING', 'PARTIAL', 'RECOVERED', 'WAIVED']).optional(),
  dateFrom: isoDate.optional(),
  dateTo: isoDate.optional(),
  loanId: z.coerce.number().int().optional(),
});

const SELECT = `b.id, b.bounce_number, b.loan_id, l.loan_number, l.customer_id, c.customer_code, c.full_name AS customer_name,
  b.emi_schedule_id, e.installment_no, b.payment_id, p.payment_number, b.payment_reference, b.bounce_date, b.bounce_reason,
  b.bounce_amount, b.bounce_charges, b.recovery_status, b.resolution_date, b.reattempt_count, b.remarks, b.created_at,
  (SELECT count(*) FROM payment_bounces b2 WHERE b2.loan_id = b.loan_id)::int AS loan_bounce_count`;
const FROM = `payment_bounces b JOIN loans l ON l.id = b.loan_id JOIN customers c ON c.id = l.customer_id
  LEFT JOIN emi_schedules e ON e.id = b.emi_schedule_id LEFT JOIN payments p ON p.id = b.payment_id`;

route(router, BASE, {
  method: 'get',
  path: '',
  tag: 'Bounces',
  summary: 'Bounce register (format=csv|xlsx|pdf to export)',
  permission: 'bounces.read',
  query: listQuery,
  raw: true,
  handler: async (ctx) => {
    const q = ctx.query;
    const sql = new Sql();
    if (q.search) {
      const s = sql.p(`%${q.search}%`);
      sql.and(`(b.bounce_number ILIKE ${s} OR l.loan_number ILIKE ${s} OR c.full_name ILIKE ${s} OR b.payment_reference ILIKE ${s})`);
    }
    if (q.reason) sql.and(`b.bounce_reason = ${sql.p(q.reason)}`);
    if (q.recoveryStatus) sql.and(`b.recovery_status = ${sql.p(q.recoveryStatus)}`);
    if (q.dateFrom) sql.and(`b.bounce_date >= ${sql.p(q.dateFrom)}`);
    if (q.dateTo) sql.and(`b.bounce_date <= ${sql.p(q.dateTo)}`);
    if (q.loanId) sql.and(`b.loan_id = ${sql.p(q.loanId)}`);
    const exec = executiveScope(ctx.user);
    if (exec)
      sql.and(`EXISTS (SELECT 1 FROM collection_assignments a WHERE a.loan_id = b.loan_id AND a.is_active AND a.executive_id = ${sql.p(exec)})`);
    await respondList(ctx, {
      select: SELECT,
      from: FROM,
      sql,
      order: orderBy(
        q,
        { bounceNumber: 'b.bounce_number', bounceDate: 'b.bounce_date', bounceAmount: 'b.bounce_amount', loanNumber: 'l.loan_number', customerName: 'c.full_name', recoveryStatus: 'b.recovery_status', bounceReason: 'b.bounce_reason' },
        'b.bounce_date DESC, b.id DESC',
      ),
      title: 'Bounce Report',
      columns: [
        { key: 'bounceNumber', label: 'Bounce ID' },
        { key: 'bounceDate', label: 'Date', type: 'date' },
        { key: 'loanNumber', label: 'Loan ID' },
        { key: 'customerName', label: 'Customer' },
        { key: 'installmentNo', label: 'EMI #', type: 'number' },
        { key: 'paymentReference', label: 'Payment Ref' },
        { key: 'bounceReason', label: 'Reason' },
        { key: 'bounceAmount', label: 'Amount', type: 'money' },
        { key: 'bounceCharges', label: 'Charges', type: 'money' },
        { key: 'recoveryStatus', label: 'Recovery' },
        { key: 'resolutionDate', label: 'Resolved', type: 'date' },
        { key: 'loanBounceCount', label: 'Bounces on Loan', type: 'number' },
      ],
    });
  },
});

route(router, BASE, {
  method: 'get',
  path: '/stats',
  tag: 'Bounces',
  summary: 'Bounce rate and breakdown for a period',
  permission: 'bounces.read',
  query: z.object({ from: isoDate, to: isoDate }),
  handler: async ({ query: q }) => {
    const totals = await one(
      `WITH pres AS (
         SELECT count(*) AS n FROM payments WHERE payment_mode IN ('NACH','CHEQUE') AND payment_date BETWEEN $1 AND $2
       ), nb AS (SELECT count(*) AS n FROM payment_bounces WHERE payment_id IS NULL AND bounce_date BETWEEN $1 AND $2),
       b AS (SELECT count(*) AS n, COALESCE(sum(bounce_amount), 0) AS amt, COALESCE(sum(bounce_charges), 0) AS chg,
                    count(*) FILTER (WHERE recovery_status = 'RECOVERED') AS rec
               FROM payment_bounces WHERE bounce_date BETWEEN $1 AND $2)
       SELECT b.n::int AS bounces, b.amt AS bounce_amount, b.chg AS bounce_charges, b.rec::int AS recovered,
              (pres.n + nb.n)::int AS presentations,
              CASE WHEN pres.n + nb.n > 0 THEN round(b.n * 100.0 / (pres.n + nb.n), 2) ELSE 0 END AS bounce_rate_pct
         FROM b, pres, nb`,
      [q.from, q.to],
    );
    const byReason = await query(
      `SELECT bounce_reason, count(*)::int AS count, sum(bounce_amount) AS amount FROM payment_bounces
        WHERE bounce_date BETWEEN $1 AND $2 GROUP BY 1 ORDER BY 2 DESC`,
      [q.from, q.to],
    );
    return { ...totals, byReason };
  },
});

route(router, BASE, {
  method: 'post',
  path: '',
  tag: 'Bounces',
  summary: 'Record a bounce (of a presented payment, or a NACH/cheque return without prior credit)',
  permission: 'bounces.write',
  body: z
    .object({
      loanId: z.coerce.number().int().positive(),
      paymentId: z.coerce.number().int().positive().optional().nullable(),
      emiScheduleId: z.coerce.number().int().positive().optional().nullable(),
      amount: money.optional().nullable(),
      paymentReference: z.string().trim().max(64).optional().nullable(),
      bounceDate: isoDate,
      bounceReason: z.enum(BOUNCE_REASONS),
      applyCharge: z.boolean().default(true),
      remarks: z.string().trim().max(500).optional().nullable(),
    })
    .refine((b) => b.paymentId || (b.emiScheduleId && b.amount), {
      message: 'Provide the bounced payment, or the installment and amount',
      path: ['paymentId'],
    }),
  handler: async ({ body, db, user }) => {
    await assertLoanAccess(user, body.loanId);
    const id = await tx(db, async (c) => {
      const r = await one<{ id: number }>(
        `SELECT sp_record_payment_bounce($1, $2::date, $3, $4, $5, $6, $7, $8, $9, $10) AS id`,
        [body.loanId, body.bounceDate, body.bounceReason, body.paymentId ?? null, body.emiScheduleId ?? null, body.amount ?? null,
         body.paymentReference ?? null, body.applyCharge, body.remarks ?? null, user.id],
        c,
      );
      return r!.id;
    });
    return one(`SELECT ${SELECT} FROM ${FROM} WHERE b.id = $1`, [id]);
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id',
  tag: 'Bounces',
  summary: 'Bounce details',
  permission: 'bounces.read',
  params: idParam,
  handler: async ({ params, user }) => {
    const b = await one<any>(`SELECT ${SELECT} FROM ${FROM} WHERE b.id = $1`, [params.id]);
    if (!b) throw notFound('Bounce');
    await assertLoanAccess(user, b.loanId);
    b.charges = await query(`SELECT * FROM loan_charges WHERE bounce_id = $1`, [params.id]);
    b.reattempts = await query(
      `SELECT id, payment_number, payment_date, amount, status FROM payments
        WHERE loan_id = $1 AND remarks LIKE $2 ORDER BY id`,
      [b.loanId, `%Re-presentation of ${b.bounceNumber}%`],
    );
    return b;
  },
});

route(router, BASE, {
  method: 'post',
  path: '/:id/reattempt',
  tag: 'Bounces',
  summary: 'Re-present a bounced collection (creates a PENDING payment to realise or bounce later)',
  permission: 'bounces.write',
  params: idParam,
  idempotent: true,
  body: z.object({
    presentationDate: isoDate,
    paymentMode: z.enum(['NACH', 'CHEQUE', 'UPI']).default('NACH'),
    transactionReference: z.string().trim().min(3).max(64),
    amount: money.optional(),
  }),
  handler: async ({ params, body, db, user }) => {
    const b = await one<any>(
      `SELECT b.*, e.remaining_amount AS emi_remaining FROM payment_bounces b LEFT JOIN emi_schedules e ON e.id = b.emi_schedule_id WHERE b.id = $1`,
      [params.id],
    );
    if (!b) throw notFound('Bounce');
    await assertLoanAccess(user, b.loanId);
    if (b.recoveryStatus === 'RECOVERED' || b.recoveryStatus === 'WAIVED') throw badRequest('This bounce is already resolved');
    const amount = body.amount ?? Number(b.emiRemaining ?? b.bounceAmount);
    if (!(amount > 0)) throw badRequest('Nothing left to collect for this installment');
    return tx(db, async (c) => {
      const p = await one<{ id: number }>(
        `SELECT sp_process_payment($1, $2, $3::date, $4, $5, 'PENDING', NULL, $6, $7, NULL, 'MANUAL', $8) AS id`,
        [b.loanId, amount, body.presentationDate, body.paymentMode, body.transactionReference, `Re-presentation of ${b.bounceNumber}`, b.emiScheduleId, user.id],
        c,
      );
      await c.query(`UPDATE payment_bounces SET reattempt_count = reattempt_count + 1 WHERE id = $1`, [params.id]);
      return one(`SELECT id, payment_number, status, amount FROM payments WHERE id = $1`, [p!.id], c);
    });
  },
});
