import { Router } from 'express';
import { z } from 'zod';
import { one, query, tx } from '../db/pool.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { route } from '../lib/http.js';
import { respondList } from '../lib/listing.js';
import { buildSchedule } from '../lib/emi.js';
import { idParam, isoDate, listQuerySchema, money, orderBy, Sql } from '../lib/sql.js';
import { executiveScope, type AuthUser } from '../middleware/auth.js';

export const router = Router();
const BASE = '/api/loans';

export async function assertLoanAccess(user: AuthUser, loanId: number) {
  const exec = executiveScope(user);
  if (!exec) return;
  const ok = await one(`SELECT 1 FROM collection_assignments WHERE loan_id = $1 AND executive_id = $2 AND is_active`, [loanId, exec]);
  if (!ok) throw forbidden('This loan is not assigned to you');
}

const loanStatus = z.enum(['DRAFT', 'APPROVED', 'DISBURSED', 'ACTIVE', 'OVERDUE', 'CLOSED', 'WRITTEN_OFF', 'CANCELLED']);

export const loanListQuery = listQuerySchema.extend({
  status: z.union([loanStatus, z.literal('LIVE')]).optional(),
  productId: z.coerce.number().int().optional(),
  branchId: z.coerce.number().int().optional(),
  executiveId: z.coerce.number().int().optional(),
  bucket: z.string().max(20).optional(),
  state: z.string().max(80).optional(),
  dpdMin: z.coerce.number().int().min(0).optional(),
  dpdMax: z.coerce.number().int().min(0).optional(),
  disbursedFrom: isoDate.optional(),
  disbursedTo: isoDate.optional(),
  customerId: z.coerce.number().int().optional(),
});

export const LOAN_SORT: Record<string, string> = {
  loanNumber: 'loan_number', customerName: 'customer_name', productName: 'product_name', principalAmount: 'principal_amount',
  emiAmount: 'emi_amount', status: 'status', disbursementDate: 'disbursement_date', dpd: 'dpd',
  outstandingPrincipal: 'outstanding_principal', overdueAmount: 'overdue_amount', nextEmiDueDate: 'next_emi_due_date',
  createdAt: 'created_at', executiveName: 'executive_name', state: 'state',
};

export const LOAN_COLUMNS = [
  { key: 'loanNumber', label: 'Loan ID' },
  { key: 'customerCode', label: 'Customer ID' },
  { key: 'customerName', label: 'Customer' },
  { key: 'productName', label: 'Product' },
  { key: 'branchName', label: 'Branch' },
  { key: 'principalAmount', label: 'Principal', type: 'money' as const },
  { key: 'annualInterestRate', label: 'Rate %', type: 'number' as const },
  { key: 'tenureMonths', label: 'Tenure', type: 'number' as const },
  { key: 'emiAmount', label: 'EMI', type: 'money' as const },
  { key: 'disbursementDate', label: 'Disbursed', type: 'date' as const },
  { key: 'status', label: 'Status' },
  { key: 'dpd', label: 'DPD', type: 'number' as const },
  { key: 'bucketCode', label: 'Bucket' },
  { key: 'outstandingPrincipal', label: 'POS', type: 'money' as const },
  { key: 'overdueAmount', label: 'Overdue', type: 'money' as const },
  { key: 'executiveName', label: 'Executive' },
];

/** Shared loan filter → used by the loan list and the loan register / overdue reports */
export function loanFilters(q: z.infer<typeof loanListQuery>, user: AuthUser, sql = new Sql()) {
  if (q.search) {
    const s = sql.p(`%${q.search}%`);
    sql.and(`(loan_number ILIKE ${s} OR customer_name ILIKE ${s} OR customer_code ILIKE ${s} OR mobile LIKE ${s})`);
  }
  if (q.status === 'LIVE') sql.and(`status IN ('DISBURSED','ACTIVE','OVERDUE')`);
  else if (q.status) sql.and(`status = ${sql.p(q.status)}`);
  if (q.productId) sql.and(`product_id = ${sql.p(q.productId)}`);
  if (q.branchId) sql.and(`branch_id = ${sql.p(q.branchId)}`);
  if (q.executiveId) sql.and(`executive_id = ${sql.p(q.executiveId)}`);
  if (q.bucket) sql.and(`bucket_code = ${sql.p(q.bucket)}`);
  if (q.state) sql.and(`state = ${sql.p(q.state)}`);
  if (q.dpdMin !== undefined) sql.and(`dpd >= ${sql.p(q.dpdMin)}`);
  if (q.dpdMax !== undefined) sql.and(`dpd <= ${sql.p(q.dpdMax)}`);
  if (q.disbursedFrom) sql.and(`disbursement_date >= ${sql.p(q.disbursedFrom)}`);
  if (q.disbursedTo) sql.and(`disbursement_date <= ${sql.p(q.disbursedTo)}`);
  if (q.customerId) sql.and(`customer_id = ${sql.p(q.customerId)}`);
  const exec = executiveScope(user);
  if (exec) sql.and(`executive_id = ${sql.p(exec)}`);
  return sql;
}

route(router, BASE, {
  method: 'get',
  path: '',
  tag: 'Loans',
  summary: 'Loan register with filters (format=csv|xlsx|pdf to export)',
  permission: 'loans.read',
  query: loanListQuery,
  raw: true,
  handler: async (ctx) => {
    await respondList(ctx, {
      select: '*',
      from: 'vw_loan_register',
      sql: loanFilters(ctx.query, ctx.user),
      order: orderBy(ctx.query, LOAN_SORT, 'id DESC'),
      title: 'Loan Register',
      columns: LOAN_COLUMNS,
      pii: true,
    });
  },
});

const loanBody = z.object({
  customerId: z.coerce.number().int().positive(),
  productId: z.coerce.number().int().positive(),
  branchId: z.coerce.number().int().positive().optional().nullable(),
  principalAmount: money,
  annualInterestRate: z.coerce.number().min(0).max(60),
  interestMethod: z.enum(['REDUCING', 'FLAT']).default('REDUCING'),
  tenureMonths: z.coerce.number().int().min(1).max(360),
  paymentDueDay: z.coerce.number().int().min(1).max(28).default(5),
  processingFee: z.coerce.number().min(0).optional(),
});

async function validateAgainstProduct(b: z.infer<typeof loanBody>) {
  const p = await one<any>(`SELECT * FROM loan_products WHERE id = $1 AND is_active`, [b.productId]);
  if (!p) throw badRequest('Loan product not found or inactive');
  if (b.principalAmount < Number(p.minAmount) || b.principalAmount > Number(p.maxAmount))
    throw badRequest(`Principal must be between ₹${p.minAmount} and ₹${p.maxAmount} for ${p.name}`);
  if (b.tenureMonths < p.minTenureMonths || b.tenureMonths > p.maxTenureMonths)
    throw badRequest(`Tenure must be ${p.minTenureMonths}–${p.maxTenureMonths} months for ${p.name}`);
  const fee = b.processingFee ?? Math.round(b.principalAmount * Number(p.processingFeePct)) / 100;
  if (fee > b.principalAmount * 0.1) throw badRequest('Processing fee cannot exceed 10% of principal');
  const cust = await one<any>(`SELECT status FROM customers WHERE id = $1 AND deleted_at IS NULL`, [b.customerId]);
  if (!cust) throw badRequest('Customer not found');
  if (cust.status !== 'ACTIVE') throw badRequest(`Customer is ${cust.status}`);
  return { fee: Math.round(fee * 100) / 100 };
}

route(router, BASE, {
  method: 'post',
  path: '/preview-schedule',
  tag: 'Loans',
  summary: 'EMI calculator — preview a repayment schedule without saving',
  permission: ['loans.read', 'loans.write'],
  status: 200,
  body: z.object({
    principalAmount: money,
    annualInterestRate: z.coerce.number().min(0).max(60),
    tenureMonths: z.coerce.number().int().min(1).max(360),
    interestMethod: z.enum(['REDUCING', 'FLAT']).default('REDUCING'),
    firstEmiDate: isoDate.optional(),
  }),
  handler: async ({ body }) => {
    const places = await one<{ v: string }>(`SELECT fn_setting('emi_rounding_places') AS v`);
    return buildSchedule({
      principal: body.principalAmount,
      annualRate: body.annualInterestRate,
      tenureMonths: body.tenureMonths,
      method: body.interestMethod,
      firstEmiDate: body.firstEmiDate,
      roundingPlaces: Number(places?.v ?? 0),
    });
  },
});

route(router, BASE, {
  method: 'post',
  path: '',
  tag: 'Loans',
  summary: 'Create a loan in DRAFT status',
  permission: 'loans.write',
  body: loanBody,
  handler: async ({ body, db, user }) => {
    const { fee } = await validateAgainstProduct(body);
    return tx(db, (c) =>
      one(
        `INSERT INTO loans (customer_id, product_id, branch_id, principal_amount, annual_interest_rate, interest_method,
                            tenure_months, payment_due_day, processing_fee, status, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'DRAFT',$10) RETURNING id, loan_number, status`,
        [body.customerId, body.productId, body.branchId ?? null, body.principalAmount, body.annualInterestRate,
         body.interestMethod, body.tenureMonths, body.paymentDueDay, fee, user.id],
        c,
      ),
    );
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id',
  tag: 'Loans',
  summary: 'Loan details incl. outstanding, DPD, charges',
  permission: 'loans.read',
  params: idParam,
  handler: async ({ params, user }) => {
    await assertLoanAccess(user, params.id);
    const loan = await one<any>(`SELECT * FROM vw_loan_register WHERE id = $1`, [params.id]);
    if (!loan) throw notFound('Loan');
    const [outstanding, charges, extra, counts] = await Promise.all([
      one(`SELECT * FROM vw_loan_outstanding WHERE loan_id = $1`, [params.id]),
      query(`SELECT * FROM loan_charges WHERE loan_id = $1 ORDER BY charge_date DESC, id DESC`, [params.id]),
      one(
        `SELECT l.closed_at, l.closure_remarks, l.approved_at, ua.full_name AS approved_by_name, ud.full_name AS disbursed_by_name,
                uc.full_name AS created_by_name, p.bounce_charge, p.processing_fee_pct
           FROM loans l JOIN loan_products p ON p.id = l.product_id
           LEFT JOIN users ua ON ua.id = l.approved_by LEFT JOIN users ud ON ud.id = l.disbursed_by
           LEFT JOIN users uc ON uc.id = l.created_by WHERE l.id = $1`,
        [params.id],
      ),
      one(
        `SELECT (SELECT count(*) FROM payment_bounces WHERE loan_id = $1)::int AS bounce_count,
                (SELECT count(*) FROM payments WHERE loan_id = $1 AND status = 'SUCCESSFUL')::int AS payment_count,
                (SELECT count(*) FROM payments WHERE loan_id = $1 AND status IN ('PENDING','INITIATED'))::int AS pending_payment_count,
                (SELECT count(*) FROM promise_to_pay WHERE loan_id = $1 AND status = 'PENDING')::int AS open_ptp_count`,
        [params.id],
      ),
    ]);
    return { ...loan, ...extra, outstanding, charges, ...counts };
  },
});

route(router, BASE, {
  method: 'put',
  path: '/:id',
  tag: 'Loans',
  summary: 'Edit a DRAFT loan (terms are frozen after approval)',
  permission: 'loans.write',
  params: idParam,
  body: loanBody,
  handler: async ({ params, body, db }) => {
    const cur = await one<any>(`SELECT status FROM loans WHERE id = $1`, [params.id]);
    if (!cur) throw notFound('Loan');
    if (cur.status !== 'DRAFT') throw conflict(`Only DRAFT loans can be edited (loan is ${cur.status})`);
    const { fee } = await validateAgainstProduct(body);
    return tx(db, (c) =>
      one(
        `UPDATE loans SET customer_id=$2, product_id=$3, branch_id=$4, principal_amount=$5, annual_interest_rate=$6,
                interest_method=$7, tenure_months=$8, payment_due_day=$9, processing_fee=$10
          WHERE id = $1 AND status = 'DRAFT' RETURNING id, loan_number, status`,
        [params.id, body.customerId, body.productId, body.branchId ?? null, body.principalAmount, body.annualInterestRate,
         body.interestMethod, body.tenureMonths, body.paymentDueDay, fee],
        c,
      ),
    );
  },
});

async function transition(loanId: number, from: string[], to: string, db: any, extra = '') {
  return tx(db, async (c) => {
    const cur = await one<any>(`SELECT status, loan_number FROM loans WHERE id = $1 FOR UPDATE`, [loanId], c);
    if (!cur) throw notFound('Loan');
    if (!from.includes(cur.status)) throw conflict(`Loan ${cur.loanNumber} is ${cur.status}; expected ${from.join(' or ')}`);
    return one(`UPDATE loans SET status = $2 ${extra} WHERE id = $1 RETURNING id, loan_number, status`, [loanId, to], c);
  });
}

route(router, BASE, {
  method: 'post',
  path: '/:id/approve',
  tag: 'Loans',
  summary: 'Approve a DRAFT loan',
  permission: 'loans.approve',
  params: idParam,
  status: 200,
  handler: async ({ params, db, user }) =>
    transition(params.id, ['DRAFT'], 'APPROVED', db, `, approved_by = ${Number(user.id)}, approved_at = now()`),
});

route(router, BASE, {
  method: 'post',
  path: '/:id/cancel',
  tag: 'Loans',
  summary: 'Cancel a DRAFT or APPROVED loan',
  permission: 'loans.approve',
  params: idParam,
  status: 200,
  body: z.object({ remarks: z.string().trim().min(3).max(500) }),
  handler: async ({ params, db, body }) => {
    const r = await transition(params.id, ['DRAFT', 'APPROVED'], 'CANCELLED', db);
    await query(`UPDATE loans SET closure_remarks = $2 WHERE id = $1`, [params.id, body.remarks]);
    return r;
  },
});

route(router, BASE, {
  method: 'post',
  path: '/:id/disburse',
  tag: 'Loans',
  summary: 'Disburse an APPROVED loan and generate its EMI schedule (atomic)',
  permission: 'loans.disburse',
  params: idParam,
  status: 200,
  body: z.object({ disbursementDate: isoDate, firstEmiDate: isoDate.optional().nullable() }),
  handler: async ({ params, body, db, user }) => {
    await tx(db, (c) =>
      c.query('SELECT sp_disburse_loan($1, $2::date, $3::date, $4)', [params.id, body.disbursementDate, body.firstEmiDate ?? null, user.id]),
    );
    return one(`SELECT id, loan_number, status, emi_amount, first_emi_date, maturity_date FROM loans WHERE id = $1`, [params.id]);
  },
});

route(router, BASE, {
  method: 'post',
  path: '/:id/close',
  tag: 'Loans',
  summary: 'Close a loan (all dues must be settled or waived)',
  permission: 'loans.close',
  params: idParam,
  status: 200,
  body: z.object({ remarks: z.string().trim().max(500).optional() }),
  handler: async ({ params, body, db, user }) => {
    await tx(db, (c) => c.query('SELECT sp_close_loan($1, $2, $3)', [params.id, user.id, body.remarks ?? null]));
    return { ok: true };
  },
});

route(router, BASE, {
  method: 'post',
  path: '/:id/write-off',
  tag: 'Loans',
  summary: 'Write off an overdue loan (DPD ≥ configured minimum)',
  permission: 'loans.write_off',
  params: idParam,
  status: 200,
  body: z.object({ remarks: z.string().trim().min(3).max(500) }),
  handler: async ({ params, body, db, user }) => {
    await tx(db, (c) => c.query('SELECT sp_write_off_loan($1, $2, $3)', [params.id, user.id, body.remarks]));
    return { ok: true };
  },
});

route(router, BASE, {
  method: 'post',
  path: '/:id/waive',
  tag: 'Loans',
  summary: 'Formally waive a charge (partly or fully) or the remaining amount of an installment',
  permission: 'loans.waive',
  params: idParam,
  status: 200,
  body: z.object({
    target: z.enum(['CHARGE', 'EMI']),
    targetId: z.coerce.number().int().positive(),
    amount: money.optional(),
    reason: z.string().trim().min(3).max(500),
  }),
  handler: async ({ params, body, db, user }) => {
    if (body.target === 'CHARGE' && !body.amount) throw badRequest('Amount is required for a charge waiver');
    await tx(db, (c) =>
      c.query('SELECT sp_waive($1, $2, $3, $4, $5, $6)', [params.id, body.target, body.targetId, body.amount ?? null, body.reason, user.id]),
    );
    return { ok: true };
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id/emi-schedule',
  tag: 'EMI',
  summary: 'Installment-wise schedule with payment allocation status',
  permission: 'loans.read',
  params: idParam,
  handler: async ({ params, user }) => {
    await assertLoanAccess(user, params.id);
    return query(`SELECT * FROM emi_schedules WHERE loan_id = $1 ORDER BY installment_no`, [params.id]);
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id/payments',
  tag: 'Loans',
  summary: 'Repayment history with allocations',
  permission: 'payments.read',
  params: idParam,
  handler: async ({ params, user }) => {
    await assertLoanAccess(user, params.id);
    return query(
      `SELECT p.*, u.full_name AS collected_by_name,
              COALESCE((SELECT json_agg(json_build_object('component', a.component, 'amount', a.amount, 'isAdvance', a.is_advance,
                         'installmentNo', e.installment_no, 'chargeId', a.charge_id) ORDER BY a.id)
                          FROM payment_allocations a LEFT JOIN emi_schedules e ON e.id = a.emi_schedule_id
                         WHERE a.payment_id = p.id), '[]') AS allocations,
              r.reason AS reversal_reason, r.reversal_date
         FROM payments p LEFT JOIN users u ON u.id = p.collected_by LEFT JOIN payment_reversals r ON r.payment_id = p.id
        WHERE p.loan_id = $1 ORDER BY p.payment_date DESC, p.id DESC`,
      [params.id],
    );
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id/bounces',
  tag: 'Loans',
  summary: 'Bounce history of a loan',
  permission: 'bounces.read',
  params: idParam,
  handler: async ({ params, user }) => {
    await assertLoanAccess(user, params.id);
    return query(
      `SELECT b.*, e.installment_no, p.payment_number FROM payment_bounces b
         LEFT JOIN emi_schedules e ON e.id = b.emi_schedule_id LEFT JOIN payments p ON p.id = b.payment_id
        WHERE b.loan_id = $1 ORDER BY b.bounce_date DESC, b.id DESC`,
      [params.id],
    );
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id/ledger',
  tag: 'Loans',
  summary: 'Loan ledger: dues vs receipts with running balance',
  permission: 'loans.read',
  params: idParam,
  query: z.object({ asOf: isoDate.optional() }),
  handler: async ({ params, query: q, user }) => {
    await assertLoanAccess(user, params.id);
    return query(`SELECT * FROM fn_loan_ledger($1, $2::date)`, [params.id, q.asOf ?? null]);
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id/dpd-history',
  tag: 'Loans',
  summary: 'Daily DPD snapshots of a loan',
  permission: 'dpd.read',
  params: idParam,
  handler: async ({ params, user }) => {
    await assertLoanAccess(user, params.id);
    return query(
      `SELECT business_date, dpd, bucket_code, overdue_amount, overdue_emi_count, outstanding_principal, account_status
         FROM dpd_daily_snapshots WHERE loan_id = $1 ORDER BY business_date DESC LIMIT 400`,
      [params.id],
    );
  },
});

route(router, BASE, {
  method: 'get',
  path: '/:id/history',
  tag: 'Loans',
  summary: 'Audit history of a loan',
  permission: 'loans.read',
  params: idParam,
  handler: async ({ params, user }) => {
    await assertLoanAccess(user, params.id);
    return query(
      `SELECT a.id, a.action, a.entity_type, a.old_values, a.new_values, a.created_at, u.full_name AS user_name
         FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
        WHERE (a.entity_type = 'loans' AND a.entity_id = $1::text)
           OR (a.action = 'WAIVER' AND (a.new_values ->> 'loan_id') = $1::text)
        ORDER BY a.id DESC LIMIT 300`,
      [params.id],
    );
  },
});
