import { Router } from 'express';
import { z } from 'zod';
import { one, query } from '../db/pool.js';
import { badRequest } from '../lib/errors.js';
import { route } from '../lib/http.js';
import { isoDate } from '../lib/sql.js';
import { bucketPortfolio, currentBusinessDate } from './dpd.js';

export const router = Router();
const BASE = '/api/dashboard';

const range = z.object({ from: isoDate.optional(), to: isoDate.optional() });

async function resolveRange(q: { from?: string; to?: string }) {
  const bd = await currentBusinessDate();
  const to = q.to ?? bd;
  const from = q.from ?? `${to.slice(0, 7)}-01`;
  if (from > to) throw badRequest('"from" must not be after "to"');
  return { from, to, bd };
}

/**
 * KPIs. Period figures use [from, to]; position figures (POS, overdue, PAR, buckets)
 * are as of the current business date. Collection efficiency uses fn_collection_efficiency,
 * the same function the Collection Efficiency report uses.
 */
route(router, BASE, {
  method: 'get',
  path: '/overview',
  tag: 'Dashboard',
  summary: 'Headline KPIs for a period (defaults to month-to-date)',
  permission: 'dashboard.read',
  query: range,
  handler: async ({ query: q }) => {
    const { from, to, bd } = await resolveRange(q);
    const k = await one(
      `SELECT
         (SELECT count(*) FROM loans WHERE disbursement_date IS NOT NULL)::int AS total_loan_accounts,
         (SELECT COALESCE(sum(principal_amount), 0) FROM loans WHERE disbursement_date IS NOT NULL) AS total_disbursed_amount,
         (SELECT COALESCE(sum(principal_amount), 0) FROM loans WHERE disbursement_date BETWEEN $1 AND $2) AS disbursed_in_period,
         (SELECT count(*) FROM loans WHERE disbursement_date BETWEEN $1 AND $2)::int AS loans_disbursed_in_period,
         (SELECT count(*) FROM loans WHERE status IN ('DISBURSED','ACTIVE','OVERDUE'))::int AS total_active_accounts,
         (SELECT count(*) FROM loans WHERE status = 'CLOSED')::int AS total_closed_accounts,
         (SELECT count(*) FROM loans WHERE status = 'WRITTEN_OFF')::int AS total_written_off_accounts,
         (SELECT COALESCE(sum(overdue_amount), 0) FROM dpd_current WHERE account_status IN ('DISBURSED','ACTIVE','OVERDUE')) AS total_overdue_amount,
         (SELECT COALESCE(sum(overdue_charges), 0) FROM dpd_current WHERE account_status IN ('DISBURSED','ACTIVE','OVERDUE')) AS total_overdue_charges,
         (SELECT count(*) FROM dpd_current WHERE account_status IN ('DISBURSED','ACTIVE','OVERDUE') AND dpd >= 90)::int AS accounts_90_plus,
         (SELECT count(*) FROM dpd_current WHERE account_status IN ('DISBURSED','ACTIVE','OVERDUE') AND dpd > 0)::int AS overdue_accounts,
         (SELECT count(*) FROM payment_bounces WHERE bounce_date BETWEEN $1 AND $2)::int AS total_bounced_payments,
         (SELECT COALESCE(sum(amount), 0) FROM payments WHERE status = 'SUCCESSFUL' AND payment_date BETWEEN $1 AND $2) AS total_collected,
         (SELECT COALESCE(sum(a.amount), 0) FROM payment_allocations a JOIN payments p ON p.id = a.payment_id
           WHERE p.status = 'SUCCESSFUL' AND p.payment_date BETWEEN $1 AND $2 AND a.component <> 'CHARGE') AS total_emi_collected`,
      [from, to],
    );
    const ce = await one(`SELECT * FROM fn_collection_efficiency($1, $2)`, [from, to]);
    const par = await one(`SELECT * FROM vw_par_summary`);
    return {
      period: { from, to },
      businessDate: bd,
      ...k,
      totalOutstandingPrincipal: par.totalPos,
      totalEmiDue: ce.demand,
      collectedAgainstDue: ce.collectedAgainstDemand,
      collectionEfficiencyPct: ce.efficiencyPct,
      par,
    };
  },
});

route(router, BASE, {
  method: 'get',
  path: '/dpd-buckets',
  tag: 'Dashboard',
  summary: 'Live DPD bucket distribution (count, POS, overdue) with PAR',
  permission: 'dashboard.read',
  handler: async ({ user }) => bucketPortfolio({}, user),
});

route(router, BASE, {
  method: 'get',
  path: '/collections',
  tag: 'Dashboard',
  summary: 'Monthly collection trend, EMI due vs collected, collection by mode and by executive',
  permission: 'dashboard.read',
  query: range,
  handler: async ({ query: q }) => {
    const { from, to } = await resolveRange(q);
    // monthly series always shows at least the last 6 months for context
    const seriesFrom = (await one<{ d: string }>(`SELECT LEAST($1::date, (date_trunc('month', $2::date) - interval '5 months')::date)::text AS d`, [from, to]))!.d;
    const monthly = await query(
      `WITH m AS (SELECT generate_series(date_trunc('month', $1::date), date_trunc('month', $2::date), interval '1 month')::date AS m)
       SELECT to_char(m.m, 'YYYY-MM') AS month,
              ce.demand AS emi_due, ce.collected_against_demand, ce.efficiency_pct,
              (SELECT COALESCE(sum(amount), 0) FROM payments p WHERE p.status = 'SUCCESSFUL'
                 AND p.payment_date BETWEEN m.m AND LEAST((m.m + interval '1 month - 1 day')::date, $2::date)) AS collected
         FROM m CROSS JOIN LATERAL fn_collection_efficiency(m.m, LEAST((m.m + interval '1 month - 1 day')::date, $2::date)) ce
        ORDER BY m.m`,
      [seriesFrom, to],
    );
    const byMode = await query(
      `SELECT payment_mode, sum(successful_count)::int AS count, sum(successful_amount) AS amount
         FROM vw_daily_collection_summary WHERE payment_date BETWEEN $1 AND $2 GROUP BY 1 ORDER BY 3 DESC`,
      [from, to],
    );
    const byExecutive = await query(
      `SELECT u.full_name AS executive_name, COALESCE(sum(p.amount), 0) AS collected, count(p.id)::int AS payments
         FROM users u JOIN roles r ON r.id = u.role_id AND r.code = 'COLLECTION_EXECUTIVE'
         LEFT JOIN collection_assignments a ON a.executive_id = u.id AND a.is_active
         LEFT JOIN payments p ON p.loan_id = a.loan_id AND p.status = 'SUCCESSFUL' AND p.payment_date BETWEEN $1 AND $2
        WHERE u.deleted_at IS NULL GROUP BY u.id, u.full_name ORDER BY 2 DESC`,
      [from, to],
    );
    const daily = await query(
      `SELECT g.d::date::text AS date, COALESCE(sum(s.successful_amount), 0) AS collected
         FROM generate_series($1::date, $2::date, interval '1 day') g(d)
         LEFT JOIN vw_daily_collection_summary s ON s.payment_date = g.d::date GROUP BY g.d ORDER BY g.d`,
      [from, to],
    );
    return { period: { from, to }, monthly, byMode, byExecutive, daily };
  },
});

route(router, BASE, {
  method: 'get',
  path: '/trends',
  tag: 'Dashboard',
  summary: 'Bounce-rate trend, daily overdue-account trend and portfolio mix by product',
  permission: 'dashboard.read',
  query: range,
  handler: async ({ query: q }) => {
    const { from, to } = await resolveRange(q);
    const monthsFrom = (await one<{ d: string }>(`SELECT LEAST($1::date, (date_trunc('month', $2::date) - interval '5 months')::date)::text AS d`, [from, to]))!.d;
    const bounceTrend = await query(
      `WITH m AS (SELECT generate_series(date_trunc('month', $1::date), date_trunc('month', $2::date), interval '1 month')::date AS m)
       SELECT to_char(m.m, 'YYYY-MM') AS month, x.bounces, x.presentations,
              CASE WHEN x.presentations > 0 THEN round(x.bounces * 100.0 / x.presentations, 2) ELSE 0 END AS bounce_rate_pct
         FROM m CROSS JOIN LATERAL (
           SELECT (SELECT count(*) FROM payment_bounces b WHERE date_trunc('month', b.bounce_date) = m.m)::int AS bounces,
                  ((SELECT count(*) FROM payments p WHERE p.payment_mode IN ('NACH','CHEQUE') AND date_trunc('month', p.payment_date) = m.m)
                 + (SELECT count(*) FROM payment_bounces b WHERE b.payment_id IS NULL AND date_trunc('month', b.bounce_date) = m.m))::int AS presentations) x
        ORDER BY m.m`,
      [monthsFrom, to],
    );
    const overdueTrend = await query(
      `SELECT business_date::text AS date,
              sum(account_count) FILTER (WHERE bucket_code <> (SELECT code FROM fn_dpd_bucket(0)))::int AS overdue_accounts,
              sum(account_count)::int AS total_accounts,
              sum(overdue_amount) AS overdue_amount
         FROM portfolio_daily_summary WHERE business_date BETWEEN $1 AND $2 GROUP BY business_date ORDER BY business_date`,
      [from, to],
    );
    const byProduct = await query(
      `SELECT p.name AS product_name, count(d.loan_id)::int AS accounts, COALESCE(sum(d.outstanding_principal), 0) AS outstanding_principal,
              COALESCE(sum(d.overdue_amount), 0) AS overdue_amount
         FROM loan_products p LEFT JOIN loans l ON l.product_id = p.id
         LEFT JOIN dpd_current d ON d.loan_id = l.id AND d.account_status IN ('DISBURSED','ACTIVE','OVERDUE')
        GROUP BY p.id, p.name ORDER BY 3 DESC`,
    );
    return { period: { from, to }, bounceTrend, overdueTrend, byProduct };
  },
});
