import { registry, zodToJson } from './lib/http.js';

/** OpenAPI 3.1 document generated from the same route definitions that serve requests. */
export function buildOpenApi() {
  const paths: Record<string, any> = {};
  for (const { def, fullPath } of registry) {
    const p = fullPath.replace(/:([A-Za-z_]+)/g, '{$1}');
    const params: any[] = [];
    for (const m of fullPath.matchAll(/:([A-Za-z_]+)/g)) params.push({ name: m[1], in: 'path', required: true, schema: { type: 'string' } });
    if (def.query) {
      const js: any = zodToJson(def.query);
      for (const [name, schema] of Object.entries<any>(js.properties ?? {}))
        params.push({ name, in: 'query', required: (js.required ?? []).includes(name), schema });
    }
    if (def.idempotent) params.push({ name: 'Idempotency-Key', in: 'header', required: false, schema: { type: 'string', minLength: 8, maxLength: 128 } });
    const perms = def.permission ? (Array.isArray(def.permission) ? def.permission : [def.permission]) : [];
    paths[p] ??= {};
    paths[p][def.method] = {
      tags: [def.tag],
      summary: def.summary,
      description: perms.length ? `Requires permission: ${perms.join(' or ')}` : def.public ? 'Public endpoint' : 'Any authenticated user',
      security: def.public ? [] : [{ bearerAuth: [] }],
      parameters: params,
      requestBody: def.body ? { required: true, content: { 'application/json': { schema: zodToJson(def.body) } } } : undefined,
      responses: {
        [def.status ?? (def.method === 'post' ? 201 : 200)]: { description: 'Success' },
        400: { $ref: '#/components/responses/Error' },
        401: { $ref: '#/components/responses/Error' },
        403: { $ref: '#/components/responses/Error' },
        404: { $ref: '#/components/responses/Error' },
        409: { $ref: '#/components/responses/Error' },
      },
    };
  }
  return {
    openapi: '3.1.0',
    info: {
      title: 'Loan Collections & DPD Management API',
      version: '1.0.0',
      description:
        'All money values are decimal amounts in INR. Dates are YYYY-MM-DD business dates. List endpoints accept page, pageSize, sort, order, search and format=json|csv|xlsx|pdf. Errors share one shape: { error: { code, message, details, requestId } }.',
    },
    servers: [{ url: '/' }],
    components: {
      securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } },
      responses: {
        Error: {
          description: 'Error',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  error: { type: 'object', properties: { code: { type: 'string' }, message: { type: 'string' }, details: {}, requestId: { type: 'string' } } },
                },
              },
            },
          },
        },
      },
    },
    paths,
  };
}
