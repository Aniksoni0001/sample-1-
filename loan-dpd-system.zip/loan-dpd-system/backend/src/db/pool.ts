import pg from 'pg';
import { env } from '../config/env.js';

// NUMERIC → JS number for transport only. All money arithmetic happens in
// PostgreSQL (NUMERIC) or decimal.js; values carry ≤ 2 decimals so the
// JSON number round-trips exactly.
pg.types.setTypeParser(1700, (v) => (v === null ? null : Number(v)));
pg.types.setTypeParser(20, (v) => (v === null ? null : Number.parseInt(v, 10))); // int8 (counts, ids)
pg.types.setTypeParser(1082, (v) => v); // DATE stays 'YYYY-MM-DD' — never shifted by timezones

export const pool = new pg.Pool({
  connectionString: env.DATABASE_URL,
  max: 15,
  idleTimeoutMillis: 30_000,
  application_name: 'loan-dpd-api',
});

export type Db = pg.Pool | pg.PoolClient;

const keyCache = new Map<string, string>();
const camel = (k: string) => {
  let c = keyCache.get(k);
  if (!c) {
    c = k.replace(/_([a-z0-9])/g, (_, ch: string) => ch.toUpperCase());
    keyCache.set(k, c);
  }
  return c;
};

/** Runs a query and returns rows with camelCase keys (API responses are camelCase end to end). */
export async function query<T = any>(text: string, params: unknown[] = [], db: Db = pool): Promise<T[]> {
  const res = await db.query(text, params as any[]);
  if (!res.rows.length) return [];
  const keys = Object.keys(res.rows[0]);
  if (!keys.some((k) => k.includes('_'))) return res.rows as T[];
  return res.rows.map((r) => {
    const o: Record<string, unknown> = {};
    for (const k of keys) o[camel(k)] = r[k];
    return o as T;
  });
}

export async function one<T = any>(text: string, params: unknown[] = [], db: Db = pool): Promise<T | undefined> {
  const rows = await query<T>(text, params, db);
  return rows[0];
}

export interface DbContext {
  userId?: number | null;
  requestId?: string;
  ip?: string;
}

/**
 * Runs fn inside a transaction. The acting user / request id / IP are put in
 * transaction-local settings so database triggers can write the audit trail.
 */
export async function tx<T>(ctx: DbContext, fn: (client: pg.PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `SELECT set_config('app.user_id', $1, true), set_config('app.request_id', $2, true), set_config('app.ip', $3, true)`,
      [ctx.userId ? String(ctx.userId) : '', ctx.requestId ?? '', ctx.ip ?? ''],
    );
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => undefined);
    throw err;
  } finally {
    client.release();
  }
}

/** Like tx() but always rolls back — used for "preview" calls that reuse the real stored procedures. */
export async function dryRun<T>(ctx: DbContext, fn: (client: pg.PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(`SELECT set_config('app.user_id', $1, true)`, [ctx.userId ? String(ctx.userId) : '']);
    return await fn(client);
  } finally {
    await client.query('ROLLBACK').catch(() => undefined);
    client.release();
  }
}
