/**
 * Demo data generator.
 *
 * Instead of inserting rows directly, it REPLAYS ~11 months of business day by day
 * through the real stored procedures: loans are disbursed, NACH debits are
 * presented, some bounce, customers pay late / partially / not at all,
 * executives log calls and promises, payments get reversed — and the nightly DPD
 * job runs for every day. The result is internally consistent by construction:
 * every snapshot, bucket and balance is what the engine itself produced.
 *
 *   npm run seed            → seeds an empty database (no-op if users exist)
 *   npm run seed -- --reset → DROPS everything, re-migrates, seeds  (dev only)
 */
import bcrypt from 'bcryptjs';
import { fakerEN_IN as faker } from '@faker-js/faker';
import type pg from 'pg';
import { pool } from '../db/pool.js';
import { migrate } from '../db/migrate.js';

const DEMO_PASSWORD = 'Demo@12345';
const LOAN_COUNT = 150;
const CUSTOMER_COUNT = 100;
const HISTORY_DAYS = 330;

const args = new Set(process.argv.slice(2));
const quiet = args.has('--quiet');
const log = (...a: unknown[]) => !quiet && console.log(...a);

// ---------------------------------------------------------------- deterministic RNG
let seed = 20261104;
const rnd = () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const int = (a: number, b: number) => a + Math.floor(rnd() * (b - a + 1));
const pick = <T,>(xs: readonly T[]) => xs[Math.floor(rnd() * xs.length)];
const chance = (p: number) => rnd() < p;
faker.seed(42);

const addDays = (iso: string, n: number) => {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};
const round2 = (n: number) => Math.round(n * 100) / 100;

type Profile = 'GOOD' | 'LATE' | 'PARTIAL' | 'BOUNCER' | 'DEFAULTER' | 'PREPAYER';
interface SimLoan {
  id: number;
  number: string;
  profile: Profile;
  disburseOn: string;
  productId: number;
  defaultTargetDpd?: number; // defaulters: stop paying so that they end near this DPD
  prepayAt?: number;
  closed?: boolean;
}
interface Ev {
  date: string;
  loanId: number;
  kind: 'PAY_DUE' | 'PAY_ALL_OVERDUE' | 'PAY_PARTIAL' | 'BOUNCE_EMI' | 'FORECLOSE' | 'CHEQUE' | 'UPI_FAIL';
  emiId?: number;
  frac?: number;
}

async function q<T = any>(c: pg.PoolClient | pg.Pool, sql: string, params: unknown[] = []): Promise<T[]> {
  return (await c.query(sql, params as any[])).rows as T[];
}

async function main() {
  if (process.env.NODE_ENV === 'production' && !args.has('--force')) throw new Error('Refusing to seed in production (use --force)');
  if (process.env.SEED_DEMO_DATA === 'false') {
    log('SEED_DEMO_DATA=false — applying migrations only.');
    await migrate(log);
    return;
  }

  if (args.has('--reset')) {
    log('⚠  --reset: dropping and recreating the public schema');
    await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  }
  await migrate(log);

  const existing = (await q<{ n: number }>(pool, 'SELECT count(*)::int AS n FROM users'))[0].n;
  if (existing > 0) {
    log(`Database already has ${existing} user(s) — skipping seed. Use --reset to rebuild demo data.`);
    return;
  }

  const c = await pool.connect();
  const t0 = Date.now();
  try {
    await c.query(`SELECT set_config('app.request_id', 'seed', false)`);
    const today = (await q<{ d: string }>(c, `SELECT fn_calendar_today()::text AS d`))[0].d;
    const start = addDays(today, -HISTORY_DAYS);
    log(`Simulating ${start} → ${today}`);
    // wind the business clock back to the start of the simulation (the daily job only moves it forward)
    await c.query(`UPDATE system_settings SET value = $1 WHERE key = 'business_date'`, [addDays(start, -1)]);

    // ------------------------------------------------------------ users
    const hash = await bcrypt.hash(DEMO_PASSWORD, 10);
    const roleId = async (code: string) => (await q<{ id: number }>(c, 'SELECT id FROM roles WHERE code = $1', [code]))[0].id;
    const mkUser = async (email: string, name: string, role: string, branch: string | null = null) =>
      (
        await q<{ id: number }>(
          c,
          `INSERT INTO users (email, full_name, phone, password_hash, role_id, branch_id)
           VALUES ($1,$2,$3,$4,$5,(SELECT id FROM branches WHERE code = $6)) RETURNING id`,
          [email, name, faker.helpers.replaceSymbols('9#########'), hash, await roleId(role), branch],
        )
      )[0].id;
    const superAdmin = await mkUser('superadmin@demo.local', 'Aarav Mehta', 'SUPER_ADMIN', 'HO');
    await mkUser('admin@demo.local', 'Priya Nair', 'ADMIN', 'HO');
    const manager = await mkUser('manager@demo.local', 'Rohit Deshmukh', 'COLLECTION_MANAGER', 'HO');
    const finance = await mkUser('finance@demo.local', 'Sneha Kulkarni', 'FINANCE_USER', 'HO');
    await mkUser('analyst@demo.local', 'Vikram Rao', 'READ_ONLY_ANALYST', 'HO');
    const execs = [
      await mkUser('exec1@demo.local', 'Amit Patil', 'COLLECTION_EXECUTIVE', 'PNQ'),
      await mkUser('exec2@demo.local', 'Neha Singh', 'COLLECTION_EXECUTIVE', 'PAT'),
      await mkUser('exec3@demo.local', 'Suresh Mahato', 'COLLECTION_EXECUTIVE', 'RNC'),
      await mkUser('exec4@demo.local', 'Anjali Das', 'COLLECTION_EXECUTIVE', 'BBS'),
    ];
    await c.query(`SELECT set_config('app.user_id', $1, false)`, [String(finance)]);

    // ------------------------------------------------------------ customers
    const branches = await q<{ id: number; city: string; state: string }>(c, `SELECT id, city, state FROM branches WHERE code <> 'HO' ORDER BY id`);
    const occupations = ['Salaried', 'Self-employed', 'Shop owner', 'Farmer', 'Driver', 'Teacher', 'Electrician', 'Delivery partner', 'Nurse', 'Contractor'];
    const customers: { id: number; branchId: number }[] = [];
    const usedPan = new Set<string>();
    for (let i = 0; i < CUSTOMER_COUNT; i++) {
      const b = pick(branches);
      const sex = chance(0.62) ? 'MALE' : 'FEMALE';
      const first = faker.person.firstName(sex === 'MALE' ? 'male' : 'female');
      const last = faker.person.lastName();
      let pan: string;
      do pan = `${faker.string.alpha({ length: 3, casing: 'upper' })}P${last[0].toUpperCase().replace(/[^A-Z]/, 'K')}${faker.string.numeric(4)}${faker.string.alpha({ length: 1, casing: 'upper' })}`;
      while (usedPan.has(pan));
      usedPan.add(pan);
      const row = await q<{ id: number }>(
        c,
        `INSERT INTO customers (full_name, mobile, email, date_of_birth, gender, pan, aadhaar_last4, address_line, city, state, pincode, occupation, monthly_income, created_by, created_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14, $15::date + time '10:00') RETURNING id`,
        [
          `${first} ${last}`,
          `${pick(['6', '7', '8', '9'])}${faker.string.numeric(9)}`,
          chance(0.7) ? `${first}.${last}${int(1, 99)}@example.com`.toLowerCase() : null,
          faker.date.birthdate({ min: 22, max: 58, mode: 'age' }).toISOString().slice(0, 10),
          sex,
          pan,
          faker.string.numeric(4),
          `${int(1, 250)}, ${faker.location.street()}`,
          b.city,
          b.state,
          `${int(1, 8)}${faker.string.numeric(5)}`,
          pick(occupations),
          int(12, 90) * 1000,
          finance,
          addDays(start, -int(1, 30)),
        ],
      );
      customers.push({ id: row[0].id, branchId: b.id });
    }
    log(`✓ ${customers.length} customers`);

    // ------------------------------------------------------------ loan plan
    const products = await q<any>(c, `SELECT * FROM loan_products ORDER BY id`);
    const P = Object.fromEntries(products.map((p: any) => [p.code, p]));
    const profiles: Profile[] = [];
    const mix: [Profile, number][] = [['GOOD', 58], ['LATE', 24], ['PARTIAL', 12], ['BOUNCER', 16], ['DEFAULTER', 32], ['PREPAYER', 8]];
    for (const [p, n] of mix) for (let i = 0; i < n; i++) profiles.push(p);
    const targets = [12, 25, 40, 55, 70, 85, 100, 140, 180, 240];
    const plan: { customer: (typeof customers)[number]; product: any; amount: number; tenure: number; rate: number; dueDay: number; disburseOn: string; profile: Profile; method: 'REDUCING' | 'FLAT' }[] = [];
    for (let i = 0; i < LOAN_COUNT; i++) {
      const customer = i < CUSTOMER_COUNT ? customers[i] : pick(customers);
      const prodCode = pick(['TW', 'TW', 'TW', 'PL', 'PL', 'LAP', 'CD']);
      const product = P[prodCode];
      const amount =
        prodCode === 'TW' ? int(45, 160) * 1000 : prodCode === 'PL' ? int(30, 300) * 1000 : prodCode === 'LAP' ? int(6, 40) * 100000 : int(15, 90) * 1000;
      const tenure = prodCode === 'TW' ? pick([12, 18, 24, 30, 36]) : prodCode === 'PL' ? pick([12, 18, 24, 36]) : prodCode === 'LAP' ? pick([60, 84, 120]) : pick([6, 9, 12]);
      const rate = prodCode === 'CD' ? 0 : round2(Number(product.default_rate) + (int(-150, 250) / 100));
      // most loans disbursed early enough to have repayment history; ~8% very recent
      const disburseOn = i % 12 === 0 ? addDays(today, -int(2, 25)) : addDays(start, int(0, HISTORY_DAYS - 70));
      plan.push({ customer, product, amount, tenure, rate, dueDay: pick([2, 5, 7, 10, 15]), disburseOn, profile: profiles[i % profiles.length], method: prodCode === 'CD' ? 'FLAT' : 'REDUCING' });
    }
    plan.sort((a, b) => a.disburseOn.localeCompare(b.disburseOn));

    const sim: SimLoan[] = [];
    const byDate = new Map<string, typeof plan>();
    for (const p of plan) byDate.set(p.disburseOn, [...(byDate.get(p.disburseOn) ?? []), p]);

    const events = new Map<string, Ev[]>();
    const addEv = (e: Ev) => events.set(e.date, [...(events.get(e.date) ?? []), e]);

    let counters = { payments: 0, bounces: 0, reversals: 0, activities: 0, ptps: 0, failedJobs: 0 };
    let ptpIdx = 0;
    let execRR = 0;

    const outstandingDue = async (loanId: number, asOf: string) =>
      Number(
        (
          await q<{ v: number }>(
            c,
            `SELECT COALESCE((SELECT sum(remaining_amount) FROM emi_schedules WHERE loan_id = $1 AND due_date <= $2), 0)
                  + COALESCE((SELECT sum(remaining_amount) FROM loan_charges WHERE loan_id = $1), 0) AS v`,
            [loanId, asOf],
          )
        )[0].v,
      );

    const pay = async (loanId: number, amount: number, date: string, mode: string, status = 'SUCCESSFUL', emiId: number | null = null, collector: number | null = null) => {
      // never exceed what the loan can accept (dues minus payments still awaiting realisation)
      const cap = Number(
        (await q<{ v: number }>(c, `SELECT fn_loan_total_outstanding($1) - COALESCE((SELECT sum(amount) FROM payments WHERE loan_id = $1 AND status IN ('PENDING','INITIATED')), 0) AS v`, [loanId]))[0].v,
      );
      amount = round2(Math.min(amount, cap));
      if (amount <= 0) return null;
      const ref = mode === 'CASH' ? null : `${mode}${date.replace(/-/g, '')}${String(++counters.payments).padStart(6, '0')}`;
      const r = await q<{ id: number }>(
        c,
        `SELECT sp_process_payment($1, $2, $3::date, $4, $5, $6, $7, NULL, $8, NULL, $9, $10) AS id`,
        [loanId, amount, date, mode, ref, status, collector, emiId, mode === 'NACH' ? 'SYSTEM' : 'MANUAL', finance],
      );
      return r[0].id;
    };

    const assignedTo = async (loanId: number) =>
      (await q<{ e: number }>(c, `SELECT executive_id AS e FROM collection_assignments WHERE loan_id = $1 AND is_active`, [loanId]))[0]?.e ?? null;

    // ------------------------------------------------------------ day loop
    for (let day = start; day <= today; day = addDays(day, 1)) {
      // 1) nightly DPD job for this business date (00:30)
      const job = await q<{ p_status: string }>(c, `CALL sp_update_daily_dpd($1::date, 'SEED', NULL, NULL, NULL)`, [day]);
      if (job[0].p_status !== 'SUCCESS') {
        counters.failedJobs++;
        throw new Error(`DPD job failed for ${day}`);
      }

      // 2) disbursements
      for (const p of byDate.get(day) ?? []) {
        const loan = (
          await q<{ id: number; loan_number: string }>(
            c,
            `INSERT INTO loans (customer_id, product_id, branch_id, principal_amount, annual_interest_rate, interest_method, tenure_months, payment_due_day, processing_fee, status, created_by, created_at)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'DRAFT',$10,$11::date + time '11:00') RETURNING id, loan_number`,
            [p.customer.id, p.product.id, p.customer.branchId, p.amount, p.rate, p.method, p.tenure, p.dueDay, round2((p.amount * Number(p.product.processing_fee_pct)) / 100), finance, addDays(day, -int(1, 4))],
          )
        )[0];
        await c.query(`UPDATE loans SET status = 'APPROVED', approved_by = $2, approved_at = $3::date + time '15:00' WHERE id = $1`, [loan.id, superAdmin, addDays(day, -1)]);
        await c.query(`SELECT sp_disburse_loan($1, $2::date, NULL, $3)`, [loan.id, day, finance]);
        const s: SimLoan = { id: loan.id, number: loan.loan_number, profile: p.profile, disburseOn: day, productId: p.product.id };
        if (p.profile === 'DEFAULTER') {
          // pick a target DPD the loan is actually old enough to reach, so every bucket gets populated
          const age = Math.round((Date.parse(today) - Date.parse(day)) / 86_400_000) - 35;
          const feasible = targets.filter((t) => t < age);
          s.defaultTargetDpd = feasible.length ? pick(feasible) : 5;
        }
        if (p.profile === 'PREPAYER') s.prepayAt = int(3, Math.max(4, Math.min(p.tenure - 1, 8)));
        sim.push(s);
      }

      // 3) installments falling due today → schedule customer behaviour
      const due = await q<{ id: number; loan_id: number; installment_no: number; due_date: string }>(
        c,
        `SELECT e.id, e.loan_id, e.installment_no, e.due_date::text FROM emi_schedules e JOIN loans l ON l.id = e.loan_id
          WHERE e.due_date = $1 AND l.status IN ('DISBURSED','ACTIVE','OVERDUE') AND e.remaining_amount > 0
          ORDER BY e.loan_id, e.installment_no`,
        [day],
      );
      for (const e of due) {
        const L = sim.find((x) => x.id === e.loan_id);
        if (!L || L.closed) continue;
        switch (L.profile) {
          case 'GOOD':
            if (chance(0.04)) {
              addEv({ date: day, loanId: L.id, kind: 'BOUNCE_EMI', emiId: e.id });
              addEv({ date: addDays(day, int(2, 9)), loanId: L.id, kind: 'PAY_ALL_OVERDUE' });
            } else if (chance(0.06)) addEv({ date: addDays(day, int(1, 4)), loanId: L.id, kind: 'CHEQUE', emiId: e.id });
            else addEv({ date: day, loanId: L.id, kind: 'PAY_DUE', emiId: e.id });
            break;
          case 'LATE':
            if (chance(0.35)) addEv({ date: day, loanId: L.id, kind: 'PAY_DUE', emiId: e.id });
            else addEv({ date: addDays(day, int(4, 38)), loanId: L.id, kind: 'PAY_ALL_OVERDUE' });
            break;
          case 'PARTIAL':
            if (e.installment_no % 3 === 0) addEv({ date: addDays(day, int(3, 20)), loanId: L.id, kind: 'PAY_ALL_OVERDUE' });
            else addEv({ date: addDays(day, int(0, 10)), loanId: L.id, kind: 'PAY_PARTIAL', frac: int(45, 85) / 100 });
            break;
          case 'BOUNCER':
            if (chance(0.45)) {
              addEv({ date: day, loanId: L.id, kind: 'BOUNCE_EMI', emiId: e.id });
              if (chance(0.85)) addEv({ date: addDays(day, int(4, 26)), loanId: L.id, kind: 'PAY_ALL_OVERDUE' });
            } else addEv({ date: day, loanId: L.id, kind: 'PAY_DUE', emiId: e.id });
            break;
          case 'DEFAULTER':
            if (e.due_date < addDays(today, -(L.defaultTargetDpd ?? 90))) {
              if (chance(0.3)) addEv({ date: day, loanId: L.id, kind: 'BOUNCE_EMI', emiId: e.id });
              addEv({ date: addDays(day, int(0, 6)), loanId: L.id, kind: 'PAY_ALL_OVERDUE' });
            } else if (chance(0.5)) addEv({ date: day, loanId: L.id, kind: 'BOUNCE_EMI', emiId: e.id });
            break;
          case 'PREPAYER':
            addEv({ date: day, loanId: L.id, kind: 'PAY_DUE', emiId: e.id });
            if (e.installment_no === L.prepayAt) addEv({ date: addDays(day, int(2, 8)), loanId: L.id, kind: 'FORECLOSE' });
            break;
        }
        if (chance(0.015)) addEv({ date: addDays(day, int(1, 3)), loanId: L.id, kind: 'UPI_FAIL' });
      }

      // 4) execute today's events
      for (const ev of events.get(day) ?? []) {
        const L = sim.find((x) => x.id === ev.loanId)!;
        if (L.closed) continue;
        const status = (await q<{ status: string }>(c, `SELECT status FROM loans WHERE id = $1`, [L.id]))[0].status;
        if (!['DISBURSED', 'ACTIVE', 'OVERDUE'].includes(status)) continue;
        const exec = await assignedTo(L.id);
        try {
          if (ev.kind === 'PAY_DUE') {
            const amt = (await q<{ v: number }>(c, `SELECT remaining_amount AS v FROM emi_schedules WHERE id = $1`, [ev.emiId]))[0]?.v ?? 0;
            await pay(L.id, Number(amt), day, 'NACH', 'SUCCESSFUL', ev.emiId ?? null);
          } else if (ev.kind === 'PAY_ALL_OVERDUE') {
            await pay(L.id, await outstandingDue(L.id, day), day, exec ? pick(['UPI', 'CASH', 'UPI', 'IMPS']) : pick(['UPI', 'NEFT', 'IMPS']), 'SUCCESSFUL', null, exec);
          } else if (ev.kind === 'PAY_PARTIAL') {
            const total = await outstandingDue(L.id, day);
            await pay(L.id, Math.floor(total * (ev.frac ?? 0.6)), day, pick(['UPI', 'CASH']), 'SUCCESSFUL', null, exec);
          } else if (ev.kind === 'BOUNCE_EMI') {
            const amt = (await q<{ v: number }>(c, `SELECT remaining_amount AS v FROM emi_schedules WHERE id = $1`, [ev.emiId]))[0]?.v ?? 0;
            if (Number(amt) > 0) {
              // NACH presented → credited → returned by the bank the same day
              const pid = await pay(L.id, Number(amt), day, 'NACH', 'PENDING', ev.emiId ?? null);
              await c.query(`SELECT sp_record_payment_bounce($1, $2::date, $3, $4, NULL, NULL, NULL, TRUE, NULL, $5)`, [
                L.id, day, pick(['INSUFFICIENT_FUNDS', 'INSUFFICIENT_FUNDS', 'INSUFFICIENT_FUNDS', 'PAYMENT_STOPPED', 'MANDATE_FAILURE', 'ACCOUNT_CLOSED', 'TECHNICAL_FAILURE']), pid, finance,
              ]);
              counters.bounces++;
            }
          } else if (ev.kind === 'CHEQUE') {
            const amt = (await q<{ v: number }>(c, `SELECT remaining_amount AS v FROM emi_schedules WHERE id = $1`, [ev.emiId]))[0]?.v ?? 0;
            const pid = await pay(L.id, Number(amt), day, 'CHEQUE', 'PENDING', ev.emiId ?? null);
            if (pid) {
              if (chance(0.15)) {
                await c.query(`SELECT sp_record_payment_bounce($1, $2::date, 'INSUFFICIENT_FUNDS', $3, NULL, NULL, NULL, TRUE, 'Cheque returned', $4)`, [L.id, addDays(day, 0), pid, finance]);
                counters.bounces++;
                addEv({ date: addDays(day, int(3, 12)), loanId: L.id, kind: 'PAY_ALL_OVERDUE' });
              } // otherwise it is realised two days later (below)
            }
          } else if (ev.kind === 'UPI_FAIL') {
            const pid = await pay(L.id, 1000, day, 'UPI', 'INITIATED');
            if (pid) await c.query(`SELECT sp_fail_payment($1, 'Gateway timeout', $2)`, [pid, finance]);
          } else if (ev.kind === 'FORECLOSE') {
            const all = Number((await q<{ v: number }>(c, `SELECT fn_loan_total_outstanding($1) AS v`, [L.id]))[0].v);
            await pay(L.id, all, day, 'NEFT');
            await c.query(`SELECT sp_close_loan($1, $2, 'Foreclosed by customer')`, [L.id, finance]);
            L.closed = true;
          }
        } catch (e) {
          throw new Error(`Seed event ${ev.kind} on ${day} for ${L.number} failed: ${(e as Error).message}`);
        }
      }
      // realise cheques presented 2 days ago
      const pending = await q<{ id: number }>(c, `SELECT id FROM payments WHERE status = 'PENDING' AND payment_mode = 'CHEQUE' AND payment_date <= $1::date - 2 ORDER BY id`, [day]);
      for (const p of pending) {
        try {
          await c.query(`SELECT sp_realize_payment($1, $2)`, [p.id, finance]);
        } catch {
          await c.query(`SELECT sp_fail_payment($1, 'Stale cheque', $2)`, [p.id, finance]);
        }
      }

      // 5) a few reversals of recent successful UPI receipts
      if (chance(0.02)) {
        const candidates = await q<{ id: number }>(
          c,
          `SELECT p.id FROM payments p JOIN loans l ON l.id = p.loan_id
            WHERE p.status = 'SUCCESSFUL' AND p.payment_mode IN ('UPI','IMPS') AND p.payment_date BETWEEN $1::date - 5 AND $1::date
              AND l.status <> 'CLOSED' ORDER BY p.id`,
          [day],
        );
        const victim = candidates.length ? [pick(candidates)] : []; // seeded RNG → identical demo data on every install
        if (victim[0]) {
          await c.query(`SELECT sp_reverse_payment($1, $2, $3::date, $4)`, [victim[0].id, pick(['Credit not received in bank statement', 'Duplicate entry', 'Posted to wrong loan']), day, finance]);
          counters.reversals++;
        }
      }

      // 6) collections: weekly assignment of new overdue accounts (Mondays)
      if (new Date(`${day}T00:00:00Z`).getUTCDay() === 1) {
        const un = await q<{ loan_id: number }>(
          c,
          `SELECT d.loan_id FROM dpd_current d WHERE d.dpd >= 3 AND d.account_status = 'OVERDUE'
              AND NOT EXISTS (SELECT 1 FROM collection_assignments a WHERE a.loan_id = d.loan_id AND a.is_active) ORDER BY d.dpd DESC, d.loan_id`,
        );
        for (const u of un) {
          await c.query(`INSERT INTO collection_assignments (loan_id, executive_id, assigned_by, assigned_at, remarks) VALUES ($1,$2,$3,$4::date + time '09:30','Weekly allocation')`, [
            u.loan_id, execs[execRR++ % execs.length], manager, day,
          ]);
        }
      }

      // 7) collection activities on assigned overdue accounts
      const work = await q<{ loan_id: number; executive_id: number; dpd: number; overdue: number }>(
        c,
        `SELECT a.loan_id, a.executive_id, d.dpd, d.overdue_amount + d.overdue_charges AS overdue
           FROM collection_assignments a JOIN dpd_current d ON d.loan_id = a.loan_id
          WHERE a.is_active AND d.dpd > 0 ORDER BY a.loan_id`,
      );
      for (const w of work) {
        if (!chance(w.dpd > 60 ? 0.18 : 0.12)) continue;
        const L = sim.find((x) => x.id === w.loan_id)!;
        const type = w.dpd > 45 && chance(0.4) ? 'FIELD_VISIT' : pick(['PHONE_CALL', 'PHONE_CALL', 'WHATSAPP', 'SMS']);
        const reachable = chance(0.7);
        const promise = reachable && chance(L.profile === 'DEFAULTER' ? 0.35 : 0.55);
        const result = !reachable ? pick(['NOT_REACHABLE', 'CUSTOMER_NOT_AVAILABLE', 'NOT_REACHABLE', 'WRONG_NUMBER']) : promise ? 'PROMISE_TO_PAY' : pick(['CONTACTED', 'CALLBACK_REQUESTED', 'REFUSED_TO_PAY']);
        const ptpDate = promise ? addDays(day, int(2, 9)) : null;
        const ptpAmt = promise ? Math.max(500, Math.round(Number(w.overdue) * pick([1, 1, 0.5]))) : null;
        const a = await q<{ id: number }>(
          c,
          `INSERT INTO collection_activities (loan_id, executive_id, activity_date, activity_type, contact_result, ptp_date, ptp_amount, notes, next_follow_up_date, created_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$3::date + time '12:00') RETURNING id`,
          [w.loan_id, w.executive_id, day, type, result, ptpDate, ptpAmt,
           pick(['Customer says salary delayed', 'Business slow this month', 'Will pay after harvest sale', 'Spoke to spouse', 'Asked to call in evening', 'Medical expense in family', 'Visited residence, house locked', null]),
           ptpDate ?? addDays(day, int(2, 7))],
        );
        counters.activities++;
        if (promise) {
          await c.query(`INSERT INTO promise_to_pay (loan_id, activity_id, executive_id, promised_on, promised_date, promised_amount) VALUES ($1,$2,$3,$4,$5,$6)`, [
            w.loan_id, a[0].id, w.executive_id, day, ptpDate, ptpAmt,
          ]);
          counters.ptps++;
          // keep or break according to profile
          const keeps = L.profile === 'DEFAULTER' ? chance(0.12) : L.profile === 'PARTIAL' ? chance(0.6) : chance(0.75);
          const payOn = addDays(ptpDate!, -int(0, 1)) > day ? addDays(ptpDate!, -int(0, 1)) : addDays(day, 1);
          // defaulters only ever part-pay on a promise, so they stay delinquent
          const kind = L.profile === 'DEFAULTER' ? 'PAY_PARTIAL' : ptpIdx++ % 4 === 0 ? 'PAY_PARTIAL' : 'PAY_ALL_OVERDUE';
          if (keeps && payOn <= today) addEv({ date: payOn, loanId: w.loan_id, kind, frac: L.profile === 'DEFAULTER' ? 0.3 : 0.6 });
        }
      }

      if (day.endsWith('-01') || day === today) log(`  ${day}  loans=${sim.length}  payments≈${counters.payments}  bounces=${counters.bounces}`);
    }

    // ------------------------------------------------------------ pipeline loans + targets
    const mkPipeline = async (status: 'DRAFT' | 'APPROVED' | 'CANCELLED') => {
      const p = pick(['TW', 'PL']);
      const r = await q<{ id: number }>(
        c,
        `INSERT INTO loans (customer_id, product_id, branch_id, principal_amount, annual_interest_rate, tenure_months, payment_due_day, processing_fee, status, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,5,$7,'DRAFT',$8) RETURNING id`,
        [pick(customers).id, P[p].id, pick(branches).id, int(5, 15) * 10000, Number(P[p].default_rate), pick([12, 24]), 1000, finance],
      );
      if (status !== 'DRAFT') await c.query(`UPDATE loans SET status = 'APPROVED', approved_by = $2, approved_at = now() WHERE id = $1`, [r[0].id, superAdmin]);
      if (status === 'CANCELLED') await c.query(`UPDATE loans SET status = 'CANCELLED', closure_remarks = 'Customer withdrew application' WHERE id = $1`, [r[0].id]);
    };
    for (const s of ['DRAFT', 'DRAFT', 'DRAFT', 'APPROVED', 'APPROVED', 'CANCELLED'] as const) await mkPipeline(s);

    // a write-off to show the status
    const wo = await q<{ loan_id: number }>(c, `SELECT loan_id FROM dpd_current WHERE dpd >= 180 AND account_status = 'OVERDUE' ORDER BY dpd DESC LIMIT 1`);
    if (wo[0]) await c.query(`SELECT sp_write_off_loan($1, $2, 'Customer untraceable; written off per policy')`, [wo[0].loan_id, finance]);

    const month = `${today.slice(0, 7)}-01`;
    for (const e of execs) {
      await c.query(`INSERT INTO collection_targets (executive_id, target_month, target_amount, created_by) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING`, [
        e, month, int(15, 40) * 10000, manager,
      ]);
    }

    // notifications for a lively UI
    await c.query(
      `INSERT INTO notifications (user_id, type, title, message, link)
       SELECT u.id, 'JOB', 'Daily DPD completed', 'Business date ' || fn_business_date() || ' processed', '/jobs'
         FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code IN ('SUPER_ADMIN','ADMIN','COLLECTION_MANAGER')`,
    );

    const s = (await q(c, `SELECT
        (SELECT count(*) FROM customers)::int AS customers,
        (SELECT count(*) FROM loans WHERE disbursement_date IS NOT NULL)::int AS disbursed_loans,
        (SELECT count(*) FROM loans WHERE status = 'CLOSED')::int AS closed,
        (SELECT count(*) FROM emi_schedules)::int AS installments,
        (SELECT count(*) FROM payments)::int AS payments,
        (SELECT count(*) FROM payments WHERE status = 'SUCCESSFUL')::int AS successful,
        (SELECT count(*) FROM payments WHERE status = 'REVERSED')::int AS reversed,
        (SELECT count(*) FROM payments WHERE status = 'FAILED')::int AS failed,
        (SELECT count(*) FROM payment_bounces)::int AS bounces,
        (SELECT count(*) FROM collection_activities)::int AS activities,
        (SELECT count(*) FROM promise_to_pay)::int AS ptps,
        (SELECT count(*) FROM dpd_daily_snapshots)::int AS snapshots,
        (SELECT json_object_agg(bucket_code, account_count) FROM vw_dpd_bucket_portfolio) AS buckets`))[0];
    log('✓ Seed complete in', Math.round((Date.now() - t0) / 1000), 's');
    log(s);
    log(`\nDemo logins (password for all: ${DEMO_PASSWORD}) — local development only:`);
    for (const u of ['superadmin', 'admin', 'manager', 'finance', 'analyst', 'exec1', 'exec2', 'exec3', 'exec4']) log(`  ${u}@demo.local`);
  } finally {
    c.release();
  }
}

main()
  .then(() => pool.end())
  .catch(async (e) => {
    console.error('Seed failed:', e.message);
    await pool.end();
    process.exit(1);
  });
