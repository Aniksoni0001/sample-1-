-- =====================================================================
-- Triggers: updated_at, audit trail, immutability, state-machine guards
-- The API sets app.user_id / app.request_id / app.ip with set_config(..., true)
-- at the start of every write transaction so triggers know who acted.
-- =====================================================================

CREATE OR REPLACE FUNCTION trg_set_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END $$;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['roles','branches','users','customers','loan_products','loans','emi_schedules',
                           'payments','loan_charges','payment_bounces','promise_to_pay','dpd_bucket_config']
  LOOP
    EXECUTE format('CREATE TRIGGER %I BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION trg_set_updated_at()',
                   'trg_' || t || '_updated_at', t);
  END LOOP;
END $$;

-- ---------------------------------------------------------------------
-- Generic audit trigger: stores only the columns that changed
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION trg_audit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  v_user int  := NULLIF(current_setting('app.user_id', true), '')::int;
  v_req  text := NULLIF(current_setting('app.request_id', true), '');
  v_ip   text := NULLIF(current_setting('app.ip', true), '');
  v_old  jsonb;
  v_new  jsonb;
  v_row  jsonb;
  v_drop text[] := ARRAY['password_hash','updated_at','amount_paid','remaining_amount'];
BEGIN
  IF TG_OP <> 'INSERT' THEN v_old := to_jsonb(OLD) - v_drop; END IF;
  IF TG_OP <> 'DELETE' THEN v_new := to_jsonb(NEW) - v_drop; END IF;
  v_row := COALESCE(v_new, v_old);

  IF TG_OP = 'UPDATE' THEN
    SELECT jsonb_object_agg(n.key, n.value) INTO v_new
      FROM jsonb_each(v_new) n WHERE (v_old -> n.key) IS DISTINCT FROM n.value;
    IF v_new IS NULL THEN RETURN NEW; END IF;                       -- no real change
    SELECT jsonb_object_agg(k, v_old -> k) INTO v_old FROM jsonb_object_keys(v_new) k;
  END IF;

  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, old_values, new_values, ip, request_id)
  VALUES (v_user, TG_OP, TG_TABLE_NAME, COALESCE(v_row ->> 'id', v_row ->> 'key', v_row ->> 'code'),
          v_old, v_new, v_ip, v_req);
  RETURN COALESCE(NEW, OLD);
END $$;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['customers','loans','payments','payment_reversals','payment_bounces','loan_charges',
                           'users','roles','system_settings','dpd_bucket_config','loan_products','branches',
                           'collection_assignments','collection_targets','holidays']
  LOOP
    EXECUTE format('CREATE TRIGGER %I AFTER INSERT OR UPDATE OR DELETE ON %I FOR EACH ROW EXECUTE FUNCTION trg_audit()',
                   'trg_' || t || '_audit', t);
  END LOOP;
END $$;

-- ---------------------------------------------------------------------
-- Immutability of financial history
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION trg_block_modification() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION '% on % is not allowed: records are immutable (%)', TG_OP, TG_TABLE_NAME, TG_ARGV[0]
    USING ERRCODE = 'CW409';
END $$;

CREATE TRIGGER trg_snapshots_immutable BEFORE UPDATE OR DELETE ON dpd_daily_snapshots
  FOR EACH ROW EXECUTE FUNCTION trg_block_modification('historical DPD snapshot');
CREATE TRIGGER trg_allocations_immutable BEFORE UPDATE OR DELETE ON payment_allocations
  FOR EACH ROW EXECUTE FUNCTION trg_block_modification('use a reversal instead');
CREATE TRIGGER trg_reversals_immutable BEFORE UPDATE OR DELETE ON payment_reversals
  FOR EACH ROW EXECUTE FUNCTION trg_block_modification('reversal record');
CREATE TRIGGER trg_audit_immutable BEFORE UPDATE OR DELETE ON audit_logs
  FOR EACH ROW EXECUTE FUNCTION trg_block_modification('audit trail');
CREATE TRIGGER trg_payments_no_delete BEFORE DELETE ON payments
  FOR EACH ROW EXECUTE FUNCTION trg_block_modification('use a reversal instead');
CREATE TRIGGER trg_loans_no_delete BEFORE DELETE ON loans
  FOR EACH ROW EXECUTE FUNCTION trg_block_modification('cancel the loan instead');
CREATE TRIGGER trg_bounces_no_delete BEFORE DELETE ON payment_bounces
  FOR EACH ROW EXECUTE FUNCTION trg_block_modification('bounce record');

-- Payments: the money facts can never change once written; only status moves forward
CREATE OR REPLACE FUNCTION trg_payment_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF (NEW.loan_id, NEW.amount, NEW.payment_date, NEW.payment_mode)
     IS DISTINCT FROM (OLD.loan_id, OLD.amount, OLD.payment_date, OLD.payment_mode) THEN
    RAISE EXCEPTION 'Payment % amount/date/mode/loan cannot be edited; reverse and re-enter instead', OLD.payment_number
      USING ERRCODE = 'CW409';
  END IF;
  IF OLD.status <> NEW.status AND NOT (
       (OLD.status IN ('INITIATED','PENDING') AND NEW.status IN ('PENDING','SUCCESSFUL','FAILED')) OR
       (OLD.status = 'SUCCESSFUL' AND NEW.status IN ('REVERSED','FAILED'))) THEN
    RAISE EXCEPTION 'Illegal payment status change % -> %', OLD.status, NEW.status USING ERRCODE = 'CW409';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_payments_guard BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION trg_payment_guard();

-- Loans: legal state transitions + financial terms frozen after disbursement
CREATE OR REPLACE FUNCTION trg_loan_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.status <> NEW.status AND NOT (
       (OLD.status = 'DRAFT'     AND NEW.status IN ('APPROVED','CANCELLED')) OR
       (OLD.status = 'APPROVED'  AND NEW.status IN ('DRAFT','DISBURSED','CANCELLED')) OR
       (OLD.status = 'DISBURSED' AND NEW.status IN ('ACTIVE','OVERDUE','CLOSED')) OR
       (OLD.status = 'ACTIVE'    AND NEW.status IN ('OVERDUE','CLOSED')) OR
       (OLD.status = 'OVERDUE'   AND NEW.status IN ('ACTIVE','CLOSED','WRITTEN_OFF')) OR
       (OLD.status = 'WRITTEN_OFF' AND NEW.status IN ('CLOSED'))) THEN
    RAISE EXCEPTION 'Illegal loan status change % -> % for %', OLD.status, NEW.status, OLD.loan_number
      USING ERRCODE = 'CW409';
  END IF;
  IF OLD.disbursement_date IS NOT NULL AND
     (NEW.principal_amount, NEW.annual_interest_rate, NEW.interest_method, NEW.tenure_months, NEW.customer_id,
      NEW.disbursement_date, NEW.first_emi_date, NEW.product_id)
     IS DISTINCT FROM
     (OLD.principal_amount, OLD.annual_interest_rate, OLD.interest_method, OLD.tenure_months, OLD.customer_id,
      OLD.disbursement_date, OLD.first_emi_date, OLD.product_id) THEN
    RAISE EXCEPTION 'Financial terms of disbursed loan % cannot be changed', OLD.loan_number USING ERRCODE = 'CW409';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_loans_guard BEFORE UPDATE ON loans FOR EACH ROW EXECUTE FUNCTION trg_loan_guard();

-- EMI schedule rows: contractual columns are frozen once generated
CREATE OR REPLACE FUNCTION trg_emi_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF (NEW.loan_id, NEW.installment_no, NEW.due_date, NEW.principal_component, NEW.interest_component, NEW.emi_amount)
     IS DISTINCT FROM
     (OLD.loan_id, OLD.installment_no, OLD.due_date, OLD.principal_component, OLD.interest_component, OLD.emi_amount) THEN
    RAISE EXCEPTION 'Contractual installment values cannot be edited' USING ERRCODE = 'CW409';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_emi_guard BEFORE UPDATE ON emi_schedules FOR EACH ROW EXECUTE FUNCTION trg_emi_guard();
CREATE TRIGGER trg_emi_no_delete BEFORE DELETE ON emi_schedules
  FOR EACH ROW EXECUTE FUNCTION trg_block_modification('repayment schedule');
