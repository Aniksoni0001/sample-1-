-- =====================================================================
-- Loan ledger: dues (debits) vs receipts (credits) in date order.
-- Running balance = amount due-and-unpaid; negative = paid in advance.
-- Closing balance reconciles with vw_loan_outstanding (overdue + due today
-- + open charges − advance receipts).
-- =====================================================================
CREATE OR REPLACE FUNCTION fn_loan_ledger(p_loan_id bigint, p_as_of date DEFAULT NULL)
RETURNS TABLE (entry_date date, seq int, entry_type text, reference text, particulars text,
               debit numeric, credit numeric, balance numeric)
LANGUAGE sql STABLE AS $$
  WITH asof AS (SELECT COALESCE(p_as_of, fn_business_date()) AS d),
  e AS (
    -- installment fell due
    SELECT es.due_date AS entry_date, 1 AS seq, 'EMI_DUE' AS entry_type, 'EMI #' || es.installment_no AS reference,
           'Installment ' || es.installment_no || ' due (P ' || es.principal_component || ' + I ' || es.interest_component || ')' AS particulars,
           es.emi_amount AS debit, 0::numeric AS credit
      FROM emi_schedules es WHERE es.loan_id = p_loan_id AND es.due_date <= (SELECT d FROM asof)
    UNION ALL
    SELECT c.charge_date, 2, 'CHARGE', c.charge_type, COALESCE(c.remarks, c.charge_type || ' charge'), c.amount, 0
      FROM loan_charges c WHERE c.loan_id = p_loan_id AND c.charge_date <= (SELECT d FROM asof)
    UNION ALL
    -- every receipt that was ever credited (realised), whatever happened later
    SELECT p.payment_date, 3, 'RECEIPT', p.payment_number,
           p.payment_mode || COALESCE(' ref ' || p.transaction_reference, '') AS particulars, 0, p.amount
      FROM payments p
     WHERE p.loan_id = p_loan_id AND p.realized_at IS NOT NULL AND p.payment_date <= (SELECT d FROM asof)
    UNION ALL
    SELECT r.reversal_date, 4, 'REVERSAL', p.payment_number, 'Reversal: ' || r.reason, r.reversed_amount, 0
      FROM payment_reversals r JOIN payments p ON p.id = r.payment_id
     WHERE p.loan_id = p_loan_id AND r.reversal_date <= (SELECT d FROM asof)
    UNION ALL
    SELECT b.bounce_date, 4, 'BOUNCE', p.payment_number, 'Bounced (' || b.bounce_reason || ')', p.amount, 0
      FROM payment_bounces b JOIN payments p ON p.id = b.payment_id
     WHERE b.loan_id = p_loan_id AND p.realized_at IS NOT NULL AND b.bounce_date <= (SELECT d FROM asof)
    UNION ALL
    SELECT a.created_at::date, 5, 'WAIVER', a.entity_type || ' ' || a.entity_id,
           'Waiver: ' || (a.new_values ->> 'reason'), 0, (a.new_values ->> 'amount')::numeric
      FROM audit_logs a
     WHERE a.action = 'WAIVER' AND (a.new_values ->> 'loan_id')::bigint = p_loan_id
       AND a.created_at::date <= (SELECT d FROM asof)
  )
  SELECT entry_date, seq, entry_type, reference, particulars, debit, credit,
         sum(debit - credit) OVER (ORDER BY entry_date, seq, reference ROWS UNBOUNDED PRECEDING) AS balance
    FROM e
   ORDER BY entry_date, seq, reference
$$;
