-- Collection executives work from their own desk; the company-wide dashboard
-- shows unscoped portfolio figures, so they no longer get dashboard.read.
DELETE FROM role_permissions
 WHERE role_id = (SELECT id FROM roles WHERE code = 'COLLECTION_EXECUTIVE')
   AND permission_id = (SELECT id FROM permissions WHERE code = 'dashboard.read');
