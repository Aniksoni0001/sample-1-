-- =====================================================================
-- Reporting views. Dashboards and reports read from the same views so
-- their numbers always reconcile.
-- =====================================================================

-- Every loan with its customer, product, branch, live DPD state and current executive
CREATE OR REPLACE VIEW vw_loan_register AS
SELECT l.id, l.loan_number, l.customer_id, c.customer_code, c.full_name AS customer_name, c.mobile,
       c.city, c.state, l.product_id, p.code AS product_code, p.name AS product_name,
       l.branch_id, b.name AS branch_name,
       l.principal_amount, l.annual_interest_rate, l.interest_method, l.tenure_months,
       l.repayment_frequency, l.payment_due_day, l.loan_start_date, l.first_emi_date,
       l.disbursement_date, l.maturity_date, l.emi_amount, l.processing_fee, l.total_interest,
       l.total_payable, l.status, l.created_at,
       COALESCE(d.dpd, 0) AS dpd, d.bucket_code, COALESCE(d.overdue_amount, 0) AS overdue_amount,
       COALESCE(d.overdue_charges, 0) AS overdue_charges, COALESCE(d.overdue_emi_count, 0) AS overdue_emi_count,
       CASE WHEN l.disbursement_date IS NULL THEN 0
            ELSE COALESCE(d.outstanding_principal, l.principal_amount) END AS outstanding_principal,
       d.oldest_overdue_date, d.next_emi_due_date, d.next_emi_amount, d.last_payment_date,
       a.executive_id, u.full_name AS executive_name
  FROM loans l
  JOIN customers c       ON c.id = l.customer_id
  JOIN loan_products p   ON p.id = l.product_id
  LEFT JOIN branches b   ON b.id = l.branch_id
  LEFT JOIN dpd_current d ON d.loan_id = l.id
  LEFT JOIN collection_assignments a ON a.loan_id = l.id AND a.is_active
  LEFT JOIN users u      ON u.id = a.executive_id;

CREATE OR REPLACE VIEW vw_active_loans AS
SELECT * FROM vw_loan_register WHERE status = ANY (fn_active_statuses());

-- Installments past their due date and still unpaid (as of the business date)
CREATE OR REPLACE VIEW vw_emi_overdue AS
SELECT e.id AS emi_schedule_id, e.loan_id, l.loan_number, l.customer_id, c.customer_code, c.full_name AS customer_name,
       c.mobile, e.installment_no, e.due_date, e.emi_amount, e.amount_paid, e.remaining_amount, e.status,
       fn_business_date() - e.due_date AS days_overdue, l.product_id, l.branch_id
  FROM emi_schedules e
  JOIN loans l ON l.id = e.loan_id
  JOIN customers c ON c.id = l.customer_id
 WHERE e.remaining_amount > 0
   AND e.due_date < fn_business_date()
   AND (l.status = ANY (fn_active_statuses()) OR l.status = 'WRITTEN_OFF');

-- Balance position of every disbursed loan
CREATE OR REPLACE VIEW vw_loan_outstanding AS
SELECT l.id AS loan_id, l.loan_number, l.status, l.principal_amount,
       COALESCE(s.principal_paid, 0) AS principal_paid,
       COALESCE(s.interest_paid, 0)  AS interest_paid,
       l.principal_amount - COALESCE(s.principal_paid, 0) AS outstanding_principal,
       COALESCE(s.overdue_principal, 0) AS overdue_principal,
       COALESCE(s.overdue_interest, 0)  AS overdue_interest,
       COALESCE(s.emi_remaining, 0)     AS total_emi_remaining,
       COALESCE(s.waived, 0)            AS emi_waived,
       COALESCE(ch.charges_outstanding, 0) AS charges_outstanding,
       COALESCE(s.emi_remaining, 0) + COALESCE(ch.charges_outstanding, 0) AS total_outstanding
  FROM loans l
  LEFT JOIN LATERAL (
    SELECT sum(principal_paid) AS principal_paid, sum(interest_paid) AS interest_paid,
           sum(remaining_amount) AS emi_remaining, sum(waived_amount) AS waived,
           sum(principal_component - principal_paid) FILTER (WHERE due_date < fn_business_date() AND remaining_amount > 0) AS overdue_principal,
           sum(interest_component - interest_paid)   FILTER (WHERE due_date < fn_business_date() AND remaining_amount > 0) AS overdue_interest
      FROM emi_schedules e WHERE e.loan_id = l.id) s ON TRUE
  LEFT JOIN LATERAL (
    SELECT sum(remaining_amount) AS charges_outstanding FROM loan_charges c WHERE c.loan_id = l.id) ch ON TRUE
 WHERE l.disbursement_date IS NOT NULL;

-- Live bucket table (all configured buckets, including empty ones)
CREATE OR REPLACE VIEW vw_dpd_bucket_portfolio AS
WITH book AS (
  SELECT d.* FROM dpd_current d WHERE d.account_status = ANY (fn_active_statuses())
)
SELECT b.code AS bucket_code, b.label, b.sort_order, b.min_dpd, b.max_dpd, b.color,
       count(k.loan_id)::int AS account_count,
       COALESCE(sum(k.outstanding_principal), 0) AS outstanding_principal,
       COALESCE(sum(k.overdue_amount), 0) AS overdue_amount,
       CASE WHEN (SELECT sum(outstanding_principal) FROM book) > 0
            THEN round(COALESCE(sum(k.outstanding_principal), 0) * 100 / (SELECT sum(outstanding_principal) FROM book), 2)
            ELSE 0 END AS pct_of_pos
  FROM dpd_bucket_config b
  LEFT JOIN book k ON k.bucket_code = b.code
 WHERE b.is_active
 GROUP BY b.code, b.label, b.sort_order, b.min_dpd, b.max_dpd, b.color
 ORDER BY b.sort_order;

-- Day × mode collection summary. Bounced/reversed money is never counted as collected.
CREATE OR REPLACE VIEW vw_daily_collection_summary AS
SELECT p.payment_date, p.payment_mode,
       count(*) FILTER (WHERE p.status = 'SUCCESSFUL')::int AS successful_count,
       COALESCE(sum(p.amount) FILTER (WHERE p.status = 'SUCCESSFUL'), 0) AS successful_amount,
       count(*) FILTER (WHERE p.status = 'FAILED')::int AS failed_count,
       COALESCE(sum(p.amount) FILTER (WHERE p.status = 'FAILED'), 0) AS failed_amount,
       count(*) FILTER (WHERE p.status = 'REVERSED')::int AS reversed_count,
       COALESCE(sum(p.amount) FILTER (WHERE p.status = 'REVERSED'), 0) AS reversed_amount,
       count(*) FILTER (WHERE p.status IN ('PENDING','INITIATED'))::int AS pending_count
  FROM payments p
 GROUP BY p.payment_date, p.payment_mode;

CREATE OR REPLACE VIEW vw_bounce_summary AS
SELECT date_trunc('month', b.bounce_date)::date AS bounce_month, b.bounce_reason,
       count(*)::int AS bounce_count, sum(b.bounce_amount) AS bounce_amount, sum(b.bounce_charges) AS bounce_charges,
       count(*) FILTER (WHERE b.recovery_status = 'RECOVERED')::int AS recovered_count,
       count(*) FILTER (WHERE b.recovery_status IN ('PENDING','PARTIAL'))::int AS open_count
  FROM payment_bounces b
 GROUP BY 1, 2;

-- Executive scorecard for the business month
CREATE OR REPLACE VIEW vw_collection_performance AS
WITH m AS (SELECT date_trunc('month', fn_business_date())::date AS m_start, fn_business_date() AS bd),
ex AS (
  SELECT u.id AS executive_id, u.full_name AS executive_name
    FROM users u JOIN roles r ON r.id = u.role_id
   WHERE r.code = 'COLLECTION_EXECUTIVE' AND u.deleted_at IS NULL
),
asg AS (
  SELECT a.executive_id, count(*)::int AS assigned_accounts,
         count(*) FILTER (WHERE d.dpd > 0)::int AS overdue_accounts,
         COALESCE(sum(d.overdue_amount + d.overdue_charges), 0) AS total_overdue
    FROM collection_assignments a JOIN dpd_current d ON d.loan_id = a.loan_id
   WHERE a.is_active GROUP BY a.executive_id
),
col AS (
  SELECT a.executive_id, COALESCE(sum(p.amount), 0) AS collected_mtd, count(*)::int AS payments_mtd
    FROM payments p
    JOIN collection_assignments a ON a.loan_id = p.loan_id AND a.is_active
    CROSS JOIN m
   WHERE p.status = 'SUCCESSFUL' AND p.payment_date BETWEEN m.m_start AND m.bd
   GROUP BY a.executive_id
),
ptp AS (
  SELECT t.executive_id,
         count(*) FILTER (WHERE t.status = 'PENDING')::int AS ptp_pending,
         COALESCE(sum(t.promised_amount) FILTER (WHERE t.status = 'PENDING'), 0) AS ptp_pending_amount,
         count(*) FILTER (WHERE t.status = 'KEPT' AND t.resolved_on >= m.m_start)::int AS ptp_kept_mtd,
         count(*) FILTER (WHERE t.status = 'BROKEN' AND t.resolved_on >= m.m_start)::int AS ptp_broken_mtd
    FROM promise_to_pay t CROSS JOIN m GROUP BY t.executive_id
),
act AS (
  SELECT c.executive_id,
         count(*) FILTER (WHERE c.activity_date >= m.m_start)::int AS activities_mtd,
         count(DISTINCT c.loan_id) FILTER (WHERE c.next_follow_up_date = m.bd)::int AS follow_ups_today
    FROM collection_activities c CROSS JOIN m GROUP BY c.executive_id
)
SELECT ex.executive_id, ex.executive_name,
       COALESCE(asg.assigned_accounts, 0) AS assigned_accounts,
       COALESCE(asg.overdue_accounts, 0) AS overdue_accounts,
       COALESCE(asg.total_overdue, 0) AS total_overdue,
       COALESCE(col.collected_mtd, 0) AS collected_mtd,
       COALESCE(col.payments_mtd, 0) AS payments_mtd,
       COALESCE(t.target_amount, asg.total_overdue, 0) AS target_amount,
       CASE WHEN COALESCE(t.target_amount, asg.total_overdue, 0) > 0
            THEN round(COALESCE(col.collected_mtd, 0) * 100 / COALESCE(t.target_amount, asg.total_overdue), 2) END AS achievement_pct,
       COALESCE(ptp.ptp_pending, 0) AS ptp_pending, COALESCE(ptp.ptp_pending_amount, 0) AS ptp_pending_amount,
       COALESCE(ptp.ptp_kept_mtd, 0) AS ptp_kept_mtd, COALESCE(ptp.ptp_broken_mtd, 0) AS ptp_broken_mtd,
       COALESCE(act.activities_mtd, 0) AS activities_mtd, COALESCE(act.follow_ups_today, 0) AS follow_ups_today
  FROM ex
  CROSS JOIN m
  LEFT JOIN asg ON asg.executive_id = ex.executive_id
  LEFT JOIN col ON col.executive_id = ex.executive_id
  LEFT JOIN ptp ON ptp.executive_id = ex.executive_id
  LEFT JOIN act ON act.executive_id = ex.executive_id
  LEFT JOIN collection_targets t ON t.executive_id = ex.executive_id AND t.target_month = m.m_start;

-- Portfolio at Risk: PAR-N = POS of loans with DPD > N ÷ total POS of the live book
CREATE OR REPLACE VIEW vw_par_summary AS
WITH book AS (SELECT * FROM dpd_current WHERE account_status = ANY (fn_active_statuses()))
SELECT count(*)::int AS total_accounts,
       COALESCE(sum(outstanding_principal), 0) AS total_pos,
       count(*) FILTER (WHERE dpd > 0)::int  AS par0_accounts,
       COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 0), 0)  AS par0_pos,
       count(*) FILTER (WHERE dpd > 30)::int AS par30_accounts,
       COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 30), 0) AS par30_pos,
       count(*) FILTER (WHERE dpd > 60)::int AS par60_accounts,
       COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 60), 0) AS par60_pos,
       count(*) FILTER (WHERE dpd > 90)::int AS par90_accounts,
       COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 90), 0) AS par90_pos,
       CASE WHEN sum(outstanding_principal) > 0 THEN round(COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 0), 0)  * 100 / sum(outstanding_principal), 2) ELSE 0 END AS par0_pct,
       CASE WHEN sum(outstanding_principal) > 0 THEN round(COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 30), 0) * 100 / sum(outstanding_principal), 2) ELSE 0 END AS par30_pct,
       CASE WHEN sum(outstanding_principal) > 0 THEN round(COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 60), 0) * 100 / sum(outstanding_principal), 2) ELSE 0 END AS par60_pct,
       CASE WHEN sum(outstanding_principal) > 0 THEN round(COALESCE(sum(outstanding_principal) FILTER (WHERE dpd > 90), 0) * 100 / sum(outstanding_principal), 2) ELSE 0 END AS par90_pct
  FROM book;
