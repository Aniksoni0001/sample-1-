-- =====================================================================
-- Loan Collections & DPD Management System — core schema
-- PostgreSQL 15+.  All money is NUMERIC(14,2); business dates are DATE;
-- audit timestamps are TIMESTAMPTZ.
-- Normalisation note: customer_id is NOT repeated on payments, bounces,
-- collection activities etc. — it is functionally dependent on loan_id
-- (loan_id -> customer_id), so storing it again would be a transitive
-- dependency (3NF violation). Views/joins expose it instead.
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;   -- fast ILIKE search on names

-- ---------------------------------------------------------------------
-- Enumerations (as CHECK-constrained text so they stay migration-friendly)
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Access control
-- ---------------------------------------------------------------------
CREATE TABLE roles (
  id            SMALLSERIAL PRIMARY KEY,
  code          TEXT NOT NULL UNIQUE,                 -- SUPER_ADMIN, ADMIN ...
  name          TEXT NOT NULL,
  description   TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE permissions (
  id            SMALLSERIAL PRIMARY KEY,
  code          TEXT NOT NULL UNIQUE,                 -- e.g. payments.write
  module        TEXT NOT NULL,
  description   TEXT
);

CREATE TABLE role_permissions (
  role_id       SMALLINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id SMALLINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE branches (
  id            SERIAL PRIMARY KEY,
  code          TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  city          TEXT NOT NULL,
  state         TEXT NOT NULL,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  deleted_at    TIMESTAMPTZ,                          -- soft delete (non-financial)
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id             SERIAL PRIMARY KEY,
  email          TEXT NOT NULL,
  full_name      TEXT NOT NULL,
  phone          TEXT,
  password_hash  TEXT NOT NULL,
  role_id        SMALLINT NOT NULL REFERENCES roles(id),
  branch_id      INT REFERENCES branches(id),
  is_active      BOOLEAN NOT NULL DEFAULT TRUE,
  password_changed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_login_at  TIMESTAMPTZ,
  failed_login_count INT NOT NULL DEFAULT 0,
  locked_until   TIMESTAMPTZ,
  deleted_at     TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ux_users_email ON users (lower(email)) WHERE deleted_at IS NULL;
CREATE INDEX ix_users_role ON users(role_id);

-- Refresh-token sessions (token stored only as SHA-256 hash)
CREATE TABLE user_sessions (
  id             BIGSERIAL PRIMARY KEY,
  user_id        INT NOT NULL REFERENCES users(id),
  token_hash     TEXT NOT NULL UNIQUE,
  expires_at     TIMESTAMPTZ NOT NULL,
  revoked_at     TIMESTAMPTZ,
  replaced_by    BIGINT REFERENCES user_sessions(id),
  ip             TEXT,
  user_agent     TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_sessions_user ON user_sessions(user_id);

CREATE TABLE password_resets (
  id             BIGSERIAL PRIMARY KEY,
  user_id        INT NOT NULL REFERENCES users(id),
  token_hash     TEXT NOT NULL UNIQUE,
  expires_at     TIMESTAMPTZ NOT NULL,
  used_at        TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE login_history (
  id             BIGSERIAL PRIMARY KEY,
  user_id        INT REFERENCES users(id),
  email          TEXT NOT NULL,
  success        BOOLEAN NOT NULL,
  reason         TEXT,
  ip             TEXT,
  user_agent     TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_login_history_user ON login_history(user_id, created_at DESC);

-- ---------------------------------------------------------------------
-- Configuration
-- ---------------------------------------------------------------------
CREATE TABLE system_settings (
  key            TEXT PRIMARY KEY,
  value          TEXT NOT NULL,
  data_type      TEXT NOT NULL DEFAULT 'string'
                 CHECK (data_type IN ('string','number','boolean','date','json')),
  description    TEXT,
  is_editable    BOOLEAN NOT NULL DEFAULT TRUE,
  updated_by     INT REFERENCES users(id),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE dpd_bucket_config (
  id             SMALLSERIAL PRIMARY KEY,
  code           TEXT NOT NULL UNIQUE,                -- CURRENT, B1_30 ...
  label          TEXT NOT NULL,
  min_dpd        INT  NOT NULL CHECK (min_dpd >= 0),
  max_dpd        INT  CHECK (max_dpd IS NULL OR max_dpd >= min_dpd),  -- NULL = open ended
  sort_order     SMALLINT NOT NULL UNIQUE,            -- severity order (used for roll fwd/back)
  color          TEXT NOT NULL DEFAULT '#64748b',
  is_active      BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE holidays (
  holiday_date   DATE PRIMARY KEY,
  name           TEXT NOT NULL
);

-- ---------------------------------------------------------------------
-- Customers & products
-- ---------------------------------------------------------------------
CREATE TABLE customers (
  id              BIGSERIAL PRIMARY KEY,
  customer_code   TEXT NOT NULL UNIQUE,               -- CUST000001
  full_name       TEXT NOT NULL,
  mobile          TEXT NOT NULL CHECK (mobile ~ '^[6-9][0-9]{9}$'),
  email           TEXT,
  date_of_birth   DATE,
  gender          TEXT CHECK (gender IN ('MALE','FEMALE','OTHER')),
  pan             TEXT CHECK (pan ~ '^[A-Z]{5}[0-9]{4}[A-Z]$'),
  aadhaar_last4   CHAR(4) CHECK (aadhaar_last4 ~ '^[0-9]{4}$'),   -- only last 4 digits are kept
  address_line    TEXT,
  city            TEXT,
  state           TEXT,
  pincode         CHAR(6) CHECK (pincode ~ '^[1-9][0-9]{5}$'),
  occupation      TEXT,
  monthly_income  NUMERIC(14,2) CHECK (monthly_income >= 0),
  status          TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE','BLOCKED')),
  deleted_at      TIMESTAMPTZ,
  created_by      INT REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ux_customers_pan ON customers(pan) WHERE pan IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX ix_customers_mobile ON customers(mobile);
CREATE INDEX ix_customers_name_trgm ON customers USING gin (full_name gin_trgm_ops);
CREATE INDEX ix_customers_state_city ON customers(state, city);

CREATE TABLE loan_products (
  id                   SMALLSERIAL PRIMARY KEY,
  code                 TEXT NOT NULL UNIQUE,
  name                 TEXT NOT NULL,
  min_amount           NUMERIC(14,2) NOT NULL,
  max_amount           NUMERIC(14,2) NOT NULL,
  min_tenure_months    INT NOT NULL,
  max_tenure_months    INT NOT NULL,
  default_rate         NUMERIC(6,3) NOT NULL,
  processing_fee_pct   NUMERIC(5,2) NOT NULL DEFAULT 0,
  bounce_charge        NUMERIC(14,2) NOT NULL DEFAULT 500,
  is_active            BOOLEAN NOT NULL DEFAULT TRUE,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (max_amount >= min_amount), CHECK (max_tenure_months >= min_tenure_months)
);

-- ---------------------------------------------------------------------
-- Loans & schedules
-- ---------------------------------------------------------------------
CREATE TABLE loans (
  id                   BIGSERIAL PRIMARY KEY,
  loan_number          TEXT NOT NULL UNIQUE,          -- LN000000001
  customer_id          BIGINT NOT NULL REFERENCES customers(id),
  product_id           SMALLINT NOT NULL REFERENCES loan_products(id),
  branch_id            INT REFERENCES branches(id),
  principal_amount     NUMERIC(14,2) NOT NULL CHECK (principal_amount > 0),
  annual_interest_rate NUMERIC(6,3)  NOT NULL CHECK (annual_interest_rate >= 0 AND annual_interest_rate < 100),
  interest_method      TEXT NOT NULL DEFAULT 'REDUCING' CHECK (interest_method IN ('REDUCING','FLAT')),
  tenure_months        INT NOT NULL CHECK (tenure_months BETWEEN 1 AND 360),
  repayment_frequency  TEXT NOT NULL DEFAULT 'MONTHLY' CHECK (repayment_frequency = 'MONTHLY'),
  payment_due_day      SMALLINT NOT NULL CHECK (payment_due_day BETWEEN 1 AND 28),
  loan_start_date      DATE,
  first_emi_date       DATE,
  disbursement_date    DATE,
  maturity_date        DATE,
  emi_amount           NUMERIC(14,2),
  processing_fee       NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (processing_fee >= 0),
  total_interest       NUMERIC(14,2),
  total_payable        NUMERIC(14,2),
  status               TEXT NOT NULL DEFAULT 'DRAFT'
                       CHECK (status IN ('DRAFT','APPROVED','DISBURSED','ACTIVE','OVERDUE','CLOSED','WRITTEN_OFF','CANCELLED')),
  approved_by          INT REFERENCES users(id),
  approved_at          TIMESTAMPTZ,
  disbursed_by         INT REFERENCES users(id),
  closed_at            TIMESTAMPTZ,
  closure_remarks      TEXT,
  created_by           INT REFERENCES users(id),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (status IN ('DRAFT','APPROVED','CANCELLED') OR disbursement_date IS NOT NULL)
);
CREATE INDEX ix_loans_customer ON loans(customer_id);
CREATE INDEX ix_loans_status ON loans(status);
CREATE INDEX ix_loans_product ON loans(product_id);
CREATE INDEX ix_loans_branch ON loans(branch_id);
CREATE INDEX ix_loans_disbursement_date ON loans(disbursement_date);

CREATE TABLE emi_schedules (
  id                   BIGSERIAL PRIMARY KEY,
  loan_id              BIGINT NOT NULL REFERENCES loans(id),
  installment_no       INT NOT NULL CHECK (installment_no > 0),
  due_date             DATE NOT NULL,
  opening_principal    NUMERIC(14,2) NOT NULL,
  principal_component  NUMERIC(14,2) NOT NULL CHECK (principal_component >= 0),
  interest_component   NUMERIC(14,2) NOT NULL CHECK (interest_component >= 0),
  emi_amount           NUMERIC(14,2) NOT NULL,
  closing_principal    NUMERIC(14,2) NOT NULL,
  principal_paid       NUMERIC(14,2) NOT NULL DEFAULT 0,
  interest_paid        NUMERIC(14,2) NOT NULL DEFAULT 0,
  waived_amount        NUMERIC(14,2) NOT NULL DEFAULT 0,
  amount_paid          NUMERIC(14,2) GENERATED ALWAYS AS (principal_paid + interest_paid) STORED,
  remaining_amount     NUMERIC(14,2) GENERATED ALWAYS AS (emi_amount - principal_paid - interest_paid - waived_amount) STORED,
  status               TEXT NOT NULL DEFAULT 'UPCOMING'
                       CHECK (status IN ('UPCOMING','DUE','PARTIALLY_PAID','PAID','OVERDUE','BOUNCED','WAIVED')),
  dpd                  INT NOT NULL DEFAULT 0,
  last_payment_date    DATE,
  paid_date            DATE,                            -- date the installment was fully cleared
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (loan_id, installment_no),
  CHECK (emi_amount = principal_component + interest_component),
  CHECK (principal_paid BETWEEN 0 AND principal_component),
  CHECK (interest_paid  BETWEEN 0 AND interest_component),
  CHECK (waived_amount >= 0 AND principal_paid + interest_paid + waived_amount <= emi_amount)
);
CREATE INDEX ix_emi_loan_due ON emi_schedules(loan_id, due_date);
CREATE INDEX ix_emi_due_date ON emi_schedules(due_date);
CREATE INDEX ix_emi_status ON emi_schedules(status);
-- partial index used by the DPD engine: only unpaid installments
CREATE INDEX ix_emi_unpaid ON emi_schedules(loan_id, due_date) WHERE remaining_amount > 0;

-- ---------------------------------------------------------------------
-- Payments
-- ---------------------------------------------------------------------
CREATE TABLE payments (
  id                   BIGSERIAL PRIMARY KEY,
  payment_number       TEXT NOT NULL UNIQUE,            -- PAY0000000001
  loan_id              BIGINT NOT NULL REFERENCES loans(id),
  emi_schedule_id      BIGINT REFERENCES emi_schedules(id),   -- installment it was presented for (optional)
  payment_date         DATE NOT NULL,
  amount               NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  payment_mode         TEXT NOT NULL CHECK (payment_mode IN ('UPI','NEFT','RTGS','IMPS','CASH','CHEQUE','NACH','OTHER')),
  transaction_reference TEXT,
  status               TEXT NOT NULL CHECK (status IN ('INITIATED','PENDING','SUCCESSFUL','FAILED','REVERSED')),
  collected_by         INT REFERENCES users(id),        -- collection executive
  remarks              TEXT,
  unallocated_amount   NUMERIC(14,2) NOT NULL DEFAULT 0,
  realized_at          TIMESTAMPTZ,
  idempotency_key      TEXT UNIQUE,
  source               TEXT NOT NULL DEFAULT 'MANUAL' CHECK (source IN ('MANUAL','CSV_IMPORT','SYSTEM')),
  created_by           INT REFERENCES users(id),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- duplicate protection: one live payment per bank reference
CREATE UNIQUE INDEX ux_payments_txn_ref ON payments(upper(transaction_reference))
  WHERE transaction_reference IS NOT NULL AND status <> 'FAILED';
CREATE INDEX ix_payments_loan ON payments(loan_id, payment_date);
CREATE INDEX ix_payments_date ON payments(payment_date);
CREATE INDEX ix_payments_status ON payments(status);
CREATE INDEX ix_payments_collected_by ON payments(collected_by);

-- Separate charges ledger (bounce charges, penal charges) so they never mix with EMI
CREATE TABLE loan_charges (
  id                   BIGSERIAL PRIMARY KEY,
  loan_id              BIGINT NOT NULL REFERENCES loans(id),
  emi_schedule_id      BIGINT REFERENCES emi_schedules(id),
  bounce_id            BIGINT,                           -- FK added below
  charge_type          TEXT NOT NULL CHECK (charge_type IN ('BOUNCE','PENAL','OTHER')),
  charge_date          DATE NOT NULL,
  amount               NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  paid_amount          NUMERIC(14,2) NOT NULL DEFAULT 0,
  waived_amount        NUMERIC(14,2) NOT NULL DEFAULT 0,
  remaining_amount     NUMERIC(14,2) GENERATED ALWAYS AS (amount - paid_amount - waived_amount) STORED,
  status               TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','PARTIALLY_PAID','PAID','WAIVED')),
  remarks              TEXT,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (paid_amount >= 0 AND waived_amount >= 0 AND paid_amount + waived_amount <= amount)
);
CREATE INDEX ix_charges_loan ON loan_charges(loan_id);

CREATE TABLE payment_allocations (
  id                   BIGSERIAL PRIMARY KEY,
  payment_id           BIGINT NOT NULL REFERENCES payments(id),
  emi_schedule_id      BIGINT REFERENCES emi_schedules(id),
  charge_id            BIGINT REFERENCES loan_charges(id),
  component            TEXT NOT NULL CHECK (component IN ('INTEREST','PRINCIPAL','CHARGE')),
  amount               NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  is_advance           BOOLEAN NOT NULL DEFAULT FALSE,   -- allocated to a not-yet-due installment
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((component = 'CHARGE') = (charge_id IS NOT NULL)),
  CHECK ((component = 'CHARGE') = (emi_schedule_id IS NULL))
);
CREATE INDEX ix_alloc_payment ON payment_allocations(payment_id);
CREATE INDEX ix_alloc_emi ON payment_allocations(emi_schedule_id);

CREATE TABLE payment_reversals (
  id                   BIGSERIAL PRIMARY KEY,
  payment_id           BIGINT NOT NULL UNIQUE REFERENCES payments(id),
  reversal_date        DATE NOT NULL,
  reason               TEXT NOT NULL,
  reversed_amount      NUMERIC(14,2) NOT NULL,
  reversed_by          INT REFERENCES users(id),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE payment_bounces (
  id                   BIGSERIAL PRIMARY KEY,
  bounce_number        TEXT NOT NULL UNIQUE,
  loan_id              BIGINT NOT NULL REFERENCES loans(id),
  emi_schedule_id      BIGINT REFERENCES emi_schedules(id),
  payment_id           BIGINT UNIQUE REFERENCES payments(id),   -- one bounce per presentation
  payment_reference    TEXT,
  bounce_date          DATE NOT NULL,
  bounce_reason        TEXT NOT NULL CHECK (bounce_reason IN
                       ('INSUFFICIENT_FUNDS','ACCOUNT_CLOSED','PAYMENT_STOPPED','INVALID_ACCOUNT',
                        'MANDATE_FAILURE','TECHNICAL_FAILURE','OTHER')),
  bounce_amount        NUMERIC(14,2) NOT NULL CHECK (bounce_amount > 0),
  bounce_charges       NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (bounce_charges >= 0),
  recovery_status      TEXT NOT NULL DEFAULT 'PENDING' CHECK (recovery_status IN ('PENDING','PARTIAL','RECOVERED','WAIVED')),
  resolution_date      DATE,
  reattempt_count      INT NOT NULL DEFAULT 0,
  remarks              TEXT,
  created_by           INT REFERENCES users(id),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_bounces_loan ON payment_bounces(loan_id);
CREATE INDEX ix_bounces_date ON payment_bounces(bounce_date);
ALTER TABLE loan_charges ADD CONSTRAINT fk_charges_bounce FOREIGN KEY (bounce_id) REFERENCES payment_bounces(id);

-- ---------------------------------------------------------------------
-- Collections
-- ---------------------------------------------------------------------
CREATE TABLE collection_assignments (
  id                   BIGSERIAL PRIMARY KEY,
  loan_id              BIGINT NOT NULL REFERENCES loans(id),
  executive_id         INT NOT NULL REFERENCES users(id),
  assigned_by          INT REFERENCES users(id),
  assigned_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  unassigned_at        TIMESTAMPTZ,
  is_active            BOOLEAN NOT NULL DEFAULT TRUE,
  remarks              TEXT
);
-- at most one active executive per loan
CREATE UNIQUE INDEX ux_assignment_active ON collection_assignments(loan_id) WHERE is_active;
CREATE INDEX ix_assignment_exec ON collection_assignments(executive_id) WHERE is_active;

CREATE TABLE collection_activities (
  id                   BIGSERIAL PRIMARY KEY,
  loan_id              BIGINT NOT NULL REFERENCES loans(id),
  executive_id         INT NOT NULL REFERENCES users(id),
  activity_date        DATE NOT NULL,
  activity_type        TEXT NOT NULL CHECK (activity_type IN ('PHONE_CALL','SMS','EMAIL','FIELD_VISIT','WHATSAPP','OTHER')),
  contact_result       TEXT NOT NULL CHECK (contact_result IN
                       ('CONTACTED','NOT_REACHABLE','WRONG_NUMBER','PROMISE_TO_PAY','PAID','REFUSED_TO_PAY',
                        'CALLBACK_REQUESTED','CUSTOMER_NOT_AVAILABLE','OTHER')),
  ptp_date             DATE,
  ptp_amount           NUMERIC(14,2) CHECK (ptp_amount > 0),
  notes                TEXT,
  next_follow_up_date  DATE,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((ptp_date IS NULL) = (ptp_amount IS NULL))
);
CREATE INDEX ix_activities_loan ON collection_activities(loan_id, activity_date DESC);
CREATE INDEX ix_activities_exec ON collection_activities(executive_id, activity_date DESC);
CREATE INDEX ix_activities_followup ON collection_activities(next_follow_up_date);

CREATE TABLE promise_to_pay (
  id                   BIGSERIAL PRIMARY KEY,
  loan_id              BIGINT NOT NULL REFERENCES loans(id),
  activity_id          BIGINT UNIQUE REFERENCES collection_activities(id),
  executive_id         INT NOT NULL REFERENCES users(id),
  promised_on          DATE NOT NULL,           -- date the promise was made
  promised_date        DATE NOT NULL,           -- date customer promised to pay by
  promised_amount      NUMERIC(14,2) NOT NULL CHECK (promised_amount > 0),
  kept_amount          NUMERIC(14,2) NOT NULL DEFAULT 0,
  status               TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','KEPT','PARTIALLY_KEPT','BROKEN','CANCELLED')),
  resolved_on          DATE,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (promised_date >= promised_on)
);
CREATE INDEX ix_ptp_loan ON promise_to_pay(loan_id);
CREATE INDEX ix_ptp_exec_status ON promise_to_pay(executive_id, status, promised_date);

CREATE TABLE collection_targets (
  id                   BIGSERIAL PRIMARY KEY,
  executive_id         INT NOT NULL REFERENCES users(id),
  target_month         DATE NOT NULL CHECK (target_month = date_trunc('month', target_month)::date),
  target_amount        NUMERIC(14,2) NOT NULL CHECK (target_amount > 0),
  created_by           INT REFERENCES users(id),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (executive_id, target_month)
);

-- ---------------------------------------------------------------------
-- DPD
-- ---------------------------------------------------------------------
CREATE TABLE dpd_current (
  loan_id               BIGINT PRIMARY KEY REFERENCES loans(id),
  business_date         DATE NOT NULL,
  dpd                   INT NOT NULL DEFAULT 0 CHECK (dpd >= 0),
  bucket_code           TEXT NOT NULL,
  overdue_emi_count     INT NOT NULL DEFAULT 0,
  overdue_amount        NUMERIC(14,2) NOT NULL DEFAULT 0,   -- unpaid EMI past due date
  overdue_charges       NUMERIC(14,2) NOT NULL DEFAULT 0,   -- open bounce/penal charges
  oldest_overdue_date   DATE,
  outstanding_principal NUMERIC(14,2) NOT NULL DEFAULT 0,
  last_payment_date     DATE,
  next_emi_due_date     DATE,
  next_emi_amount       NUMERIC(14,2),
  account_status        TEXT NOT NULL,
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_dpd_current_bucket ON dpd_current(bucket_code);
CREATE INDEX ix_dpd_current_dpd ON dpd_current(dpd);

CREATE TABLE dpd_daily_snapshots (
  business_date         DATE   NOT NULL,
  loan_id               BIGINT NOT NULL REFERENCES loans(id),
  product_id            SMALLINT NOT NULL,
  branch_id             INT,
  executive_id          INT,
  state                 TEXT,
  dpd                   INT NOT NULL,
  bucket_code           TEXT NOT NULL,
  bucket_sort_order     SMALLINT NOT NULL,
  overdue_emi_count     INT NOT NULL,
  overdue_amount        NUMERIC(14,2) NOT NULL,
  overdue_charges       NUMERIC(14,2) NOT NULL,
  oldest_overdue_date   DATE,
  outstanding_principal NUMERIC(14,2) NOT NULL,
  last_payment_date     DATE,
  next_emi_due_date     DATE,
  account_status        TEXT NOT NULL,
  job_id                BIGINT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (business_date, loan_id)                 -- guarantees one snapshot per loan per day
);
CREATE INDEX ix_snap_loan_date ON dpd_daily_snapshots(loan_id, business_date);
CREATE INDEX ix_snap_date_bucket ON dpd_daily_snapshots(business_date, bucket_code);
CREATE INDEX ix_snap_exec ON dpd_daily_snapshots(executive_id, business_date);

CREATE TABLE portfolio_daily_summary (
  business_date         DATE NOT NULL,
  bucket_code           TEXT NOT NULL,
  bucket_sort_order     SMALLINT NOT NULL,
  account_count         INT NOT NULL,
  outstanding_principal NUMERIC(16,2) NOT NULL,
  overdue_amount        NUMERIC(16,2) NOT NULL,
  generated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (business_date, bucket_code)
);

CREATE TABLE job_execution_logs (
  id                    BIGSERIAL PRIMARY KEY,
  job_name              TEXT NOT NULL,
  business_date         DATE,
  trigger_type          TEXT NOT NULL CHECK (trigger_type IN ('SCHEDULED','MANUAL','RETRY','SEED')),
  status                TEXT NOT NULL CHECK (status IN ('RUNNING','SUCCESS','FAILED','SKIPPED')),
  started_at            TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
  finished_at           TIMESTAMPTZ,
  loans_processed       INT,
  snapshots_inserted    INT,
  message               TEXT,
  error_message         TEXT,
  triggered_by          INT REFERENCES users(id)
);
CREATE INDEX ix_jobs_name_date ON job_execution_logs(job_name, business_date DESC);

-- ---------------------------------------------------------------------
-- Cross-cutting
-- ---------------------------------------------------------------------
CREATE TABLE audit_logs (
  id                    BIGSERIAL PRIMARY KEY,
  user_id               INT,                         -- no FK: audit must survive anything
  action                TEXT NOT NULL,               -- INSERT/UPDATE/DELETE or app action (LOGIN, EXPORT ...)
  entity_type           TEXT NOT NULL,
  entity_id             TEXT,
  old_values            JSONB,
  new_values            JSONB,
  ip                    TEXT,
  request_id            TEXT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_audit_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX ix_audit_user ON audit_logs(user_id, created_at DESC);
CREATE INDEX ix_audit_created ON audit_logs(created_at DESC);

CREATE TABLE notifications (
  id                    BIGSERIAL PRIMARY KEY,
  user_id               INT NOT NULL REFERENCES users(id),
  type                  TEXT NOT NULL,               -- JOB, PTP, ASSIGNMENT, BOUNCE ...
  title                 TEXT NOT NULL,
  message               TEXT NOT NULL,
  link                  TEXT,
  is_read               BOOLEAN NOT NULL DEFAULT FALSE,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_notifications_user ON notifications(user_id, is_read, created_at DESC);

CREATE TABLE idempotency_keys (
  key                   TEXT PRIMARY KEY,
  user_id               INT,
  request_hash          TEXT NOT NULL,
  status_code           INT,
  response_body         JSONB,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- human-readable number sequences
CREATE SEQUENCE seq_customer_code START 1;
CREATE SEQUENCE seq_loan_number START 1;
CREATE SEQUENCE seq_payment_number START 1;
CREATE SEQUENCE seq_bounce_number START 1;
