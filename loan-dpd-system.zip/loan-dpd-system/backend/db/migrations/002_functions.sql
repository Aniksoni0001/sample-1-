-- =====================================================================
-- Business logic in PL/pgSQL.
-- Custom SQLSTATEs (mapped to HTTP by the API):
--   CW400 = validation error, CW404 = not found, CW409 = conflict/state error
-- All monetary arithmetic is NUMERIC — never float.
-- =====================================================================

ALTER TABLE customers ALTER COLUMN customer_code SET DEFAULT 'CUST' || lpad(nextval('seq_customer_code')::text, 6, '0');
ALTER TABLE loans     ALTER COLUMN loan_number   SET DEFAULT 'LN'   || lpad(nextval('seq_loan_number')::text, 8, '0');
ALTER TABLE payments  ALTER COLUMN payment_number SET DEFAULT 'PAY' || lpad(nextval('seq_payment_number')::text, 9, '0');
ALTER TABLE payment_bounces ALTER COLUMN bounce_number SET DEFAULT 'BNC' || lpad(nextval('seq_bounce_number')::text, 7, '0');

-- ---------------------------------------------------------------------
-- Settings helpers
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_setting(p_key text) RETURNS text
LANGUAGE sql STABLE AS $$ SELECT value FROM system_settings WHERE key = p_key $$;

CREATE OR REPLACE FUNCTION fn_business_date() RETURNS date
LANGUAGE sql STABLE AS $$ SELECT value::date FROM system_settings WHERE key = 'business_date' $$;

-- "today" in the configured business timezone (never the server's local date)
CREATE OR REPLACE FUNCTION fn_calendar_today() RETURNS date
LANGUAGE sql STABLE AS $$
  SELECT (now() AT TIME ZONE COALESCE(fn_setting('business_timezone'), 'Asia/Kolkata'))::date
$$;

CREATE OR REPLACE FUNCTION fn_active_statuses() RETURNS text[]
LANGUAGE sql IMMUTABLE AS $$ SELECT ARRAY['DISBURSED','ACTIVE','OVERDUE'] $$;

-- ---------------------------------------------------------------------
-- DPD bucket lookup (configurable via dpd_bucket_config)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_dpd_bucket(p_dpd int) RETURNS TABLE(code text, sort_order smallint)
LANGUAGE sql STABLE AS $$
  SELECT b.code, b.sort_order
  FROM dpd_bucket_config b
  WHERE b.is_active AND p_dpd >= b.min_dpd AND (b.max_dpd IS NULL OR p_dpd <= b.max_dpd)
  ORDER BY b.sort_order
  LIMIT 1
$$;

-- Pure DPD rule (grace period applied at account level)
CREATE OR REPLACE FUNCTION fn_calc_dpd(p_business_date date, p_oldest_unpaid_due date, p_grace int)
RETURNS int LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE
           WHEN p_oldest_unpaid_due IS NULL OR p_oldest_unpaid_due >= p_business_date THEN 0
           WHEN (p_business_date - p_oldest_unpaid_due) <= COALESCE(p_grace, 0) THEN 0
           ELSE p_business_date - p_oldest_unpaid_due
         END
$$;

-- ---------------------------------------------------------------------
-- Due-date rule (holidays / weekly off)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_adjust_due_date(p_date date) RETURNS date
LANGUAGE plpgsql STABLE AS $$
DECLARE
  v_rule text := COALESCE(fn_setting('due_date_holiday_rule'), 'NEXT_WORKING_DAY');
  v_sunday_off boolean := COALESCE(fn_setting('sunday_is_holiday'), 'false')::boolean;
  v_d date := p_date;
  v_i int := 0;
BEGIN
  IF v_rule = 'NONE' THEN RETURN p_date; END IF;
  WHILE (EXISTS (SELECT 1 FROM holidays WHERE holiday_date = v_d)
         OR (v_sunday_off AND extract(isodow FROM v_d) = 7)) AND v_i < 15 LOOP
    v_d := v_d + CASE WHEN v_rule = 'PREVIOUS_WORKING_DAY' THEN -1 ELSE 1 END;
    v_i := v_i + 1;
  END LOOP;
  RETURN v_d;
END $$;

-- ---------------------------------------------------------------------
-- EMI schedule generation (reducing balance or flat)
--   EMI = P·r·(1+r)^n / ((1+r)^n − 1),  r = annual_rate / 12 / 100
--   Interest per installment is rounded to paise; EMI to `emi_rounding_places`.
--   The last installment absorbs every rounding difference so that
--   Σ principal_component = P exactly.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION sp_generate_emi_schedule(p_loan_id bigint) RETURNS int
LANGUAGE plpgsql AS $$
DECLARE
  l          loans%ROWTYPE;
  v_places   int := COALESCE(fn_setting('emi_rounding_places'), '0')::int;
  r          numeric;
  f          numeric;
  v_emi      numeric;
  v_open     numeric;
  v_int      numeric;
  v_prin     numeric;
  v_flat_int numeric := 0;
  v_int_sum  numeric := 0;
  v_due      date;
  k          int;
BEGIN
  SELECT * INTO l FROM loans WHERE id = p_loan_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Loan % not found', p_loan_id USING ERRCODE = 'CW404'; END IF;
  IF l.first_emi_date IS NULL THEN
    RAISE EXCEPTION 'First EMI date is not set for loan %', l.loan_number USING ERRCODE = 'CW400';
  END IF;
  IF EXISTS (SELECT 1 FROM emi_schedules WHERE loan_id = p_loan_id) THEN
    RAISE EXCEPTION 'EMI schedule already exists for loan %', l.loan_number USING ERRCODE = 'CW409';
  END IF;

  r := l.annual_interest_rate / 1200;
  IF l.interest_method = 'FLAT' THEN
    v_flat_int := round(l.principal_amount * l.annual_interest_rate * l.tenure_months / 1200, 2);
    v_emi := round((l.principal_amount + v_flat_int) / l.tenure_months, v_places);
  ELSIF r = 0 THEN
    v_emi := round(l.principal_amount / l.tenure_months, v_places);
  ELSE
    f := power(1 + r, l.tenure_months);
    v_emi := round(l.principal_amount * r * f / (f - 1), v_places);
  END IF;

  v_open := l.principal_amount;
  FOR k IN 1 .. l.tenure_months LOOP
    IF l.interest_method = 'FLAT' THEN
      v_int := CASE WHEN k = l.tenure_months THEN v_flat_int - v_int_sum
                    ELSE round(v_flat_int / l.tenure_months, 2) END;
    ELSE
      v_int := round(v_open * r, 2);
    END IF;

    IF k = l.tenure_months THEN
      v_prin := v_open;                                   -- absorb rounding residue
    ELSE
      v_prin := LEAST(GREATEST(v_emi - v_int, 0), v_open);
    END IF;

    v_due := fn_adjust_due_date((l.first_emi_date + make_interval(months => k - 1))::date);

    INSERT INTO emi_schedules (loan_id, installment_no, due_date, opening_principal,
                               principal_component, interest_component, emi_amount, closing_principal)
    VALUES (p_loan_id, k, v_due, v_open, v_prin, v_int, v_prin + v_int, v_open - v_prin);

    v_int_sum := v_int_sum + v_int;
    v_open := v_open - v_prin;
  END LOOP;

  UPDATE loans
     SET emi_amount = v_emi,
         total_interest = v_int_sum,
         total_payable = principal_amount + v_int_sum,
         maturity_date = v_due
   WHERE id = p_loan_id;

  RETURN l.tenure_months;
END $$;

-- ---------------------------------------------------------------------
-- Status refreshers (set-based; optional single-loan filter)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_refresh_charge_status(p_loan_id bigint) RETURNS void
LANGUAGE sql AS $$
  UPDATE loan_charges c
     SET status = s.new_status
    FROM (SELECT id,
                 CASE WHEN remaining_amount = 0 AND paid_amount = 0 THEN 'WAIVED'
                      WHEN remaining_amount = 0 THEN 'PAID'
                      WHEN paid_amount > 0 THEN 'PARTIALLY_PAID'
                      ELSE 'OPEN' END AS new_status
            FROM loan_charges WHERE loan_id = p_loan_id) s
   WHERE c.id = s.id AND c.status IS DISTINCT FROM s.new_status;
$$;

CREATE OR REPLACE FUNCTION fn_refresh_bounce_recovery(p_loan_id bigint, p_business_date date) RETURNS void
LANGUAGE sql AS $$
  UPDATE payment_bounces b
     SET recovery_status = x.new_status,
         resolution_date = CASE WHEN x.new_status = 'RECOVERED'
                                THEN COALESCE(b.resolution_date, x.cleared_on, p_business_date) END
    FROM (SELECT b2.id,
                 CASE WHEN COALESCE(e.remaining_amount, 0) = 0 AND COALESCE(ch.rem, 0) = 0 THEN 'RECOVERED'
                      WHEN COALESCE(e.remaining_amount, 0) < b2.bounce_amount OR COALESCE(ch.paid, 0) > 0 THEN 'PARTIAL'
                      ELSE 'PENDING' END AS new_status,
                 e.paid_date AS cleared_on
            FROM payment_bounces b2
            LEFT JOIN emi_schedules e ON e.id = b2.emi_schedule_id
            LEFT JOIN LATERAL (SELECT sum(c.remaining_amount) AS rem, sum(c.paid_amount) AS paid
                                 FROM loan_charges c WHERE c.bounce_id = b2.id) ch ON TRUE
           WHERE b2.loan_id = p_loan_id AND b2.recovery_status <> 'WAIVED') x
   WHERE b.id = x.id AND b.recovery_status IS DISTINCT FROM x.new_status;
$$;

CREATE OR REPLACE FUNCTION fn_refresh_emi_status(p_business_date date, p_loan_id bigint DEFAULT NULL) RETURNS int
LANGUAGE plpgsql AS $$
DECLARE v_rows int;
BEGIN
  UPDATE emi_schedules e
     SET status = s.new_status, dpd = s.new_dpd
    FROM (
      SELECT e2.id,
             CASE
               WHEN e2.remaining_amount = 0 AND e2.waived_amount > 0 THEN 'WAIVED'
               WHEN e2.remaining_amount = 0 THEN 'PAID'
               WHEN e2.due_date < p_business_date THEN
                    CASE WHEN EXISTS (SELECT 1 FROM payment_bounces b
                                       WHERE b.emi_schedule_id = e2.id
                                         AND b.recovery_status IN ('PENDING','PARTIAL'))
                         THEN 'BOUNCED' ELSE 'OVERDUE' END
               WHEN e2.amount_paid > 0 THEN 'PARTIALLY_PAID'
               WHEN e2.due_date = p_business_date THEN 'DUE'
               ELSE 'UPCOMING'
             END AS new_status,
             CASE WHEN e2.remaining_amount > 0 AND e2.due_date < p_business_date
                  THEN p_business_date - e2.due_date ELSE 0 END AS new_dpd
        FROM emi_schedules e2
        JOIN loans l ON l.id = e2.loan_id
       WHERE l.status IN ('DISBURSED','ACTIVE','OVERDUE','WRITTEN_OFF')
         AND (p_loan_id IS NULL OR e2.loan_id = p_loan_id)
    ) s
   WHERE e.id = s.id AND (e.status, e.dpd) IS DISTINCT FROM (s.new_status, s.new_dpd);
  GET DIAGNOSTICS v_rows = ROW_COUNT;
  RETURN v_rows;
END $$;

-- ---------------------------------------------------------------------
-- DPD computation — ONE definition used by both the daily batch and the
-- real-time single-loan refresh, so the two can never disagree.
--   DPD = business_date − due_date of the OLDEST installment with
--         remaining_amount > 0 and due_date < business_date
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_compute_dpd(p_business_date date, p_loan_id bigint DEFAULT NULL)
RETURNS TABLE (
  loan_id bigint, business_date date, dpd int, bucket_code text, bucket_sort_order smallint,
  overdue_emi_count int, overdue_amount numeric, overdue_charges numeric, oldest_overdue_date date,
  outstanding_principal numeric, last_payment_date date, next_emi_due_date date, next_emi_amount numeric,
  account_status text, product_id smallint, branch_id int, executive_id int, state text
)
LANGUAGE sql STABLE AS $$
  WITH params AS (
    SELECT COALESCE(fn_setting('dpd_grace_days'), '0')::int AS grace
  ),
  scope AS (
    SELECT l.* FROM loans l
     WHERE l.status = ANY (fn_active_statuses())
       AND (p_loan_id IS NULL OR l.id = p_loan_id)
  ),
  emi AS (                                      -- one pass over the schedule, set-based
    SELECT e.loan_id,
           min(e.due_date)         FILTER (WHERE e.remaining_amount > 0 AND e.due_date < p_business_date) AS oldest_unpaid,
           count(*)                FILTER (WHERE e.remaining_amount > 0 AND e.due_date < p_business_date) AS overdue_cnt,
           COALESCE(sum(e.remaining_amount) FILTER (WHERE e.remaining_amount > 0 AND e.due_date < p_business_date), 0) AS overdue_amt,
           sum(e.principal_paid)   AS principal_paid,
           min(e.due_date)         FILTER (WHERE e.remaining_amount > 0 AND e.due_date >= p_business_date) AS next_due
      FROM emi_schedules e
     WHERE e.loan_id IN (SELECT id FROM scope)
     GROUP BY e.loan_id
  ),
  chg AS (
    SELECT c.loan_id, sum(c.remaining_amount) AS open_charges
      FROM loan_charges c
     WHERE c.loan_id IN (SELECT id FROM scope) AND c.remaining_amount > 0
     GROUP BY c.loan_id
  ),
  pay AS (
    SELECT p.loan_id, max(p.payment_date) AS last_pay
      FROM payments p
     WHERE p.loan_id IN (SELECT id FROM scope) AND p.status = 'SUCCESSFUL'
     GROUP BY p.loan_id
  ),
  base AS (
    SELECT s.id AS loan_id,
           fn_calc_dpd(p_business_date, e.oldest_unpaid, (SELECT grace FROM params)) AS dpd,
           COALESCE(e.overdue_cnt, 0)::int AS overdue_cnt,
           COALESCE(e.overdue_amt, 0) AS overdue_amt,
           COALESCE(ch.open_charges, 0) AS open_charges,
           e.oldest_unpaid,
           s.principal_amount - COALESCE(e.principal_paid, 0) AS pos,
           pay.last_pay,
           e.next_due,
           s.first_emi_date, s.product_id, s.branch_id, s.customer_id
      FROM scope s
      LEFT JOIN emi e   ON e.loan_id = s.id
      LEFT JOIN chg ch  ON ch.loan_id = s.id
      LEFT JOIN pay     ON pay.loan_id = s.id
  )
  SELECT b.loan_id, p_business_date, b.dpd, bk.code, bk.sort_order,
         b.overdue_cnt, b.overdue_amt, b.open_charges, b.oldest_unpaid, b.pos, b.last_pay, b.next_due,
         (SELECT n.remaining_amount FROM emi_schedules n WHERE n.loan_id = b.loan_id AND n.due_date = b.next_due
           ORDER BY n.installment_no LIMIT 1),
         CASE WHEN b.dpd > 0 THEN 'OVERDUE'
              WHEN b.first_emi_date > p_business_date THEN 'DISBURSED'
              ELSE 'ACTIVE' END,
         b.product_id, b.branch_id, a.executive_id, c.state
    FROM base b
    CROSS JOIN LATERAL fn_dpd_bucket(b.dpd) bk
    JOIN customers c ON c.id = b.customer_id
    LEFT JOIN collection_assignments a ON a.loan_id = b.loan_id AND a.is_active
$$;

-- Upsert dpd_current + sync loans.status for one loan (or all active loans)
CREATE OR REPLACE FUNCTION fn_upsert_dpd_current(p_business_date date, p_loan_id bigint DEFAULT NULL) RETURNS int
LANGUAGE plpgsql AS $$
DECLARE v_rows int;
BEGIN
  INSERT INTO dpd_current AS d (loan_id, business_date, dpd, bucket_code, overdue_emi_count, overdue_amount,
         overdue_charges, oldest_overdue_date, outstanding_principal, last_payment_date, next_emi_due_date,
         next_emi_amount, account_status, updated_at)
  SELECT c.loan_id, c.business_date, c.dpd, c.bucket_code, c.overdue_emi_count, c.overdue_amount,
         c.overdue_charges, c.oldest_overdue_date, c.outstanding_principal, c.last_payment_date,
         c.next_emi_due_date, c.next_emi_amount, c.account_status, now()
    FROM fn_compute_dpd(p_business_date, p_loan_id) c
  ON CONFLICT (loan_id) DO UPDATE SET
         business_date = EXCLUDED.business_date, dpd = EXCLUDED.dpd, bucket_code = EXCLUDED.bucket_code,
         overdue_emi_count = EXCLUDED.overdue_emi_count, overdue_amount = EXCLUDED.overdue_amount,
         overdue_charges = EXCLUDED.overdue_charges, oldest_overdue_date = EXCLUDED.oldest_overdue_date,
         outstanding_principal = EXCLUDED.outstanding_principal, last_payment_date = EXCLUDED.last_payment_date,
         next_emi_due_date = EXCLUDED.next_emi_due_date, next_emi_amount = EXCLUDED.next_emi_amount,
         account_status = EXCLUDED.account_status, updated_at = now();
  GET DIAGNOSTICS v_rows = ROW_COUNT;

  UPDATE loans l SET status = d.account_status
    FROM dpd_current d
   WHERE d.loan_id = l.id
     AND l.status = ANY (fn_active_statuses())
     AND l.status <> d.account_status
     AND (p_loan_id IS NULL OR l.id = p_loan_id);
  RETURN v_rows;
END $$;

-- Real-time refresh after any financial event on one loan
CREATE OR REPLACE FUNCTION fn_refresh_loan(p_loan_id bigint) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE v_bd date := fn_business_date();
BEGIN
  PERFORM fn_refresh_charge_status(p_loan_id);
  PERFORM fn_refresh_bounce_recovery(p_loan_id, v_bd);
  PERFORM fn_refresh_emi_status(v_bd, p_loan_id);
  PERFORM fn_upsert_dpd_current(v_bd, p_loan_id);
END $$;

-- ---------------------------------------------------------------------
-- Loan lifecycle
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION sp_disburse_loan(p_loan_id bigint, p_disbursement_date date,
                                            p_first_emi_date date DEFAULT NULL, p_user int DEFAULT NULL)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  l loans%ROWTYPE;
  v_first date;
  v_bd date := fn_business_date();
BEGIN
  SELECT * INTO l FROM loans WHERE id = p_loan_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Loan % not found', p_loan_id USING ERRCODE = 'CW404'; END IF;
  IF l.status <> 'APPROVED' THEN
    RAISE EXCEPTION 'Only APPROVED loans can be disbursed (loan % is %)', l.loan_number, l.status USING ERRCODE = 'CW409';
  END IF;
  IF p_disbursement_date > v_bd THEN
    RAISE EXCEPTION 'Disbursement date % cannot be after the business date %', p_disbursement_date, v_bd USING ERRCODE = 'CW400';
  END IF;

  IF p_first_emi_date IS NULL THEN
    -- next occurrence of the due day; at least 15 days after disbursement
    v_first := make_date(extract(year FROM p_disbursement_date + interval '1 month')::int,
                         extract(month FROM p_disbursement_date + interval '1 month')::int,
                         l.payment_due_day);
    IF v_first - p_disbursement_date < 15 THEN v_first := (v_first + interval '1 month')::date; END IF;
  ELSE
    v_first := p_first_emi_date;
    IF v_first <= p_disbursement_date OR v_first > p_disbursement_date + 75 THEN
      RAISE EXCEPTION 'First EMI date must be within 75 days after disbursement' USING ERRCODE = 'CW400';
    END IF;
    IF extract(day FROM v_first) > 28 THEN
      RAISE EXCEPTION 'First EMI date must fall on day 1-28 of the month' USING ERRCODE = 'CW400';
    END IF;
  END IF;

  UPDATE loans
     SET status = 'DISBURSED', disbursement_date = p_disbursement_date, loan_start_date = p_disbursement_date,
         first_emi_date = v_first, payment_due_day = extract(day FROM v_first)::int, disbursed_by = p_user
   WHERE id = p_loan_id;

  PERFORM sp_generate_emi_schedule(p_loan_id);
  PERFORM fn_refresh_loan(p_loan_id);
END $$;

CREATE OR REPLACE FUNCTION sp_close_loan(p_loan_id bigint, p_user int DEFAULT NULL, p_remarks text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE l loans%ROWTYPE; v_due numeric; v_chg numeric;
BEGIN
  SELECT * INTO l FROM loans WHERE id = p_loan_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Loan % not found', p_loan_id USING ERRCODE = 'CW404'; END IF;
  IF NOT (l.status = ANY (fn_active_statuses()) OR l.status = 'WRITTEN_OFF') THEN
    RAISE EXCEPTION 'Loan % cannot be closed from status %', l.loan_number, l.status USING ERRCODE = 'CW409';
  END IF;
  SELECT COALESCE(sum(remaining_amount), 0) INTO v_due FROM emi_schedules WHERE loan_id = p_loan_id;
  SELECT COALESCE(sum(remaining_amount), 0) INTO v_chg FROM loan_charges  WHERE loan_id = p_loan_id;
  IF v_due > 0 OR v_chg > 0 THEN
    RAISE EXCEPTION 'Loan % has unsettled dues (EMI %, charges %). Settle or waive before closure.',
      l.loan_number, v_due, v_chg USING ERRCODE = 'CW409';
  END IF;
  IF EXISTS (SELECT 1 FROM payments WHERE loan_id = p_loan_id AND status IN ('PENDING','INITIATED')) THEN
    RAISE EXCEPTION 'Loan % has payments awaiting realisation', l.loan_number USING ERRCODE = 'CW409';
  END IF;

  UPDATE loans SET status = 'CLOSED', closed_at = now(), closure_remarks = p_remarks WHERE id = p_loan_id;
  UPDATE dpd_current SET dpd = 0, bucket_code = (SELECT code FROM fn_dpd_bucket(0)), overdue_emi_count = 0,
         overdue_amount = 0, overdue_charges = 0, oldest_overdue_date = NULL, outstanding_principal = 0,
         next_emi_due_date = NULL, next_emi_amount = NULL, account_status = 'CLOSED', updated_at = now()
   WHERE loan_id = p_loan_id;
  UPDATE collection_assignments SET is_active = FALSE, unassigned_at = now(), remarks = 'Loan closed'
   WHERE loan_id = p_loan_id AND is_active;
  UPDATE promise_to_pay SET status = 'CANCELLED', resolved_on = fn_business_date()
   WHERE loan_id = p_loan_id AND status = 'PENDING';
END $$;

CREATE OR REPLACE FUNCTION sp_write_off_loan(p_loan_id bigint, p_user int DEFAULT NULL, p_remarks text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE l loans%ROWTYPE; v_dpd int; v_min int := COALESCE(fn_setting('write_off_min_dpd'), '90')::int;
BEGIN
  SELECT * INTO l FROM loans WHERE id = p_loan_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Loan % not found', p_loan_id USING ERRCODE = 'CW404'; END IF;
  SELECT dpd INTO v_dpd FROM dpd_current WHERE loan_id = p_loan_id;
  IF l.status <> 'OVERDUE' OR COALESCE(v_dpd, 0) < v_min THEN
    RAISE EXCEPTION 'Only OVERDUE loans with DPD >= % can be written off', v_min USING ERRCODE = 'CW409';
  END IF;
  UPDATE loans SET status = 'WRITTEN_OFF', closure_remarks = p_remarks WHERE id = p_loan_id;
  UPDATE dpd_current SET account_status = 'WRITTEN_OFF', updated_at = now() WHERE loan_id = p_loan_id;
END $$;

-- ---------------------------------------------------------------------
-- Payments
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_loan_total_outstanding(p_loan_id bigint) RETURNS numeric
LANGUAGE sql STABLE AS $$
  SELECT COALESCE((SELECT sum(remaining_amount) FROM emi_schedules WHERE loan_id = p_loan_id), 0)
       + COALESCE((SELECT sum(remaining_amount) FROM loan_charges  WHERE loan_id = p_loan_id), 0)
$$;

-- Allocation waterfall. Modes (system_settings.allocation_waterfall):
--   EMI_ORDER      : overdue/due installments oldest first (interest → principal each), then charges
--   CHARGES_FIRST  : open charges first, then installments oldest first
--   INTEREST_FIRST : all due interest (oldest first), then all due principal, then charges
-- In every mode any remainder goes to future installments as an ADVANCE payment.
CREATE OR REPLACE FUNCTION fn_allocate_payment(p_payment_id bigint) RETURNS numeric
LANGUAGE plpgsql AS $$
DECLARE
  v_pay   payments%ROWTYPE;
  v_mode  text := COALESCE(fn_setting('allocation_waterfall'), 'EMI_ORDER');
  v_rem   numeric;
  v_take  numeric;
  it      record;
BEGIN
  SELECT * INTO v_pay FROM payments WHERE id = p_payment_id;
  v_rem := v_pay.amount;

  -- row locks on everything we may touch (deterministic order avoids deadlocks)
  PERFORM 1 FROM emi_schedules WHERE loan_id = v_pay.loan_id AND remaining_amount > 0 ORDER BY id FOR UPDATE;
  PERFORM 1 FROM loan_charges  WHERE loan_id = v_pay.loan_id AND remaining_amount > 0 ORDER BY id FOR UPDATE;

  FOR it IN
    WITH items AS (
      SELECT 'EMI'::text AS kind, e.id AS ref_id, 'INTEREST'::text AS component,
             e.interest_component - e.interest_paid AS available,
             e.due_date AS ord_date, e.installment_no AS ord_no, 1 AS comp_ord,
             (e.due_date > v_pay.payment_date) AS is_adv
        FROM emi_schedules e
       WHERE e.loan_id = v_pay.loan_id AND e.remaining_amount > 0
      UNION ALL
      SELECT 'EMI', e.id, 'PRINCIPAL', e.principal_component - e.principal_paid,
             e.due_date, e.installment_no, 2, (e.due_date > v_pay.payment_date)
        FROM emi_schedules e
       WHERE e.loan_id = v_pay.loan_id AND e.remaining_amount > 0
      UNION ALL
      SELECT 'CHARGE', c.id, 'CHARGE', c.remaining_amount, c.charge_date, 0, 3, FALSE
        FROM loan_charges c
       WHERE c.loan_id = v_pay.loan_id AND c.remaining_amount > 0
    )
    SELECT i.*,
           CASE
             WHEN i.is_adv THEN 9
             WHEN v_mode = 'CHARGES_FIRST'  THEN CASE i.kind WHEN 'CHARGE' THEN 1 ELSE 2 END
             WHEN v_mode = 'INTEREST_FIRST' THEN CASE i.component WHEN 'INTEREST' THEN 1 WHEN 'PRINCIPAL' THEN 2 ELSE 3 END
             ELSE CASE i.kind WHEN 'EMI' THEN 1 ELSE 2 END
           END AS tier
      FROM items i
     WHERE i.available > 0
     ORDER BY tier, i.ord_date, i.ord_no, i.comp_ord, i.ref_id
  LOOP
    EXIT WHEN v_rem <= 0;
    v_take := LEAST(v_rem, it.available);

    INSERT INTO payment_allocations (payment_id, emi_schedule_id, charge_id, component, amount, is_advance)
    VALUES (p_payment_id,
            CASE WHEN it.kind = 'EMI' THEN it.ref_id END,
            CASE WHEN it.kind = 'CHARGE' THEN it.ref_id END,
            it.component, v_take, it.is_adv);

    IF it.component = 'INTEREST' THEN
      UPDATE emi_schedules SET interest_paid = interest_paid + v_take,
             last_payment_date = GREATEST(COALESCE(last_payment_date, v_pay.payment_date), v_pay.payment_date)
       WHERE id = it.ref_id;
    ELSIF it.component = 'PRINCIPAL' THEN
      UPDATE emi_schedules SET principal_paid = principal_paid + v_take,
             last_payment_date = GREATEST(COALESCE(last_payment_date, v_pay.payment_date), v_pay.payment_date)
       WHERE id = it.ref_id;
    ELSE
      UPDATE loan_charges SET paid_amount = paid_amount + v_take WHERE id = it.ref_id;
    END IF;

    v_rem := v_rem - v_take;
  END LOOP;

  -- stamp the date each installment became fully paid
  UPDATE emi_schedules
     SET paid_date = v_pay.payment_date
   WHERE loan_id = v_pay.loan_id AND remaining_amount = 0 AND paid_date IS NULL
     AND id IN (SELECT emi_schedule_id FROM payment_allocations WHERE payment_id = p_payment_id);

  UPDATE payments SET unallocated_amount = v_rem, realized_at = COALESCE(realized_at, now())
   WHERE id = p_payment_id;
  RETURN v_rem;
END $$;

-- Undo all allocations of a payment (used by reversal and bounce) — restores balances exactly.
CREATE OR REPLACE FUNCTION fn_unwind_allocations(p_payment_id bigint) RETURNS numeric
LANGUAGE plpgsql AS $$
DECLARE a record; v_total numeric := 0;
BEGIN
  FOR a IN SELECT * FROM payment_allocations WHERE payment_id = p_payment_id ORDER BY id LOOP
    IF a.component = 'INTEREST' THEN
      UPDATE emi_schedules SET interest_paid = interest_paid - a.amount WHERE id = a.emi_schedule_id;
    ELSIF a.component = 'PRINCIPAL' THEN
      UPDATE emi_schedules SET principal_paid = principal_paid - a.amount WHERE id = a.emi_schedule_id;
    ELSE
      UPDATE loan_charges SET paid_amount = paid_amount - a.amount WHERE id = a.charge_id;
    END IF;
    v_total := v_total + a.amount;
  END LOOP;

  -- re-derive last_payment_date / paid_date of affected installments from the remaining good payments
  UPDATE emi_schedules e
     SET paid_date = CASE WHEN e.remaining_amount = 0 THEN e.paid_date END,
         last_payment_date = (SELECT max(p.payment_date)
                                FROM payment_allocations pa JOIN payments p ON p.id = pa.payment_id
                               WHERE pa.emi_schedule_id = e.id AND p.status = 'SUCCESSFUL' AND p.id <> p_payment_id)
   WHERE e.id IN (SELECT emi_schedule_id FROM payment_allocations
                   WHERE payment_id = p_payment_id AND emi_schedule_id IS NOT NULL);
  RETURN v_total;
END $$;

CREATE OR REPLACE FUNCTION sp_process_payment(
  p_loan_id bigint, p_amount numeric, p_payment_date date, p_mode text,
  p_reference text DEFAULT NULL, p_status text DEFAULT 'SUCCESSFUL', p_collected_by int DEFAULT NULL,
  p_remarks text DEFAULT NULL, p_emi_schedule_id bigint DEFAULT NULL, p_idempotency_key text DEFAULT NULL,
  p_source text DEFAULT 'MANUAL', p_user int DEFAULT NULL)
RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE
  l loans%ROWTYPE;
  v_id bigint;
  v_bd date := fn_business_date();
  v_outstanding numeric;
BEGIN
  -- idempotency: same key → same payment, no second posting
  IF p_idempotency_key IS NOT NULL THEN
    SELECT id INTO v_id FROM payments WHERE idempotency_key = p_idempotency_key;
    IF FOUND THEN RETURN v_id; END IF;
  END IF;

  SELECT * INTO l FROM loans WHERE id = p_loan_id FOR UPDATE;      -- serialises payments per loan
  IF NOT FOUND THEN RAISE EXCEPTION 'Loan % not found', p_loan_id USING ERRCODE = 'CW404'; END IF;
  IF NOT (l.status = ANY (fn_active_statuses()) OR l.status = 'WRITTEN_OFF') THEN
    RAISE EXCEPTION 'Payments cannot be posted to a % loan', l.status USING ERRCODE = 'CW409';
  END IF;
  IF p_amount IS NULL OR p_amount <= 0 OR p_amount <> round(p_amount, 2) THEN
    RAISE EXCEPTION 'Payment amount must be positive with at most 2 decimals' USING ERRCODE = 'CW400';
  END IF;
  IF p_status NOT IN ('SUCCESSFUL','PENDING','INITIATED') THEN
    RAISE EXCEPTION 'New payments must be SUCCESSFUL, PENDING or INITIATED' USING ERRCODE = 'CW400';
  END IF;
  IF p_payment_date > v_bd THEN
    RAISE EXCEPTION 'Payment date % is after the business date %', p_payment_date, v_bd USING ERRCODE = 'CW400';
  END IF;
  IF p_payment_date < l.disbursement_date THEN
    RAISE EXCEPTION 'Payment date is before the disbursement date' USING ERRCODE = 'CW400';
  END IF;
  IF p_reference IS NOT NULL AND EXISTS (SELECT 1 FROM payments
       WHERE upper(transaction_reference) = upper(p_reference) AND status <> 'FAILED') THEN
    RAISE EXCEPTION 'Duplicate transaction reference %', p_reference USING ERRCODE = 'CW409';
  END IF;
  IF p_emi_schedule_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM emi_schedules WHERE id = p_emi_schedule_id AND loan_id = p_loan_id) THEN
    RAISE EXCEPTION 'Installment does not belong to this loan' USING ERRCODE = 'CW400';
  END IF;

  v_outstanding := fn_loan_total_outstanding(p_loan_id)
                 - COALESCE((SELECT sum(amount) FROM payments WHERE loan_id = p_loan_id AND status IN ('PENDING','INITIATED')), 0);
  IF p_amount > v_outstanding THEN
    RAISE EXCEPTION 'Payment % exceeds total outstanding % (incl. payments awaiting realisation)', p_amount, v_outstanding
      USING ERRCODE = 'CW400';
  END IF;

  INSERT INTO payments (loan_id, emi_schedule_id, payment_date, amount, payment_mode, transaction_reference,
                        status, collected_by, remarks, idempotency_key, source, created_by)
  VALUES (p_loan_id, p_emi_schedule_id, p_payment_date, p_amount, p_mode, NULLIF(trim(p_reference), ''),
          p_status, p_collected_by, p_remarks, p_idempotency_key, p_source, p_user)
  RETURNING id INTO v_id;

  IF p_status = 'SUCCESSFUL' THEN
    PERFORM fn_allocate_payment(v_id);
    PERFORM fn_refresh_loan(p_loan_id);
  END IF;
  RETURN v_id;
END $$;

-- PENDING/INITIATED → SUCCESSFUL (cheque cleared, NACH credited, UPI callback)
CREATE OR REPLACE FUNCTION sp_realize_payment(p_payment_id bigint, p_user int DEFAULT NULL) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE v_pay payments%ROWTYPE; v_out numeric;
BEGIN
  SELECT * INTO v_pay FROM payments WHERE id = p_payment_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Payment % not found', p_payment_id USING ERRCODE = 'CW404'; END IF;
  PERFORM 1 FROM loans WHERE id = v_pay.loan_id FOR UPDATE;
  SELECT * INTO v_pay FROM payments WHERE id = p_payment_id FOR UPDATE;
  IF v_pay.status NOT IN ('PENDING','INITIATED') THEN
    RAISE EXCEPTION 'Only PENDING/INITIATED payments can be realised (payment is %)', v_pay.status USING ERRCODE = 'CW409';
  END IF;
  v_out := fn_loan_total_outstanding(v_pay.loan_id);
  IF v_pay.amount > v_out THEN
    RAISE EXCEPTION 'Payment % exceeds current outstanding %', v_pay.amount, v_out USING ERRCODE = 'CW409';
  END IF;
  UPDATE payments SET status = 'SUCCESSFUL' WHERE id = p_payment_id;
  PERFORM fn_allocate_payment(p_payment_id);
  PERFORM fn_refresh_loan(v_pay.loan_id);
END $$;

-- PENDING/INITIATED → FAILED without a bounce record (e.g. UPI timeout)
CREATE OR REPLACE FUNCTION sp_fail_payment(p_payment_id bigint, p_reason text, p_user int DEFAULT NULL) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE v_status text;
BEGIN
  SELECT status INTO v_status FROM payments WHERE id = p_payment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Payment % not found', p_payment_id USING ERRCODE = 'CW404'; END IF;
  IF v_status NOT IN ('PENDING','INITIATED') THEN
    RAISE EXCEPTION 'Only PENDING/INITIATED payments can be marked failed' USING ERRCODE = 'CW409';
  END IF;
  UPDATE payments SET status = 'FAILED', remarks = concat_ws(' | ', remarks, 'Failed: ' || p_reason) WHERE id = p_payment_id;
END $$;

CREATE OR REPLACE FUNCTION sp_reverse_payment(p_payment_id bigint, p_reason text, p_reversal_date date DEFAULT NULL,
                                              p_user int DEFAULT NULL)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE v_pay payments%ROWTYPE; l loans%ROWTYPE; v_amt numeric;
BEGIN
  SELECT * INTO v_pay FROM payments WHERE id = p_payment_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Payment % not found', p_payment_id USING ERRCODE = 'CW404'; END IF;
  SELECT * INTO l FROM loans WHERE id = v_pay.loan_id FOR UPDATE;
  SELECT * INTO v_pay FROM payments WHERE id = p_payment_id FOR UPDATE;
  IF v_pay.status <> 'SUCCESSFUL' THEN
    RAISE EXCEPTION 'Only SUCCESSFUL payments can be reversed (payment is %)', v_pay.status USING ERRCODE = 'CW409';
  END IF;
  IF l.status = 'CLOSED' THEN
    RAISE EXCEPTION 'Loan % is closed; reopen is required before reversing its payments', l.loan_number USING ERRCODE = 'CW409';
  END IF;
  IF p_reason IS NULL OR length(trim(p_reason)) < 3 THEN
    RAISE EXCEPTION 'A reversal reason is required' USING ERRCODE = 'CW400';
  END IF;

  v_amt := fn_unwind_allocations(p_payment_id);
  UPDATE payments SET status = 'REVERSED' WHERE id = p_payment_id;
  INSERT INTO payment_reversals (payment_id, reversal_date, reason, reversed_amount, reversed_by)
  VALUES (p_payment_id, COALESCE(p_reversal_date, fn_business_date()), p_reason, v_amt, p_user);
  PERFORM fn_refresh_loan(v_pay.loan_id);
END $$;

-- Bounce: either a presented payment came back (p_payment_id) or a NACH/cheque
-- return arrived without any prior credit (p_emi_schedule_id + p_amount).
CREATE OR REPLACE FUNCTION sp_record_payment_bounce(
  p_loan_id bigint, p_bounce_date date, p_reason text,
  p_payment_id bigint DEFAULT NULL, p_emi_schedule_id bigint DEFAULT NULL, p_amount numeric DEFAULT NULL,
  p_reference text DEFAULT NULL, p_apply_charge boolean DEFAULT TRUE, p_remarks text DEFAULT NULL,
  p_user int DEFAULT NULL)
RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE
  l loans%ROWTYPE; v_pay payments%ROWTYPE; v_emi bigint := p_emi_schedule_id; v_amt numeric := p_amount;
  v_ref text := p_reference; v_charge numeric := 0; v_id bigint;
BEGIN
  SELECT * INTO l FROM loans WHERE id = p_loan_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Loan % not found', p_loan_id USING ERRCODE = 'CW404'; END IF;
  IF NOT (l.status = ANY (fn_active_statuses()) OR l.status = 'WRITTEN_OFF') THEN
    RAISE EXCEPTION 'Bounces cannot be recorded on a % loan', l.status USING ERRCODE = 'CW409';
  END IF;
  IF p_bounce_date > fn_business_date() THEN
    RAISE EXCEPTION 'Bounce date cannot be after the business date' USING ERRCODE = 'CW400';
  END IF;

  IF p_payment_id IS NOT NULL THEN
    SELECT * INTO v_pay FROM payments WHERE id = p_payment_id AND loan_id = p_loan_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Payment does not belong to this loan' USING ERRCODE = 'CW400'; END IF;
    IF v_pay.status NOT IN ('SUCCESSFUL','PENDING','INITIATED') THEN
      RAISE EXCEPTION 'Payment % is % and cannot bounce', v_pay.payment_number, v_pay.status USING ERRCODE = 'CW409';
    END IF;
    IF v_pay.payment_mode NOT IN ('NACH','CHEQUE','UPI','OTHER') THEN
      RAISE EXCEPTION 'Only NACH, cheque, UPI-autopay or other presented payments can bounce' USING ERRCODE = 'CW400';
    END IF;
    v_amt := v_pay.amount;
    v_ref := COALESCE(v_ref, v_pay.transaction_reference);
    v_emi := COALESCE(v_emi, v_pay.emi_schedule_id,
                      (SELECT min(emi_schedule_id) FROM payment_allocations WHERE payment_id = p_payment_id));
    IF v_pay.status = 'SUCCESSFUL' THEN
      PERFORM fn_unwind_allocations(p_payment_id);    -- restore the dues it had cleared
    END IF;
    UPDATE payments SET status = 'FAILED',
           remarks = concat_ws(' | ', remarks, 'Bounced: ' || p_reason) WHERE id = p_payment_id;
  ELSE
    IF v_emi IS NULL OR v_amt IS NULL OR v_amt <= 0 THEN
      RAISE EXCEPTION 'Installment and amount are required when no payment is referenced' USING ERRCODE = 'CW400';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM emi_schedules WHERE id = v_emi AND loan_id = p_loan_id) THEN
      RAISE EXCEPTION 'Installment does not belong to this loan' USING ERRCODE = 'CW400';
    END IF;
  END IF;

  IF p_apply_charge THEN
    v_charge := COALESCE(NULLIF(fn_setting('bounce_charge_override'), '')::numeric,
                         (SELECT bounce_charge FROM loan_products WHERE id = l.product_id), 0);
  END IF;

  INSERT INTO payment_bounces (loan_id, emi_schedule_id, payment_id, payment_reference, bounce_date, bounce_reason,
                               bounce_amount, bounce_charges, remarks, created_by)
  VALUES (p_loan_id, v_emi, p_payment_id, v_ref, p_bounce_date, p_reason, v_amt, v_charge, p_remarks, p_user)
  RETURNING id INTO v_id;

  IF v_charge > 0 THEN
    INSERT INTO loan_charges (loan_id, emi_schedule_id, bounce_id, charge_type, charge_date, amount, remarks)
    VALUES (p_loan_id, v_emi, v_id, 'BOUNCE', p_bounce_date, v_charge, 'Bounce charge: ' || p_reason);
  END IF;

  PERFORM fn_refresh_loan(p_loan_id);
  RETURN v_id;
END $$;

-- Formal waiver: a charge (partially or fully) or the full remaining amount of an installment
CREATE OR REPLACE FUNCTION sp_waive(p_loan_id bigint, p_target text, p_target_id bigint, p_amount numeric,
                                    p_reason text, p_user int DEFAULT NULL)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE v_rem numeric;
BEGIN
  PERFORM 1 FROM loans WHERE id = p_loan_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Loan % not found', p_loan_id USING ERRCODE = 'CW404'; END IF;
  IF p_reason IS NULL OR length(trim(p_reason)) < 3 THEN RAISE EXCEPTION 'Waiver reason is required' USING ERRCODE = 'CW400'; END IF;
  IF p_target = 'CHARGE' THEN
    SELECT remaining_amount INTO v_rem FROM loan_charges WHERE id = p_target_id AND loan_id = p_loan_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Charge not found on this loan' USING ERRCODE = 'CW404'; END IF;
    IF p_amount IS NULL OR p_amount <= 0 OR p_amount > v_rem THEN
      RAISE EXCEPTION 'Waiver amount must be between 0.01 and %', v_rem USING ERRCODE = 'CW400';
    END IF;
    UPDATE loan_charges SET waived_amount = waived_amount + p_amount,
           remarks = concat_ws(' | ', remarks, 'Waived ' || p_amount || ': ' || p_reason) WHERE id = p_target_id;
  ELSIF p_target = 'EMI' THEN
    SELECT remaining_amount INTO v_rem FROM emi_schedules WHERE id = p_target_id AND loan_id = p_loan_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Installment not found on this loan' USING ERRCODE = 'CW404'; END IF;
    IF v_rem <= 0 THEN RAISE EXCEPTION 'Installment has nothing to waive' USING ERRCODE = 'CW409'; END IF;
    UPDATE emi_schedules SET waived_amount = waived_amount + v_rem WHERE id = p_target_id;   -- full remaining only
  ELSE
    RAISE EXCEPTION 'Waiver target must be CHARGE or EMI' USING ERRCODE = 'CW400';
  END IF;
  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, new_values)
  VALUES (p_user, 'WAIVER', p_target, p_target_id::text,
          jsonb_build_object('loan_id', p_loan_id, 'amount', COALESCE(p_amount, v_rem), 'reason', p_reason));
  PERFORM fn_refresh_loan(p_loan_id);
END $$;

-- ---------------------------------------------------------------------
-- Portfolio summary (derived from immutable snapshots → safely rebuildable)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION sp_generate_portfolio_summary(p_business_date date) RETURNS int
LANGUAGE plpgsql AS $$
DECLARE v_rows int;
BEGIN
  DELETE FROM portfolio_daily_summary WHERE business_date = p_business_date;
  INSERT INTO portfolio_daily_summary (business_date, bucket_code, bucket_sort_order, account_count,
                                       outstanding_principal, overdue_amount)
  SELECT p_business_date, b.code, b.sort_order,
         count(s.loan_id), COALESCE(sum(s.outstanding_principal), 0), COALESCE(sum(s.overdue_amount), 0)
    FROM dpd_bucket_config b
    LEFT JOIN dpd_daily_snapshots s ON s.bucket_code = b.code AND s.business_date = p_business_date
   WHERE b.is_active
   GROUP BY b.code, b.sort_order;
  GET DIAGNOSTICS v_rows = ROW_COUNT;
  RETURN v_rows;
END $$;

-- ---------------------------------------------------------------------
-- Promise-to-pay evaluation
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_evaluate_ptps(p_business_date date) RETURNS int
LANGUAGE plpgsql AS $$
DECLARE v_rows int;
BEGIN
  WITH eval AS (
    SELECT t.id, t.executive_id, t.loan_id, t.promised_amount, t.promised_date,
           COALESCE((SELECT sum(p.amount) FROM payments p
                      WHERE p.loan_id = t.loan_id AND p.status = 'SUCCESSFUL'
                        AND p.payment_date BETWEEN t.promised_on AND LEAST(t.promised_date, p_business_date)), 0) AS kept
      FROM promise_to_pay t
     WHERE t.status = 'PENDING'
  ), upd AS (
    UPDATE promise_to_pay t
       SET kept_amount = e.kept,
           status = CASE WHEN e.kept >= e.promised_amount THEN 'KEPT'
                         WHEN e.promised_date < p_business_date AND e.kept > 0 THEN 'PARTIALLY_KEPT'
                         WHEN e.promised_date < p_business_date THEN 'BROKEN'
                         ELSE 'PENDING' END,
           resolved_on = CASE WHEN e.kept >= e.promised_amount OR e.promised_date < p_business_date
                              THEN p_business_date END
      FROM eval e
     WHERE t.id = e.id
    RETURNING t.id, t.status, t.executive_id, t.loan_id
  )
  INSERT INTO notifications (user_id, type, title, message, link)
  SELECT u.executive_id, 'PTP', 'Promise to pay broken',
         'Customer missed a promise on loan ' || l.loan_number, '/loans/' || l.id
    FROM upd u JOIN loans l ON l.id = u.loan_id
   WHERE u.status = 'BROKEN';
  GET DIAGNOSTICS v_rows = ROW_COUNT;
  RETURN v_rows;
END $$;

-- ---------------------------------------------------------------------
-- Daily DPD batch (work part). Runs inside the caller's transaction.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_run_daily_dpd(p_business_date date, p_job_id bigint,
                                            OUT o_loans int, OUT o_snapshots int)
LANGUAGE plpgsql AS $$
DECLARE v_last date;
BEGIN
  -- one DPD run at a time (transaction-scoped advisory lock)
  IF NOT pg_try_advisory_xact_lock(hashtext('sp_update_daily_dpd')) THEN
    RAISE EXCEPTION 'Another DPD run is in progress' USING ERRCODE = 'CW409';
  END IF;
  IF p_business_date IS NULL THEN RAISE EXCEPTION 'Business date is required' USING ERRCODE = 'CW400'; END IF;
  IF p_business_date > fn_calendar_today() THEN
    RAISE EXCEPTION 'Business date % is in the future (today is %)', p_business_date, fn_calendar_today() USING ERRCODE = 'CW400';
  END IF;
  SELECT max(business_date) INTO v_last FROM job_execution_logs
   WHERE job_name = 'DAILY_DPD' AND status = 'SUCCESS';
  IF v_last IS NOT NULL AND p_business_date < v_last THEN
    RAISE EXCEPTION 'Business date % is before the last successful run %; historical snapshots are immutable',
      p_business_date, v_last USING ERRCODE = 'CW409';
  END IF;

  UPDATE system_settings SET value = p_business_date::text, updated_at = now()
   WHERE key = 'business_date' AND value::date < p_business_date;

  PERFORM fn_refresh_emi_status(p_business_date, NULL);
  -- bounce recovery for every loan that has open bounces
  PERFORM fn_refresh_bounce_recovery(b.loan_id, p_business_date)
     FROM (SELECT DISTINCT loan_id FROM payment_bounces WHERE recovery_status IN ('PENDING','PARTIAL')) b;
  o_loans := fn_upsert_dpd_current(p_business_date, NULL);

  INSERT INTO dpd_daily_snapshots (business_date, loan_id, product_id, branch_id, executive_id, state, dpd, bucket_code,
         bucket_sort_order, overdue_emi_count, overdue_amount, overdue_charges, oldest_overdue_date,
         outstanding_principal, last_payment_date, next_emi_due_date, account_status, job_id)
  SELECT c.business_date, c.loan_id, c.product_id, c.branch_id, c.executive_id, c.state, c.dpd, c.bucket_code,
         c.bucket_sort_order, c.overdue_emi_count, c.overdue_amount, c.overdue_charges, c.oldest_overdue_date,
         c.outstanding_principal, c.last_payment_date, c.next_emi_due_date, c.account_status, p_job_id
    FROM fn_compute_dpd(p_business_date, NULL) c
  ON CONFLICT (business_date, loan_id) DO NOTHING;          -- idempotent: never touch an existing snapshot
  GET DIAGNOSTICS o_snapshots = ROW_COUNT;

  PERFORM fn_evaluate_ptps(p_business_date);
  PERFORM sp_generate_portfolio_summary(p_business_date);
END $$;

-- ---------------------------------------------------------------------
-- Daily DPD procedure with its own transaction control:
--   1) log RUNNING and COMMIT (so the log survives a failure)
--   2) do all the work atomically; on error the work rolls back and the log is marked FAILED
-- Must be invoked with CALL outside an explicit transaction block.
-- ---------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE sp_update_daily_dpd(
  p_business_date date,
  p_trigger_type text DEFAULT 'MANUAL',
  p_triggered_by int DEFAULT NULL,
  INOUT p_job_id bigint DEFAULT NULL,
  INOUT p_status text DEFAULT NULL)
LANGUAGE plpgsql AS $$
DECLARE
  v_loans int; v_snaps int; v_msg text; v_detail text;
BEGIN
  INSERT INTO job_execution_logs (job_name, business_date, trigger_type, status, triggered_by)
  VALUES ('DAILY_DPD', p_business_date, p_trigger_type, 'RUNNING', p_triggered_by)
  RETURNING id INTO p_job_id;
  COMMIT;

  BEGIN
    SELECT o_loans, o_snapshots INTO v_loans, v_snaps FROM fn_run_daily_dpd(p_business_date, p_job_id);
    UPDATE job_execution_logs
       SET status = 'SUCCESS', finished_at = clock_timestamp(), loans_processed = v_loans,
           snapshots_inserted = v_snaps,
           message = CASE WHEN v_snaps = 0 AND v_loans > 0 THEN 'Re-run: snapshots for this date already existed (unchanged)'
                          ELSE 'Completed' END
     WHERE id = p_job_id;
    p_status := 'SUCCESS';
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_msg = MESSAGE_TEXT, v_detail = PG_EXCEPTION_DETAIL;
    UPDATE job_execution_logs
       SET status = 'FAILED', finished_at = clock_timestamp(), error_message = v_msg
     WHERE id = p_job_id;
    INSERT INTO notifications (user_id, type, title, message, link)
    SELECT u.id, 'JOB', 'Daily DPD run failed', 'Business date ' || p_business_date || ': ' || v_msg, '/jobs'
      FROM users u JOIN roles r ON r.id = u.role_id
     WHERE r.code IN ('SUPER_ADMIN','ADMIN') AND u.is_active AND u.deleted_at IS NULL;
    p_status := 'FAILED';
  END;
  COMMIT;
END $$;

-- ---------------------------------------------------------------------
-- Business metrics shared by dashboard and reports (single definition)
-- ---------------------------------------------------------------------
-- Collection efficiency for a period:
--   demand    = Σ EMI amount of installments due in [from, to]
--   collected = Σ successful, non-reversed allocations to those installments paid up to `to`
CREATE OR REPLACE FUNCTION fn_collection_efficiency(p_from date, p_to date, p_product_id int DEFAULT NULL)
RETURNS TABLE (demand numeric, collected_against_demand numeric, efficiency_pct numeric)
LANGUAGE sql STABLE AS $$
  WITH d AS (
    SELECT e.id, e.emi_amount FROM emi_schedules e JOIN loans l ON l.id = e.loan_id
     WHERE e.due_date BETWEEN p_from AND p_to AND l.status NOT IN ('CANCELLED','DRAFT','APPROVED')
       AND (p_product_id IS NULL OR l.product_id = p_product_id)
  ), c AS (
    SELECT COALESCE(sum(a.amount), 0) AS amt
      FROM payment_allocations a JOIN payments p ON p.id = a.payment_id
     WHERE a.emi_schedule_id IN (SELECT id FROM d) AND p.status = 'SUCCESSFUL' AND p.payment_date <= p_to
  )
  SELECT COALESCE((SELECT sum(emi_amount) FROM d), 0),
         (SELECT amt FROM c),
         CASE WHEN COALESCE((SELECT sum(emi_amount) FROM d), 0) = 0 THEN NULL
              ELSE round((SELECT amt FROM c) * 100 / (SELECT sum(emi_amount) FROM d), 2) END
$$;
