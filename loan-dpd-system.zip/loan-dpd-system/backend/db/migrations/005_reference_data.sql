-- =====================================================================
-- Reference / configuration data required by the application
-- =====================================================================

INSERT INTO roles (code, name, description) VALUES
 ('SUPER_ADMIN',          'Super Admin',          'Full access including role & permission management'),
 ('ADMIN',                'Admin',                'Administration, configuration and all operations'),
 ('COLLECTION_MANAGER',   'Collection Manager',   'Runs the collections team: assignments, targets, reports'),
 ('COLLECTION_EXECUTIVE', 'Collection Executive', 'Works assigned overdue accounts only'),
 ('FINANCE_USER',         'Finance User',         'Loans, disbursement, payments, reversals, DPD runs'),
 ('READ_ONLY_ANALYST',    'Read-Only Analyst',    'Read access to dashboards, data and reports');

INSERT INTO permissions (code, module, description) VALUES
 ('dashboard.read',      'dashboard',   'View dashboards'),
 ('customers.read',      'customers',   'View customers'),
 ('customers.write',     'customers',   'Create/edit customers'),
 ('customers.pii',       'customers',   'See unmasked mobile/PAN'),
 ('loans.read',          'loans',       'View loans and schedules'),
 ('loans.write',         'loans',       'Create/edit draft loans'),
 ('loans.approve',       'loans',       'Approve / cancel loans'),
 ('loans.disburse',      'loans',       'Disburse loans'),
 ('loans.close',         'loans',       'Close loans'),
 ('loans.write_off',     'loans',       'Write off loans'),
 ('loans.waive',         'loans',       'Waive charges / installments'),
 ('payments.read',       'payments',    'View payments'),
 ('payments.write',      'payments',    'Record payments'),
 ('payments.reverse',    'payments',    'Reverse / realise / fail payments'),
 ('payments.import',     'payments',    'Bulk CSV import'),
 ('bounces.read',        'bounces',     'View bounces'),
 ('bounces.write',       'bounces',     'Record bounces and re-presentations'),
 ('dpd.read',            'dpd',         'View DPD data'),
 ('dpd.run',             'dpd',         'Run / retry daily DPD job'),
 ('collections.read',    'collections', 'View collection data'),
 ('collections.write',   'collections', 'Log activities and promises'),
 ('collections.assign',  'collections', 'Assign / reassign accounts'),
 ('collections.targets', 'collections', 'Set collection targets'),
 ('reports.read',        'reports',     'View reports'),
 ('reports.export',      'reports',     'Export reports (CSV/Excel/PDF)'),
 ('users.read',          'admin',       'View users'),
 ('users.manage',        'admin',       'Create/edit/deactivate users'),
 ('roles.manage',        'admin',       'Edit role permissions'),
 ('config.manage',       'admin',       'Edit system configuration'),
 ('jobs.read',           'admin',       'View scheduled jobs'),
 ('audit.read',          'admin',       'View audit logs');

-- Super Admin: everything
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p WHERE r.code = 'SUPER_ADMIN';

-- Admin: everything except role management
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p WHERE r.code = 'ADMIN' AND p.code <> 'roles.manage';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code = ANY (CASE r.code
  WHEN 'COLLECTION_MANAGER' THEN ARRAY['dashboard.read','customers.read','customers.pii','loans.read','payments.read',
       'payments.write','bounces.read','bounces.write','dpd.read','collections.read','collections.write',
       'collections.assign','collections.targets','reports.read','reports.export','jobs.read','users.read']
  WHEN 'COLLECTION_EXECUTIVE' THEN ARRAY['dashboard.read','customers.read','customers.pii','loans.read','payments.read',
       'payments.write','bounces.read','dpd.read','collections.read','collections.write']
  WHEN 'FINANCE_USER' THEN ARRAY['dashboard.read','customers.read','customers.write','customers.pii','loans.read',
       'loans.write','loans.approve','loans.disburse','loans.close','loans.write_off','loans.waive','payments.read',
       'payments.write','payments.reverse','payments.import','bounces.read','bounces.write','dpd.read','dpd.run',
       'collections.read','reports.read','reports.export','jobs.read']
  WHEN 'READ_ONLY_ANALYST' THEN ARRAY['dashboard.read','customers.read','loans.read','payments.read','bounces.read',
       'dpd.read','collections.read','reports.read','reports.export','jobs.read']
  END)
WHERE r.code IN ('COLLECTION_MANAGER','COLLECTION_EXECUTIVE','FINANCE_USER','READ_ONLY_ANALYST');

INSERT INTO dpd_bucket_config (code, label, min_dpd, max_dpd, sort_order, color) VALUES
 ('CURRENT', 'Current',   0,  0,    1, '#0d9488'),
 ('B1_30',   '1–30 DPD',  1,  30,   2, '#f59e0b'),
 ('B31_60',  '31–60 DPD', 31, 60,   3, '#f97316'),
 ('B61_89',  '61–89 DPD', 61, 89,   4, '#ef4444'),
 ('B90P',    '90+ DPD',   90, NULL, 5, '#991b1b');

INSERT INTO system_settings (key, value, data_type, description, is_editable) VALUES
 ('business_date',          to_char((now() AT TIME ZONE 'Asia/Kolkata')::date, 'YYYY-MM-DD'), 'date',
                            'Current business date (advanced only by the daily DPD job)', FALSE),
 ('business_timezone',      'Asia/Kolkata', 'string', 'IANA timezone used to derive business dates', TRUE),
 ('company_name',           'Demo Finance Pvt. Ltd.', 'string', 'Shown on receipts and reports', TRUE),
 ('dpd_grace_days',         '0', 'number', 'Days after due date before an account is counted as past due', TRUE),
 ('emi_rounding_places',    '0', 'number', 'Decimal places for EMI rounding (0 = nearest rupee)', TRUE),
 ('allocation_waterfall',   'EMI_ORDER', 'string', 'EMI_ORDER | CHARGES_FIRST | INTEREST_FIRST', TRUE),
 ('due_date_holiday_rule',  'NEXT_WORKING_DAY', 'string', 'NONE | NEXT_WORKING_DAY | PREVIOUS_WORKING_DAY', TRUE),
 ('sunday_is_holiday',      'false', 'boolean', 'Treat Sundays as non-working days for due dates', TRUE),
 ('bounce_charge_override', '', 'number', 'Flat bounce charge for all products (blank = product setting)', TRUE),
 ('write_off_min_dpd',      '90', 'number', 'Minimum DPD before a loan can be written off', TRUE),
 ('dpd_job_enabled',        'true', 'boolean', 'Run the daily DPD job automatically', TRUE),
 ('dpd_job_cron',           '30 0 * * *', 'string', 'Cron expression (business timezone) for the daily DPD job', TRUE);

INSERT INTO loan_products (code, name, min_amount, max_amount, min_tenure_months, max_tenure_months,
                           default_rate, processing_fee_pct, bounce_charge) VALUES
 ('TW',  'Two-Wheeler Loan',        30000,   250000,  6,  36, 18.50, 2.00, 590),
 ('PL',  'Personal Loan',           25000,   500000,  6,  48, 22.00, 2.50, 590),
 ('LAP', 'Loan Against Property',  300000,  5000000, 24, 180, 14.50, 1.00, 750),
 ('CD',  'Consumer Durable (0%)',   10000,   150000,  3,  24,  0.00, 3.00, 400);

INSERT INTO branches (code, name, city, state) VALUES
 ('HO',  'Head Office',   'Navi Mumbai', 'Maharashtra'),
 ('PNQ', 'Pune',          'Pune',        'Maharashtra'),
 ('NSK', 'Nashik',        'Nashik',      'Maharashtra'),
 ('RNC', 'Ranchi',        'Ranchi',      'Jharkhand'),
 ('BBS', 'Bhubaneswar',   'Bhubaneswar', 'Odisha'),
 ('PAT', 'Patna',         'Patna',       'Bihar');

INSERT INTO holidays (holiday_date, name) VALUES
 ('2025-01-26', 'Republic Day'), ('2025-08-15', 'Independence Day'), ('2025-10-02', 'Gandhi Jayanti'),
 ('2025-10-21', 'Diwali'),
 ('2026-01-26', 'Republic Day'), ('2026-08-15', 'Independence Day'), ('2026-10-02', 'Gandhi Jayanti'),
 ('2026-11-09', 'Diwali (Laxmi Pujan)'),
 ('2027-01-26', 'Republic Day'), ('2027-08-15', 'Independence Day'), ('2027-10-02', 'Gandhi Jayanti');
