/**
 * End-to-end business flows against a real PostgreSQL database through the HTTP API.
 * Runs sequentially (one shared timeline): business dates only move forward.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import request from 'supertest';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'node:crypto';
import { createApp } from '../../src/app.js';
import { pool } from '../../src/db/pool.js';
import { buildSchedule } from '../../src/lib/emi.js';
import { parPct } from '../../src/lib/dpd.js';

const app = createApp();
const PASSWORD = 'Test@12345';
const tokens: Record<string, string> = {};
const sql = async (q: string, p: unknown[] = []) => (await pool.query(q, p as any[])).rows;
const addDays = (iso: string, n: number) => {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};
const as = (who: string) => ({ Authorization: `Bearer ${tokens[who]}` });
const runDpd = (date: string) => request(app).post('/api/dpd/run').set(as('admin')).send({ businessDate: date });
const dpdOf = async (loanId: number) => (await sql(`SELECT * FROM dpd_current WHERE loan_id = $1`, [loanId]))[0];
const emi = async (loanId: number, n: number) =>
  (await sql(`SELECT * FROM emi_schedules WHERE loan_id = $1 AND installment_no = $2`, [loanId, n]))[0];
const pay = (body: Record<string, unknown>, key = randomUUID(), who = 'finance') =>
  request(app).post('/api/payments').set(as(who)).set('Idempotency-Key', key).send(body);

let today: string;
let start: string;
let customerId: number;
let loanId: number;
let due1: string;
let d1: string;

beforeAll(async () => {
  const roles = await sql(`SELECT id, code FROM roles`);
  const hash = await bcrypt.hash(PASSWORD, 4);
  for (const [who, role] of [
    ['admin', 'ADMIN'],
    ['finance', 'FINANCE_USER'],
    ['analyst', 'READ_ONLY_ANALYST'],
    ['exec', 'COLLECTION_EXECUTIVE'],
    ['manager', 'COLLECTION_MANAGER'],
  ]) {
    await sql(`INSERT INTO users (email, full_name, password_hash, role_id) VALUES ($1, $2, $3, $4)`, [
      `${who}@test.local`,
      `Test ${who}`,
      hash,
      roles.find((r: any) => r.code === role).id,
    ]);
    const res = await request(app).post('/api/auth/login').send({ email: `${who}@test.local`, password: PASSWORD });
    expect(res.status).toBe(200);
    tokens[who] = res.body.accessToken;
  }
  today = (await sql(`SELECT fn_calendar_today()::text AS d`))[0].d;
  start = addDays(today, -200);
  await sql(`UPDATE system_settings SET value = $1 WHERE key = 'business_date'`, [start]);
});

afterAll(async () => {
  await pool.end();
});

describe('authentication & access control', () => {
  it('rejects bad credentials and unknown users the same way', async () => {
    const a = await request(app).post('/api/auth/login').send({ email: 'admin@test.local', password: 'wrong-pass1' });
    const b = await request(app).post('/api/auth/login').send({ email: 'nobody@test.local', password: 'wrong-pass1' });
    expect(a.status).toBe(401);
    expect(b.status).toBe(401);
    expect(a.body.error.message).toBe(b.body.error.message);
  });

  it('requires a token and returns the profile with permissions', async () => {
    expect((await request(app).get('/api/auth/me')).status).toBe(401);
    const me = await request(app).get('/api/auth/me').set(as('analyst'));
    expect(me.status).toBe(200);
    expect(me.body.role).toBe('READ_ONLY_ANALYST');
    expect(me.body.permissions).not.toContain('payments.write');
  });

  it('rotates refresh tokens and detects reuse of an old one', async () => {
    const agent = request.agent(app);
    await agent.post('/api/auth/login').send({ email: 'manager@test.local', password: PASSWORD }).expect(200);
    const firstCookie = (await sql(`SELECT count(*)::int AS n FROM user_sessions s JOIN users u ON u.id = s.user_id WHERE u.email = 'manager@test.local'`))[0].n;
    expect(firstCookie).toBeGreaterThan(0);
    const login = await request(app).post('/api/auth/login').send({ email: 'manager@test.local', password: PASSWORD });
    const oldCookie = login.headers['set-cookie'][0].split(';')[0];
    const r1 = await request(app).post('/api/auth/refresh').set('Cookie', oldCookie);
    expect(r1.status).toBe(200);
    expect(r1.body.accessToken).toBeTruthy();
    // replaying the rotated cookie is treated as theft → 401 and every session revoked
    const r2 = await request(app).post('/api/auth/refresh').set('Cookie', oldCookie);
    expect(r2.status).toBe(401);
    const live = await sql(`SELECT count(*)::int AS n FROM user_sessions s JOIN users u ON u.id = s.user_id WHERE u.email = 'manager@test.local' AND s.revoked_at IS NULL`);
    expect(live[0].n).toBe(0);
  });

  it('enforces role permissions', async () => {
    const r = await pay({ loanId: 1, amount: 10, paymentDate: start, paymentMode: 'CASH' }, randomUUID(), 'analyst');
    expect(r.status).toBe(403);
    expect((await request(app).get('/api/users').set(as('exec'))).status).toBe(403);
  });
});

describe('customers', () => {
  it('validates input', async () => {
    const r = await request(app).post('/api/customers').set(as('finance')).send({ fullName: 'X', mobile: '12345', pan: 'BAD' });
    expect(r.status).toBe(400);
    expect(r.body.error.code).toBe('VALIDATION');
    expect(r.body.error.details.map((d: any) => d.path)).toEqual(expect.arrayContaining(['fullName', 'mobile', 'pan']));
  });

  it('creates a customer and stores only the last 4 Aadhaar digits', async () => {
    const r = await request(app).post('/api/customers').set(as('finance')).send({
      fullName: 'Ramesh Kumar', mobile: '9876543210', pan: 'abcpk1234z', aadhaar: '123412341234', state: 'Bihar', city: 'Patna', monthlyIncome: 40000,
    });
    expect(r.status).toBe(201);
    customerId = r.body.id;
    const row = (await sql(`SELECT pan, aadhaar_last4 FROM customers WHERE id = $1`, [customerId]))[0];
    expect(row).toEqual({ pan: 'ABCPK1234Z', aadhaar_last4: '1234' });
  });

  it('masks PII for roles without customers.pii', async () => {
    const r = await request(app).get(`/api/customers/${customerId}`).set(as('analyst'));
    expect(r.status).toBe(200);
    expect(r.body.mobile).toBe('98XXXXXX10');
    expect(r.body.pan).toBe('XXXXX1234X');
    expect(r.body.aadhaarMasked).toBe('XXXX-XXXX-1234');
    const full = await request(app).get(`/api/customers/${customerId}`).set(as('finance'));
    expect(full.body.mobile).toBe('9876543210');
  });
});

describe('loan lifecycle & EMI schedule', () => {
  it('creates, approves and disburses a loan atomically with its schedule', async () => {
    const c = await request(app).post('/api/loans').set(as('finance')).send({
      customerId, productId: 1, principalAmount: 100000, annualInterestRate: 18, tenureMonths: 12, paymentDueDay: 5,
    });
    expect(c.status).toBe(201);
    loanId = c.body.id;
    expect(c.body.status).toBe('DRAFT');
    // cannot disburse before approval
    expect((await request(app).post(`/api/loans/${loanId}/disburse`).set(as('finance')).send({ disbursementDate: start })).status).toBe(409);
    expect((await request(app).post(`/api/loans/${loanId}/approve`).set(as('finance'))).status).toBe(200);
    const d = await request(app).post(`/api/loans/${loanId}/disburse`).set(as('finance')).send({ disbursementDate: start });
    expect(d.status).toBe(200);
    expect(d.body.emiAmount).toBe(9168);

    const sched = await request(app).get(`/api/loans/${loanId}/emi-schedule`).set(as('finance'));
    expect(sched.body).toHaveLength(12);
    const ts = buildSchedule({ principal: 100000, annualRate: 18, tenureMonths: 12 });
    sched.body.forEach((row: any, i: number) => {
      expect(row.principalComponent).toBe(Number(ts.rows[i].principal));
      expect(row.interestComponent).toBe(Number(ts.rows[i].interest));
    });
    const totalPrincipal = sched.body.reduce((s: number, r: any) => s + Math.round(r.principalComponent * 100), 0) / 100;
    expect(totalPrincipal).toBe(100000);
    due1 = sched.body[0].dueDate;
    d1 = addDays(due1, 10);
  });

  it('database and TypeScript EMI engines agree for many loan shapes', async () => {
    const shapes = [
      [57345.67, 21.25, 17, 'REDUCING', 2],
      [2500000, 14.5, 120, 'REDUCING', 3],
      [45000, 0, 9, 'FLAT', 4],
      [36000, 12, 12, 'FLAT', 4],
      [250000, 9.99, 36, 'REDUCING', 2],
    ] as const;
    for (const [p, r, n, m, product] of shapes) {
      const l = (await sql(
        `INSERT INTO loans (customer_id, product_id, principal_amount, annual_interest_rate, interest_method, tenure_months, payment_due_day, status, first_emi_date)
         VALUES ($1,$2,$3,$4,$5,$6,10,'DRAFT', $7) RETURNING id`,
        [customerId, product, p, r, m, n, addDays(start, 30)],
      ))[0].id;
      await sql(`SELECT sp_generate_emi_schedule($1)`, [l]);
      const db = await sql(`SELECT principal_component::text AS p, interest_component::text AS i FROM emi_schedules WHERE loan_id = $1 ORDER BY installment_no`, [l]);
      const ts = buildSchedule({ principal: p, annualRate: r, tenureMonths: n, method: m });
      expect(db.map((x: any) => [x.p, x.i])).toEqual(ts.rows.map((x) => [x.principal, x.interest]));
      await sql(`UPDATE loans SET status = 'CANCELLED' WHERE id = $1`, [l]);
    }
  });

  it('freezes financial terms after disbursement', async () => {
    await expect(sql(`UPDATE loans SET principal_amount = 1 WHERE id = $1`, [loanId])).rejects.toThrow(/cannot be changed/);
    await expect(sql(`UPDATE emi_schedules SET emi_amount = 1 WHERE loan_id = $1`, [loanId])).rejects.toThrow(/cannot be edited/);
  });
});

describe('DPD engine & payments', () => {
  it('computes DPD from the oldest unpaid installment', async () => {
    const r = await runDpd(d1);
    expect(r.status).toBe(200);
    expect(r.body.status).toBe('SUCCESS');
    const d = await dpdOf(loanId);
    expect(d.dpd).toBe(10);
    expect(d.bucket_code).toBe('B1_30');
    expect(Number(d.overdue_amount)).toBe(9168);
    expect((await emi(loanId, 1)).status).toBe('OVERDUE');
    expect((await sql(`SELECT status FROM loans WHERE id = $1`, [loanId]))[0].status).toBe('OVERDUE');
  });

  it('a partial payment reduces the overdue amount but does not mark the EMI paid', async () => {
    const key = randomUUID();
    const body = { loanId, amount: 5000, paymentDate: d1, paymentMode: 'UPI', transactionReference: 'UTR-PART-1' };
    const r = await pay(body, key);
    expect(r.status).toBe(201);
    // interest first, then principal
    expect(r.body.allocations.map((a: any) => [a.component, a.amount])).toEqual([
      ['INTEREST', 1500],
      ['PRINCIPAL', 3500],
    ]);
    const e1 = await emi(loanId, 1);
    expect(Number(e1.remaining_amount)).toBe(4168);
    expect(e1.status).toBe('OVERDUE');
    expect((await dpdOf(loanId)).dpd).toBe(10);

    // idempotent replay: same key + body → same payment, nothing new posted
    const again = await pay(body, key);
    expect(again.status).toBe(201);
    expect(again.headers['idempotent-replayed']).toBe('true');
    expect(again.body.id).toBe(r.body.id);
    expect((await sql(`SELECT count(*)::int AS n FROM payments WHERE loan_id = $1`, [loanId]))[0].n).toBe(1);
    // same key, different body → rejected
    expect((await pay({ ...body, amount: 10 }, key)).status).toBe(422);
    // new key, same bank reference → duplicate
    const dup = await pay(body);
    expect(dup.status).toBe(409);
    expect(dup.body.error.message).toMatch(/Duplicate transaction reference/);
  });

  it('clearing the installment brings DPD back to 0', async () => {
    const r = await pay({ loanId, amount: 4168, paymentDate: d1, paymentMode: 'NACH', transactionReference: 'NACH-001' });
    expect(r.status).toBe(201);
    expect((await emi(loanId, 1)).status).toBe('PAID');
    const d = await dpdOf(loanId);
    expect(d.dpd).toBe(0);
    expect(d.bucket_code).toBe('CURRENT');
  });

  it('a bounce restores the dues, adds a charge and is never counted as collected', async () => {
    const nach = (await sql(`SELECT id FROM payments WHERE transaction_reference = 'NACH-001'`))[0].id;
    const b = await request(app).post('/api/bounces').set(as('finance')).send({ loanId, paymentId: nach, bounceDate: d1, bounceReason: 'INSUFFICIENT_FUNDS' });
    expect(b.status).toBe(201);
    expect(b.body.bounceCharges).toBe(590);
    const e1 = await emi(loanId, 1);
    expect(Number(e1.remaining_amount)).toBe(4168);
    expect(e1.status).toBe('BOUNCED');
    const d = await dpdOf(loanId);
    expect(d.dpd).toBe(10);
    expect(Number(d.overdue_charges)).toBe(590);
    const coll = await sql(`SELECT sum(successful_amount)::numeric AS s FROM vw_daily_collection_summary WHERE payment_date = $1`, [d1]);
    expect(Number(coll[0].s)).toBe(5000);
    // a bounced payment cannot bounce again or be reversed
    expect((await request(app).post(`/api/payments/${nach}/reverse`).set(as('finance')).send({ reason: 'test' })).status).toBe(409);
  });

  it('a reversal restores exactly what the payment had cleared', async () => {
    const p = (await sql(`SELECT id FROM payments WHERE transaction_reference = 'UTR-PART-1'`))[0].id;
    const r = await request(app).post(`/api/payments/${p}/reverse`).set(as('finance')).send({ reason: 'Credit not received' });
    expect(r.status).toBe(200);
    expect(r.body.status).toBe('REVERSED');
    const e1 = await emi(loanId, 1);
    expect(Number(e1.remaining_amount)).toBe(9168);
    expect(Number(e1.interest_paid)).toBe(0);
    // ledger: dues 9168 + charge 590 − receipts 9168 + reversal 5000 + bounce 4168 = 9758 owed
    const ledger = await request(app).get(`/api/loans/${loanId}/ledger`).set(as('finance'));
    expect(ledger.body.at(-1).balance).toBe(9758);
    const out = (await sql(`SELECT * FROM vw_loan_outstanding WHERE loan_id = $1`, [loanId]))[0];
    expect(Number(out.overdue_principal) + Number(out.overdue_interest) + Number(out.charges_outstanding)).toBe(9758);
    // financial records cannot be deleted
    await expect(sql(`DELETE FROM payments WHERE id = $1`, [p])).rejects.toThrow(/immutable/);
    await expect(sql(`DELETE FROM payment_allocations`)).rejects.toThrow(/immutable/);
  });

  it('allocates an advance payment to future installments', async () => {
    const r = await pay({ loanId, amount: 9168 + 590 + 9168, paymentDate: d1, paymentMode: 'NEFT', transactionReference: 'NEFT-ADV-1' });
    expect(r.status).toBe(201);
    const adv = r.body.allocations.filter((a: any) => a.isAdvance);
    expect(adv.reduce((s: number, a: any) => s + a.amount, 0)).toBe(9168);
    expect(adv.every((a: any) => a.installmentNo === 2)).toBe(true);
    expect((await emi(loanId, 2)).status).toBe('PAID');
    const bounce = (await sql(`SELECT recovery_status FROM payment_bounces WHERE loan_id = $1`, [loanId]))[0];
    expect(bounce.recovery_status).toBe('RECOVERED');
    // when EMI 2 falls due it is already paid → DPD stays 0
    const due2 = (await emi(loanId, 2)).due_date;
    expect((await runDpd(addDays(due2.toISOString?.().slice(0, 10) ?? due2, 1))).body.status).toBe('SUCCESS');
    expect((await dpdOf(loanId)).dpd).toBe(0);
  });

  it('rejects a payment larger than the total outstanding', async () => {
    const total = Number((await sql(`SELECT fn_loan_total_outstanding($1) AS v`, [loanId]))[0].v);
    const bd = (await sql(`SELECT fn_business_date()::text AS d`))[0].d;
    const r = await pay({ loanId, amount: total + 1, paymentDate: bd, paymentMode: 'CASH' });
    expect(r.status).toBe(400);
    expect(r.body.error.message).toMatch(/exceeds total outstanding/);
  });

  it('serialises concurrent payments on the same loan (no double collection)', async () => {
    const bd = (await sql(`SELECT fn_business_date()::text AS d`))[0].d;
    const total = Number((await sql(`SELECT fn_loan_total_outstanding($1) AS v`, [loanId]))[0].v);
    const [a, b] = await Promise.all([
      pay({ loanId, amount: total, paymentDate: bd, paymentMode: 'IMPS', transactionReference: 'RACE-A' }),
      pay({ loanId, amount: total, paymentDate: bd, paymentMode: 'IMPS', transactionReference: 'RACE-B' }),
    ]);
    expect([a.status, b.status].sort()).toEqual([201, 400]);
    expect(Number((await sql(`SELECT fn_loan_total_outstanding($1) AS v`, [loanId]))[0].v)).toBe(0);
  });

  it('closes a fully paid loan and blocks further postings', async () => {
    const r = await request(app).post(`/api/loans/${loanId}/close`).set(as('finance')).send({ remarks: 'Foreclosed' });
    expect(r.status).toBe(200);
    expect((await sql(`SELECT status FROM loans WHERE id = $1`, [loanId]))[0].status).toBe('CLOSED');
    const bd = (await sql(`SELECT fn_business_date()::text AS d`))[0].d;
    expect((await pay({ loanId, amount: 1, paymentDate: bd, paymentMode: 'CASH' })).status).toBe(409);
  });
});

describe('daily DPD job', () => {
  let loan2: number;
  it('blocks closure while dues are open, and supports waivers', async () => {
    const bd = (await sql(`SELECT fn_business_date()::text AS d`))[0].d;
    loan2 = (await request(app).post('/api/loans').set(as('finance')).send({ customerId, productId: 4, principalAmount: 12000, annualInterestRate: 0, tenureMonths: 3 })).body.id;
    await request(app).post(`/api/loans/${loan2}/approve`).set(as('finance')).expect(200);
    await request(app).post(`/api/loans/${loan2}/disburse`).set(as('finance')).send({ disbursementDate: bd }).expect(200);
    const close = await request(app).post(`/api/loans/${loan2}/close`).set(as('finance')).send({});
    expect(close.status).toBe(409);
    expect(close.body.error.message).toMatch(/unsettled dues/);
  });

  it('is idempotent for the same business date and never rewrites snapshots', async () => {
    const date = addDays(today, -20);
    const first = await runDpd(date);
    expect(first.body.status).toBe('SUCCESS');
    const n1 = (await sql(`SELECT count(*)::int AS n FROM dpd_daily_snapshots WHERE business_date = $1`, [date]))[0].n;
    const again = await runDpd(date);
    expect(again.body.status).toBe('SUCCESS');
    expect(again.body.job.snapshotsInserted).toBe(0);
    const n2 = (await sql(`SELECT count(*)::int AS n FROM dpd_daily_snapshots WHERE business_date = $1`, [date]))[0].n;
    expect(n2).toBe(n1);
    await expect(sql(`UPDATE dpd_daily_snapshots SET dpd = 999 WHERE business_date = $1`, [date])).rejects.toThrow(/immutable/);
  });

  it('refuses earlier dates and future dates, and logs the failure', async () => {
    const back = await runDpd(addDays(today, -60));
    expect(back.body.status).toBe('FAILED');
    expect(back.body.job.errorMessage).toMatch(/before the last successful run/);
    const fut = await runDpd(addDays(today, 2));
    expect(fut.body.status).toBe('FAILED');
    const jobs = await request(app).get('/api/dpd/jobs').set(as('admin'));
    expect(jobs.body.data.some((j: any) => j.status === 'FAILED')).toBe(true);
    expect(jobs.body.meta.lastSuccessfulBusinessDate).toBe(addDays(today, -20));
  });

  it('runs up to today and the portfolio reconciles with loan-level data', async () => {
    expect((await runDpd(today)).body.status).toBe('SUCCESS');
    const buckets = await request(app).get('/api/dpd/buckets').set(as('analyst'));
    expect(buckets.status).toBe(200);
    const rows = await sql(`SELECT dpd, outstanding_principal::numeric AS pos, overdue_amount::numeric AS od FROM dpd_current WHERE account_status IN ('DISBURSED','ACTIVE','OVERDUE')`);
    expect(buckets.body.totals.accountCount).toBe(rows.length);
    expect(buckets.body.totals.outstandingPrincipal).toBeCloseTo(rows.reduce((s: number, r: any) => s + Number(r.pos), 0), 2);
    expect(buckets.body.totals.overdueAmount).toBeCloseTo(rows.reduce((s: number, r: any) => s + Number(r.od), 0), 2);
    const book = rows.map((r: any) => ({ dpd: r.dpd, pos: Number(r.pos) }));
    expect(buckets.body.par.par30Pct).toBe(parPct(book, 30));
    // the overdue report and DPD screen agree
    const rep = await request(app).get('/api/reports/overdue').set(as('analyst'));
    expect(rep.body.totals.overdueAmount).toBeCloseTo(rows.reduce((s: number, r: any) => s + Number(r.od), 0), 2);
  });

  it('waivers settle dues so the loan can be closed', async () => {
    const insts = await sql(`SELECT id, remaining_amount FROM emi_schedules WHERE loan_id = $1 AND remaining_amount > 0`, [loan2]);
    for (const i of insts) {
      const r = await request(app).post(`/api/loans/${loan2}/waive`).set(as('finance')).send({ target: 'EMI', targetId: i.id, reason: 'Settlement approved' });
      expect(r.status).toBe(200);
    }
    expect((await request(app).post(`/api/loans/${loan2}/close`).set(as('finance')).send({})).status).toBe(200);
    expect((await sql(`SELECT count(*)::int AS n FROM audit_logs WHERE action = 'WAIVER'`))[0].n).toBe(insts.length);
  });
});

describe('collections scope', () => {
  it('executives only see assigned loans; assignment and PTP flow', async () => {
    const bd = (await sql(`SELECT fn_business_date()::text AS d`))[0].d;
    const l = (await request(app).post('/api/loans').set(as('finance')).send({ customerId, productId: 1, principalAmount: 60000, annualInterestRate: 20, tenureMonths: 12 })).body.id;
    await request(app).post(`/api/loans/${l}/approve`).set(as('finance')).expect(200);
    await request(app).post(`/api/loans/${l}/disburse`).set(as('finance')).send({ disbursementDate: bd }).expect(200);
    expect((await request(app).get(`/api/loans/${l}`).set(as('exec'))).status).toBe(403);
    const execId = (await sql(`SELECT id FROM users WHERE email = 'exec@test.local'`))[0].id;
    const a = await request(app).post('/api/collections/assignments').set(as('manager')).send({ loanIds: [l], executiveId: execId });
    expect(a.body.assigned).toBe(1);
    expect((await request(app).get(`/api/loans/${l}`).set(as('exec'))).status).toBe(200);
    const list = await request(app).get('/api/loans').set(as('exec'));
    expect(list.body.data.map((x: any) => x.id)).toEqual([l]);
    const act = await request(app).post('/api/collections/activities').set(as('exec')).send({
      loanId: l, activityDate: bd, activityType: 'PHONE_CALL', contactResult: 'PROMISE_TO_PAY', ptpDate: addDays(bd, 3), ptpAmount: 2000,
    });
    expect(act.status).toBe(201);
    const ptp = await request(app).get('/api/collections/ptp').set(as('exec'));
    expect(ptp.body.data[0].status).toBe('PENDING');
    const notes = await request(app).get('/api/notifications').set(as('exec'));
    expect(notes.body.unread).toBeGreaterThan(0);
  });
});

describe('exports', () => {
  it('exports CSV/XLSX/PDF with audit, and requires the export permission', async () => {
    for (const f of ['csv', 'xlsx', 'pdf']) {
      const r = await request(app).get(`/api/reports/loan-register?format=${f}`).set(as('analyst'));
      expect(r.status).toBe(200);
      expect(r.headers['content-disposition']).toMatch(new RegExp(`\\.${f}"`));
    }
    expect((await request(app).get('/api/loans?format=csv').set(as('exec'))).status).toBe(403);
    const audits = await sql(`SELECT count(*)::int AS n FROM audit_logs WHERE action = 'EXPORT'`);
    expect(audits[0].n).toBeGreaterThanOrEqual(3);
  });
});
