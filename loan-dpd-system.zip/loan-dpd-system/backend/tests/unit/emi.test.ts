import { describe, expect, it } from 'vitest';
import { addMonths, buildSchedule, calculateEmi } from '../../src/lib/emi.js';

const sum = (xs: string[]) => xs.reduce((s, x) => s + Math.round(Number(x) * 100), 0) / 100;

describe('EMI calculation (reducing balance)', () => {
  it('matches the textbook formula for ₹1,00,000 @ 18% for 12 months', () => {
    // exact EMI = 9167.9978… → rounded to the nearest rupee
    expect(calculateEmi({ principal: 100000, annualRate: 18, tenureMonths: 12 })).toBe('9168.00');
    expect(calculateEmi({ principal: 100000, annualRate: 18, tenureMonths: 12, roundingPlaces: 2 })).toBe('9168.00');
  });

  it('computes a long-tenure LAP EMI', () => {
    // 25 lakh @ 14.5% for 120 months: exact EMI 39,571.697… → 39,572 (verified independently)
    expect(Number(calculateEmi({ principal: 2500000, annualRate: 14.5, tenureMonths: 120 }))).toBe(39572);
    // rounding the EMI up by ~₹0.30 compounds over 120 months; the last installment absorbs it exactly
    const s = buildSchedule({ principal: 2500000, annualRate: 14.5, tenureMonths: 120 });
    expect(s.rows.at(-1)!.emi).toBe('39491.14');
  });

  it('handles zero-interest loans', () => {
    expect(calculateEmi({ principal: 10000, annualRate: 0, tenureMonths: 3 })).toBe('3333.00');
    const s = buildSchedule({ principal: 10000, annualRate: 0, tenureMonths: 3 });
    expect(s.rows.map((r) => r.principal)).toEqual(['3333.00', '3333.00', '3334.00']);
    expect(s.totalInterest).toBe('0.00');
    expect(s.rows.every((r) => r.interest === '0.00')).toBe(true);
  });

  it('rejects invalid inputs', () => {
    expect(() => calculateEmi({ principal: 0, annualRate: 10, tenureMonths: 12 })).toThrow();
    expect(() => calculateEmi({ principal: 1000, annualRate: -1, tenureMonths: 12 })).toThrow();
    expect(() => calculateEmi({ principal: 1000, annualRate: 10, tenureMonths: 0 })).toThrow();
  });
});

describe('Repayment schedule', () => {
  it('reduces the balance to exactly zero and absorbs rounding in the last installment', () => {
    for (const [p, r, n] of [
      [100000, 18, 12],
      [57345.67, 21.25, 17],
      [2500000, 14.5, 120],
      [45000, 0, 9],
      [123456.78, 9.99, 36],
    ] as const) {
      const s = buildSchedule({ principal: p, annualRate: r, tenureMonths: n });
      expect(s.rows).toHaveLength(n);
      expect(sum(s.rows.map((x) => x.principal))).toBeCloseTo(p, 2);
      expect(s.rows.at(-1)!.closingPrincipal).toBe('0.00');
      // every row: emi = principal + interest, opening − principal = closing
      for (const row of s.rows) {
        expect(Number(row.emi)).toBeCloseTo(Number(row.principal) + Number(row.interest), 2);
        expect(Number(row.closingPrincipal)).toBeCloseTo(Number(row.openingPrincipal) - Number(row.principal), 2);
      }
      // all installments but the last equal the EMI
      for (const row of s.rows.slice(0, -1)) expect(row.emi).toBe(s.emi);
      // the rupee-rounding residue is at most ~₹1 per installment (it compounds with interest)
      expect(Math.abs(Number(s.rows.at(-1)!.emi) - Number(s.emi))).toBeLessThan(n);
    }
  });

  it('computes interest on the reducing balance', () => {
    const s = buildSchedule({ principal: 100000, annualRate: 18, tenureMonths: 12 });
    expect(s.rows[0].interest).toBe('1500.00'); // 1,00,000 × 1.5%
    expect(s.rows[0].principal).toBe('7668.00');
    expect(s.rows[1].interest).toBe('1384.98'); // 92,332 × 1.5%
    expect(s.totalInterest).toBe('10015.99');
    expect(s.totalPayable).toBe('110015.99');
  });

  it('supports flat interest', () => {
    const s = buildSchedule({ principal: 12000, annualRate: 12, tenureMonths: 12, method: 'FLAT' });
    expect(s.totalInterest).toBe('1440.00'); // 12,000 × 12% × 1 yr
    expect(s.emi).toBe('1120.00');
    expect(sum(s.rows.map((r) => r.interest))).toBe(1440);
  });

  it('lays out monthly due dates', () => {
    const s = buildSchedule({ principal: 1000, annualRate: 10, tenureMonths: 3, firstEmiDate: '2026-11-05' });
    expect(s.rows.map((r) => r.dueDate)).toEqual(['2026-11-05', '2026-12-05', '2027-01-05']);
    expect(addMonths('2026-01-28', 1)).toBe('2026-02-28');
  });
});
