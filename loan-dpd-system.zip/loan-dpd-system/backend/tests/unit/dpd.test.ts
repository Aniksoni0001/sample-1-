import { describe, expect, it } from 'vitest';
import { accountDpd, bucketFor, calcDpd, daysBetween, DEFAULT_BUCKETS, oldestUnpaidDue, parPct, validateBuckets } from '../../src/lib/dpd.js';

describe('DPD calculation', () => {
  it('is 0 when nothing is past due', () => {
    expect(calcDpd('2026-11-04', null)).toBe(0);
    expect(calcDpd('2026-11-04', '2026-11-04')).toBe(0); // due today is not past due
    expect(calcDpd('2026-11-04', '2026-12-05')).toBe(0);
  });

  it('counts days from the oldest unpaid due date', () => {
    expect(calcDpd('2026-11-04', '2026-11-03')).toBe(1);
    expect(calcDpd('2026-11-04', '2026-10-05')).toBe(30);
    expect(calcDpd('2026-03-01', '2026-01-31')).toBe(29); // month boundary
    expect(calcDpd('2024-03-01', '2024-02-28')).toBe(2); // leap year
    expect(daysBetween('2025-12-31', '2026-01-01')).toBe(1);
  });

  it('applies the grace period consistently', () => {
    expect(calcDpd('2026-11-08', '2026-11-05', 3)).toBe(0);
    expect(calcDpd('2026-11-09', '2026-11-05', 3)).toBe(4);
  });

  it('uses the oldest unpaid installment and ignores paid and future ones', () => {
    const inst = [
      { dueDate: '2026-08-05', remaining: 0 }, // paid
      { dueDate: '2026-09-05', remaining: 1200.5 }, // partially paid → still unpaid
      { dueDate: '2026-10-05', remaining: 5000 },
      { dueDate: '2026-12-05', remaining: 5000 }, // future
    ];
    expect(oldestUnpaidDue(inst, '2026-11-04')).toBe('2026-09-05');
    expect(accountDpd(inst, '2026-11-04')).toBe(60);
  });

  it('drops to the next unpaid installment once the oldest is fully paid', () => {
    const inst = [
      { dueDate: '2026-09-05', remaining: 0 },
      { dueDate: '2026-10-05', remaining: 5000 },
    ];
    expect(accountDpd(inst, '2026-11-04')).toBe(30);
    expect(accountDpd([{ dueDate: '2026-10-05', remaining: 0 }], '2026-11-04')).toBe(0);
  });
});

describe('DPD buckets', () => {
  it.each([
    [0, 'CURRENT'],
    [1, 'B1_30'],
    [30, 'B1_30'],
    [31, 'B31_60'],
    [60, 'B31_60'],
    [61, 'B61_89'],
    [89, 'B61_89'],
    [90, 'B90P'],
    [1000, 'B90P'],
  ])('DPD %i → %s', (dpd, code) => {
    expect(bucketFor(dpd).code).toBe(code);
  });

  it('validates bucket configurations', () => {
    expect(validateBuckets(DEFAULT_BUCKETS)).toBeNull();
    expect(validateBuckets([{ code: 'A', minDpd: 1, maxDpd: null, sortOrder: 1 }])).toMatch(/start at 0/);
    expect(validateBuckets([{ code: 'A', minDpd: 0, maxDpd: 10, sortOrder: 1 }, { code: 'B', minDpd: 12, maxDpd: null, sortOrder: 2 }])).toMatch(/Gap/);
    expect(validateBuckets([{ code: 'A', minDpd: 0, maxDpd: 10, sortOrder: 1 }, { code: 'B', minDpd: 11, maxDpd: 20, sortOrder: 2 }])).toMatch(/open-ended/);
  });
});

describe('Portfolio at Risk', () => {
  const book = [
    { dpd: 0, pos: 100000 },
    { dpd: 15, pos: 50000 },
    { dpd: 45, pos: 30000 },
    { dpd: 75, pos: 15000 },
    { dpd: 120, pos: 5000 },
  ];
  it('PAR-N is POS with DPD > N over total POS', () => {
    expect(parPct(book, 30)).toBe(25); // (30k+15k+5k)/200k
    expect(parPct(book, 60)).toBe(10);
    expect(parPct(book, 90)).toBe(2.5);
    expect(parPct([], 30)).toBe(0);
  });
});
