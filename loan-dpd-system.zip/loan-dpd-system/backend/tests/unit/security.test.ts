import { describe, expect, it } from 'vitest';
import { safeCell, toCsv } from '../../src/lib/export.js';
import { maskEmail, maskMobile, maskPan, maskRow } from '../../src/lib/mask.js';
import { orderBy, Sql } from '../../src/lib/sql.js';

describe('Export safety', () => {
  it('neutralises spreadsheet formula injection', () => {
    expect(safeCell('=HYPERLINK("http://x")')).toBe(`'=HYPERLINK("http://x")`);
    expect(safeCell('+cmd')).toBe(`'+cmd`);
    expect(safeCell('@SUM(A1)')).toBe(`'@SUM(A1)`);
    expect(safeCell('-1500.50')).toBe('-1500.50'); // plain negative numbers are left alone
    expect(safeCell('Ramesh')).toBe('Ramesh');
  });

  it('escapes CSV correctly', () => {
    const csv = toCsv([{ key: 'a', label: 'A' }, { key: 'b', label: 'B' }], [{ a: 'x, "y"', b: 'line1\nline2' }]);
    expect(csv).toContain('"x, ""y"""');
    expect(csv).toContain('"line1\nline2"');
  });
});

describe('PII masking', () => {
  it('masks identifiers', () => {
    expect(maskMobile('9876543210')).toBe('98XXXXXX10');
    expect(maskPan('ABCDE1234F')).toBe('XXXXX1234X');
    expect(maskEmail('ravi.kumar@example.com')).toBe('r***@example.com');
  });
  it('masks rows only for users without PII access', () => {
    const row = { name: 'A', mobile: '9876543210', pan: 'ABCDE1234F' };
    expect(maskRow(row, true)).toEqual(row);
    expect(maskRow(row, false)).toEqual({ name: 'A', mobile: '98XXXXXX10', pan: 'XXXXX1234X' });
  });
});

describe('SQL building', () => {
  it('binds values instead of concatenating them', () => {
    const s = new Sql();
    s.and(`name = ${s.p("x'; DROP TABLE loans; --")}`);
    expect(s.where).toBe('WHERE name = $1');
    expect(s.params).toEqual(["x'; DROP TABLE loans; --"]);
  });
  it('only sorts by whitelisted columns', () => {
    expect(orderBy({ sort: 'dpd', order: 'asc' }, { dpd: 'd.dpd' }, 'id')).toBe('ORDER BY d.dpd ASC NULLS LAST, 1');
    expect(orderBy({ sort: 'id; DROP TABLE x', order: 'asc' }, { dpd: 'd.dpd' }, 'id')).toBe('ORDER BY id');
  });
});
