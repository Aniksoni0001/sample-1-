import pg from 'pg';

/**
 * Recreates the test database from scratch (migrations only, no demo data)
 * before every run, so integration tests always start from a known state.
 * Unit tests don't need the database; if it's unreachable they still run.
 */
export default async function setup() {
  const url = new URL(process.env.TEST_DATABASE_URL ?? 'postgresql://postgres@localhost:5432/collections_test');
  const dbName = url.pathname.slice(1);
  if (!/^[a-z0-9_]*test[a-z0-9_]*$/.test(dbName)) throw new Error(`Refusing to reset "${dbName}": test database names must contain "test"`);
  const admin = new URL(url);
  admin.pathname = '/postgres';
  const c = new pg.Client({ connectionString: admin.toString() });
  try {
    await c.connect();
  } catch (e) {
    console.warn(`[tests] PostgreSQL not reachable (${(e as Error).message}); integration tests will fail.`);
    return;
  }
  await c.query(`DROP DATABASE IF EXISTS ${dbName} WITH (FORCE)`);
  await c.query(`CREATE DATABASE ${dbName}`);
  await c.end();

  process.env.DATABASE_URL = url.toString();
  process.env.JWT_SECRET ??= 'test-only-secret-0123456789abcdefghijklmnop';
  process.env.NODE_ENV = 'test';
  const { migrate } = await import('../src/db/migrate.js');
  const { pool } = await import('../src/db/pool.js');
  await migrate(() => undefined);
  await pool.end();
}
