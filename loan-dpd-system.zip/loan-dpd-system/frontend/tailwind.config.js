import animate from 'tailwindcss-animate';
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['"IBM Plex Sans"', 'system-ui', 'sans-serif'] },
      colors: {
        ink: { DEFAULT: '#16264A', 600: '#1F3463', 500: '#2B4580', 300: '#8A9BC2', 100: '#E4E9F3', 50: '#F1F4FA' },
        canvas: '#F2F4F7',
        line: '#E1E5EC',
        text: { DEFAULT: '#1C2433', muted: '#5B6577', faint: '#8A93A3' },
        paid: { DEFAULT: '#0F8B7E', soft: '#E3F4F1' },
        due: { DEFAULT: '#E2780F', soft: '#FDF0E1' },
        risk: { DEFAULT: '#C2352C', deep: '#8E1F18', soft: '#FBE7E5' },
      },
      borderRadius: { lg: '8px', md: '6px', sm: '4px' },
      keyframes: { 'ladder-in': { from: { transform: 'scaleX(0)' }, to: { transform: 'scaleX(1)' } } },
      animation: { 'ladder-in': 'ladder-in 700ms cubic-bezier(.2,.7,.2,1) both' },
    },
  },
  plugins: [animate],
};
