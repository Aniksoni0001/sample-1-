/**
 * API client. The access token lives only in memory; the refresh token is an
 * httpOnly cookie the browser sends to /api/auth/refresh. A 401 triggers one
 * shared refresh attempt and a single retry.
 */
export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
    public details?: { path: string; message: string }[],
  ) {
    super(message);
  }
}

let accessToken: string | null = null;
let refreshing: Promise<boolean> | null = null;
let onSessionLost: (() => void) | null = null;

export const setAccessToken = (t: string | null) => (accessToken = t);
export const setSessionLostHandler = (fn: () => void) => (onSessionLost = fn);

async function refresh(): Promise<boolean> {
  refreshing ??= fetch('/api/auth/refresh', { method: 'POST', credentials: 'include' })
    .then(async (r) => {
      if (!r.ok) return false;
      const j = await r.json();
      accessToken = j.accessToken;
      return true;
    })
    .catch(() => false)
    .finally(() => setTimeout(() => (refreshing = null), 0));
  return refreshing;
}

export type Query = Record<string, string | number | boolean | null | undefined>;

export function qs(params?: Query) {
  if (!params) return '';
  const u = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== '') u.set(k, String(v));
  const s = u.toString();
  return s ? `?${s}` : '';
}

async function raw(path: string, init: RequestInit = {}, retry = true): Promise<Response> {
  const headers = new Headers(init.headers);
  if (accessToken) headers.set('Authorization', `Bearer ${accessToken}`);
  if (init.body && !(init.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const res = await fetch(path, { ...init, headers, credentials: 'include' });
  if (res.status === 401 && retry && !path.startsWith('/api/auth/login') && !path.startsWith('/api/auth/refresh')) {
    if (await refresh()) return raw(path, init, false);
    onSessionLost?.();
  }
  return res;
}

async function parse<T>(res: Response): Promise<T> {
  if (res.ok) return (res.status === 204 ? undefined : await res.json()) as T;
  let body: any = null;
  try {
    body = await res.json();
  } catch {
    /* non-JSON error */
  }
  const e = body?.error;
  throw new ApiError(res.status, e?.message ?? `Request failed (${res.status})`, e?.code, e?.details);
}

export const api = {
  get: <T = any>(path: string, params?: Query) => raw(path + qs(params)).then(parse<T>),
  post: <T = any>(path: string, body?: unknown, headers?: Record<string, string>) =>
    raw(path, { method: 'POST', body: body instanceof FormData ? body : JSON.stringify(body ?? {}), headers }).then(parse<T>),
  put: <T = any>(path: string, body?: unknown) => raw(path, { method: 'PUT', body: JSON.stringify(body ?? {}) }).then(parse<T>),
  del: <T = any>(path: string) => raw(path, { method: 'DELETE' }).then(parse<T>),
  /** Downloads an export/receipt using the auth header, then saves it with the server's filename. */
  async download(path: string, params?: Query) {
    const res = await raw(path + qs(params));
    if (!res.ok) await parse(res);
    const blob = await res.blob();
    const cd = res.headers.get('Content-Disposition') ?? '';
    const name = /filename="([^"]+)"/.exec(cd)?.[1] ?? 'download';
    const url = URL.createObjectURL(blob);
    if (cd.startsWith('inline')) window.open(url, '_blank', 'noopener');
    else {
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      a.click();
    }
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
  },
  refresh,
};

export const newIdempotencyKey = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`);
