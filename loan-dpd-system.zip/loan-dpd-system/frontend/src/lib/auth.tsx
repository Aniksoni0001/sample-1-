import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { api, setAccessToken, setSessionLostHandler } from './api';

export interface Me {
  id: number;
  email: string;
  fullName: string;
  role: string;
  roleName: string;
  branchId: number | null;
  permissions: string[];
  businessDate: string;
  companyName: string;
}

interface AuthState {
  user: Me | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  can: (...perms: string[]) => boolean;
  reload: () => Promise<void>;
}

const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const qc = useQueryClient();

  const reload = useCallback(async () => {
    try {
      setUser(await api.get<Me>('/api/auth/me'));
    } catch {
      setUser(null);
    }
  }, []);

  // restore the session from the refresh cookie on page load
  useEffect(() => {
    setSessionLostHandler(() => {
      setAccessToken(null);
      setUser(null);
      qc.clear();
    });
    (async () => {
      if (await api.refresh()) await reload();
      setLoading(false);
    })();
  }, [qc, reload]);

  const login = useCallback(async (email: string, password: string) => {
    const r = await api.post<{ accessToken: string; user: Me }>('/api/auth/login', { email, password });
    setAccessToken(r.accessToken);
    setUser(r.user);
  }, []);

  const logout = useCallback(async () => {
    await api.post('/api/auth/logout').catch(() => undefined);
    setAccessToken(null);
    setUser(null);
    qc.clear();
  }, [qc]);

  const value = useMemo<AuthState>(
    () => ({
      user,
      loading,
      login,
      logout,
      reload,
      can: (...perms) => !!user && perms.some((p) => user.permissions.includes(p)),
    }),
    [user, loading, login, logout, reload],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useAuth outside AuthProvider');
  return c;
}
