import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format, parseISO } from 'date-fns';

export const cn = (...inputs: ClassValue[]) => twMerge(clsx(inputs));

const inrFmt = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2, maximumFractionDigits: 2 });
const inr0 = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });
const numFmt = new Intl.NumberFormat('en-IN');

export const inr = (v: unknown, whole = false) => (v === null || v === undefined || v === '' ? '—' : (whole ? inr0 : inrFmt).format(Number(v)));

/** ₹6.36 Cr / ₹7.07 L — the way Indian lenders read portfolio sizes */
export function inrShort(v: unknown) {
  if (v === null || v === undefined) return '—';
  const n = Number(v);
  const a = Math.abs(n);
  if (a >= 1e7) return `₹${(n / 1e7).toFixed(2)} Cr`;
  if (a >= 1e5) return `₹${(n / 1e5).toFixed(2)} L`;
  if (a >= 1e3) return `₹${(n / 1e3).toFixed(1)} K`;
  return inr0.format(n);
}

export const num = (v: unknown) => (v === null || v === undefined ? '—' : numFmt.format(Number(v)));
export const pct = (v: unknown, digits = 2) => (v === null || v === undefined ? '—' : `${Number(v).toFixed(digits)}%`);

export function date(v: unknown) {
  if (!v) return '—';
  const s = String(v);
  try {
    return format(parseISO(s.length === 10 ? s : s), 'd MMM yyyy');
  } catch {
    return s;
  }
}
export function dateTime(v: unknown) {
  if (!v) return '—';
  try {
    return format(new Date(String(v)), 'd MMM yyyy, HH:mm');
  } catch {
    return String(v);
  }
}

/** "PARTIALLY_PAID" → "Partially paid" */
export const label = (v: unknown) => {
  if (v === null || v === undefined || v === '') return '—';
  const s = String(v).replace(/_/g, ' ').toLowerCase();
  return s.charAt(0).toUpperCase() + s.slice(1);
};

export const addDays = (iso: string, n: number) => {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};
export const monthStart = (iso: string) => `${iso.slice(0, 7)}-01`;
export const prevMonth = (iso: string) => {
  const d = new Date(`${monthStart(iso)}T00:00:00Z`);
  d.setUTCMonth(d.getUTCMonth() - 1);
  const from = d.toISOString().slice(0, 10);
  return { from, to: addDays(monthStart(iso), -1) };
};
