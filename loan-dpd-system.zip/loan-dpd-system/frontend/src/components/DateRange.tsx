import { useAuth } from '@/lib/auth';
import { addDays, monthStart, prevMonth } from '@/lib/format';
import { Input, NativeSelect } from './ui/base';

export type Preset = 'today' | 'yesterday' | 'last7' | 'last30' | 'month' | 'prevMonth' | 'custom';

export const PRESETS: { value: Preset; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: 'yesterday', label: 'Yesterday' },
  { value: 'last7', label: 'Last 7 days' },
  { value: 'last30', label: 'Last 30 days' },
  { value: 'month', label: 'Current month' },
  { value: 'prevMonth', label: 'Previous month' },
  { value: 'custom', label: 'Custom range' },
];

/** Ranges are relative to the BUSINESS date, not the browser clock. */
export function presetRange(p: Preset, bd: string): { from: string; to: string } {
  switch (p) {
    case 'today':
      return { from: bd, to: bd };
    case 'yesterday':
      return { from: addDays(bd, -1), to: addDays(bd, -1) };
    case 'last7':
      return { from: addDays(bd, -6), to: bd };
    case 'last30':
      return { from: addDays(bd, -29), to: bd };
    case 'prevMonth':
      return prevMonth(bd);
    default:
      return { from: monthStart(bd), to: bd };
  }
}

/** Resolves preset/from/to URL params into an effective range. */
export function useRange(state: { preset?: string; from?: string; to?: string }, fallback: Preset = 'month') {
  const { user } = useAuth();
  const bd = user?.businessDate ?? new Date().toISOString().slice(0, 10);
  const preset = (state.preset as Preset) ?? (state.from || state.to ? 'custom' : fallback);
  if (preset === 'custom') {
    const d = presetRange(fallback, bd);
    return { preset, from: state.from ?? d.from, to: state.to ?? d.to, bd };
  }
  return { preset, ...presetRange(preset, bd), bd };
}

export function DateRangeFilter({ state, set, fallback = 'month' }: { state: Record<string, string | undefined>; set: (p: Record<string, string | undefined>) => void; fallback?: Preset }) {
  const r = useRange(state, fallback);
  return (
    <div className="flex flex-wrap items-center gap-2">
      <NativeSelect
        value={r.preset}
        aria-label="Date range"
        className="h-9 w-[172px]"
        onChange={(e) => {
          const p = e.target.value as Preset;
          if (p === 'custom') set({ preset: 'custom', from: r.from, to: r.to });
          else set({ preset: p, from: undefined, to: undefined });
        }}
      >
        {PRESETS.map((p) => (
          <option key={p.value} value={p.value}>
            {p.label}
          </option>
        ))}
      </NativeSelect>
      {r.preset === 'custom' && (
        <>
          <Input type="date" className="h-9 w-[150px]" value={r.from} max={r.to} onChange={(e) => set({ preset: 'custom', from: e.target.value })} aria-label="From date" />
          <span className="text-text-faint">to</span>
          <Input type="date" className="h-9 w-[150px]" value={r.to} min={r.from} max={r.bd} onChange={(e) => set({ preset: 'custom', to: e.target.value })} aria-label="To date" />
        </>
      )}
    </div>
  );
}
