import * as React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, Inbox } from 'lucide-react';
import { cn, inr, inrShort, label, num, pct } from '@/lib/format';
import { Button } from './ui/base';

// ------------------------------------------------------------------ status badges
type Tone = 'paid' | 'due' | 'risk' | 'riskDeep' | 'ink' | 'muted';
const toneClass: Record<Tone, string> = {
  paid: 'bg-paid-soft text-paid',
  due: 'bg-due-soft text-[#A85508]',
  risk: 'bg-risk-soft text-risk',
  riskDeep: 'bg-risk-deep text-white',
  ink: 'bg-ink-50 text-ink-500',
  muted: 'bg-canvas text-text-muted',
};

const STATUS_TONE: Record<string, Tone> = {
  // loans
  DRAFT: 'muted', APPROVED: 'ink', DISBURSED: 'ink', ACTIVE: 'paid', OVERDUE: 'risk', CLOSED: 'muted', WRITTEN_OFF: 'riskDeep', CANCELLED: 'muted',
  // EMI
  UPCOMING: 'muted', DUE: 'due', PARTIALLY_PAID: 'due', PAID: 'paid', BOUNCED: 'risk', WAIVED: 'ink',
  // payments
  INITIATED: 'due', PENDING: 'due', SUCCESSFUL: 'paid', FAILED: 'risk', REVERSED: 'risk',
  // bounces / PTP / jobs / charges
  PARTIAL: 'due', RECOVERED: 'paid', KEPT: 'paid', PARTIALLY_KEPT: 'due', BROKEN: 'risk', RUNNING: 'due', SUCCESS: 'paid', SKIPPED: 'muted',
  OPEN: 'due', INACTIVE: 'muted', BLOCKED: 'risk',
};

export function StatusBadge({ status, className }: { status?: string | null; className?: string }) {
  if (!status) return <span className="text-text-faint">—</span>;
  const tone = STATUS_TONE[status] ?? 'muted';
  return <span className={cn('inline-flex items-center rounded px-1.5 py-0.5 text-xs font-medium', toneClass[tone], className)}>{label(status)}</span>;
}

/** Bucket colours run from teal (current) through orange to deep red (90+). */
export const BUCKET_STYLE: Record<string, { bg: string; text: string; bar: string }> = {
  CURRENT: { bg: 'bg-paid-soft', text: 'text-paid', bar: '#0F8B7E' },
  B1_30: { bg: 'bg-due-soft', text: 'text-[#A85508]', bar: '#E2A13A' },
  B31_60: { bg: 'bg-due-soft', text: 'text-[#A85508]', bar: '#E2780F' },
  B61_89: { bg: 'bg-risk-soft', text: 'text-risk', bar: '#C2352C' },
  B90P: { bg: 'bg-risk-deep', text: 'text-white', bar: '#8E1F18' },
};
export const bucketColor = (code: string, fallback?: string) => BUCKET_STYLE[code]?.bar ?? fallback ?? '#64748b';

export function DpdBadge({ dpd, bucket }: { dpd: number | null | undefined; bucket?: string | null }) {
  const d = dpd ?? 0;
  const code = bucket ?? (d === 0 ? 'CURRENT' : d <= 30 ? 'B1_30' : d <= 60 ? 'B31_60' : d < 90 ? 'B61_89' : 'B90P');
  const s = BUCKET_STYLE[code] ?? BUCKET_STYLE.CURRENT;
  return <span className={cn('inline-flex min-w-[2.75rem] justify-center rounded px-1.5 py-0.5 text-xs font-semibold tabular-nums', s.bg, s.text)}>{d === 0 ? 'Current' : `${d} DPD`}</span>;
}

// ------------------------------------------------------------------ DPD ladder (signature element)
export interface LadderBucket {
  bucketCode: string;
  label: string;
  accountCount: number;
  outstandingPrincipal: number;
  overdueAmount: number;
  color?: string;
}

/** The book in one bar: each bucket's width is its share of outstanding principal. */
export function DpdLadder({ buckets, onSelect, compact }: { buckets: LadderBucket[]; onSelect?: (code: string) => void; compact?: boolean }) {
  const total = buckets.reduce((s, b) => s + b.outstandingPrincipal, 0) || 1;
  const totalAccounts = buckets.reduce((s, b) => s + b.accountCount, 0);
  return (
    <div>
      <div className={cn('flex w-full overflow-hidden rounded-md bg-canvas', compact ? 'h-3' : 'h-11')} role="img" aria-label="Outstanding principal by DPD bucket">
        {buckets.map((b, i) => {
          const w = (b.outstandingPrincipal / total) * 100;
          if (w <= 0) return null;
          return (
            <button
              key={b.bucketCode}
              type="button"
              disabled={!onSelect}
              onClick={() => onSelect?.(b.bucketCode)}
              title={`${b.label}: ${inr(b.outstandingPrincipal, true)} (${w.toFixed(1)}%)`}
              className="h-full origin-left animate-ladder-in border-r-2 border-white last:border-r-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-white enabled:hover:brightness-110 motion-reduce:animate-none"
              style={{ width: `${Math.max(w, 0.8)}%`, background: bucketColor(b.bucketCode, b.color), animationDelay: `${i * 60}ms` }}
            />
          );
        })}
      </div>
      {!compact && (
        <div className="mt-3 grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-3 lg:grid-cols-5">
          {buckets.map((b) => (
            <button
              key={b.bucketCode}
              type="button"
              disabled={!onSelect}
              onClick={() => onSelect?.(b.bucketCode)}
              className="group text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink-500 rounded"
            >
              <div className="flex items-center gap-2 text-[13px] text-text-muted">
                <span className="h-2.5 w-2.5 rounded-sm" style={{ background: bucketColor(b.bucketCode, b.color) }} />
                <span className="group-enabled:group-hover:text-ink">{b.label}</span>
              </div>
              <div className="mt-0.5 text-lg font-semibold tabular-nums text-text">{inrShort(b.outstandingPrincipal)}</div>
              <div className="text-xs tabular-nums text-text-faint">
                {num(b.accountCount)} accounts ({pct((b.accountCount * 100) / (totalAccounts || 1), 1)})
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ layout bits
export function PageHeader({ title, description, actions, back }: { title: React.ReactNode; description?: React.ReactNode; actions?: React.ReactNode; back?: { to: string; label: string } }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        {back && (
          <Link to={back.to} className="mb-1 inline-block text-[13px] text-text-muted hover:text-ink">
            ‹ {back.label}
          </Link>
        )}
        <h1 className="text-[22px] font-semibold leading-tight tracking-tight text-text">{title}</h1>
        {description && <p className="mt-1 max-w-3xl text-sm text-text-muted">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function Stat({ label: l, value, sub, tone, to }: { label: string; value: React.ReactNode; sub?: React.ReactNode; tone?: 'paid' | 'due' | 'risk'; to?: string }) {
  const body = (
    <>
      <div className="text-[13px] text-text-muted">{l}</div>
      <div className={cn('mt-1 text-[22px] font-semibold leading-tight tabular-nums', tone === 'risk' ? 'text-risk' : tone === 'due' ? 'text-[#A85508]' : tone === 'paid' ? 'text-paid' : 'text-text')}>{value}</div>
      {sub && <div className="mt-0.5 text-xs text-text-faint tabular-nums">{sub}</div>}
    </>
  );
  const cls = 'block bg-white px-4 py-3.5';
  return to ? (
    <Link to={to} className={cn(cls, 'hover:bg-ink-50/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ink-500')}>
      {body}
    </Link>
  ) : (
    <div className={cls}>{body}</div>
  );
}

/** Stats share hairline dividers instead of separate floating cards. */
export function StatGrid({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={cn('grid gap-px overflow-hidden rounded-lg border border-line bg-line', className)}>{children}</div>;
}

export function EmptyState({ title, body, action }: { title: string; body?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      <Inbox className="h-8 w-8 text-text-faint" strokeWidth={1.5} />
      <p className="mt-3 text-sm font-medium text-text">{title}</p>
      {body && <p className="mt-1 max-w-sm text-[13px] text-text-muted">{body}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorState({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  return (
    <div className="flex items-start gap-3 rounded-lg border border-risk/30 bg-risk-soft px-4 py-3 text-sm text-risk">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
      <div className="flex-1">{(error as Error)?.message ?? 'Something went wrong loading this data.'}</div>
      {onRetry && (
        <Button size="sm" variant="secondary" onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  );
}

export const Money = ({ v, className, whole }: { v: unknown; className?: string; whole?: boolean }) => <span className={cn('tabular-nums', className)}>{inr(v, whole)}</span>;

export function KeyValues({ items, cols = 3 }: { items: [string, React.ReactNode][]; cols?: 2 | 3 | 4 }) {
  return (
    <dl className={cn('grid gap-x-6 gap-y-3 text-sm', cols === 2 ? 'sm:grid-cols-2' : cols === 4 ? 'sm:grid-cols-2 lg:grid-cols-4' : 'sm:grid-cols-2 lg:grid-cols-3')}>
      {items.map(([k, v]) => (
        <div key={k} className="min-w-0">
          <dt className="text-[13px] text-text-muted">{k}</dt>
          <dd className="mt-0.5 truncate font-medium text-text">{v ?? '—'}</dd>
        </div>
      ))}
    </dl>
  );
}
