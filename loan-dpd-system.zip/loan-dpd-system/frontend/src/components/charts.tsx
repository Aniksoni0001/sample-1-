import * as React from 'react';
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { inr, inrShort, num } from '@/lib/format';
import { Card, CardHeader, Skeleton } from './ui/base';

const AXIS = { fontSize: 12, fill: '#5B6577', fontFamily: 'IBM Plex Sans' };
const GRID = <CartesianGrid stroke="#E1E5EC" strokeDasharray="0" vertical={false} />;
export const SERIES = { navy: '#16264A', teal: '#0F8B7E', orange: '#E2780F', red: '#C2352C', slate: '#8A9BC2' };

function Tip({ active, payload, label, money }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-md border border-line bg-white px-3 py-2 text-xs shadow-md">
      <div className="mb-1 font-medium text-text">{label}</div>
      {payload.map((p: any) => (
        <div key={p.dataKey} className="flex items-center gap-2 tabular-nums text-text-muted">
          <span className="h-2 w-2 rounded-sm" style={{ background: p.color ?? p.payload?.fill }} />
          {p.name}: <span className="font-medium text-text">{money === 'pct' ? `${Number(p.value).toFixed(2)}%` : money ? inr(p.value, true) : num(p.value)}</span>
        </div>
      ))}
    </div>
  );
}

export function ChartCard({ title, description, loading, children, className, height = 240 }: { title: string; description?: string; loading?: boolean; children: React.ReactNode; className?: string; height?: number }) {
  return (
    <Card className={className}>
      <CardHeader title={title} description={description} />
      <div className="px-3 pb-3 pt-4" style={{ height }}>
        {loading ? <Skeleton className="h-full w-full" /> : children}
      </div>
    </Card>
  );
}

export function SimpleBars({ data, x, y, money, colors, name, horizontal }: { data: any[]; x: string; y: string; money?: boolean; colors?: string[] | ((d: any) => string); name: string; horizontal?: boolean }) {
  const color = (d: any, i: number) => (typeof colors === 'function' ? colors(d) : colors?.[i % colors.length] ?? SERIES.navy);
  if (horizontal)
    return (
      <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} layout="vertical" margin={{ left: 8, right: 16 }}>
        <CartesianGrid stroke="#E1E5EC" horizontal={false} />
        <XAxis type="number" tick={AXIS} tickFormatter={(v) => (money ? inrShort(v) : num(v))} axisLine={false} tickLine={false} />
        <YAxis type="category" dataKey={x} tick={AXIS} width={130} axisLine={false} tickLine={false} />
        <Tooltip content={<Tip money={money} />} cursor={{ fill: '#F1F4FA' }} />
        <Bar dataKey={y} name={name} radius={[0, 3, 3, 0]} maxBarSize={22}>
          {data.map((d, i) => (
            <Cell key={i} fill={color(d, i)} />
          ))}
        </Bar>
      </BarChart>
      </ResponsiveContainer>
    );
  return (
    <ResponsiveContainer width="100%" height="100%">
    <BarChart data={data} margin={{ left: 0, right: 8 }}>
      {GRID}
      <XAxis dataKey={x} tick={AXIS} axisLine={false} tickLine={false} />
      <YAxis tick={AXIS} tickFormatter={(v) => (money ? inrShort(v) : num(v))} axisLine={false} tickLine={false} width={64} />
      <Tooltip content={<Tip money={money} />} cursor={{ fill: '#F1F4FA' }} />
      <Bar dataKey={y} name={name} radius={[3, 3, 0, 0]} maxBarSize={44}>
        {data.map((d, i) => (
          <Cell key={i} fill={color(d, i)} />
        ))}
      </Bar>
    </BarChart>
    </ResponsiveContainer>
  );
}

export function GroupedBars({ data, x, series, money }: { data: any[]; x: string; series: { key: string; name: string; color: string }[]; money?: boolean }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
    <BarChart data={data} margin={{ left: 0, right: 8 }}>
      {GRID}
      <XAxis dataKey={x} tick={AXIS} axisLine={false} tickLine={false} />
      <YAxis tick={AXIS} tickFormatter={(v) => (money ? inrShort(v) : num(v))} axisLine={false} tickLine={false} width={64} />
      <Tooltip content={<Tip money={money} />} cursor={{ fill: '#F1F4FA' }} />
      <Legend iconType="square" iconSize={9} wrapperStyle={{ fontSize: 12, fontFamily: 'IBM Plex Sans' }} />
      {series.map((s) => (
        <Bar key={s.key} dataKey={s.key} name={s.name} fill={s.color} radius={[3, 3, 0, 0]} maxBarSize={28} />
      ))}
    </BarChart>
    </ResponsiveContainer>
  );
}

export function Lines({ data, x, series, money, pctAxis }: { data: any[]; x: string; series: { key: string; name: string; color: string }[]; money?: boolean; pctAxis?: boolean }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
    <LineChart data={data} margin={{ left: 0, right: 12 }}>
      {GRID}
      <XAxis dataKey={x} tick={AXIS} axisLine={false} tickLine={false} minTickGap={24} />
      <YAxis tick={AXIS} tickFormatter={(v) => (pctAxis ? `${v}%` : money ? inrShort(v) : num(v))} axisLine={false} tickLine={false} width={64} />
      <Tooltip content={<Tip money={pctAxis ? 'pct' : money} />} />
      {series.length > 1 && <Legend iconType="plainline" wrapperStyle={{ fontSize: 12, fontFamily: 'IBM Plex Sans' }} />}
      {series.map((s) => (
        <Line key={s.key} type="monotone" dataKey={s.key} name={s.name} stroke={s.color} strokeWidth={2} dot={data.length < 16 ? { r: 2.5 } : false} activeDot={{ r: 4 }} />
      ))}
    </LineChart>
    </ResponsiveContainer>
  );
}
