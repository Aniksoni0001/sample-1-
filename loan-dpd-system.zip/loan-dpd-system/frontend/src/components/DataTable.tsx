import * as React from 'react';
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Download, FileSpreadsheet, FileText, Search, X } from 'lucide-react';
import { toast } from 'sonner';
import { api, type Query } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { cn, inr, num } from '@/lib/format';
import { useList, useUrlState } from '@/hooks/data';
import { Button, Checkbox, Input, NativeSelect, Skeleton } from './ui/base';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/overlay';
import { EmptyState, ErrorState } from './domain';

export interface Column<T> {
  key: string;
  header: string;
  sortable?: boolean;
  align?: 'right' | 'center';
  cell?: (row: T) => React.ReactNode;
  className?: string;
  /** money / number totals shown in the footer when the API returns them */
  total?: 'money' | 'number';
}

export function ExportMenu({ endpoint, params, disabled }: { endpoint: string; params: Query; disabled?: boolean }) {
  const { can } = useAuth();
  const [busy, setBusy] = React.useState(false);
  if (!can('reports.export')) return null;
  const go = async (format: string) => {
    setBusy(true);
    try {
      await api.download(endpoint, { ...params, format, page: undefined, pageSize: undefined });
      toast.success('Export downloaded');
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="secondary" size="sm" loading={busy} disabled={disabled}>
          <Download /> Export
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuItem onSelect={() => go('csv')}>
          <FileText /> CSV
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => go('xlsx')}>
          <FileSpreadsheet /> Excel
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => go('pdf')}>
          <FileText /> PDF
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function SearchBox({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  const [v, setV] = React.useState(value);
  React.useEffect(() => setV(value), [value]);
  React.useEffect(() => {
    if (v === value) return;
    const t = setTimeout(() => onChange(v), 350);
    return () => clearTimeout(t);
  }, [v, value, onChange]);
  return (
    <div className="relative w-full sm:w-72">
      <Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-text-faint" />
      <Input value={v} onChange={(e) => setV(e.target.value)} placeholder={placeholder} className="pl-8 pr-8" aria-label="Search" />
      {v && (
        <button type="button" className="absolute right-2 top-2.5 text-text-faint hover:text-text" onClick={() => setV('')} aria-label="Clear search">
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}

/**
 * Server-driven table: pagination, sorting, search and export all hit the API;
 * state is mirrored in the URL. Page-specific filters are passed as `filters`
 * and rendered by the caller in `toolbar`.
 */
export function DataTable<T extends Record<string, any>>({
  endpoint,
  columns,
  filters = {},
  toolbar,
  rowKey = 'id',
  onRowClick,
  searchPlaceholder = 'Search…',
  defaultSort,
  exportable = true,
  selectable,
  selected,
  onSelectedChange,
  emptyTitle = 'Nothing matches these filters',
  emptyBody = 'Try widening the date range or clearing a filter.',
  showTotals,
  urlPrefix = '',
  initialPageSize = 25,
}: {
  endpoint: string;
  columns: Column<T>[];
  filters?: Query;
  toolbar?: React.ReactNode;
  rowKey?: string;
  onRowClick?: (row: T) => void;
  searchPlaceholder?: string;
  defaultSort?: { sort: string; order: 'asc' | 'desc' };
  exportable?: boolean;
  selectable?: boolean;
  selected?: Set<number>;
  onSelectedChange?: (s: Set<number>) => void;
  emptyTitle?: string;
  emptyBody?: string;
  showTotals?: boolean;
  /** lets two tables on one page keep separate URL state */
  urlPrefix?: string;
  initialPageSize?: number;
}) {
  const [url, setUrl] = useUrlState();
  const k = (s: string) => urlPrefix + s;
  const page = Number(url[k('page')] ?? 1);
  const pageSize = Number(url[k('pageSize')] ?? initialPageSize);
  const sort = url[k('sort')] ?? defaultSort?.sort;
  const order = (url[k('order')] as 'asc' | 'desc') ?? defaultSort?.order ?? 'desc';
  const search = url[k('search')] ?? '';
  const params: Query = { ...filters, page, pageSize, sort, order, search: search || undefined };
  const q = useList<T>(endpoint, params);

  const rows = q.data?.data ?? [];
  const allSelected = selectable && rows.length > 0 && rows.every((r) => selected?.has(r[rowKey]));
  const toggleAll = () => {
    const next = new Set(selected);
    if (allSelected) rows.forEach((r) => next.delete(r[rowKey]));
    else rows.forEach((r) => next.add(r[rowKey]));
    onSelectedChange?.(next);
  };
  const toggle = (id: number) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    onSelectedChange?.(next);
  };
  const setSort = (key: string) => {
    if (sort === key) setUrl({ [k('order')]: order === 'asc' ? 'desc' : 'asc' }, { resetPage: false });
    else setUrl({ [k('sort')]: key, [k('order')]: 'desc' }, { resetPage: false });
  };
  const totals = q.data?.totals;

  return (
    <div className="min-w-0 rounded-lg border border-line bg-white">
      <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2.5">
        <SearchBox value={search} onChange={(v) => setUrl({ [k('search')]: v, [k('page')]: undefined })} placeholder={searchPlaceholder} />
        {toolbar}
        <div className="ml-auto flex items-center gap-2">
          {q.isFetching && !q.isLoading && <span className="text-xs text-text-faint">Updating…</span>}
          {exportable && <ExportMenu endpoint={endpoint} params={{ ...filters, sort, order, search: search || undefined }} disabled={!q.data?.total} />}
        </div>
      </div>

      {q.isError ? (
        <div className="p-4">
          <ErrorState error={q.error} onRetry={() => q.refetch()} />
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line bg-canvas/60 text-left text-[13px] text-text-muted">
                {selectable && (
                  <th className="w-10 px-3 py-2">
                    <Checkbox checked={!!allSelected} onCheckedChange={toggleAll} aria-label="Select all on this page" />
                  </th>
                )}
                {columns.map((c) => (
                  <th key={c.key} className={cn('whitespace-nowrap px-3 py-2 font-medium', c.align === 'right' && 'text-right', c.align === 'center' && 'text-center')}>
                    {c.sortable ? (
                      <button type="button" onClick={() => setSort(c.key)} className="inline-flex items-center gap-1 hover:text-text focus-visible:outline-none focus-visible:underline">
                        {c.header}
                        {sort === c.key && (order === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
                      </button>
                    ) : (
                      c.header
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {q.isLoading
                ? Array.from({ length: 8 }).map((_, i) => (
                    <tr key={i} className="border-b border-line/70">
                      {selectable && <td className="px-3 py-2.5" />}
                      {columns.map((c) => (
                        <td key={c.key} className="px-3 py-2.5">
                          <Skeleton className="h-4 w-full max-w-[140px]" />
                        </td>
                      ))}
                    </tr>
                  ))
                : rows.map((r, i) => (
                    <tr
                      key={r[rowKey] ?? i}
                      onClick={onRowClick ? () => onRowClick(r) : undefined}
                      className={cn('border-b border-line/70 last:border-0', onRowClick && 'cursor-pointer hover:bg-ink-50/50', selected?.has(r[rowKey]) && 'bg-ink-50')}
                    >
                      {selectable && (
                        <td className="px-3 py-2" onClick={(e) => e.stopPropagation()}>
                          <Checkbox checked={!!selected?.has(r[rowKey])} onCheckedChange={() => toggle(r[rowKey])} aria-label="Select row" />
                        </td>
                      )}
                      {columns.map((c) => (
                        <td key={c.key} className={cn('whitespace-nowrap px-3 py-2', c.align === 'right' && 'text-right tabular-nums', c.align === 'center' && 'text-center', c.className)}>
                          {c.cell ? c.cell(r) : (r[c.key] ?? '—')}
                        </td>
                      ))}
                    </tr>
                  ))}
            </tbody>
            {showTotals && totals && rows.length > 0 && (
              <tfoot>
                <tr className="border-t-2 border-line bg-canvas/60 font-semibold">
                  {selectable && <td />}
                  {columns.map((c, i) => (
                    <td key={c.key} className={cn('whitespace-nowrap px-3 py-2', c.align === 'right' && 'text-right tabular-nums')}>
                      {i === 0 ? 'Total (all pages)' : totals[c.key] !== undefined ? (c.total === 'number' ? num(totals[c.key]) : inr(totals[c.key])) : ''}
                    </td>
                  ))}
                </tr>
              </tfoot>
            )}
          </table>
          {!q.isLoading && rows.length === 0 && <EmptyState title={emptyTitle} body={emptyBody} />}
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-line px-3 py-2 text-[13px] text-text-muted">
        <div className="tabular-nums">
          {q.data ? (
            <>
              {q.data.total === 0 ? 0 : (page - 1) * pageSize + 1}–{Math.min(page * pageSize, q.data.total)} of {num(q.data.total)}
              {selectable && selected && selected.size > 0 && <span className="ml-2 text-ink">({selected.size} selected)</span>}
            </>
          ) : (
            ' '
          )}
        </div>
        <div className="flex items-center gap-2">
          <NativeSelect value={pageSize} onChange={(e) => setUrl({ [k('pageSize')]: e.target.value })} className="h-8 w-[88px]" aria-label="Rows per page">
            {[10, 25, 50, 100].map((n) => (
              <option key={n} value={n}>
                {n} / page
              </option>
            ))}
          </NativeSelect>
          <Button variant="secondary" size="icon" className="h-8 w-8" disabled={page <= 1} onClick={() => setUrl({ [k('page')]: page - 1 }, { resetPage: false })} aria-label="Previous page">
            <ChevronLeft />
          </Button>
          <span className="tabular-nums">
            {page} / {q.data?.totalPages ?? 1}
          </span>
          <Button
            variant="secondary"
            size="icon"
            className="h-8 w-8"
            disabled={!q.data || page >= q.data.totalPages}
            onClick={() => setUrl({ [k('page')]: page + 1 }, { resetPage: false })}
            aria-label="Next page"
          >
            <ChevronRight />
          </Button>
        </div>
      </div>
    </div>
  );
}

/** Compact filter select bound to URL state. */
export function FilterSelect({ value, onChange, options, placeholder, className, ariaLabel }: { value?: string; onChange: (v: string | undefined) => void; options: { value: string | number; label: string }[]; placeholder: string; className?: string; ariaLabel?: string }) {
  return (
    <NativeSelect value={value ?? ''} onChange={(e) => onChange(e.target.value || undefined)} className={cn('h-9 w-auto min-w-[140px]', className)} aria-label={ariaLabel ?? placeholder}>
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </NativeSelect>
  );
}
