import * as React from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  AlarmClock, BadgeIndianRupee, Bell, CalendarClock, CalendarDays, ClipboardList, FileBarChart, Gauge, Handshake, History,
  KeyRound, Landmark, LayoutDashboard, ListChecks, LogOut, Menu, PanelLeftClose, PanelLeftOpen, ScrollText, Settings, ShieldCheck,
  UserCog, Users, UsersRound, X, CircleSlash2, PhoneCall,
} from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { cn, date, dateTime } from '@/lib/format';
import { Button } from './ui/base';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/overlay';

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  perm?: string[];
  end?: boolean;
}
const NAV: { group: string; items: NavItem[] }[] = [
  {
    group: 'Overview',
    items: [
      { to: '/', label: 'Dashboard', icon: LayoutDashboard, perm: ['dashboard.read'], end: true },
      { to: '/dpd', label: 'DPD portfolio', icon: Gauge, perm: ['dpd.read'], end: true },
    ],
  },
  {
    group: 'Lending',
    items: [
      { to: '/customers', label: 'Customers', icon: Users, perm: ['customers.read'] },
      { to: '/loans', label: 'Loan register', icon: Landmark, perm: ['loans.read'] },
      { to: '/emi', label: 'EMI schedule', icon: CalendarDays, perm: ['loans.read'] },
    ],
  },
  {
    group: 'Money',
    items: [
      { to: '/payments', label: 'Payments', icon: BadgeIndianRupee, perm: ['payments.read'] },
      { to: '/bounces', label: 'Bounces', icon: CircleSlash2, perm: ['bounces.read'] },
    ],
  },
  {
    group: 'Collections',
    items: [
      { to: '/collections', label: 'Collection desk', icon: PhoneCall, perm: ['collections.read'], end: true },
      { to: '/collections/assignments', label: 'Account assignment', icon: UsersRound, perm: ['collections.read'] },
      { to: '/collections/activities', label: 'Activities', icon: ClipboardList, perm: ['collections.read'] },
      { to: '/collections/ptp', label: 'Promises to pay', icon: Handshake, perm: ['collections.read'] },
    ],
  },
  {
    group: 'Analysis',
    items: [
      { to: '/dpd/accounts', label: 'DPD accounts', icon: ListChecks, perm: ['dpd.read'] },
      { to: '/dpd/snapshots', label: 'Daily snapshots', icon: History, perm: ['dpd.read'] },
      { to: '/reports', label: 'Reports', icon: FileBarChart, perm: ['reports.read'] },
    ],
  },
  {
    group: 'Administration',
    items: [
      { to: '/admin/users', label: 'Users', icon: UserCog, perm: ['users.read'] },
      { to: '/admin/roles', label: 'Roles & permissions', icon: ShieldCheck, perm: ['users.read', 'roles.manage'] },
      { to: '/admin/config', label: 'Configuration', icon: Settings, perm: ['config.manage'] },
      { to: '/admin/jobs', label: 'Scheduled jobs', icon: CalendarClock, perm: ['jobs.read'] },
      { to: '/admin/audit', label: 'Audit log', icon: ScrollText, perm: ['audit.read'] },
    ],
  },
];

function Notifications() {
  const qc = useQueryClient();
  const nav = useNavigate();
  const q = useQuery({ queryKey: ['/api/notifications'], queryFn: () => api.get('/api/notifications'), refetchInterval: 60_000 });
  const unread = q.data?.unread ?? 0;
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" aria-label={`Notifications${unread ? ` (${unread} unread)` : ''}`} className="relative">
          <Bell />
          {unread > 0 && <span className="absolute right-1.5 top-1.5 min-w-[16px] rounded-full bg-risk px-1 text-[10px] font-semibold leading-4 text-white">{unread > 9 ? '9+' : unread}</span>}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80 p-0">
        <div className="flex items-center justify-between border-b border-line px-3 py-2">
          <span className="text-sm font-semibold">Notifications</span>
          {unread > 0 && (
            <button
              className="text-xs text-ink-500 hover:underline"
              onClick={async () => {
                await api.post('/api/notifications/read-all');
                qc.invalidateQueries({ queryKey: ['/api/notifications'] });
              }}
            >
              Mark all read
            </button>
          )}
        </div>
        <div className="max-h-96 overflow-y-auto">
          {(q.data?.items ?? []).length === 0 && <p className="px-3 py-6 text-center text-[13px] text-text-muted">You're all caught up.</p>}
          {(q.data?.items ?? []).map((n: any) => (
            <DropdownMenuItem
              key={n.id}
              className={cn('flex-col items-start gap-0.5 rounded-none border-b border-line/60 px-3 py-2', !n.isRead && 'bg-ink-50/60')}
              onSelect={async () => {
                await api.post(`/api/notifications/${n.id}/read`);
                qc.invalidateQueries({ queryKey: ['/api/notifications'] });
                if (n.link) nav(n.link);
              }}
            >
              <span className="text-[13px] font-medium text-text">{n.title}</span>
              <span className="text-xs text-text-muted">{n.message}</span>
              <span className="text-[11px] text-text-faint">{dateTime(n.createdAt)}</span>
            </DropdownMenuItem>
          ))}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function SideNav({ collapsed, onNavigate }: { collapsed: boolean; onNavigate?: () => void }) {
  const { can } = useAuth();
  return (
    <nav className="flex-1 overflow-y-auto px-2 pb-4" aria-label="Main">
      {NAV.map((g) => {
        const items = g.items.filter((i) => !i.perm || can(...i.perm));
        if (!items.length) return null;
        return (
          <div key={g.group} className="mt-4">
            {!collapsed && <div className="px-2.5 pb-1 text-[11.5px] font-medium text-ink-300">{g.group}</div>}
            {items.map((i) => (
              <NavLink
                key={i.to}
                to={i.to}
                end={i.end}
                onClick={onNavigate}
                title={collapsed ? i.label : undefined}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-2.5 rounded-md px-2.5 py-[7px] text-[13.5px] text-white/75 hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60',
                    isActive && 'bg-white/[.13] font-medium text-white',
                    collapsed && 'justify-center px-0',
                  )
                }
              >
                <i.icon className="h-[17px] w-[17px] shrink-0" />
                {!collapsed && <span className="truncate">{i.label}</span>}
              </NavLink>
            ))}
          </div>
        );
      })}
    </nav>
  );
}

export function Layout() {
  const { user, logout } = useAuth();
  const [collapsed, setCollapsed] = React.useState(() => localStorage.getItem('nav-collapsed') === '1');
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const loc = useLocation();
  React.useEffect(() => setMobileOpen(false), [loc.pathname]);
  React.useEffect(() => localStorage.setItem('nav-collapsed', collapsed ? '1' : '0'), [collapsed]);

  const brand = (
    <Link to="/" className="flex items-center gap-2.5 px-3.5 py-4 text-white">
      <svg viewBox="0 0 32 32" className="h-7 w-7 shrink-0" aria-hidden>
        <rect width="32" height="32" rx="6" fill="#ffffff1a" />
        <rect x="6" y="20" width="5" height="6" fill="#2BB5A5" />
        <rect x="13.5" y="14" width="5" height="12" fill="#F0923A" />
        <rect x="21" y="7" width="5" height="19" fill="#E2554B" />
      </svg>
      {!collapsed && (
        <span className="leading-tight">
          <span className="block text-[14px] font-semibold">Collections & DPD</span>
          <span className="block text-[11.5px] text-ink-300">{user?.companyName}</span>
        </span>
      )}
    </Link>
  );

  return (
    <div className="flex h-full min-h-screen bg-canvas">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-white focus:px-3 focus:py-2">
        Skip to content
      </a>
      {/* desktop sidebar */}
      <aside className={cn('sticky top-0 hidden h-screen shrink-0 flex-col bg-ink lg:flex', collapsed ? 'w-[64px]' : 'w-[232px]')}>
        {brand}
        <SideNav collapsed={collapsed} />
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="flex items-center gap-2 border-t border-white/10 px-4 py-3 text-[13px] text-white/60 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-white/60"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <PanelLeftOpen className="mx-auto h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
          {!collapsed && 'Collapse'}
        </button>
      </aside>
      {/* mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-ink/50" onClick={() => setMobileOpen(false)} />
          <aside className="absolute inset-y-0 left-0 flex w-[260px] flex-col bg-ink">
            <div className="flex items-center justify-between pr-2">
              {brand}
              <button onClick={() => setMobileOpen(false)} className="p-2 text-white/70" aria-label="Close menu">
                <X className="h-5 w-5" />
              </button>
            </div>
            <SideNav collapsed={false} onNavigate={() => setMobileOpen(false)} />
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-line bg-white px-4 lg:px-6">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open menu">
            <Menu />
          </Button>
          <div className="flex items-center gap-2 rounded-md border border-line bg-canvas px-2.5 py-1 text-[13px]" title="All balances, DPD and buckets are as of this business date">
            <AlarmClock className="h-4 w-4 text-ink-500" />
            <span className="text-text-muted">Business date</span>
            <span className="font-semibold tabular-nums text-text">{date(user?.businessDate)}</span>
          </div>
          <div className="ml-auto flex items-center gap-1">
            <Notifications />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-canvas focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink-500">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-ink text-xs font-semibold text-white">
                    {user?.fullName
                      .split(' ')
                      .map((p) => p[0])
                      .slice(0, 2)
                      .join('')}
                  </span>
                  <span className="hidden text-left leading-tight sm:block">
                    <span className="block text-[13px] font-medium">{user?.fullName}</span>
                    <span className="block text-[11.5px] text-text-muted">{user?.roleName}</span>
                  </span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuLabel>{user?.email}</DropdownMenuLabel>
                <DropdownMenuItem asChild>
                  <Link to="/profile">
                    <KeyRound /> Change password
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => logout()}>
                  <LogOut /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main id="main" className="mx-auto w-full max-w-[1440px] flex-1 px-4 py-6 lg:px-6">
          <React.Suspense fallback={<div className="py-20 text-center text-sm text-text-muted">Loading…</div>}>
            <Outlet />
          </React.Suspense>
        </main>
      </div>
    </div>
  );
}

