import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { date, inrShort, num, pct } from '@/lib/format';
import { useUrlState } from '@/hooks/data';
import { Card, CardHeader, Skeleton } from '@/components/ui/base';
import { DpdLadder, ErrorState, PageHeader, Stat, StatGrid, bucketColor } from '@/components/domain';
import { DateRangeFilter, useRange } from '@/components/DateRange';
import { ChartCard, GroupedBars, Lines, SERIES, SimpleBars } from '@/components/charts';

export default function Dashboard() {
  const [url, setUrl] = useUrlState();
  const r = useRange(url, 'month');
  const nav = useNavigate();
  const range = { from: r.from, to: r.to };
  const overview = useQuery({ queryKey: ['/api/dashboard/overview', range], queryFn: () => api.get('/api/dashboard/overview', range) });
  const buckets = useQuery({ queryKey: ['/api/dashboard/dpd-buckets'], queryFn: () => api.get('/api/dashboard/dpd-buckets') });
  const coll = useQuery({ queryKey: ['/api/dashboard/collections', range], queryFn: () => api.get('/api/dashboard/collections', range) });
  const trends = useQuery({ queryKey: ['/api/dashboard/trends', range], queryFn: () => api.get('/api/dashboard/trends', range) });
  const k = overview.data;
  const periodLabel = r.from === r.to ? date(r.from) : `${date(r.from)} – ${date(r.to)}`;

  return (
    <div className="space-y-5">
      <PageHeader title="Portfolio overview" description={`Positions as of the business date; flows for ${periodLabel}.`} actions={<DateRangeFilter state={url} set={setUrl} />} />

      <Card>
        <CardHeader
          title="Book by days past due"
          description={buckets.data ? `${num(buckets.data.totals.accountCount)} live accounts, ${inrShort(buckets.data.totals.outstandingPrincipal)} outstanding principal. Select a segment to see its accounts.` : ' '}
        />
        <div className="px-5 py-5">
          {buckets.isError ? (
            <ErrorState error={buckets.error} onRetry={() => buckets.refetch()} />
          ) : buckets.isLoading ? (
            <Skeleton className="h-28 w-full" />
          ) : (
            <DpdLadder buckets={buckets.data.buckets} onSelect={(code) => nav(`/dpd/accounts?bucket=${code}`)} />
          )}
        </div>
      </Card>

      {overview.isError ? (
        <ErrorState error={overview.error} onRetry={() => overview.refetch()} />
      ) : (
        <StatGrid className="grid-cols-2 md:grid-cols-3 xl:grid-cols-6">
          {!k ? (
            Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="bg-white px-4 py-3.5">
                <Skeleton className="h-3 w-24" />
                <Skeleton className="mt-2 h-6 w-28" />
              </div>
            ))
          ) : (
            <>
              <Stat label="Loan accounts" value={num(k.totalLoanAccounts)} sub={`${num(k.loansDisbursedInPeriod)} disbursed in period`} to="/loans" />
              <Stat label="Disbursed amount" value={inrShort(k.totalDisbursedAmount)} sub={`${inrShort(k.disbursedInPeriod)} in period`} />
              <Stat label="Outstanding principal" value={inrShort(k.totalOutstandingPrincipal)} sub="Live book" />
              <Stat label="EMI due" value={inrShort(k.totalEmiDue)} sub="Installments due in period" to="/emi" />
              <Stat label="EMI collected" value={inrShort(k.totalEmiCollected)} sub={`${inrShort(k.totalCollected)} total receipts`} tone="paid" to="/payments" />
              <Stat label="Collection efficiency" value={k.collectionEfficiencyPct === null ? '—' : pct(k.collectionEfficiencyPct, 1)} sub={`${inrShort(k.collectedAgainstDue)} of period demand`} tone={k.collectionEfficiencyPct >= 90 ? 'paid' : 'due'} />
              <Stat label="Active accounts" value={num(k.totalActiveAccounts)} sub={`${num(k.overdueAccounts)} of them overdue`} />
              <Stat label="Closed accounts" value={num(k.totalClosedAccounts)} sub={k.totalWrittenOffAccounts ? `${num(k.totalWrittenOffAccounts)} written off` : 'No write-offs'} />
              <Stat label="Overdue amount" value={inrShort(k.totalOverdueAmount)} sub={`+ ${inrShort(k.totalOverdueCharges)} charges`} tone="risk" to="/collections/assignments" />
              <Stat label="Bounced payments" value={num(k.totalBouncedPayments)} sub="In period" tone={k.totalBouncedPayments ? 'due' : undefined} to="/bounces" />
              <Stat label="Portfolio at risk (30+)" value={pct(k.par.par30Pct)} sub={`PAR 60 ${pct(k.par.par60Pct)}, PAR 90 ${pct(k.par.par90Pct)}`} tone={k.par.par30Pct > 5 ? 'risk' : undefined} to="/reports/par" />
              <Stat label="Accounts 90+ DPD" value={num(k.accounts90Plus)} sub={inrShort(k.par.par90Pos) + ' POS beyond 90 days'} tone={k.accounts90Plus ? 'risk' : undefined} to="/reports/npa" />
            </>
          )}
        </StatGrid>
      )}

      <div className="grid gap-5 lg:grid-cols-2">
        <ChartCard title="Accounts by DPD bucket" loading={buckets.isLoading}>
          <SimpleBars data={buckets.data?.buckets ?? []} x="label" y="accountCount" name="Accounts" colors={(d) => bucketColor(d.bucketCode)} />
        </ChartCard>
        <ChartCard title="Outstanding principal by DPD bucket" loading={buckets.isLoading}>
          <SimpleBars data={buckets.data?.buckets ?? []} x="label" y="outstandingPrincipal" name="POS" money colors={(d) => bucketColor(d.bucketCode)} />
        </ChartCard>
        <ChartCard title="Monthly collections" description="Successful receipts by month (bounced and reversed money excluded)" loading={coll.isLoading}>
          <Lines data={coll.data?.monthly ?? []} x="month" money series={[{ key: 'collected', name: 'Collected', color: SERIES.teal }]} />
        </ChartCard>
        <ChartCard title="EMI due vs collected" description="Demand for the month and the part of it already collected" loading={coll.isLoading}>
          <GroupedBars
            data={coll.data?.monthly ?? []}
            x="month"
            money
            series={[
              { key: 'emiDue', name: 'EMI due', color: SERIES.slate },
              { key: 'collectedAgainstDemand', name: 'Collected', color: SERIES.teal },
            ]}
          />
        </ChartCard>
        <ChartCard title="Bounce rate" description="Bounces as a share of NACH and cheque presentations" loading={trends.isLoading}>
          <Lines data={trends.data?.bounceTrend ?? []} x="month" pctAxis series={[{ key: 'bounceRatePct', name: 'Bounce rate', color: SERIES.red }]} />
        </ChartCard>
        <ChartCard title="Daily overdue accounts" description="From the nightly DPD snapshots" loading={trends.isLoading}>
          <Lines data={(trends.data?.overdueTrend ?? []).map((d: any) => ({ ...d, date: d.date.slice(5) }))} x="date" series={[{ key: 'overdueAccounts', name: 'Overdue accounts', color: SERIES.orange }]} />
        </ChartCard>
        <ChartCard title="Portfolio by product" description="Outstanding principal of the live book" loading={trends.isLoading}>
          <SimpleBars horizontal data={trends.data?.byProduct ?? []} x="productName" y="outstandingPrincipal" name="POS" money colors={[SERIES.navy]} />
        </ChartCard>
        <ChartCard title="Collections by executive" description="Receipts in period on accounts each executive holds" loading={coll.isLoading}>
          <SimpleBars horizontal data={coll.data?.byExecutive ?? []} x="executiveName" y="collected" name="Collected" money colors={[SERIES.teal]} />
        </ChartCard>
      </div>
    </div>
  );
}
