import * as React from 'react';
import { useQuery } from '@tanstack/react-query';
import { History, KeyRound, Play, Plus, RotateCcw, Save, Trash2 } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { cn, date, dateTime, inr, label } from '@/lib/format';
import { useAction, useGet, useLookups, useUrlState } from '@/hooks/data';
import { Button, Card, CardHeader, Checkbox, Field, Input, NativeSelect, Skeleton, Switch } from '@/components/ui/base';
import { ConfirmDialog, Dialog, DialogContent, Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/overlay';
import { DataTable, FilterSelect } from '@/components/DataTable';
import { ErrorState, KeyValues, PageHeader, Stat, StatGrid, StatusBadge, bucketColor } from '@/components/domain';
import { SimpleTable } from './customers';

// ================================================================== users
export function UsersPage() {
  const { can } = useAuth();
  const lk = useLookups();
  const [url, setUrl] = useUrlState();
  const [edit, setEdit] = React.useState<any | null>(null);
  const [reset, setReset] = React.useState<any | null>(null);
  const [activity, setActivity] = React.useState<any | null>(null);
  const manage = can('users.manage');
  return (
    <>
      <PageHeader
        title="Users"
        description="Staff accounts, roles and access. Deactivating someone ends their sessions and releases their collection accounts."
        actions={
          manage && (
            <Button onClick={() => setEdit({})}>
              <Plus /> Add user
            </Button>
          )
        }
      />
      <DataTable
        endpoint="/api/users"
        searchPlaceholder="Name or email"
        filters={{ roleId: url.roleId, active: url.active }}
        defaultSort={{ sort: 'fullName', order: 'asc' }}
        onRowClick={(u) => setActivity(u)}
        toolbar={
          <>
            <FilterSelect value={url.roleId} onChange={(v) => setUrl({ roleId: v })} placeholder="Any role" options={(lk.data?.roles ?? []).map((r) => ({ value: r.id, label: r.name }))} />
            <FilterSelect value={url.active} onChange={(v) => setUrl({ active: v })} placeholder="Active or not" options={[{ value: 'true', label: 'Active' }, { value: 'false', label: 'Deactivated' }]} />
          </>
        }
        columns={[
          { key: 'fullName', header: 'Name', sortable: true, cell: (u) => <span className="font-medium">{u.fullName}</span> },
          { key: 'email', header: 'Email', sortable: true },
          { key: 'roleName', header: 'Role', sortable: true },
          { key: 'branchName', header: 'Branch', cell: (u) => u.branchName ?? '—' },
          { key: 'assignedAccounts', header: 'Accounts', align: 'right', cell: (u) => (u.roleCode === 'COLLECTION_EXECUTIVE' ? u.assignedAccounts : '') },
          { key: 'lastLoginAt', header: 'Last sign-in', sortable: true, cell: (u) => dateTime(u.lastLoginAt) },
          { key: 'isActive', header: 'Status', cell: (u) => (u.lockedUntil && new Date(u.lockedUntil) > new Date() ? <StatusBadge status="BLOCKED" /> : <StatusBadge status={u.isActive ? 'ACTIVE' : 'INACTIVE'} />) },
          {
            key: 'actions',
            header: '',
            cell: (u) =>
              manage && (
                <div className="flex justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                  <Button size="sm" variant="ghost" onClick={() => setEdit(u)}>
                    Edit
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setReset(u)} aria-label="Reset password">
                    <KeyRound />
                  </Button>
                </div>
              ),
          },
        ]}
      />
      {edit && <UserDialog user={edit} onClose={() => setEdit(null)} />}
      {reset && <ResetPasswordDialog user={reset} onClose={() => setReset(null)} />}
      {activity && <ActivityDialog user={activity} onClose={() => setActivity(null)} />}
    </>
  );
}

function UserDialog({ user, onClose }: { user: any; onClose: () => void }) {
  const lk = useLookups();
  const isNew = !user.id;
  const [v, setV] = React.useState({ email: user.email ?? '', fullName: user.fullName ?? '', phone: user.phone ?? '', roleId: String(user.roleId ?? ''), branchId: String(user.branchId ?? ''), password: '', isActive: user.isActive ?? true });
  const set = (k: string) => (e: React.ChangeEvent<any>) => setV((s) => ({ ...s, [k]: e.target.value }));
  const a = useAction(
    () =>
      isNew
        ? api.post('/api/users', { email: v.email, fullName: v.fullName, phone: v.phone || null, roleId: Number(v.roleId), branchId: v.branchId ? Number(v.branchId) : null, password: v.password })
        : api.put(`/api/users/${user.id}`, { fullName: v.fullName, phone: v.phone || null, roleId: Number(v.roleId), branchId: v.branchId ? Number(v.branchId) : null, isActive: v.isActive }),
    { success: isNew ? 'User created' : 'User updated', onSuccess: onClose },
  );
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent title={isNew ? 'Add user' : `Edit ${user.fullName}`}>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Full name" required className="sm:col-span-2">
            <Input value={v.fullName} onChange={set('fullName')} />
          </Field>
          <Field label="Email" required>
            <Input type="email" value={v.email} onChange={set('email')} disabled={!isNew} />
          </Field>
          <Field label="Phone">
            <Input value={v.phone} onChange={set('phone')} />
          </Field>
          <Field label="Role" required>
            <NativeSelect value={v.roleId} onChange={set('roleId')}>
              <option value="">Select role</option>
              {lk.data?.roles.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </NativeSelect>
          </Field>
          <Field label="Branch">
            <NativeSelect value={v.branchId} onChange={set('branchId')}>
              <option value="">None</option>
              {lk.data?.branches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </NativeSelect>
          </Field>
          {isNew ? (
            <Field label="Initial password" required hint="8+ characters with a letter and a digit. Ask them to change it after first sign-in." className="sm:col-span-2">
              <Input type="password" autoComplete="new-password" value={v.password} onChange={set('password')} />
            </Field>
          ) : (
            <label className="flex items-center gap-3 text-sm sm:col-span-2">
              <Switch checked={v.isActive} onCheckedChange={(c) => setV((s) => ({ ...s, isActive: c }))} /> Account active
            </label>
          )}
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button loading={a.isPending} onClick={() => a.mutate(undefined)} disabled={!v.fullName || !v.roleId || (isNew && (!v.email || v.password.length < 8))}>
            {isNew ? 'Create user' : 'Save changes'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ResetPasswordDialog({ user, onClose }: { user: any; onClose: () => void }) {
  const [pw, setPw] = React.useState('');
  const a = useAction(() => api.post(`/api/users/${user.id}/reset-password`, { password: pw }), { success: 'Temporary password set; their sessions were ended', onSuccess: onClose });
  return (
    <ConfirmDialog open onOpenChange={(o) => !o && onClose()} title={`Set a temporary password for ${user.fullName}?`} description="Share it securely. They'll be signed out everywhere." confirmLabel="Set password" loading={a.isPending} onConfirm={() => a.mutate(undefined)}>
      <Field label="Temporary password" hint="8+ characters with a letter and a digit">
        <Input type="password" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} />
      </Field>
    </ConfirmDialog>
  );
}

function ActivityDialog({ user, onClose }: { user: any; onClose: () => void }) {
  const q = useGet<any>(`/api/users/${user.id}/activity`);
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent wide title={`${user.fullName}: sign-ins and activity`} description={`${user.email}, ${user.roleName}`}>
        <Tabs defaultValue="logins">
          <TabsList>
            <TabsTrigger value="logins">Sign-ins</TabsTrigger>
            <TabsTrigger value="actions">Recent actions</TabsTrigger>
          </TabsList>
          <TabsContent value="logins">
            <SimpleTable
              rows={q.data?.logins}
              loading={q.isLoading}
              empty="No sign-ins yet."
              cols={[
                ['When', (r) => dateTime(r.createdAt)],
                ['Result', (r) => (r.success ? <span className="text-paid">Success</span> : <span className="text-risk">Failed ({r.reason})</span>)],
                ['IP', (r) => r.ip],
                ['Device', (r) => <span className="block max-w-[220px] truncate text-xs text-text-muted">{r.userAgent}</span>],
              ]}
            />
          </TabsContent>
          <TabsContent value="actions">
            <SimpleTable
              rows={q.data?.actions}
              loading={q.isLoading}
              empty="No recorded actions."
              cols={[
                ['When', (r) => dateTime(r.createdAt)],
                ['Action', (r) => label(r.action)],
                ['Record', (r) => `${r.entityType} ${r.entityId ?? ''}`],
              ]}
            />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

// ================================================================== roles
export function RolesPage() {
  const { can } = useAuth();
  const roles = useQuery({ queryKey: ['/api/roles'], queryFn: () => api.get<any[]>('/api/roles') });
  const perms = useQuery({ queryKey: ['/api/roles/permissions'], queryFn: () => api.get<any[]>('/api/roles/permissions') });
  const [draft, setDraft] = React.useState<Record<number, Set<string>>>({});
  const editable = can('roles.manage');
  React.useEffect(() => {
    if (roles.data) setDraft(Object.fromEntries(roles.data.map((r: any) => [r.id, new Set<string>(r.permissions)])));
  }, [roles.data]);
  const dirty = (roles.data ?? []).filter((r: any) => {
    const d = draft[r.id];
    return d && (d.size !== r.permissions.length || r.permissions.some((p: string) => !d.has(p)));
  });
  const save = useAction(async () => {
    for (const r of dirty) await api.put(`/api/roles/${r.id}/permissions`, { permissions: [...draft[r.id]] });
    return dirty.length;
  }, { success: (n) => `${n} role(s) updated; users pick up changes within seconds` });
  if (roles.isError) return <ErrorState error={roles.error} />;
  if (!roles.data || !perms.data) return <Skeleton className="h-96" />;
  const modules = [...new Set(perms.data.map((p: any) => p.module))];
  return (
    <>
      <PageHeader
        title="Roles and permissions"
        description={editable ? 'Tick what each role may do. Collection executives are additionally limited to accounts assigned to them.' : 'Read-only view. Only a Super Admin can change permissions.'}
        actions={
          editable && (
            <Button disabled={!dirty.length} loading={save.isPending} onClick={() => save.mutate(undefined)}>
              <Save /> Save {dirty.length ? `${dirty.length} role(s)` : 'changes'}
            </Button>
          )
        }
      />
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-white">
            <tr className="border-b border-line text-[13px] text-text-muted">
              <th className="px-4 py-2.5 text-left font-medium">Permission</th>
              {roles.data.map((r: any) => (
                <th key={r.id} className="px-2 py-2.5 text-center font-medium">
                  <span className="block text-text">{r.name}</span>
                  <span className="text-xs font-normal">{r.userCount} user(s)</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {modules.map((m) => (
              <React.Fragment key={m as string}>
                <tr className="bg-canvas/70">
                  <td colSpan={roles.data.length + 1} className="px-4 py-1.5 text-[13px] font-semibold">
                    {label(m)}
                  </td>
                </tr>
                {perms.data
                  .filter((p: any) => p.module === m)
                  .map((p: any) => (
                    <tr key={p.code} className="border-b border-line/60">
                      <td className="px-4 py-2">
                        <span className="block">{p.description}</span>
                        <span className="text-xs text-text-faint">{p.code}</span>
                      </td>
                      {roles.data.map((r: any) => (
                        <td key={r.id} className="px-2 py-2 text-center">
                          <Checkbox
                            disabled={!editable || (r.code === 'SUPER_ADMIN' && p.code === 'roles.manage')}
                            checked={!!draft[r.id]?.has(p.code)}
                            aria-label={`${r.name}: ${p.code}`}
                            onCheckedChange={(c) =>
                              setDraft((d) => {
                                const next = new Set(d[r.id]);
                                if (c) next.add(p.code);
                                else next.delete(p.code);
                                return { ...d, [r.id]: next };
                              })
                            }
                          />
                        </td>
                      ))}
                    </tr>
                  ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}

// ================================================================== configuration
export function ConfigPage() {
  return (
    <>
      <PageHeader title="Configuration" description="Business rules used by the DPD engine, payment allocation and schedule generation. Every change is audited." />
      <Tabs defaultValue="rules">
        <TabsList>
          <TabsTrigger value="rules">Business rules</TabsTrigger>
          <TabsTrigger value="buckets">DPD buckets</TabsTrigger>
          <TabsTrigger value="products">Loan products</TabsTrigger>
          <TabsTrigger value="branches">Branches</TabsTrigger>
          <TabsTrigger value="holidays">Holidays</TabsTrigger>
        </TabsList>
        <TabsContent value="rules">
          <SettingsForm />
        </TabsContent>
        <TabsContent value="buckets">
          <BucketEditor />
        </TabsContent>
        <TabsContent value="products">
          <Products />
        </TabsContent>
        <TabsContent value="branches">
          <Branches />
        </TabsContent>
        <TabsContent value="holidays">
          <Holidays />
        </TabsContent>
      </Tabs>
    </>
  );
}

const SETTING_UI: Record<string, { label: string; options?: [string, string][] }> = {
  company_name: { label: 'Company name' },
  business_timezone: { label: 'Business timezone' },
  dpd_grace_days: { label: 'DPD grace period (days)' },
  allocation_waterfall: {
    label: 'Payment allocation order',
    options: [
      ['EMI_ORDER', 'Oldest EMI first (interest, then principal), then charges'],
      ['CHARGES_FIRST', 'Charges first, then oldest EMI'],
      ['INTEREST_FIRST', 'All due interest, then all due principal, then charges'],
    ],
  },
  emi_rounding_places: { label: 'EMI rounding', options: [['0', 'Nearest rupee'], ['1', '10 paise'], ['2', 'Paise']] },
  due_date_holiday_rule: { label: 'Due date on a holiday', options: [['NEXT_WORKING_DAY', 'Move to next working day'], ['PREVIOUS_WORKING_DAY', 'Move to previous working day'], ['NONE', 'Keep the date']] },
  sunday_is_holiday: { label: 'Treat Sundays as holidays', options: [['false', 'No'], ['true', 'Yes']] },
  bounce_charge_override: { label: 'Flat bounce charge (₹, blank = per product)' },
  write_off_min_dpd: { label: 'Minimum DPD to write off' },
  dpd_job_enabled: { label: 'Run DPD job automatically', options: [['true', 'Yes'], ['false', 'No']] },
  dpd_job_cron: { label: 'DPD job schedule (cron, business timezone)' },
};

function SettingsForm() {
  const q = useQuery({ queryKey: ['/api/config/settings'], queryFn: () => api.get<any[]>('/api/config/settings') });
  const [v, setV] = React.useState<Record<string, string>>({});
  React.useEffect(() => {
    if (q.data) setV(Object.fromEntries(q.data.map((s: any) => [s.key, s.value])));
  }, [q.data]);
  const changed = (q.data ?? []).filter((s: any) => s.isEditable && v[s.key] !== s.value);
  const save = useAction(() => api.put('/api/config/settings', { settings: Object.fromEntries(changed.map((s: any) => [s.key, v[s.key]])) }), { success: 'Settings saved' });
  if (!q.data) return <Skeleton className="h-64" />;
  const bd = q.data.find((s: any) => s.key === 'business_date');
  return (
    <Card>
      <CardHeader
        title="Business rules"
        description={`Business date ${date(bd?.value)} is advanced only by the nightly DPD job.`}
        actions={
          <Button disabled={!changed.length} loading={save.isPending} onClick={() => save.mutate(undefined)}>
            <Save /> Save changes
          </Button>
        }
      />
      <div className="grid gap-x-6 gap-y-4 p-5 md:grid-cols-2">
        {q.data
          .filter((s: any) => s.isEditable)
          .map((s: any) => {
            const ui = SETTING_UI[s.key] ?? { label: s.key };
            return (
              <Field key={s.key} label={ui.label} hint={s.description}>
                {ui.options ? (
                  <NativeSelect value={v[s.key] ?? ''} onChange={(e) => setV((x) => ({ ...x, [s.key]: e.target.value }))}>
                    {ui.options.map(([val, l]) => (
                      <option key={val} value={val}>
                        {l}
                      </option>
                    ))}
                  </NativeSelect>
                ) : (
                  <Input value={v[s.key] ?? ''} onChange={(e) => setV((x) => ({ ...x, [s.key]: e.target.value }))} />
                )}
              </Field>
            );
          })}
      </div>
    </Card>
  );
}

function BucketEditor() {
  const q = useQuery({ queryKey: ['/api/dpd/bucket-config'], queryFn: () => api.get<any[]>('/api/dpd/bucket-config') });
  const [rows, setRows] = React.useState<any[]>([]);
  React.useEffect(() => {
    if (q.data) setRows(q.data.filter((b: any) => b.isActive).map((b: any) => ({ code: b.code, label: b.label, minDpd: b.minDpd, maxDpd: b.maxDpd, color: b.color })));
  }, [q.data]);
  const save = useAction(() => api.put('/api/dpd/bucket-config', { buckets: rows.map((r) => ({ ...r, minDpd: Number(r.minDpd), maxDpd: r.maxDpd === '' || r.maxDpd === null ? null : Number(r.maxDpd) })) }), {
    success: 'Buckets saved; live positions re-bucketed',
  });
  const upd = (i: number, k: string, val: string) => setRows((rs) => rs.map((r, j) => (j === i ? { ...r, [k]: val } : r)));
  return (
    <Card>
      <CardHeader
        title="DPD buckets"
        description="Must start at 0, leave no gaps, and end open-ended. Applies to live positions immediately and to future snapshots; past snapshots keep the buckets they were taken with."
        actions={
          <>
            <Button variant="secondary" size="sm" onClick={() => setRows((r) => [...r, { code: '', label: '', minDpd: '', maxDpd: '', color: '#64748b' }])}>
              <Plus /> Add bucket
            </Button>
            <Button size="sm" loading={save.isPending} onClick={() => save.mutate(undefined)}>
              <Save /> Save
            </Button>
          </>
        }
      />
      <div className="space-y-2 p-5">
        {rows.map((r, i) => (
          <div key={i} className="grid grid-cols-[28px_1fr_1.4fr_90px_90px_40px] items-center gap-2">
            <span className="h-5 w-5 rounded" style={{ background: bucketColor(r.code, r.color) }} />
            <Input value={r.code} onChange={(e) => upd(i, 'code', e.target.value.toUpperCase())} placeholder="Code" aria-label="Code" />
            <Input value={r.label} onChange={(e) => upd(i, 'label', e.target.value)} placeholder="Label" aria-label="Label" />
            <Input type="number" value={r.minDpd} onChange={(e) => upd(i, 'minDpd', e.target.value)} placeholder="Min" aria-label="Min DPD" />
            <Input type="number" value={r.maxDpd ?? ''} onChange={(e) => upd(i, 'maxDpd', e.target.value)} placeholder="Max (blank = ∞)" aria-label="Max DPD" />
            <Button variant="ghost" size="icon" onClick={() => setRows((rs) => rs.filter((_, j) => j !== i))} aria-label="Remove bucket">
              <Trash2 />
            </Button>
          </div>
        ))}
      </div>
    </Card>
  );
}

function Products() {
  const q = useQuery({ queryKey: ['/api/config/products'], queryFn: () => api.get<any[]>('/api/config/products') });
  const [edit, setEdit] = React.useState<any>(null);
  return (
    <>
      <div className="mb-2 flex justify-end">
        <Button size="sm" onClick={() => setEdit({ isActive: true })}>
          <Plus /> Add product
        </Button>
      </div>
      <SimpleTable
        rows={q.data}
        loading={q.isLoading}
        empty="No products."
        onRowClick={setEdit}
        cols={[
          ['Code', (p) => p.code],
          ['Name', (p) => p.name],
          ['Amount', (p) => `${inr(p.minAmount, true)} – ${inr(p.maxAmount, true)}`],
          ['Tenure', (p) => `${p.minTenureMonths}–${p.maxTenureMonths} m`],
          ['Rate', (p) => `${p.defaultRate}%`, true],
          ['Fee', (p) => `${p.processingFeePct}%`, true],
          ['Bounce charge', (p) => inr(p.bounceCharge, true), true],
          ['Loans', (p) => p.loanCount, true],
          ['Status', (p) => <StatusBadge status={p.isActive ? 'ACTIVE' : 'INACTIVE'} />],
        ]}
      />
      {edit && <ProductDialog p={edit} onClose={() => setEdit(null)} />}
    </>
  );
}

function ProductDialog({ p, onClose }: { p: any; onClose: () => void }) {
  const fields: [string, string, string?][] = [
    ['code', 'Code'], ['name', 'Name'], ['minAmount', 'Min amount (₹)', 'number'], ['maxAmount', 'Max amount (₹)', 'number'], ['minTenureMonths', 'Min tenure (months)', 'number'],
    ['maxTenureMonths', 'Max tenure (months)', 'number'], ['defaultRate', 'Default rate (%)', 'number'], ['processingFeePct', 'Processing fee (%)', 'number'], ['bounceCharge', 'Bounce charge (₹)', 'number'],
  ];
  const [v, setV] = React.useState<any>({ ...p });
  const a = useAction(() => (p.id ? api.put(`/api/config/products/${p.id}`, v) : api.post('/api/config/products', v)), { success: 'Product saved', onSuccess: onClose });
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent title={p.id ? `Edit ${p.name}` : 'Add product'} description="Changes apply to new loans only; existing loans keep their terms.">
        <div className="grid gap-3 sm:grid-cols-2">
          {fields.map(([k, l, t]) => (
            <Field key={k} label={l}>
              <Input type={t ?? 'text'} value={v[k] ?? ''} onChange={(e) => setV((x: any) => ({ ...x, [k]: e.target.value }))} />
            </Field>
          ))}
          <label className="flex items-center gap-3 text-sm">
            <Switch checked={!!v.isActive} onCheckedChange={(c) => setV((x: any) => ({ ...x, isActive: c }))} /> Available for new loans
          </label>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button loading={a.isPending} onClick={() => a.mutate(undefined)}>
            Save product
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Branches() {
  const q = useQuery({ queryKey: ['/api/config/branches'], queryFn: () => api.get<any[]>('/api/config/branches') });
  const [edit, setEdit] = React.useState<any>(null);
  const a = useAction(() => (edit.id ? api.put(`/api/config/branches/${edit.id}`, edit) : api.post('/api/config/branches', edit)), { success: 'Branch saved', onSuccess: () => setEdit(null) });
  return (
    <>
      <div className="mb-2 flex justify-end">
        <Button size="sm" onClick={() => setEdit({ isActive: true, code: '', name: '', city: '', state: '' })}>
          <Plus /> Add branch
        </Button>
      </div>
      <SimpleTable
        rows={q.data}
        loading={q.isLoading}
        empty="No branches."
        onRowClick={setEdit}
        cols={[
          ['Code', (b) => b.code],
          ['Name', (b) => b.name],
          ['City', (b) => b.city],
          ['State', (b) => b.state],
          ['Status', (b) => <StatusBadge status={b.isActive ? 'ACTIVE' : 'INACTIVE'} />],
        ]}
      />
      {edit && (
        <Dialog open onOpenChange={(o) => !o && setEdit(null)}>
          <DialogContent title={edit.id ? `Edit ${edit.name}` : 'Add branch'}>
            <div className="grid gap-3 sm:grid-cols-2">
              {['code', 'name', 'city', 'state'].map((k) => (
                <Field key={k} label={label(k)}>
                  <Input value={edit[k] ?? ''} onChange={(e) => setEdit((x: any) => ({ ...x, [k]: e.target.value }))} />
                </Field>
              ))}
              <label className="flex items-center gap-3 text-sm">
                <Switch checked={!!edit.isActive} onCheckedChange={(c) => setEdit((x: any) => ({ ...x, isActive: c }))} /> Active
              </label>
            </div>
            <div className="mt-4 flex justify-end gap-2">
              <Button variant="secondary" onClick={() => setEdit(null)}>
                Cancel
              </Button>
              <Button loading={a.isPending} onClick={() => a.mutate(undefined)}>
                Save branch
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}

function Holidays() {
  const q = useQuery({ queryKey: ['/api/config/holidays'], queryFn: () => api.get<any[]>('/api/config/holidays') });
  const [d, setD] = React.useState('');
  const [n, setN] = React.useState('');
  const add = useAction(() => api.post('/api/config/holidays', { holidayDate: d, name: n }), { success: 'Holiday added', onSuccess: () => (setD(''), setN('')) });
  const del = useAction((date: string) => api.del(`/api/config/holidays/${date}`), { success: 'Holiday removed' });
  return (
    <Card>
      <CardHeader title="Holiday calendar" description="Due dates that land on a holiday move according to the due-date rule. Affects schedules generated after the change." />
      <div className="flex flex-wrap items-end gap-2 border-b border-line p-4">
        <Field label="Date">
          <Input type="date" value={d} onChange={(e) => setD(e.target.value)} />
        </Field>
        <Field label="Name">
          <Input value={n} onChange={(e) => setN(e.target.value)} />
        </Field>
        <Button disabled={!d || n.length < 2} loading={add.isPending} onClick={() => add.mutate(undefined)}>
          <Plus /> Add
        </Button>
      </div>
      <div className="divide-y divide-line">
        {(q.data ?? []).map((h: any) => (
          <div key={h.holidayDate} className="flex items-center justify-between px-5 py-2 text-sm">
            <span>
              <span className="tabular-nums">{date(h.holidayDate)}</span> <span className="text-text-muted">{h.name}</span>
            </span>
            <Button size="sm" variant="ghost" onClick={() => del.mutate(h.holidayDate)} aria-label="Remove holiday">
              <Trash2 />
            </Button>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ================================================================== jobs
export function JobsPage() {
  const { can, user, reload } = useAuth();
  const [page, setPage] = React.useState(1);
  const q = useQuery({ queryKey: ['/api/dpd/jobs', page], queryFn: () => api.get('/api/dpd/jobs', { page, pageSize: 25 }), refetchInterval: 15_000 });
  const [runDate, setRunDate] = React.useState('');
  const [confirm, setConfirm] = React.useState<null | { retry: boolean; date?: string }>(null);
  const run = useAction((v: { retry: boolean; date?: string }) => api.post('/api/dpd/run', { businessDate: v.date || undefined, retry: v.retry }), {
    success: (r: any) => (r.status === 'SUCCESS' ? `DPD processed for ${date(r.job.businessDate)}: ${r.job.loansProcessed} loans, ${r.job.snapshotsInserted} new snapshots` : `Run failed: ${r.job.errorMessage}`),
    onSuccess: () => {
      setConfirm(null);
      reload();
    },
  });
  const m = q.data?.meta;
  const lastFailed = q.data?.data.find((j: any) => j.status === 'FAILED');
  return (
    <>
      <PageHeader
        title="Scheduled jobs"
        description="The nightly DPD job refreshes installment statuses, recalculates DPD for every live loan, writes that day's snapshots, evaluates promises and rebuilds the portfolio summary."
        actions={
          can('dpd.run') && (
            <>
              <Input type="date" className="h-9 w-[150px]" value={runDate} max={m?.calendarToday} onChange={(e) => setRunDate(e.target.value)} aria-label="Business date to run" />
              <Button onClick={() => setConfirm({ retry: false, date: runDate })}>
                <Play /> Run DPD now
              </Button>
            </>
          )
        }
      />
      {m && (
        <StatGrid className="mb-5 grid-cols-2 md:grid-cols-5">
          <Stat label="Business date" value={date(m.businessDate)} sub={`Calendar today ${date(m.calendarToday)}`} />
          <Stat label="Last successful run" value={date(m.lastSuccessfulBusinessDate)} tone={m.lastSuccessfulBusinessDate === m.calendarToday ? 'paid' : 'due'} />
          <Stat label="Schedule" value={m.enabled === 'true' ? m.cron : 'Disabled'} sub={m.timezone} />
          <Stat label="Next run" value={m.nextRun ? dateTime(m.nextRun) : '—'} />
          <Stat label="Running now" value={m.running ? 'Yes' : 'No'} tone={m.running ? 'due' : undefined} />
        </StatGrid>
      )}
      {lastFailed && can('dpd.run') && (
        <div className="mb-4 flex flex-wrap items-center gap-3 rounded-lg border border-risk/30 bg-risk-soft px-4 py-3 text-sm text-risk">
          <span className="flex-1">
            Run #{lastFailed.id} for {date(lastFailed.businessDate)} failed: {lastFailed.errorMessage}
          </span>
          <Button size="sm" variant="secondary" onClick={() => setConfirm({ retry: true, date: lastFailed.businessDate > (m?.lastSuccessfulBusinessDate ?? '') ? lastFailed.businessDate : undefined })}>
            <RotateCcw /> Retry
          </Button>
        </div>
      )}
      {q.isError ? (
        <ErrorState error={q.error} />
      ) : (
        <SimpleTable
          rows={q.data?.data}
          loading={q.isLoading}
          empty="The DPD job hasn't run yet."
          cols={[
            ['Run', (j) => `#${j.id}`],
            ['Business date', (j) => date(j.businessDate)],
            ['Trigger', (j) => label(j.triggerType)],
            ['By', (j) => j.triggeredByName ?? 'Scheduler'],
            ['Started', (j) => dateTime(j.startedAt)],
            ['Duration', (j) => (j.durationMs ? `${Math.round(j.durationMs)} ms` : '—'), true],
            ['Loans', (j) => j.loansProcessed ?? '—', true],
            ['Snapshots', (j) => j.snapshotsInserted ?? '—', true],
            ['Status', (j) => <StatusBadge status={j.status} />],
            ['Message', (j) => <span className={cn('block max-w-sm truncate text-xs', j.errorMessage ? 'text-risk' : 'text-text-muted')} title={j.errorMessage ?? j.message}>{j.errorMessage ?? j.message}</span>],
          ]}
        />
      )}
      <div className="mt-3 flex items-center justify-end gap-2 text-[13px] text-text-muted">
        <Button size="sm" variant="secondary" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
          Newer
        </Button>
        <span>Page {page}</span>
        <Button size="sm" variant="secondary" disabled={!q.data || page * 25 >= q.data.total} onClick={() => setPage((p) => p + 1)}>
          Older
        </Button>
      </div>
      {confirm && (
        <ConfirmDialog
          open
          onOpenChange={(o) => !o && setConfirm(null)}
          title={confirm.retry ? 'Retry the DPD run?' : `Run DPD for ${confirm.date ? date(confirm.date) : 'today'}?`}
          description={
            <>
              Runs are idempotent: existing snapshots for a date are never changed, and dates before the last successful run ({date(m?.lastSuccessfulBusinessDate)}) are refused. Current business date: {date(user!.businessDate)}.
            </>
          }
          confirmLabel={confirm.retry ? 'Retry run' : 'Run now'}
          loading={run.isPending}
          onConfirm={() => run.mutate(confirm)}
        />
      )}
    </>
  );
}

// ================================================================== audit
export function AuditPage() {
  const [url, setUrl] = useUrlState();
  const meta = useQuery({ queryKey: ['/api/audit-logs/entity-types'], queryFn: () => api.get('/api/audit-logs/entity-types') });
  const [open, setOpen] = React.useState<any>(null);
  return (
    <>
      <PageHeader title="Audit log" description="Every change to customers, loans, payments, bounces, users and configuration, captured by database triggers. Entries can't be edited or deleted." />
      <DataTable
        endpoint="/api/audit-logs"
        searchPlaceholder="Search changed values"
        defaultSort={{ sort: 'createdAt', order: 'desc' }}
        filters={{ entityType: url.entityType, action: url.action, entityId: url.entityId, dateFrom: url.dateFrom, dateTo: url.dateTo }}
        onRowClick={setOpen}
        toolbar={
          <>
            <FilterSelect value={url.entityType} onChange={(v) => setUrl({ entityType: v })} placeholder="Any record type" options={(meta.data?.entityTypes ?? []).map((e: string) => ({ value: e, label: label(e) }))} />
            <FilterSelect value={url.action} onChange={(v) => setUrl({ action: v })} placeholder="Any action" options={(meta.data?.actions ?? []).map((e: string) => ({ value: e, label: label(e) }))} />
            <Input type="date" className="h-9 w-[150px]" value={url.dateFrom ?? ''} onChange={(e) => setUrl({ dateFrom: e.target.value })} aria-label="From" />
            <Input type="date" className="h-9 w-[150px]" value={url.dateTo ?? ''} onChange={(e) => setUrl({ dateTo: e.target.value })} aria-label="To" />
          </>
        }
        columns={[
          { key: 'createdAt', header: 'When', sortable: true, cell: (a) => dateTime(a.createdAt) },
          { key: 'userName', header: 'User', cell: (a) => a.userName ?? <span className="text-text-faint">System</span> },
          { key: 'action', header: 'Action', sortable: true, cell: (a) => label(a.action) },
          { key: 'entityType', header: 'Record', sortable: true, cell: (a) => `${label(a.entityType)} ${a.entityId ?? ''}` },
          { key: 'newValues', header: 'Change', cell: (a) => <span className="block max-w-md truncate text-xs text-text-muted">{summary(a)}</span> },
          { key: 'ip', header: 'IP', cell: (a) => <span className="text-xs text-text-faint">{a.ip ?? ''}</span> },
        ]}
      />
      {open && (
        <Dialog open onOpenChange={(o) => !o && setOpen(null)}>
          <DialogContent wide title={`${label(open.action)}: ${label(open.entityType)} ${open.entityId ?? ''}`} description={`${dateTime(open.createdAt)} by ${open.userName ?? 'System'}${open.requestId ? `, request ${open.requestId}` : ''}`}>
            <KeyValues cols={2} items={[['IP address', open.ip], ['Request', open.requestId]]} />
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {[
                ['Before', open.oldValues],
                ['After', open.newValues],
              ].map(([t, val]) => (
                <div key={t as string}>
                  <div className="mb-1 flex items-center gap-1.5 text-[13px] font-medium">
                    <History className="h-3.5 w-3.5" /> {t}
                  </div>
                  <pre className="max-h-80 overflow-auto rounded-md bg-canvas p-3 text-xs leading-relaxed">{val ? JSON.stringify(val, null, 2) : '—'}</pre>
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}

function summary(a: any) {
  const n = a.newValues ?? {};
  const keys = Object.keys(n).filter((k) => k !== 'id');
  if (a.action === 'INSERT') return `Created (${keys.length} fields)`;
  if (a.action === 'DELETE') return 'Deleted';
  return keys
    .slice(0, 4)
    .map((k) => `${k}: ${a.oldValues?.[k] ?? '∅'} → ${typeof n[k] === 'object' ? JSON.stringify(n[k]) : n[k]}`)
    .join('; ');
}
