import * as React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Plus, Target, UserCheck, UserMinus, Wand2 } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { date, inr, inrShort, label, num, pct } from '@/lib/format';
import { useAction, useLookups, useUrlState } from '@/hooks/data';
import { Button, Card, CardHeader, Field, Input, NativeSelect, Skeleton, Textarea } from '@/components/ui/base';
import { ConfirmDialog, Dialog, DialogContent } from '@/components/ui/overlay';
import { DataTable, FilterSelect } from '@/components/DataTable';
import { DateRangeFilter, useRange } from '@/components/DateRange';
import { DpdBadge, ErrorState, Money, PageHeader, Stat, StatGrid, StatusBadge } from '@/components/domain';
import { ChartCard, Lines, SERIES } from '@/components/charts';
import { SimpleTable } from './customers';

const TYPES = ['PHONE_CALL', 'SMS', 'EMAIL', 'FIELD_VISIT', 'WHATSAPP', 'OTHER'];
const RESULTS = ['CONTACTED', 'NOT_REACHABLE', 'WRONG_NUMBER', 'PROMISE_TO_PAY', 'PAID', 'REFUSED_TO_PAY', 'CALLBACK_REQUESTED', 'CUSTOMER_NOT_AVAILABLE', 'OTHER'];

export function LogActivityDialog({ open, onClose, loanId }: { open: boolean; onClose: () => void; loanId: number }) {
  const { user } = useAuth();
  const bd = user!.businessDate;
  const [v, setV] = React.useState({ activityDate: bd, activityType: 'PHONE_CALL', contactResult: 'CONTACTED', ptpDate: '', ptpAmount: '', notes: '', nextFollowUpDate: '' });
  const set = (k: string) => (e: React.ChangeEvent<any>) => setV((s) => ({ ...s, [k]: e.target.value }));
  const isPtp = v.contactResult === 'PROMISE_TO_PAY';
  const a = useAction(
    () =>
      api.post('/api/collections/activities', {
        loanId,
        activityDate: v.activityDate,
        activityType: v.activityType,
        contactResult: v.contactResult,
        ptpDate: isPtp ? v.ptpDate : null,
        ptpAmount: isPtp ? Number(v.ptpAmount) : null,
        notes: v.notes || null,
        nextFollowUpDate: v.nextFollowUpDate || null,
      }),
    { success: isPtp ? 'Activity and promise recorded' : 'Activity recorded', onSuccess: onClose },
  );
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent title="Log collection activity">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Date">
            <Input type="date" value={v.activityDate} max={bd} onChange={set('activityDate')} />
          </Field>
          <Field label="Activity">
            <NativeSelect value={v.activityType} onChange={set('activityType')}>
              {TYPES.map((t) => (
                <option key={t} value={t}>
                  {label(t)}
                </option>
              ))}
            </NativeSelect>
          </Field>
          <Field label="Result" className="sm:col-span-2">
            <NativeSelect value={v.contactResult} onChange={set('contactResult')}>
              {RESULTS.map((t) => (
                <option key={t} value={t}>
                  {label(t)}
                </option>
              ))}
            </NativeSelect>
          </Field>
          {isPtp && (
            <>
              <Field label="Promised payment date" required>
                <Input type="date" min={v.activityDate} value={v.ptpDate} onChange={set('ptpDate')} />
              </Field>
              <Field label="Promised amount (₹)" required>
                <Input type="number" step="0.01" value={v.ptpAmount} onChange={set('ptpAmount')} />
              </Field>
            </>
          )}
          <Field label="Next follow-up" className="sm:col-span-2" hint={isPtp ? 'Defaults to the promised date' : undefined}>
            <Input type="date" min={v.activityDate} value={v.nextFollowUpDate} onChange={set('nextFollowUpDate')} />
          </Field>
          <Field label="Notes" className="sm:col-span-2">
            <Textarea value={v.notes} onChange={set('notes')} placeholder="What did the customer say?" />
          </Field>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button disabled={isPtp && (!v.ptpDate || !(Number(v.ptpAmount) > 0))} loading={a.isPending} onClick={() => a.mutate(undefined)}>
            Save activity
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function TargetDialog({ exec, onClose }: { exec: { executiveId: number; executiveName: string; targetAmount: number }; onClose: () => void }) {
  const { user } = useAuth();
  const [amt, setAmt] = React.useState(String(exec.targetAmount || ''));
  const a = useAction(() => api.put('/api/collections/targets', { executiveId: exec.executiveId, month: user!.businessDate, targetAmount: Number(amt) }), { success: 'Target saved', onSuccess: onClose });
  return (
    <ConfirmDialog open onOpenChange={(o) => !o && onClose()} title={`Monthly target for ${exec.executiveName}`} description="Applies to the current business month. Without a target, achievement is measured against the overdue amount held." confirmLabel="Save target" loading={a.isPending} onConfirm={() => a.mutate(undefined)}>
      <Field label="Target (₹)">
        <Input type="number" value={amt} onChange={(e) => setAmt(e.target.value)} />
      </Field>
    </ConfirmDialog>
  );
}

export function CollectionDashboard() {
  const { user, can } = useAuth();
  const nav = useNavigate();
  const lk = useLookups();
  const [url, setUrl] = useUrlState();
  const isExec = user!.role === 'COLLECTION_EXECUTIVE';
  const q = useQuery({ queryKey: ['/api/collections/dashboard', url.executiveId], queryFn: () => api.get('/api/collections/dashboard', { executiveId: url.executiveId }) });
  const [logFor, setLogFor] = React.useState<number | null>(null);
  const [target, setTarget] = React.useState<any>(null);
  const d = q.data;
  const k = d?.kpis;
  return (
    <>
      <PageHeader
        title={isExec ? 'My collection desk' : 'Collection desk'}
        description={isExec ? 'Your accounts, promises and follow-ups for today.' : 'Team performance this business month.'}
        actions={
          !isExec && (
            <FilterSelect value={url.executiveId} onChange={(v) => setUrl({ executiveId: v })} placeholder="Whole team" options={(lk.data?.executives ?? []).map((e) => ({ value: e.id, label: e.fullName }))} />
          )
        }
      />
      {q.isError ? (
        <ErrorState error={q.error} onRetry={() => q.refetch()} />
      ) : !k ? (
        <Skeleton className="h-64" />
      ) : (
        <div className="space-y-5">
          <StatGrid className="grid-cols-2 md:grid-cols-4 xl:grid-cols-8">
            <Stat label="Assigned accounts" value={num(k.assignedAccounts)} sub={`${num(k.overdueAccounts)} overdue`} to="/collections/assignments" />
            <Stat label="Overdue held" value={inrShort(k.totalOverdue)} tone="risk" />
            <Stat label="Collected this month" value={inrShort(k.collectedMtd)} tone="paid" />
            <Stat label="Target" value={inrShort(k.targetAmount)} />
            <Stat label="Achievement" value={k.achievementPct === null ? '—' : pct(k.achievementPct, 1)} tone={k.achievementPct >= 100 ? 'paid' : 'due'} />
            <Stat label="Promises pending" value={num(k.ptpPending)} sub={inrShort(k.ptpPendingAmount)} to="/collections/ptp?status=PENDING" />
            <Stat label="Broken promises" value={num(k.brokenPtpMtd)} sub="This month" tone={k.brokenPtpMtd ? 'risk' : undefined} to="/collections/ptp?status=BROKEN" />
            <Stat label="Follow-ups today" value={num(d.followUps.length)} tone={d.followUps.length ? 'due' : undefined} />
          </StatGrid>

          <div className="grid gap-5 xl:grid-cols-[1fr_420px]">
            <Card>
              <CardHeader title="Due today" description={`Follow-ups and promises falling due on or before ${date(d.businessDate)}.`} />
              <SimpleTable
                rows={d.followUps.map((r: any, i: number) => ({ ...r, id: `${r.loanId}-${r.kind}-${i}` }))}
                empty="Nothing due today."
                onRowClick={(r) => nav(`/loans/${r.loanId}`)}
                cols={[
                  ['Loan', (r) => <span className="font-medium text-ink">{r.loanNumber}</span>],
                  ['Customer', (r) => r.customerName],
                  ['Why', (r) => (r.kind === 'PTP' ? `Promise ${inr(r.amount)} by ${date(r.dueOn)}` : 'Follow-up')],
                  ['DPD', (r) => <DpdBadge dpd={r.dpd} />],
                  ['Overdue', (r) => inr(r.overdueAmount), true],
                  ...(!isExec ? ([['Executive', (r: any) => r.executiveName]] as any) : []),
                  [
                    '',
                    (r) =>
                      can('collections.write') && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            setLogFor(r.loanId);
                          }}
                        >
                          Log
                        </Button>
                      ),
                  ],
                ]}
              />
            </Card>
            <ChartCard title="Daily collections, last 30 days" description={isExec ? 'On your accounts' : undefined}>
              <Lines data={d.trend.map((t: any) => ({ ...t, day: t.date.slice(5) }))} x="day" money series={[{ key: 'collected', name: 'Collected', color: SERIES.teal }]} />
            </ChartCard>
          </div>

          {!isExec && (
            <Card>
              <CardHeader title="Executive performance" description="Business month to date." />
              <SimpleTable
                rows={d.team.map((t: any) => ({ ...t, id: t.executiveId }))}
                empty="No collection executives yet."
                onRowClick={(r) => setUrl({ executiveId: String(r.executiveId) })}
                cols={[
                  ['Executive', (r) => <span className="font-medium">{r.executiveName}</span>],
                  ['Accounts', (r) => num(r.assignedAccounts), true],
                  ['Overdue a/c', (r) => num(r.overdueAccounts), true],
                  ['Overdue held', (r) => inr(r.totalOverdue, true), true],
                  ['Collected', (r) => inr(r.collectedMtd, true), true],
                  ['Target', (r) => inr(r.targetAmount, true), true],
                  [
                    'Achievement',
                    (r) => (
                      <div className="flex items-center justify-end gap-2">
                        <div className="h-1.5 w-20 rounded bg-canvas">
                          <div className="h-full rounded bg-paid" style={{ width: `${Math.min(100, r.achievementPct ?? 0)}%` }} />
                        </div>
                        <span className="w-14 text-right">{pct(r.achievementPct, 1)}</span>
                      </div>
                    ),
                    true,
                  ],
                  ['PTP open', (r) => num(r.ptpPending), true],
                  ['Broken', (r) => <span className={r.ptpBrokenMtd ? 'text-risk' : ''}>{num(r.ptpBrokenMtd)}</span>, true],
                  ['Activities', (r) => num(r.activitiesMtd), true],
                  [
                    '',
                    (r) =>
                      can('collections.targets') && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            setTarget(r);
                          }}
                        >
                          <Target /> Target
                        </Button>
                      ),
                  ],
                ]}
              />
            </Card>
          )}
        </div>
      )}
      {logFor && <LogActivityDialog open onClose={() => setLogFor(null)} loanId={logFor} />}
      {target && <TargetDialog exec={target} onClose={() => setTarget(null)} />}
    </>
  );
}

export function AccountAssignment() {
  const { can, user } = useAuth();
  const nav = useNavigate();
  const lk = useLookups();
  const [url, setUrl] = useUrlState();
  const [selected, setSelected] = React.useState<Set<number>>(new Set());
  const [assignTo, setAssignTo] = React.useState('');
  const [confirmAuto, setConfirmAuto] = React.useState(false);
  const canAssign = can('collections.assign');
  const assign = useAction(() => api.post('/api/collections/assignments', { loanIds: [...selected], executiveId: Number(assignTo) }), {
    success: (r: any) => `${r.assigned} account(s) assigned`,
    onSuccess: () => setSelected(new Set()),
  });
  const unassign = useAction(() => api.post('/api/collections/assignments/unassign', { loanIds: [...selected] }), { success: (r: any) => `${r.unassigned} account(s) unassigned`, onSuccess: () => setSelected(new Set()) });
  const auto = useAction(() => api.post('/api/collections/assignments/auto', {}), { success: (r: any) => `${r.assigned} unassigned overdue account(s) shared across executives`, onSuccess: () => setConfirmAuto(false) });
  const isExec = user!.role === 'COLLECTION_EXECUTIVE';
  return (
    <>
      <PageHeader
        title={isExec ? 'My overdue accounts' : 'Overdue accounts and assignment'}
        description="Live accounts with unpaid dues, worst first. Select rows to assign or reassign."
        actions={
          canAssign && (
            <Button variant="secondary" onClick={() => setConfirmAuto(true)}>
              <Wand2 /> Auto-allocate unassigned
            </Button>
          )
        }
      />
      {canAssign && selected.size > 0 && (
        <div className="mb-3 flex flex-wrap items-center gap-2 rounded-lg border border-ink-100 bg-ink-50 px-3 py-2">
          <span className="text-sm font-medium text-ink">{selected.size} selected</span>
          <NativeSelect className="h-8 w-56" value={assignTo} onChange={(e) => setAssignTo(e.target.value)} aria-label="Assign to">
            <option value="">Choose executive</option>
            {lk.data?.executives.map((e) => (
              <option key={e.id} value={e.id}>
                {e.fullName}
              </option>
            ))}
          </NativeSelect>
          <Button size="sm" disabled={!assignTo} loading={assign.isPending} onClick={() => assign.mutate(undefined)}>
            <UserCheck /> Assign
          </Button>
          <Button size="sm" variant="secondary" loading={unassign.isPending} onClick={() => unassign.mutate(undefined)}>
            <UserMinus /> Unassign
          </Button>
          <button className="ml-auto text-[13px] text-text-muted hover:underline" onClick={() => setSelected(new Set())}>
            Clear selection
          </button>
        </div>
      )}
      <DataTable
        endpoint="/api/collections/overdue"
        searchPlaceholder="Loan, customer, mobile"
        defaultSort={{ sort: 'dpd', order: 'desc' }}
        selectable={canAssign}
        selected={selected}
        onSelectedChange={setSelected}
        filters={{ bucket: url.bucket, executiveId: url.executiveId, assigned: url.assigned, productId: url.productId, state: url.state, followUpDue: url.followUpDue }}
        onRowClick={(r) => nav(`/loans/${r.id}`)}
        toolbar={
          <>
            <FilterSelect value={url.bucket} onChange={(v) => setUrl({ bucket: v })} placeholder="All buckets" options={(lk.data?.buckets ?? []).filter((b) => b.minDpd > 0).map((b) => ({ value: b.code, label: b.label }))} />
            {!isExec && <FilterSelect value={url.assigned} onChange={(v) => setUrl({ assigned: v })} placeholder="Assigned or not" options={[{ value: 'false', label: 'Unassigned' }, { value: 'true', label: 'Assigned' }]} />}
            {!isExec && <FilterSelect value={url.executiveId} onChange={(v) => setUrl({ executiveId: v })} placeholder="Any executive" options={(lk.data?.executives ?? []).map((e) => ({ value: e.id, label: e.fullName }))} />}
            <FilterSelect value={url.followUpDue} onChange={(v) => setUrl({ followUpDue: v })} placeholder="Any follow-up" options={[{ value: 'true', label: 'Follow-up due' }]} />
          </>
        }
        columns={[
          { key: 'loanNumber', header: 'Loan', sortable: true, cell: (r) => <span className="font-medium text-ink">{r.loanNumber}</span> },
          { key: 'customerName', header: 'Customer', sortable: true, cell: (r) => (
              <span>
                {r.customerName}
                <span className="block text-xs text-text-faint">{r.mobile}, {r.city}</span>
              </span>
            ) },
          { key: 'dpd', header: 'DPD', sortable: true, cell: (r) => <DpdBadge dpd={r.dpd} bucket={r.bucketCode} /> },
          { key: 'overdueAmount', header: 'Overdue', align: 'right', sortable: true, cell: (r) => <Money v={Number(r.overdueAmount) + Number(r.overdueCharges)} className="text-risk" /> },
          { key: 'outstandingPrincipal', header: 'POS', align: 'right', sortable: true, cell: (r) => <Money v={r.outstandingPrincipal} whole /> },
          { key: 'executiveName', header: 'Executive', sortable: true, cell: (r) => r.executiveName ?? <span className="text-due">Unassigned</span> },
          { key: 'lastActivityDate', header: 'Last contact', sortable: true, cell: (r) => (r.lastActivityDate ? <span>{date(r.lastActivityDate)}<span className="block text-xs text-text-faint">{label(r.lastContactResult)}</span></span> : <span className="text-text-faint">Never</span>) },
          { key: 'nextFollowUpDate', header: 'Follow-up', sortable: true, cell: (r) => date(r.nextFollowUpDate) },
          { key: 'ptpDate', header: 'Promise', sortable: true, cell: (r) => (r.ptpDate ? `${inr(r.ptpAmount, true)} by ${date(r.ptpDate)}` : '—') },
        ]}
      />
      <ConfirmDialog open={confirmAuto} onOpenChange={setConfirmAuto} title="Auto-allocate unassigned accounts?" description="Every overdue account without an executive is assigned, highest DPD first, to whichever active executive holds the fewest accounts." confirmLabel="Allocate" loading={auto.isPending} onConfirm={() => auto.mutate(undefined)} />
    </>
  );
}

export function Activities() {
  const { can, user } = useAuth();
  const lk = useLookups();
  const nav = useNavigate();
  const [url, setUrl] = useUrlState();
  const r = useRange(url, 'last7');
  const [logLoan, setLogLoan] = React.useState('');
  const [open, setOpen] = React.useState(false);
  const isExec = user!.role === 'COLLECTION_EXECUTIVE';
  return (
    <>
      <PageHeader
        title="Collection activities"
        description="Calls, visits and messages logged against overdue accounts."
        actions={
          can('collections.write') && (
            <Button onClick={() => setOpen(true)}>
              <Plus /> Log activity
            </Button>
          )
        }
      />
      <DataTable
        endpoint="/api/collections/activities"
        searchPlaceholder="Loan, customer, notes"
        defaultSort={{ sort: 'activityDate', order: 'desc' }}
        filters={{ dateFrom: r.from, dateTo: r.to, activityType: url.activityType, contactResult: url.contactResult, executiveId: url.executiveId }}
        onRowClick={(a) => nav(`/loans/${a.loanId}`)}
        toolbar={
          <>
            <DateRangeFilter state={url} set={setUrl} fallback="last7" />
            <FilterSelect value={url.activityType} onChange={(v) => setUrl({ activityType: v })} placeholder="Any activity" options={TYPES.map((t) => ({ value: t, label: label(t) }))} />
            <FilterSelect value={url.contactResult} onChange={(v) => setUrl({ contactResult: v })} placeholder="Any result" options={RESULTS.map((t) => ({ value: t, label: label(t) }))} />
            {!isExec && <FilterSelect value={url.executiveId} onChange={(v) => setUrl({ executiveId: v })} placeholder="Any executive" options={(lk.data?.executives ?? []).map((e) => ({ value: e.id, label: e.fullName }))} />}
          </>
        }
        columns={[
          { key: 'activityDate', header: 'Date', sortable: true, cell: (a) => date(a.activityDate) },
          { key: 'loanNumber', header: 'Loan', sortable: true, cell: (a) => <span className="font-medium text-ink">{a.loanNumber}</span> },
          { key: 'customerName', header: 'Customer' },
          { key: 'executiveName', header: 'Executive', sortable: true },
          { key: 'activityType', header: 'Activity', cell: (a) => label(a.activityType) },
          { key: 'contactResult', header: 'Result', cell: (a) => <span className={a.contactResult === 'PROMISE_TO_PAY' ? 'font-medium text-paid' : ['REFUSED_TO_PAY', 'WRONG_NUMBER'].includes(a.contactResult) ? 'text-risk' : ''}>{label(a.contactResult)}</span> },
          { key: 'ptpAmount', header: 'Promise', cell: (a) => (a.ptpAmount ? `${inr(a.ptpAmount, true)} by ${date(a.ptpDate)}` : '—') },
          { key: 'nextFollowUpDate', header: 'Next follow-up', sortable: true, cell: (a) => date(a.nextFollowUpDate) },
          { key: 'notes', header: 'Notes', cell: (a) => <span className="block max-w-xs truncate text-text-muted">{a.notes ?? ''}</span> },
        ]}
      />
      <Dialog open={open && !logLoan} onOpenChange={setOpen}>
        <DialogContent title="Log activity" description="Pick the loan first.">
          <PickLoan onPick={(id) => setLogLoan(String(id))} />
        </DialogContent>
      </Dialog>
      {logLoan && (
        <LogActivityDialog
          open
          loanId={Number(logLoan)}
          onClose={() => {
            setLogLoan('');
            setOpen(false);
          }}
        />
      )}
    </>
  );
}

function PickLoan({ onPick }: { onPick: (id: number) => void }) {
  const [term, setTerm] = React.useState('');
  const q = useQuery({ queryKey: ['pick-loan', term], queryFn: () => api.get('/api/collections/overdue', { search: term || undefined, pageSize: 8 }) });
  return (
    <div className="space-y-2">
      <Input autoFocus placeholder="Search overdue loans" value={term} onChange={(e) => setTerm(e.target.value)} />
      <div className="divide-y divide-line rounded-md border border-line">
        {(q.data?.data ?? []).map((l: any) => (
          <button key={l.id} className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-canvas" onClick={() => onPick(l.id)}>
            <span>
              <span className="font-medium">{l.loanNumber}</span> {l.customerName}
            </span>
            <DpdBadge dpd={l.dpd} bucket={l.bucketCode} />
          </button>
        ))}
        {q.data && q.data.data.length === 0 && <p className="px-3 py-3 text-[13px] text-text-muted">No overdue loan matches.</p>}
      </div>
      <p className="text-xs text-text-faint">
        For a current account, open the loan and use <Link to="/loans" className="underline">Log activity</Link> there.
      </p>
    </div>
  );
}

export function PromiseToPay() {
  const { can, user } = useAuth();
  const lk = useLookups();
  const nav = useNavigate();
  const [url, setUrl] = useUrlState();
  const [cancel, setCancel] = React.useState<any>(null);
  const a = useAction(() => api.post(`/api/collections/ptp/${cancel.id}/cancel`), { success: 'Promise cancelled', onSuccess: () => setCancel(null) });
  const isExec = user!.role === 'COLLECTION_EXECUTIVE';
  return (
    <>
      <PageHeader title="Promises to pay" description="Promises are checked every night: kept, partly kept or broken, based on payments received by the promised date." />
      <DataTable
        endpoint="/api/collections/ptp"
        searchPlaceholder="Loan or customer"
        defaultSort={{ sort: 'promisedDate', order: 'asc' }}
        filters={{ status: url.status, executiveId: url.executiveId, dueFrom: url.dueFrom, dueTo: url.dueTo }}
        onRowClick={(p) => nav(`/loans/${p.loanId}`)}
        toolbar={
          <>
            <FilterSelect value={url.status} onChange={(v) => setUrl({ status: v })} placeholder="Any status" options={['PENDING', 'KEPT', 'PARTIALLY_KEPT', 'BROKEN', 'CANCELLED'].map((s) => ({ value: s, label: label(s) }))} />
            {!isExec && <FilterSelect value={url.executiveId} onChange={(v) => setUrl({ executiveId: v })} placeholder="Any executive" options={(lk.data?.executives ?? []).map((e) => ({ value: e.id, label: e.fullName }))} />}
            <Input type="date" className="h-9 w-[150px]" value={url.dueFrom ?? ''} onChange={(e) => setUrl({ dueFrom: e.target.value })} aria-label="Due from" />
            <Input type="date" className="h-9 w-[150px]" value={url.dueTo ?? ''} onChange={(e) => setUrl({ dueTo: e.target.value })} aria-label="Due to" />
          </>
        }
        columns={[
          { key: 'loanNumber', header: 'Loan', sortable: true, cell: (p) => <span className="font-medium text-ink">{p.loanNumber}</span> },
          { key: 'customerName', header: 'Customer' },
          { key: 'executiveName', header: 'Executive', sortable: true },
          { key: 'promisedOn', header: 'Promised on', cell: (p) => date(p.promisedOn) },
          { key: 'promisedDate', header: 'Pay by', sortable: true, cell: (p) => <span className={p.status === 'PENDING' && p.promisedDate < user!.businessDate ? 'text-risk' : ''}>{date(p.promisedDate)}</span> },
          { key: 'promisedAmount', header: 'Promised', align: 'right', sortable: true, cell: (p) => <Money v={p.promisedAmount} /> },
          { key: 'keptAmount', header: 'Received', align: 'right', cell: (p) => <Money v={p.keptAmount} /> },
          { key: 'dpd', header: 'DPD now', cell: (p) => <DpdBadge dpd={p.dpd} /> },
          { key: 'status', header: 'Status', sortable: true, cell: (p) => <StatusBadge status={p.status} /> },
          {
            key: 'x',
            header: '',
            cell: (p) =>
              can('collections.write') && p.status === 'PENDING' ? (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={(e) => {
                    e.stopPropagation();
                    setCancel(p);
                  }}
                >
                  Cancel
                </Button>
              ) : null,
          },
        ]}
      />
      {cancel && <ConfirmDialog open onOpenChange={(o) => !o && setCancel(null)} title="Cancel this promise?" description={`${inr(cancel.promisedAmount)} by ${date(cancel.promisedDate)} on ${cancel.loanNumber}. It won't count as broken.`} confirmLabel="Cancel promise" danger loading={a.isPending} onConfirm={() => a.mutate(undefined)} />}
    </>
  );
}
