import * as React from 'react';
import { Link, Navigate, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { api, ApiError } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { Button, Card, CardHeader, Field, Input } from '@/components/ui/base';
import { PageHeader } from '@/components/domain';

const passwordRule = z
  .string()
  .min(8, 'At least 8 characters')
  .regex(/[A-Za-z]/, 'Include a letter')
  .regex(/\d/, 'Include a digit');

const DEMO = [
  ['superadmin', 'Super Admin'],
  ['admin', 'Admin'],
  ['manager', 'Collection Manager'],
  ['exec1', 'Collection Executive'],
  ['finance', 'Finance User'],
  ['analyst', 'Read-Only Analyst'],
];

function AuthShell({ children }: { children: React.ReactNode }) {
  // static picture of a healthy book: mostly current, thinning into the red
  const ladder = [64, 20, 8, 5, 3];
  const colors = ['#2BB5A5', '#E2A13A', '#E2780F', '#C2352C', '#8E1F18'];
  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <div className="relative hidden flex-col justify-between bg-ink p-10 text-white lg:flex">
        <div className="text-[15px] font-semibold">Collections & DPD</div>
        <div>
          <p className="max-w-md text-[32px] font-semibold leading-[1.15] tracking-tight">Know where every account stands, every business day.</p>
          <div className="mt-10 flex h-12 w-full max-w-lg overflow-hidden rounded-md" aria-hidden>
            {ladder.map((w, i) => (
              <div key={i} className="h-full origin-left animate-ladder-in border-r-2 border-ink last:border-0 motion-reduce:animate-none" style={{ width: `${w}%`, background: colors[i], animationDelay: `${i * 90}ms` }} />
            ))}
          </div>
          <div className="mt-3 flex max-w-lg justify-between text-[12.5px] text-ink-300">
            <span>Current</span>
            <span>1–30</span>
            <span>31–60</span>
            <span>61–89</span>
            <span>90+</span>
          </div>
        </div>
        <p className="text-[12.5px] text-ink-300">Restricted system. Activity is logged.</p>
      </div>
      <div className="flex items-center justify-center bg-canvas px-4 py-10">
        <div className="w-full max-w-sm">{children}</div>
      </div>
    </div>
  );
}

export function LoginPage() {
  const { user, login } = useAuth();
  const nav = useNavigate();
  const loc = useLocation() as { state?: { from?: string } };
  const form = useForm<{ email: string; password: string }>({ resolver: zodResolver(z.object({ email: z.string().email('Enter a valid email'), password: z.string().min(1, 'Enter your password') })) });
  const [error, setError] = React.useState<string | null>(null);
  if (user) return <Navigate to={loc.state?.from ?? '/'} replace />;

  const submit = form.handleSubmit(async (v) => {
    setError(null);
    try {
      await login(v.email, v.password);
      nav(loc.state?.from ?? '/', { replace: true });
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not reach the server. Check your connection.');
    }
  });

  return (
    <AuthShell>
      <h1 className="text-[22px] font-semibold tracking-tight">Sign in</h1>
      <p className="mt-1 text-sm text-text-muted">Use your work email.</p>
      <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
        {error && (
          <div role="alert" className="rounded-md border border-risk/30 bg-risk-soft px-3 py-2 text-[13px] text-risk">
            {error}
          </div>
        )}
        <Field label="Email" error={form.formState.errors.email?.message}>
          <Input type="email" autoComplete="username" autoFocus {...form.register('email')} aria-invalid={!!form.formState.errors.email} />
        </Field>
        <Field label="Password" error={form.formState.errors.password?.message}>
          <Input type="password" autoComplete="current-password" {...form.register('password')} aria-invalid={!!form.formState.errors.password} />
        </Field>
        <Button type="submit" className="w-full" loading={form.formState.isSubmitting}>
          Sign in
        </Button>
        <div className="text-center">
          <Link to="/forgot-password" className="text-[13px] text-ink-500 hover:underline">
            Forgot password?
          </Link>
        </div>
      </form>
      {import.meta.env.DEV && (
        <div className="mt-8 rounded-md border border-dashed border-line bg-white p-3">
          <p className="text-xs text-text-muted">Local demo accounts (password Demo@12345). Click to fill.</p>
          <div className="mt-2 grid grid-cols-2 gap-1">
            {DEMO.map(([u, r]) => (
              <button
                key={u}
                type="button"
                className="rounded px-2 py-1 text-left text-xs hover:bg-canvas"
                onClick={() => {
                  form.setValue('email', `${u}@demo.local`);
                  form.setValue('password', 'Demo@12345');
                }}
              >
                <span className="block font-medium text-text">{r}</span>
                <span className="text-text-faint">{u}@demo.local</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </AuthShell>
  );
}

export function ForgotPasswordPage() {
  const form = useForm<{ email: string }>({ resolver: zodResolver(z.object({ email: z.string().email('Enter a valid email') })) });
  const [sent, setSent] = React.useState(false);
  const submit = form.handleSubmit(async (v) => {
    try {
      await api.post('/api/auth/forgot-password', v);
      setSent(true);
    } catch (e) {
      toast.error((e as Error).message);
    }
  });
  return (
    <AuthShell>
      <h1 className="text-[22px] font-semibold tracking-tight">Reset your password</h1>
      {sent ? (
        <p className="mt-3 text-sm text-text-muted">If that email belongs to an account, a reset link is on its way. The link works for 30 minutes.</p>
      ) : (
        <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
          <Field label="Work email" error={form.formState.errors.email?.message}>
            <Input type="email" autoFocus {...form.register('email')} />
          </Field>
          <Button type="submit" className="w-full" loading={form.formState.isSubmitting}>
            Send reset link
          </Button>
        </form>
      )}
      <Link to="/login" className="mt-6 inline-block text-[13px] text-ink-500 hover:underline">
        Back to sign in
      </Link>
    </AuthShell>
  );
}

export function ResetPasswordPage() {
  const [sp] = useSearchParams();
  const nav = useNavigate();
  const token = sp.get('token') ?? '';
  const form = useForm<{ password: string; confirm: string }>({
    resolver: zodResolver(z.object({ password: passwordRule, confirm: z.string() }).refine((v) => v.password === v.confirm, { message: 'Passwords do not match', path: ['confirm'] })),
  });
  const submit = form.handleSubmit(async (v) => {
    try {
      await api.post('/api/auth/reset-password', { token, password: v.password });
      toast.success('Password updated. Sign in with your new password.');
      nav('/login');
    } catch (e) {
      toast.error((e as Error).message);
    }
  });
  return (
    <AuthShell>
      <h1 className="text-[22px] font-semibold tracking-tight">Choose a new password</h1>
      {!token ? (
        <p className="mt-3 text-sm text-risk">This link is missing its token. Request a new reset link.</p>
      ) : (
        <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
          <Field label="New password" error={form.formState.errors.password?.message} hint="8+ characters with a letter and a digit">
            <Input type="password" autoComplete="new-password" {...form.register('password')} />
          </Field>
          <Field label="Confirm password" error={form.formState.errors.confirm?.message}>
            <Input type="password" autoComplete="new-password" {...form.register('confirm')} />
          </Field>
          <Button type="submit" className="w-full" loading={form.formState.isSubmitting}>
            Update password
          </Button>
        </form>
      )}
    </AuthShell>
  );
}

export function ProfilePage() {
  const { user, logout } = useAuth();
  const form = useForm<{ currentPassword: string; newPassword: string; confirm: string }>({
    resolver: zodResolver(z.object({ currentPassword: z.string().min(1, 'Required'), newPassword: passwordRule, confirm: z.string() }).refine((v) => v.newPassword === v.confirm, { message: 'Passwords do not match', path: ['confirm'] })),
  });
  const submit = form.handleSubmit(async (v) => {
    try {
      await api.post('/api/auth/change-password', { currentPassword: v.currentPassword, newPassword: v.newPassword });
      toast.success('Password changed. Please sign in again.');
      await logout();
    } catch (e) {
      toast.error((e as Error).message);
    }
  });
  return (
    <div className="max-w-xl">
      <PageHeader title="Your account" description={`${user?.fullName} — ${user?.roleName}`} />
      <Card>
        <CardHeader title="Change password" description="You'll be signed out of every device after changing it." />
        <form onSubmit={submit} className="space-y-4 p-5" noValidate>
          <Field label="Current password" error={form.formState.errors.currentPassword?.message}>
            <Input type="password" autoComplete="current-password" {...form.register('currentPassword')} />
          </Field>
          <Field label="New password" error={form.formState.errors.newPassword?.message} hint="8+ characters with a letter and a digit">
            <Input type="password" autoComplete="new-password" {...form.register('newPassword')} />
          </Field>
          <Field label="Confirm new password" error={form.formState.errors.confirm?.message}>
            <Input type="password" autoComplete="new-password" {...form.register('confirm')} />
          </Field>
          <Button type="submit" loading={form.formState.isSubmitting}>
            Change password
          </Button>
        </form>
      </Card>
    </div>
  );
}
