import * as React from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery } from '@tanstack/react-query';
import { BadgeIndianRupee, Ban, CheckCircle2, CircleSlash2, FileDown, Lock, Pencil, Plus, Send, Trash2 } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { cn, date, dateTime, inr, inrShort, label } from '@/lib/format';
import { applyServerErrors, useAction, useGet, useLookups, useUrlState } from '@/hooks/data';
import { Button, Card, CardHeader, Field, Input, NativeSelect, Skeleton, Textarea } from '@/components/ui/base';
import { ConfirmDialog, Dialog, DialogContent, Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/overlay';
import { DataTable, FilterSelect } from '@/components/DataTable';
import { DpdBadge, ErrorState, KeyValues, Money, PageHeader, Stat, StatGrid, StatusBadge } from '@/components/domain';
import { SimpleTable } from './customers';
import { ChartCard, Lines, SERIES } from '@/components/charts';
import { BounceDialog } from './bounces';
import { LogActivityDialog } from './collections';

const LOAN_STATUSES = ['DRAFT', 'APPROVED', 'DISBURSED', 'ACTIVE', 'OVERDUE', 'CLOSED', 'WRITTEN_OFF', 'CANCELLED'];

export function LoanRegister() {
  const { can } = useAuth();
  const nav = useNavigate();
  const [url, setUrl] = useUrlState();
  const lk = useLookups();
  return (
    <>
      <PageHeader
        title="Loan register"
        description="All loans from draft to closure, with live DPD and balances."
        actions={
          can('loans.write') && (
            <Button asChild>
              <Link to="/loans/new">
                <Plus /> New loan
              </Link>
            </Button>
          )
        }
      />
      <DataTable
        endpoint="/api/loans"
        searchPlaceholder="Loan ID, customer, mobile"
        defaultSort={{ sort: 'createdAt', order: 'desc' }}
        filters={{ status: url.status, productId: url.productId, branchId: url.branchId, bucket: url.bucket, executiveId: url.executiveId, state: url.state }}
        onRowClick={(r) => nav(`/loans/${r.id}`)}
        toolbar={
          <>
            <FilterSelect value={url.status} onChange={(v) => setUrl({ status: v })} placeholder="Any status" options={[{ value: 'LIVE', label: 'Live (disbursed, active, overdue)' }, ...LOAN_STATUSES.map((s) => ({ value: s, label: label(s) }))]} />
            <FilterSelect value={url.productId} onChange={(v) => setUrl({ productId: v })} placeholder="Any product" options={(lk.data?.products ?? []).map((p) => ({ value: p.id, label: p.name }))} />
            <FilterSelect value={url.bucket} onChange={(v) => setUrl({ bucket: v })} placeholder="Any bucket" options={(lk.data?.buckets ?? []).map((b) => ({ value: b.code, label: b.label }))} />
            <FilterSelect value={url.branchId} onChange={(v) => setUrl({ branchId: v })} placeholder="Any branch" options={(lk.data?.branches ?? []).map((b) => ({ value: b.id, label: b.name }))} />
          </>
        }
        columns={[
          { key: 'loanNumber', header: 'Loan ID', sortable: true, cell: (r) => <span className="font-medium text-ink">{r.loanNumber}</span> },
          { key: 'customerName', header: 'Customer', sortable: true },
          { key: 'productName', header: 'Product', sortable: true },
          { key: 'principalAmount', header: 'Principal', align: 'right', sortable: true, cell: (r) => <Money v={r.principalAmount} whole /> },
          { key: 'emiAmount', header: 'EMI', align: 'right', sortable: true, cell: (r) => <Money v={r.emiAmount} /> },
          { key: 'outstandingPrincipal', header: 'POS', align: 'right', sortable: true, cell: (r) => <Money v={r.outstandingPrincipal} /> },
          { key: 'overdueAmount', header: 'Overdue', align: 'right', sortable: true, cell: (r) => (r.overdueAmount > 0 ? <Money v={r.overdueAmount} className="text-risk" /> : <span className="text-text-faint">—</span>) },
          { key: 'dpd', header: 'DPD', sortable: true, cell: (r) => (r.disbursementDate ? <DpdBadge dpd={r.dpd} bucket={r.bucketCode} /> : <span className="text-text-faint">—</span>) },
          { key: 'disbursementDate', header: 'Disbursed', sortable: true, cell: (r) => date(r.disbursementDate) },
          { key: 'status', header: 'Status', sortable: true, cell: (r) => <StatusBadge status={r.status} /> },
        ]}
      />
    </>
  );
}

// ------------------------------------------------------------------ create / edit
const loanSchema = z.object({
  customerId: z.coerce.number({ invalid_type_error: 'Select a customer' }).int().positive('Select a customer'),
  productId: z.coerce.number().int().positive('Select a product'),
  branchId: z.string().optional(),
  principalAmount: z.coerce.number().positive('Enter the loan amount'),
  annualInterestRate: z.coerce.number().min(0).max(60, 'Up to 60%'),
  interestMethod: z.enum(['REDUCING', 'FLAT']),
  tenureMonths: z.coerce.number().int().min(1).max(360),
  paymentDueDay: z.coerce.number().int().min(1).max(28),
  processingFee: z.string().optional(),
});
type LoanValues = z.infer<typeof loanSchema>;

function CustomerPicker({ value, onChange, error }: { value?: number; onChange: (id: number) => void; error?: string }) {
  const [term, setTerm] = React.useState('');
  const [open, setOpen] = React.useState(false);
  const sel = useGet<any>(value ? `/api/customers/${value}` : null);
  const q = useQuery({ queryKey: ['cust-search', term], queryFn: () => api.get('/api/customers', { search: term, pageSize: 8, status: 'ACTIVE' }), enabled: term.length >= 2 });
  return (
    <Field label="Customer" required error={error}>
      <div className="relative">
        <Input
          value={open ? term : sel.data ? `${sel.data.fullName} (${sel.data.customerCode})` : term}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          onChange={(e) => setTerm(e.target.value)}
          placeholder="Search by name, ID or mobile"
          aria-label="Customer"
          aria-invalid={!!error}
        />
        {open && term.length >= 2 && (
          <div className="absolute z-20 mt-1 w-full overflow-hidden rounded-md border border-line bg-white shadow-lg">
            {(q.data?.data ?? []).map((c: any) => (
              <button
                key={c.id}
                type="button"
                className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-canvas"
                onMouseDown={() => {
                  onChange(c.id);
                  setTerm('');
                  setOpen(false);
                }}
              >
                <span>{c.fullName}</span>
                <span className="text-xs text-text-faint">
                  {c.customerCode}, {c.city}
                </span>
              </button>
            ))}
            {q.data && q.data.data.length === 0 && <div className="px-3 py-2 text-[13px] text-text-muted">No active customer matches.</div>}
          </div>
        )}
      </div>
    </Field>
  );
}

export function LoanCreate() {
  const { id } = useParams();
  const [sp] = useSearchParams();
  const nav = useNavigate();
  const lk = useLookups();
  const existing = useGet<any>(id ? `/api/loans/${id}` : null);
  const form = useForm<LoanValues>({
    resolver: zodResolver(loanSchema),
    defaultValues: { interestMethod: 'REDUCING', paymentDueDay: 5, tenureMonths: 12, customerId: Number(sp.get('customerId')) || (undefined as any) },
  });
  React.useEffect(() => {
    const l = existing.data;
    if (l)
      form.reset({
        customerId: l.customerId, productId: l.productId, branchId: l.branchId ? String(l.branchId) : '', principalAmount: l.principalAmount,
        annualInterestRate: l.annualInterestRate, interestMethod: l.interestMethod, tenureMonths: l.tenureMonths, paymentDueDay: l.paymentDueDay,
        processingFee: String(l.processingFee),
      });
  }, [existing.data, form]);
  const v = useWatch({ control: form.control });
  const product = lk.data?.products.find((p) => p.id === Number(v.productId));

  // EMI calculator preview, debounced
  const [previewArgs, setPreviewArgs] = React.useState<any>(null);
  React.useEffect(() => {
    const t = setTimeout(() => {
      if (Number(v.principalAmount) > 0 && Number(v.tenureMonths) > 0 && v.annualInterestRate !== undefined && String(v.annualInterestRate) !== '')
        setPreviewArgs({ principalAmount: Number(v.principalAmount), annualInterestRate: Number(v.annualInterestRate), tenureMonths: Number(v.tenureMonths), interestMethod: v.interestMethod });
      else setPreviewArgs(null);
    }, 300);
    return () => clearTimeout(t);
  }, [v.principalAmount, v.annualInterestRate, v.tenureMonths, v.interestMethod]);
  const preview = useQuery({ queryKey: ['emi-preview', previewArgs], queryFn: () => api.post('/api/loans/preview-schedule', previewArgs), enabled: !!previewArgs });

  const save = useAction(
    (val: LoanValues) => {
      const body = { ...val, branchId: val.branchId ? Number(val.branchId) : null, processingFee: val.processingFee ? Number(val.processingFee) : undefined };
      return id ? api.put(`/api/loans/${id}`, body) : api.post('/api/loans', body);
    },
    { success: (r: any) => `Loan ${r.loanNumber} saved as draft`, onSuccess: (r: any) => nav(`/loans/${r.id}`) },
  );
  const e = form.formState.errors;
  const applyProduct = (pid: string) => {
    const p = lk.data?.products.find((x) => x.id === Number(pid));
    if (p) {
      form.setValue('annualInterestRate', p.defaultRate);
      form.setValue('interestMethod', p.code === 'CD' ? 'FLAT' : 'REDUCING');
    }
  };
  const fee = product && Number(v.principalAmount) > 0 ? Math.round(Number(v.principalAmount) * product.processingFeePct) / 100 : null;

  return (
    <div className="max-w-6xl">
      <PageHeader back={{ to: id ? `/loans/${id}` : '/loans', label: id ? 'Loan' : 'Loan register' }} title={id ? `Edit ${existing.data?.loanNumber ?? 'loan'}` : 'New loan'} description="Saved as a draft. Approval and disbursement are separate steps." />
      <form onSubmit={form.handleSubmit((val) => save.mutate(val, { onError: (err) => applyServerErrors(err, form.setError) }))} noValidate className="grid gap-5 lg:grid-cols-[1fr_400px]">
        <Card>
          <CardHeader title="Terms" />
          <div className="grid gap-4 p-5 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <CustomerPicker value={Number(v.customerId) || undefined} onChange={(cid) => form.setValue('customerId', cid, { shouldValidate: true })} error={e.customerId?.message} />
            </div>
            <Field label="Product" required error={e.productId?.message}>
              <NativeSelect {...form.register('productId', { onChange: (ev) => applyProduct(ev.target.value) })}>
                <option value="">Select product</option>
                {lk.data?.products.filter((p) => p.isActive).map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </NativeSelect>
            </Field>
            <Field label="Branch">
              <NativeSelect {...form.register('branchId')}>
                <option value="">No branch</option>
                {lk.data?.branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </NativeSelect>
            </Field>
            <Field label="Principal (₹)" required error={e.principalAmount?.message} hint={product ? `${inr(product.minAmount, true)} to ${inr(product.maxAmount, true)}` : undefined}>
              <Input type="number" step="0.01" min={0} {...form.register('principalAmount')} aria-invalid={!!e.principalAmount} />
            </Field>
            <Field label="Annual interest rate (%)" required error={e.annualInterestRate?.message}>
              <Input type="number" step="0.001" min={0} {...form.register('annualInterestRate')} />
            </Field>
            <Field label="Interest method">
              <NativeSelect {...form.register('interestMethod')}>
                <option value="REDUCING">Reducing balance</option>
                <option value="FLAT">Flat</option>
              </NativeSelect>
            </Field>
            <Field label="Tenure (months)" required error={e.tenureMonths?.message} hint={product ? `${product.minTenureMonths}–${product.maxTenureMonths} months` : undefined}>
              <Input type="number" min={1} {...form.register('tenureMonths')} />
            </Field>
            <Field label="EMI due day" hint="Day 1–28 of each month" error={e.paymentDueDay?.message}>
              <Input type="number" min={1} max={28} {...form.register('paymentDueDay')} />
            </Field>
            <Field label="Processing fee (₹)" hint={fee !== null ? `Product default ${inr(fee)}` : 'Leave blank for the product default'}>
              <Input type="number" step="0.01" min={0} {...form.register('processingFee')} />
            </Field>
          </div>
          <div className="flex justify-end gap-2 border-t border-line px-5 py-3">
            <Button type="button" variant="secondary" onClick={() => history.back()}>
              Cancel
            </Button>
            <Button type="submit" loading={save.isPending}>
              Save draft
            </Button>
          </div>
        </Card>

        <Card className="self-start">
          <CardHeader title="EMI calculator" description="Reducing-balance EMI, rounded to the rupee; the last installment absorbs rounding." />
          {!previewArgs ? (
            <p className="p-5 text-[13px] text-text-muted">Enter amount, rate and tenure to see the repayment plan.</p>
          ) : preview.isError ? (
            <div className="p-4">
              <ErrorState error={preview.error} />
            </div>
          ) : !preview.data ? (
            <Skeleton className="m-5 h-40" />
          ) : (
            <>
              <div className="grid grid-cols-3 gap-px border-b border-line bg-line">
                <Stat label="Monthly EMI" value={inr(preview.data.emi, true)} />
                <Stat label="Total interest" value={inrShort(preview.data.totalInterest)} />
                <Stat label="Total payable" value={inrShort(preview.data.totalPayable)} />
              </div>
              <div className="max-h-[380px] overflow-y-auto">
                <table className="w-full text-[13px]">
                  <thead className="sticky top-0 bg-canvas text-text-muted">
                    <tr>
                      <th className="px-3 py-1.5 text-left font-medium">#</th>
                      <th className="px-3 py-1.5 text-right font-medium">Principal</th>
                      <th className="px-3 py-1.5 text-right font-medium">Interest</th>
                      <th className="px-3 py-1.5 text-right font-medium">Balance</th>
                    </tr>
                  </thead>
                  <tbody className="tabular-nums">
                    {preview.data.rows.map((r: any) => (
                      <tr key={r.installmentNo} className="border-t border-line/60">
                        <td className="px-3 py-1">{r.installmentNo}</td>
                        <td className="px-3 py-1 text-right">{inr(r.principal)}</td>
                        <td className="px-3 py-1 text-right">{inr(r.interest)}</td>
                        <td className="px-3 py-1 text-right">{inr(r.closingPrincipal)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </Card>
      </form>
    </div>
  );
}

// ------------------------------------------------------------------ detail
export function LoanDetail() {
  const { id } = useParams();
  const { can, user } = useAuth();
  const nav = useNavigate();
  const loan = useGet<any>(`/api/loans/${id}`);
  const [dialog, setDialog] = React.useState<null | 'approve' | 'cancel' | 'disburse' | 'close' | 'writeoff' | 'bounce' | 'activity'>(null);
  if (loan.isError) return <ErrorState error={loan.error} onRetry={() => loan.refetch()} />;
  if (!loan.data) return <Skeleton className="h-96 w-full" />;
  const l = loan.data;
  const live = ['DISBURSED', 'ACTIVE', 'OVERDUE'].includes(l.status);
  const o = l.outstanding;

  return (
    <>
      <PageHeader
        back={{ to: '/loans', label: 'Loan register' }}
        title={
          <span className="flex flex-wrap items-center gap-3">
            {l.loanNumber}
            <StatusBadge status={l.status} className="text-[13px]" />
            {l.disbursementDate && live && <DpdBadge dpd={l.dpd} bucket={l.bucketCode} />}
          </span>
        }
        description={
          <>
            <Link to={`/customers/${l.customerId}`} className="text-ink-500 hover:underline">
              {l.customerName}
            </Link>{' '}
            ({l.customerCode}), {l.productName}
            {l.executiveName ? `, with ${l.executiveName}` : ''}
          </>
        }
        actions={
          <>
            {l.status === 'DRAFT' && can('loans.write') && (
              <Button variant="secondary" asChild>
                <Link to={`/loans/${id}/edit`}>
                  <Pencil /> Edit
                </Link>
              </Button>
            )}
            {l.status === 'DRAFT' && can('loans.approve') && (
              <Button onClick={() => setDialog('approve')}>
                <CheckCircle2 /> Approve
              </Button>
            )}
            {l.status === 'APPROVED' && can('loans.disburse') && (
              <Button onClick={() => setDialog('disburse')}>
                <Send /> Disburse
              </Button>
            )}
            {['DRAFT', 'APPROVED'].includes(l.status) && can('loans.approve') && (
              <Button variant="secondary" onClick={() => setDialog('cancel')}>
                <Ban /> Cancel loan
              </Button>
            )}
            {(live || l.status === 'WRITTEN_OFF') && can('payments.write') && (
              <Button asChild>
                <Link to={`/payments/new?loanId=${id}`}>
                  <BadgeIndianRupee /> Record payment
                </Link>
              </Button>
            )}
            {live && can('bounces.write') && (
              <Button variant="secondary" onClick={() => setDialog('bounce')}>
                <CircleSlash2 /> Record bounce
              </Button>
            )}
            {live && can('collections.write') && (
              <Button variant="secondary" onClick={() => setDialog('activity')}>
                Log activity
              </Button>
            )}
            {(live || l.status === 'WRITTEN_OFF') && can('loans.close') && (
              <Button variant="secondary" onClick={() => setDialog('close')}>
                <Lock /> Close
              </Button>
            )}
            {l.status === 'OVERDUE' && l.dpd >= 90 && can('loans.write_off') && (
              <Button variant="danger" onClick={() => setDialog('writeoff')}>
                <Trash2 /> Write off
              </Button>
            )}
          </>
        }
      />

      {l.disbursementDate && o && (
        <StatGrid className="mb-5 grid-cols-2 md:grid-cols-3 xl:grid-cols-6">
          <Stat label="Outstanding principal" value={inr(o.outstandingPrincipal)} sub={`of ${inr(l.principalAmount, true)}`} />
          <Stat label="Overdue EMI" value={inr(l.overdueAmount)} sub={`${l.overdueEmiCount} installment(s)`} tone={l.overdueAmount > 0 ? 'risk' : undefined} />
          <Stat label="Open charges" value={inr(o.chargesOutstanding)} tone={o.chargesOutstanding > 0 ? 'due' : undefined} />
          <Stat label="Total outstanding" value={inr(o.totalOutstanding)} sub="All future EMIs + charges" />
          <Stat label="Next EMI" value={l.nextEmiDueDate ? inr(l.nextEmiAmount) : '—'} sub={l.nextEmiDueDate ? `due ${date(l.nextEmiDueDate)}` : 'No more installments'} />
          <Stat label="Last payment" value={date(l.lastPaymentDate)} sub={`${l.paymentCount} successful, ${l.bounceCount} bounce(s)`} />
        </StatGrid>
      )}

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          {l.disbursementDate && <TabsTrigger value="schedule">Repayment schedule</TabsTrigger>}
          {l.disbursementDate && can('payments.read') && <TabsTrigger value="payments">Payments</TabsTrigger>}
          {l.disbursementDate && <TabsTrigger value="ledger">Ledger</TabsTrigger>}
          {l.disbursementDate && can('bounces.read') && <TabsTrigger value="bounces">Bounces</TabsTrigger>}
          {l.disbursementDate && can('dpd.read') && <TabsTrigger value="dpd">DPD history</TabsTrigger>}
          {l.disbursementDate && can('collections.read') && <TabsTrigger value="collections">Collections</TabsTrigger>}
          <TabsTrigger value="history">Audit history</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <OverviewTab l={l} canWaive={can('loans.waive')} />
        </TabsContent>
        <TabsContent value="schedule">
          <ScheduleTab loanId={l.id} canWaive={can('loans.waive') && (live || l.status === 'WRITTEN_OFF')} />
        </TabsContent>
        <TabsContent value="payments">
          <LoanPaymentsTab loanId={l.id} onOpen={(pid) => nav(`/payments/${pid}`)} />
        </TabsContent>
        <TabsContent value="ledger">
          <LedgerTab loanId={l.id} />
        </TabsContent>
        <TabsContent value="bounces">
          <LoanBouncesTab loanId={l.id} />
        </TabsContent>
        <TabsContent value="dpd">
          <DpdHistoryTab loanId={l.id} />
        </TabsContent>
        <TabsContent value="collections">
          <LoanCollectionsTab loanId={l.id} />
        </TabsContent>
        <TabsContent value="history">
          <HistoryTab loanId={l.id} />
        </TabsContent>
      </Tabs>

      <ApproveDialog open={dialog === 'approve'} onClose={() => setDialog(null)} loan={l} />
      <CancelDialog open={dialog === 'cancel'} onClose={() => setDialog(null)} loan={l} />
      <DisburseDialog open={dialog === 'disburse'} onClose={() => setDialog(null)} loan={l} businessDate={user!.businessDate} />
      <CloseDialog open={dialog === 'close'} onClose={() => setDialog(null)} loan={l} />
      <WriteOffDialog open={dialog === 'writeoff'} onClose={() => setDialog(null)} loan={l} />
      {dialog === 'bounce' && <BounceDialog open onClose={() => setDialog(null)} loanId={l.id} />}
      {dialog === 'activity' && <LogActivityDialog open onClose={() => setDialog(null)} loanId={l.id} />}
    </>
  );
}

function OverviewTab({ l, canWaive }: { l: any; canWaive: boolean }) {
  const [waive, setWaive] = React.useState<any>(null);
  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
      <Card>
        <CardHeader title="Loan terms" />
        <div className="p-5">
          <KeyValues
            items={[
              ['Principal', inr(l.principalAmount)],
              ['Interest', `${l.annualInterestRate}% p.a., ${label(l.interestMethod)}`],
              ['Tenure', `${l.tenureMonths} months, ${label(l.repaymentFrequency)}`],
              ['EMI', inr(l.emiAmount)],
              ['Total interest', inr(l.totalInterest)],
              ['Total payable', inr(l.totalPayable)],
              ['Processing fee', inr(l.processingFee)],
              ['Due day', l.paymentDueDay],
              ['Branch', l.branchName],
              ['Disbursed', l.disbursementDate ? `${date(l.disbursementDate)} by ${l.disbursedByName ?? '—'}` : '—'],
              ['First EMI', date(l.firstEmiDate)],
              ['Maturity', date(l.maturityDate)],
              ['Created by', l.createdByName],
              ['Approved', l.approvedAt ? `${dateTime(l.approvedAt)} by ${l.approvedByName}` : '—'],
              ['Closed', l.closedAt ? dateTime(l.closedAt) : '—'],
            ]}
          />
          {l.closureRemarks && <p className="mt-4 rounded-md bg-canvas px-3 py-2 text-[13px] text-text-muted">Remarks: {l.closureRemarks}</p>}
        </div>
      </Card>
      <div className="space-y-5">
        {l.outstanding && (
          <Card>
            <CardHeader title="Balance breakdown" />
            <div className="divide-y divide-line text-sm">
              {[
                ['Principal repaid', l.outstanding.principalPaid],
                ['Interest received', l.outstanding.interestPaid],
                ['Overdue principal', l.outstanding.overduePrincipal],
                ['Overdue interest', l.outstanding.overdueInterest],
                ['Installments waived', l.outstanding.emiWaived],
                ['Charges outstanding', l.outstanding.chargesOutstanding],
              ].map(([k, v]) => (
                <div key={k as string} className="flex justify-between px-5 py-2">
                  <span className="text-text-muted">{k}</span>
                  <Money v={v} />
                </div>
              ))}
            </div>
          </Card>
        )}
        <Card>
          <CardHeader title="Charges" description="Bounce and other charges, tracked apart from EMIs." />
          {l.charges.length === 0 ? (
            <p className="px-5 py-4 text-[13px] text-text-muted">No charges on this loan.</p>
          ) : (
            <div className="divide-y divide-line text-sm">
              {l.charges.map((c: any) => (
                <div key={c.id} className="flex items-center justify-between gap-2 px-5 py-2.5">
                  <div>
                    <div className="font-medium">{label(c.chargeType)} charge</div>
                    <div className="text-xs text-text-faint">
                      {date(c.chargeDate)}, paid {inr(c.paidAmount)}, waived {inr(c.waivedAmount)}
                    </div>
                  </div>
                  <div className="text-right">
                    <Money v={c.remainingAmount} className={c.remainingAmount > 0 ? 'font-medium text-[#A85508]' : 'text-text-faint'} />
                    <div>
                      <StatusBadge status={c.status} />
                    </div>
                    {canWaive && c.remainingAmount > 0 && (
                      <button className="mt-1 text-xs text-ink-500 hover:underline" onClick={() => setWaive({ target: 'CHARGE', id: c.id, max: c.remainingAmount })}>
                        Waive
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
      {waive && <WaiveDialog loanId={l.id} target={waive} onClose={() => setWaive(null)} />}
    </div>
  );
}

function ScheduleTab({ loanId, canWaive }: { loanId: number; canWaive: boolean }) {
  const q = useGet<any[]>(`/api/loans/${loanId}/emi-schedule`);
  const [waive, setWaive] = React.useState<any>(null);
  const rows = q.data ?? [];
  const sum = (k: string) => rows.reduce((s, r) => s + Number(r[k]), 0);
  return (
    <>
      <div className="mb-2 flex justify-end">
        <Button variant="secondary" size="sm" onClick={() => api.download('/api/emi-schedules', { loanId, format: 'xlsx', pageSize: 500 }).catch((e) => alert(e.message))}>
          <FileDown /> Download schedule
        </Button>
      </div>
      <SimpleTable
        rows={rows}
        loading={q.isLoading}
        empty="No schedule generated."
        cols={[
          ['#', (r) => r.installmentNo],
          ['Due date', (r) => date(r.dueDate)],
          ['Opening', (r) => inr(r.openingPrincipal), true],
          ['Principal', (r) => inr(r.principalComponent), true],
          ['Interest', (r) => inr(r.interestComponent), true],
          ['EMI', (r) => inr(r.emiAmount), true],
          ['Paid', (r) => inr(r.amountPaid), true],
          ['Remaining', (r) => <span className={r.remainingAmount > 0 && r.status !== 'UPCOMING' ? 'font-medium text-risk' : ''}>{inr(r.remainingAmount)}</span>, true],
          ['Status', (r) => <StatusBadge status={r.status} />],
          ['DPD', (r) => (r.dpd > 0 ? <DpdBadge dpd={r.dpd} /> : '')],
          ['Last paid', (r) => date(r.lastPaymentDate)],
          ['', (r) => (canWaive && r.remainingAmount > 0 && r.status !== 'UPCOMING' ? <button className="text-xs text-ink-500 hover:underline" onClick={() => setWaive({ target: 'EMI', id: r.id, max: r.remainingAmount, no: r.installmentNo })}>Waive</button> : null)],
        ]}
        footer={
          rows.length > 0 && (
            <tfoot>
              <tr className="border-t-2 border-line bg-canvas/60 font-semibold tabular-nums">
                <td className="px-3 py-2" colSpan={3}>
                  Total
                </td>
                <td className="px-3 py-2 text-right">{inr(sum('principalComponent'))}</td>
                <td className="px-3 py-2 text-right">{inr(sum('interestComponent'))}</td>
                <td className="px-3 py-2 text-right">{inr(sum('emiAmount'))}</td>
                <td className="px-3 py-2 text-right">{inr(sum('amountPaid'))}</td>
                <td className="px-3 py-2 text-right">{inr(sum('remainingAmount'))}</td>
                <td colSpan={4} />
              </tr>
            </tfoot>
          )
        }
      />
      {waive && <WaiveDialog loanId={loanId} target={waive} onClose={() => setWaive(null)} />}
    </>
  );
}

function LoanPaymentsTab({ loanId, onOpen }: { loanId: number; onOpen: (id: number) => void }) {
  const q = useGet<any[]>(`/api/loans/${loanId}/payments`);
  return (
    <SimpleTable
      rows={q.data}
      loading={q.isLoading}
      onRowClick={(r) => onOpen(r.id)}
      empty="No payments recorded yet."
      cols={[
        ['Payment', (r) => <span className="font-medium text-ink">{r.paymentNumber}</span>],
        ['Date', (r) => date(r.paymentDate)],
        ['Mode', (r) => r.paymentMode],
        ['Reference', (r) => r.transactionReference ?? '—'],
        ['Amount', (r) => inr(r.amount), true],
        [
          'Allocated to',
          (r) => (
            <span className="text-xs text-text-muted">
              {r.allocations.length === 0
                ? '—'
                : r.allocations
                    .map((a: any) => `${a.installmentNo ? `EMI ${a.installmentNo}` : 'Charge'} ${a.component === 'CHARGE' ? '' : a.component.toLowerCase()}${a.isAdvance ? ' (advance)' : ''}`)
                    .slice(0, 4)
                    .join(', ') + (r.allocations.length > 4 ? '…' : '')}
            </span>
          ),
        ],
        ['Status', (r) => <StatusBadge status={r.status} />],
        ['By', (r) => r.collectedByName ?? '—'],
      ]}
    />
  );
}

function LedgerTab({ loanId }: { loanId: number }) {
  const q = useGet<any[]>(`/api/loans/${loanId}/ledger`);
  const rows = q.data ?? [];
  const last = rows.at(-1);
  return (
    <>
      <p className="mb-2 text-[13px] text-text-muted">
        Debits are installments and charges as they fall due; credits are money received. A positive closing balance is the amount currently due; negative means paid in advance.
      </p>
      <SimpleTable
        rows={rows.map((r, i) => ({ ...r, id: i }))}
        loading={q.isLoading}
        empty="No ledger entries yet."
        cols={[
          ['Date', (r) => date(r.entryDate)],
          ['Type', (r) => label(r.entryType)],
          ['Reference', (r) => r.reference],
          ['Particulars', (r) => <span className="block max-w-sm truncate">{r.particulars}</span>],
          ['Debit', (r) => (r.debit ? inr(r.debit) : ''), true],
          ['Credit', (r) => (r.credit ? <span className="text-paid">{inr(r.credit)}</span> : ''), true],
          ['Balance', (r) => <span className={cn(r.balance > 0 && 'text-risk')}>{inr(r.balance)}</span>, true],
        ]}
        footer={
          last && (
            <tfoot>
              <tr className="border-t-2 border-line bg-canvas/60 font-semibold">
                <td className="px-3 py-2" colSpan={6}>
                  Closing balance
                </td>
                <td className="px-3 py-2 text-right tabular-nums">{inr(last.balance)}</td>
              </tr>
            </tfoot>
          )
        }
      />
    </>
  );
}

function LoanBouncesTab({ loanId }: { loanId: number }) {
  const q = useGet<any[]>(`/api/loans/${loanId}/bounces`);
  return (
    <SimpleTable
      rows={q.data}
      loading={q.isLoading}
      empty="No bounces on this loan."
      cols={[
        ['Bounce', (r) => r.bounceNumber],
        ['Date', (r) => date(r.bounceDate)],
        ['EMI #', (r) => r.installmentNo ?? '—'],
        ['Payment', (r) => r.paymentNumber ?? '—'],
        ['Reason', (r) => label(r.bounceReason)],
        ['Amount', (r) => inr(r.bounceAmount), true],
        ['Charge', (r) => inr(r.bounceCharges), true],
        ['Recovery', (r) => <StatusBadge status={r.recoveryStatus} />],
        ['Resolved', (r) => date(r.resolutionDate)],
      ]}
    />
  );
}

function DpdHistoryTab({ loanId }: { loanId: number }) {
  const q = useGet<any[]>(`/api/loans/${loanId}/dpd-history`);
  const data = [...(q.data ?? [])].reverse().map((d) => ({ ...d, day: d.businessDate.slice(5) }));
  return (
    <div className="space-y-4">
      <ChartCard title="Days past due over time" description="One point per nightly snapshot" loading={q.isLoading} height={220}>
        <Lines data={data} x="day" series={[{ key: 'dpd', name: 'DPD', color: SERIES.red }]} />
      </ChartCard>
      <SimpleTable
        rows={(q.data ?? []).slice(0, 60).map((r) => ({ ...r, id: r.businessDate }))}
        loading={q.isLoading}
        empty="No snapshots yet. They appear after the nightly DPD job runs."
        cols={[
          ['Business date', (r) => date(r.businessDate)],
          ['DPD', (r) => <DpdBadge dpd={r.dpd} bucket={r.bucketCode} />],
          ['Overdue EMIs', (r) => r.overdueEmiCount],
          ['Overdue', (r) => inr(r.overdueAmount), true],
          ['POS', (r) => inr(r.outstandingPrincipal), true],
          ['Status', (r) => <StatusBadge status={r.accountStatus} />],
        ]}
      />
    </div>
  );
}

function LoanCollectionsTab({ loanId }: { loanId: number }) {
  const acts = useGet<any>('/api/collections/activities', { loanId, pageSize: 100 });
  const ptps = useGet<any>('/api/collections/ptp', { loanId, pageSize: 50 });
  return (
    <div className="space-y-5">
      <SimpleTable
        rows={ptps.data?.data}
        loading={ptps.isLoading}
        empty="No promises to pay."
        cols={[
          ['Promised on', (r) => date(r.promisedOn)],
          ['Pay by', (r) => date(r.promisedDate)],
          ['Promised', (r) => inr(r.promisedAmount), true],
          ['Paid', (r) => inr(r.keptAmount), true],
          ['Status', (r) => <StatusBadge status={r.status} />],
          ['Executive', (r) => r.executiveName],
        ]}
      />
      <SimpleTable
        rows={acts.data?.data}
        loading={acts.isLoading}
        empty="No collection activity logged."
        cols={[
          ['Date', (r) => date(r.activityDate)],
          ['Type', (r) => label(r.activityType)],
          ['Result', (r) => label(r.contactResult)],
          ['Executive', (r) => r.executiveName],
          ['Next follow-up', (r) => date(r.nextFollowUpDate)],
          ['Notes', (r) => <span className="block max-w-md truncate">{r.notes ?? '—'}</span>],
        ]}
      />
    </div>
  );
}

function HistoryTab({ loanId }: { loanId: number }) {
  const q = useGet<any[]>(`/api/loans/${loanId}/history`);
  return (
    <SimpleTable
      rows={q.data}
      loading={q.isLoading}
      empty="No history."
      cols={[
        ['When', (r) => dateTime(r.createdAt)],
        ['Who', (r) => r.userName ?? 'System'],
        ['Action', (r) => label(r.action)],
        [
          'Change',
          (r) => (
            <span className="block max-w-xl truncate text-xs text-text-muted" title={JSON.stringify(r.newValues)}>
              {r.action === 'WAIVER'
                ? `${r.entityType} waiver ${inr(r.newValues?.amount)}: ${r.newValues?.reason}`
                : Object.entries(r.newValues ?? {})
                    .filter(([k]) => k !== 'id')
                    .map(([k, v]) => `${k}: ${r.oldValues?.[k] !== undefined ? `${r.oldValues[k]} → ` : ''}${v}`)
                    .join('; ')}
            </span>
          ),
        ],
      ]}
    />
  );
}

// ------------------------------------------------------------------ dialogs
function ApproveDialog({ open, onClose, loan }: { open: boolean; onClose: () => void; loan: any }) {
  const a = useAction(() => api.post(`/api/loans/${loan.id}/approve`), { success: `Loan ${loan.loanNumber} approved`, onSuccess: onClose });
  return (
    <ConfirmDialog open={open} onOpenChange={(o) => !o && onClose()} title={`Approve ${loan.loanNumber}?`} description={`${inr(loan.principalAmount, true)} at ${loan.annualInterestRate}% for ${loan.tenureMonths} months. Terms can't be edited after approval.`} confirmLabel="Approve loan" loading={a.isPending} onConfirm={() => a.mutate(undefined)} />
  );
}

function CancelDialog({ open, onClose, loan }: { open: boolean; onClose: () => void; loan: any }) {
  const [remarks, setRemarks] = React.useState('');
  const a = useAction(() => api.post(`/api/loans/${loan.id}/cancel`, { remarks }), { success: 'Loan cancelled', onSuccess: onClose });
  return (
    <ConfirmDialog open={open} onOpenChange={(o) => !o && onClose()} title={`Cancel ${loan.loanNumber}?`} description="Cancelled loans can't be reopened." confirmLabel="Cancel loan" danger loading={a.isPending} onConfirm={() => a.mutate(undefined)}>
      <Field label="Reason" required>
        <Textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Why is this loan being cancelled?" />
      </Field>
    </ConfirmDialog>
  );
}

function DisburseDialog({ open, onClose, loan, businessDate }: { open: boolean; onClose: () => void; loan: any; businessDate: string }) {
  const [d, setD] = React.useState(businessDate);
  const [first, setFirst] = React.useState('');
  const a = useAction(() => api.post(`/api/loans/${loan.id}/disburse`, { disbursementDate: d, firstEmiDate: first || null }), {
    success: (r: any) => `Disbursed. First EMI ${inr(r.emiAmount)} on ${date(r.firstEmiDate)}`,
    onSuccess: onClose,
  });
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent title={`Disburse ${loan.loanNumber}`} description="Disbursement generates the full repayment schedule in the same transaction.">
        <div className="space-y-4">
          <Field label="Disbursement date" required hint="Can't be after the business date">
            <Input type="date" value={d} max={businessDate} onChange={(e) => setD(e.target.value)} />
          </Field>
          <Field label="First EMI date" hint={`Leave blank: next day ${loan.paymentDueDay} at least 15 days out`}>
            <Input type="date" value={first} onChange={(e) => setFirst(e.target.value)} />
          </Field>
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button loading={a.isPending} onClick={() => a.mutate(undefined)}>
              Disburse {inr(loan.principalAmount, true)}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CloseDialog({ open, onClose, loan }: { open: boolean; onClose: () => void; loan: any }) {
  const [remarks, setRemarks] = React.useState('');
  const due = loan.outstanding?.totalOutstanding ?? 0;
  const a = useAction(() => api.post(`/api/loans/${loan.id}/close`, { remarks: remarks || undefined }), { success: `Loan ${loan.loanNumber} closed`, onSuccess: onClose });
  return (
    <ConfirmDialog
      open={open}
      onOpenChange={(o) => !o && onClose()}
      title={`Close ${loan.loanNumber}?`}
      description={due > 0 ? `${inr(due)} is still outstanding. Collect or formally waive it first; closure will be refused otherwise.` : 'Every installment and charge is settled. Closing ends collections on this account.'}
      confirmLabel="Close loan"
      loading={a.isPending}
      onConfirm={() => a.mutate(undefined)}
    >
      <Field label="Remarks">
        <Textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="e.g. Foreclosed by customer" />
      </Field>
    </ConfirmDialog>
  );
}

function WriteOffDialog({ open, onClose, loan }: { open: boolean; onClose: () => void; loan: any }) {
  const [remarks, setRemarks] = React.useState('');
  const a = useAction(() => api.post(`/api/loans/${loan.id}/write-off`, { remarks }), { success: 'Loan written off', onSuccess: onClose });
  return (
    <ConfirmDialog open={open} onOpenChange={(o) => !o && onClose()} title={`Write off ${loan.loanNumber}?`} description={`${inr(loan.outstandingPrincipal)} principal leaves the live book. Recoveries can still be posted.`} confirmLabel="Write off" danger loading={a.isPending} onConfirm={() => a.mutate(undefined)}>
      <Field label="Reason" required>
        <Textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} />
      </Field>
    </ConfirmDialog>
  );
}

function WaiveDialog({ loanId, target, onClose }: { loanId: number; target: { target: 'EMI' | 'CHARGE'; id: number; max: number; no?: number }; onClose: () => void }) {
  const [amount, setAmount] = React.useState(String(target.max));
  const [reason, setReason] = React.useState('');
  const a = useAction(() => api.post(`/api/loans/${loanId}/waive`, { target: target.target, targetId: target.id, amount: target.target === 'CHARGE' ? Number(amount) : undefined, reason }), { success: 'Waiver recorded', onSuccess: onClose });
  return (
    <ConfirmDialog
      open
      onOpenChange={(o) => !o && onClose()}
      title={target.target === 'EMI' ? `Waive installment ${target.no}?` : 'Waive charge?'}
      description={target.target === 'EMI' ? `The remaining ${inr(target.max)} of this installment is waived. This is audited and appears on the ledger.` : 'Waive part or all of this charge. This is audited and appears on the ledger.'}
      confirmLabel="Record waiver"
      loading={a.isPending}
      onConfirm={() => a.mutate(undefined)}
    >
      <div className="space-y-3">
        {target.target === 'CHARGE' && (
          <Field label="Amount (₹)" hint={`Up to ${inr(target.max)}`}>
            <Input type="number" step="0.01" max={target.max} value={amount} onChange={(e) => setAmount(e.target.value)} />
          </Field>
        )}
        <Field label="Reason" required>
          <Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Approval reference and reason" />
        </Field>
      </div>
    </ConfirmDialog>
  );
}

