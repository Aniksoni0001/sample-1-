import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { addDays, date, label } from '@/lib/format';
import { useLookups, useUrlState } from '@/hooks/data';
import { Input } from '@/components/ui/base';
import { DataTable, FilterSelect } from '@/components/DataTable';
import { DpdBadge, Money, PageHeader, StatusBadge } from '@/components/domain';

export default function EmiSchedulePage() {
  const nav = useNavigate();
  const { user } = useAuth();
  const lk = useLookups();
  const [url, setUrl] = useUrlState();
  const bd = user!.businessDate;
  // default view: the next 30 days of installments
  const from = url.dueFrom ?? (url.loanId || url.customerId ? undefined : bd);
  const to = url.dueTo ?? (url.loanId || url.customerId ? undefined : addDays(bd, 30));
  return (
    <>
      <PageHeader title="EMI schedule" description="Installments across all loans. Narrow by loan, customer, due date or payment status." />
      <DataTable
        endpoint="/api/emi-schedules"
        searchPlaceholder="Loan ID or customer"
        defaultSort={{ sort: 'dueDate', order: 'asc' }}
        filters={{ dueFrom: from, dueTo: to, status: url.status, productId: url.productId, loanId: url.loanId, customerId: url.customerId }}
        onRowClick={(r) => nav(`/loans/${r.loanId}`)}
        toolbar={
          <>
            <Input type="date" className="h-9 w-[150px]" value={from ?? ''} onChange={(e) => setUrl({ dueFrom: e.target.value })} aria-label="Due from" />
            <span className="text-text-faint">to</span>
            <Input type="date" className="h-9 w-[150px]" value={to ?? ''} onChange={(e) => setUrl({ dueTo: e.target.value })} aria-label="Due to" />
            <FilterSelect value={url.status} onChange={(v) => setUrl({ status: v })} placeholder="Any status" options={['UPCOMING', 'DUE', 'PARTIALLY_PAID', 'PAID', 'OVERDUE', 'BOUNCED', 'WAIVED'].map((s) => ({ value: s, label: label(s) }))} />
            <FilterSelect value={url.productId} onChange={(v) => setUrl({ productId: v })} placeholder="Any product" options={(lk.data?.products ?? []).map((p) => ({ value: p.id, label: p.name }))} />
          </>
        }
        columns={[
          { key: 'loanNumber', header: 'Loan', sortable: true, cell: (r) => <span className="font-medium text-ink">{r.loanNumber}</span> },
          { key: 'customerName', header: 'Customer', sortable: true },
          { key: 'installmentNo', header: 'EMI #', align: 'right' },
          { key: 'dueDate', header: 'Due', sortable: true, cell: (r) => date(r.dueDate) },
          { key: 'principalComponent', header: 'Principal', align: 'right', cell: (r) => <Money v={r.principalComponent} /> },
          { key: 'interestComponent', header: 'Interest', align: 'right', cell: (r) => <Money v={r.interestComponent} /> },
          { key: 'emiAmount', header: 'EMI', align: 'right', sortable: true, cell: (r) => <Money v={r.emiAmount} /> },
          { key: 'amountPaid', header: 'Paid', align: 'right', cell: (r) => <Money v={r.amountPaid} /> },
          { key: 'remainingAmount', header: 'Remaining', align: 'right', sortable: true, cell: (r) => <Money v={r.remainingAmount} className={r.remainingAmount > 0 && r.dueDate < bd ? 'text-risk' : ''} /> },
          { key: 'status', header: 'Status', sortable: true, cell: (r) => <StatusBadge status={r.status} /> },
          { key: 'dpd', header: 'DPD', sortable: true, cell: (r) => (r.dpd > 0 ? <DpdBadge dpd={r.dpd} /> : '') },
        ]}
      />
    </>
  );
}
