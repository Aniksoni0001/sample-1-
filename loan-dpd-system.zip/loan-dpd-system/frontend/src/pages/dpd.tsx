import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { addDays, cn, date, inr, inrShort, label, num, pct } from '@/lib/format';
import { useLookups, useUrlState } from '@/hooks/data';
import { Card, CardHeader, Input, Skeleton } from '@/components/ui/base';
import { DataTable, FilterSelect } from '@/components/DataTable';
import { DpdBadge, DpdLadder, ErrorState, Money, PageHeader, Stat, StatGrid, StatusBadge, bucketColor } from '@/components/domain';
import { ChartCard, Lines } from '@/components/charts';

function PortfolioFilters({ url, setUrl, withBucket, withDate = true }: { url: any; setUrl: any; withBucket?: boolean; withDate?: boolean }) {
  const lk = useLookups();
  const { user } = useAuth();
  return (
    <>
      {withDate && (
        <Input type="date" className="h-9 w-[150px]" value={url.businessDate ?? user!.businessDate} max={user!.businessDate} onChange={(e) => setUrl({ businessDate: e.target.value === user!.businessDate ? undefined : e.target.value })} aria-label="Business date" title="Business date (past dates read the immutable snapshot)" />
      )}
      <FilterSelect value={url.productId} onChange={(v) => setUrl({ productId: v })} placeholder="All products" options={(lk.data?.products ?? []).map((p) => ({ value: p.id, label: p.name }))} />
      <FilterSelect value={url.branchId} onChange={(v) => setUrl({ branchId: v })} placeholder="All branches" options={(lk.data?.branches ?? []).map((b) => ({ value: b.id, label: b.name }))} />
      <FilterSelect value={url.executiveId} onChange={(v) => setUrl({ executiveId: v })} placeholder="All executives" options={(lk.data?.executives ?? []).map((e) => ({ value: e.id, label: e.fullName }))} />
      <FilterSelect value={url.state} onChange={(v) => setUrl({ state: v })} placeholder="All states" options={(lk.data?.states ?? []).map((s) => ({ value: s, label: s }))} />
      <FilterSelect value={url.status} onChange={(v) => setUrl({ status: v })} placeholder="Any loan status" options={['DISBURSED', 'ACTIVE', 'OVERDUE'].map((s) => ({ value: s, label: label(s) }))} />
      {withBucket && <FilterSelect value={url.bucket} onChange={(v) => setUrl({ bucket: v })} placeholder="All buckets" options={(lk.data?.buckets ?? []).map((b) => ({ value: b.code, label: b.label }))} />}
    </>
  );
}

export function DpdPortfolio() {
  const [url, setUrl] = useUrlState();
  const nav = useNavigate();
  const { user } = useAuth();
  const f = { businessDate: url.businessDate, productId: url.productId, branchId: url.branchId, executiveId: url.executiveId, state: url.state, status: url.status };
  const q = useQuery({ queryKey: ['/api/dpd/buckets', f], queryFn: () => api.get('/api/dpd/buckets', f) });
  const d = q.data;
  const drill = (bucket?: string) => {
    const p = new URLSearchParams(Object.entries({ ...f, bucket }).filter(([, v]) => v) as [string, string][]);
    nav(`/dpd/accounts?${p}`);
  };
  return (
    <>
      <PageHeader title="DPD portfolio" description={d ? (d.isLive ? `Live positions on business date ${date(d.businessDate)}.` : `Snapshot taken at the start of ${date(d.businessDate)}. Snapshots never change.`) : ' '} />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <PortfolioFilters url={url} setUrl={setUrl} />
      </div>
      {q.isError ? (
        <ErrorState error={q.error} onRetry={() => q.refetch()} />
      ) : !d ? (
        <Skeleton className="h-96" />
      ) : (
        <div className="space-y-5">
          <Card>
            <div className="px-5 py-5">
              <DpdLadder buckets={d.buckets} onSelect={drill} />
            </div>
          </Card>
          <div className="grid gap-5 xl:grid-cols-[1fr_340px]">
            <Card>
              <CardHeader title="Bucket position" description="Totals are summed from the same loan-level rows you see when you open a bucket." />
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-line bg-canvas/60 text-left text-[13px] text-text-muted">
                      <th className="px-4 py-2 font-medium">DPD bucket</th>
                      <th className="px-4 py-2 text-right font-medium">Accounts</th>
                      <th className="px-4 py-2 text-right font-medium">Outstanding principal</th>
                      <th className="px-4 py-2 text-right font-medium">% of POS</th>
                      <th className="px-4 py-2 text-right font-medium">Overdue amount</th>
                    </tr>
                  </thead>
                  <tbody className="tabular-nums">
                    {d.buckets.map((b: any) => (
                      <tr key={b.bucketCode} className="cursor-pointer border-b border-line/70 hover:bg-ink-50/50" onClick={() => drill(b.bucketCode)}>
                        <td className="px-4 py-2.5">
                          <span className="inline-flex items-center gap-2 font-medium">
                            <span className="h-3 w-3 rounded-sm" style={{ background: bucketColor(b.bucketCode, b.color) }} />
                            {b.label}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-right">{num(b.accountCount)}</td>
                        <td className="px-4 py-2.5 text-right">{inr(b.outstandingPrincipal)}</td>
                        <td className="px-4 py-2.5 text-right text-text-muted">{pct(b.pctOfPos, 1)}</td>
                        <td className={cn('px-4 py-2.5 text-right', b.overdueAmount > 0 && 'text-risk')}>{inr(b.overdueAmount)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="cursor-pointer bg-canvas/60 font-semibold tabular-nums" onClick={() => drill()}>
                      <td className="px-4 py-2.5">Total</td>
                      <td className="px-4 py-2.5 text-right">{num(d.totals.accountCount)}</td>
                      <td className="px-4 py-2.5 text-right">{inr(d.totals.outstandingPrincipal)}</td>
                      <td className="px-4 py-2.5 text-right">100%</td>
                      <td className="px-4 py-2.5 text-right">{inr(d.totals.overdueAmount)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </Card>
            <Card>
              <CardHeader title="Portfolio at risk" description="Share of outstanding principal with DPD above the threshold." />
              <div className="space-y-4 p-5">
                {[
                  ['PAR 30', d.par.par30Pct, d.par.par30Pos, d.par.par30Accounts],
                  ['PAR 60', d.par.par60Pct, d.par.par60Pos, d.par.par60Accounts],
                  ['PAR 90', d.par.par90Pct, d.par.par90Pos, d.par.par90Accounts],
                ].map(([k, p, pos, acc]) => (
                  <div key={k as string}>
                    <div className="flex items-baseline justify-between">
                      <span className="text-[13px] text-text-muted">{k}</span>
                      <span className="text-lg font-semibold tabular-nums">{pct(p)}</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full rounded bg-canvas">
                      <div className="h-full rounded bg-risk" style={{ width: `${Math.min(100, (p as number) * 4)}%` }} />
                    </div>
                    <div className="mt-1 text-xs tabular-nums text-text-faint">
                      {inrShort(pos)} across {num(acc)} accounts
                    </div>
                  </div>
                ))}
                <p className="border-t border-line pt-3 text-xs text-text-faint">Bar scale: full width = 25%. The 90+ bucket counts DPD ≥ 90; PAR 90 counts DPD &gt; 90.</p>
              </div>
            </Card>
          </div>
          <Movement filters={f} businessDate={d.businessDate} currentBusinessDate={user!.businessDate} />
        </div>
      )}
    </>
  );
}

function Movement({ filters, businessDate }: { filters: Record<string, any>; businessDate: string; currentBusinessDate: string }) {
  const [from, setFrom] = React.useState(addDays(businessDate, -30));
  const [to, setTo] = React.useState(businessDate);
  React.useEffect(() => {
    setTo(businessDate);
    setFrom(addDays(businessDate, -30));
  }, [businessDate]);
  const lk = useLookups();
  const params = { from, to, productId: filters.productId, branchId: filters.branchId, executiveId: filters.executiveId, state: filters.state };
  const q = useQuery({ queryKey: ['/api/dpd/movement', params], queryFn: () => api.get('/api/dpd/movement', params), retry: false });
  const buckets = lk.data?.buckets ?? [];
  const fromKeys = [...buckets.map((b) => b.code), 'NEW'];
  const toKeys = [...buckets.map((b) => b.code), 'EXITED'];
  const cell = (fk: string, tk: string) => q.data?.matrix.find((m: any) => m.fromBucket === fk && m.toBucket === tk)?.accounts ?? 0;
  const order = (c: string) => buckets.find((b) => b.code === c)?.sortOrder ?? 0;
  const name = (c: string) => buckets.find((b) => b.code === c)?.label ?? (c === 'NEW' ? 'New accounts' : 'Closed / left book');
  const s = q.data?.summary;
  return (
    <Card>
      <CardHeader
        title="Bucket movement"
        description="How accounts moved between two snapshot dates. Above the diagonal rolled forward (worse), below rolled back (better)."
        actions={
          <div className="flex items-center gap-2">
            <Input type="date" className="h-8 w-[145px]" value={from} max={to} onChange={(e) => setFrom(e.target.value)} aria-label="From snapshot" />
            <span className="text-text-faint">to</span>
            <Input type="date" className="h-8 w-[145px]" value={to} min={from} max={businessDate} onChange={(e) => setTo(e.target.value)} aria-label="To snapshot" />
          </div>
        }
      />
      {q.isError ? (
        <div className="p-4">
          <ErrorState error={q.error} />
        </div>
      ) : !q.data ? (
        <Skeleton className="m-5 h-48" />
      ) : (
        <div className="space-y-5 p-5">
          <StatGrid className="grid-cols-2 md:grid-cols-6">
            <Stat label="Rolled forward" value={num(s.rolledForward)} sub={inrShort(s.rolledForwardPos)} tone={s.rolledForward ? 'risk' : undefined} />
            <Stat label="Rolled back" value={num(s.rolledBackward)} tone="paid" />
            <Stat label="Cured to current" value={num(s.cured)} sub={inrShort(s.curedPos)} tone="paid" />
            <Stat label="Newly overdue" value={num(s.newlyOverdue)} tone={s.newlyOverdue ? 'due' : undefined} />
            <Stat label="Stayed put" value={num(s.stable)} />
            <Stat label="New / exited" value={`${num(s.newAccounts)} / ${num(s.exitedAccounts)}`} />
          </StatGrid>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-sm tabular-nums">
              <thead>
                <tr className="text-[13px] text-text-muted">
                  <th className="px-3 py-2 text-left font-medium">From \ To</th>
                  {toKeys.map((t) => (
                    <th key={t} className="px-3 py-2 text-right font-medium">
                      {name(t)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {fromKeys.map((fk) => (
                  <tr key={fk} className="border-t border-line">
                    <th className="px-3 py-2 text-left text-[13px] font-medium">{name(fk)}</th>
                    {toKeys.map((tk) => {
                      const n = cell(fk, tk);
                      const worse = fk !== 'NEW' && tk !== 'EXITED' && order(tk) > order(fk);
                      const better = fk !== 'NEW' && tk !== 'EXITED' && order(tk) < order(fk);
                      const same = fk === tk;
                      return (
                        <td key={tk} className={cn('px-3 py-2 text-right', n === 0 && 'text-text-faint', n > 0 && worse && 'bg-risk-soft font-medium text-risk', n > 0 && better && 'bg-paid-soft font-medium text-paid', same && 'bg-canvas')}>
                          {n === 0 ? '·' : num(n)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div>
            <h3 className="mb-2 text-[13px] font-medium text-text-muted">Recovery by starting bucket</h3>
            <div className="grid gap-px overflow-hidden rounded-md border border-line bg-line sm:grid-cols-5">
              {q.data.recovery.map((r: any) => (
                <div key={r.bucketCode} className="bg-white px-3 py-2.5">
                  <div className="text-xs text-text-muted">{r.label}</div>
                  <div className="font-semibold tabular-nums">{inrShort(r.recoveredAmount)}</div>
                  <div className="text-xs text-text-faint">{num(r.payingAccounts)} paying accounts</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}

export function DpdAccounts() {
  const [url, setUrl] = useUrlState();
  const nav = useNavigate();
  return (
    <>
      <PageHeader title="DPD accounts" description="Loan-level DPD positions. Pick a past business date to read that day's snapshot." />
      <DataTable
        endpoint="/api/dpd/current"
        searchPlaceholder="Loan ID or customer"
        defaultSort={{ sort: 'dpd', order: 'desc' }}
        filters={{ businessDate: url.businessDate, productId: url.productId, branchId: url.branchId, executiveId: url.executiveId, state: url.state, status: url.status, bucket: url.bucket }}
        onRowClick={(r) => nav(`/loans/${r.loanId}`)}
        rowKey="loanId"
        toolbar={<PortfolioFilters url={url} setUrl={setUrl} withBucket />}
        columns={[
          { key: 'loanNumber', header: 'Loan', sortable: true, cell: (r) => <span className="font-medium text-ink">{r.loanNumber}</span> },
          { key: 'customerName', header: 'Customer', sortable: true },
          { key: 'productName', header: 'Product' },
          { key: 'dpd', header: 'DPD', sortable: true, cell: (r) => <DpdBadge dpd={r.dpd} bucket={r.bucketCode} /> },
          { key: 'overdueEmiCount', header: 'Overdue EMIs', align: 'right' },
          { key: 'overdueAmount', header: 'Overdue', align: 'right', sortable: true, cell: (r) => <Money v={r.overdueAmount} className={r.overdueAmount > 0 ? 'text-risk' : 'text-text-faint'} /> },
          { key: 'outstandingPrincipal', header: 'POS', align: 'right', sortable: true, cell: (r) => <Money v={r.outstandingPrincipal} /> },
          { key: 'oldestOverdueDate', header: 'Oldest due', sortable: true, cell: (r) => date(r.oldestOverdueDate) },
          { key: 'lastPaymentDate', header: 'Last paid', sortable: true, cell: (r) => date(r.lastPaymentDate) },
          { key: 'nextEmiDueDate', header: 'Next due', sortable: true, cell: (r) => date(r.nextEmiDueDate) },
          { key: 'executiveName', header: 'Executive', cell: (r) => r.executiveName ?? <span className="text-text-faint">Unassigned</span> },
          { key: 'accountStatus', header: 'Status', cell: (r) => <StatusBadge status={r.accountStatus} /> },
        ]}
      />
    </>
  );
}

export function DpdSnapshots() {
  const [url, setUrl] = useUrlState();
  const { user } = useAuth();
  const nav = useNavigate();
  const lk = useLookups();
  const bd = user!.businessDate;
  const from = addDays(bd, -59);
  const trend = useQuery({ queryKey: ['/api/dpd/trend', from, bd], queryFn: () => api.get<any[]>('/api/dpd/trend', { from, to: bd }) });
  // pivot to one row per day with a column per bucket
  const pivot = React.useMemo(() => {
    const m = new Map<string, any>();
    for (const r of trend.data ?? []) {
      const row = m.get(r.businessDate) ?? { date: r.businessDate.slice(5) };
      row[r.bucketCode] = r.accountCount;
      m.set(r.businessDate, row);
    }
    return [...m.values()];
  }, [trend.data]);
  const overdueBuckets = (lk.data?.buckets ?? []).filter((b) => b.minDpd > 0);
  return (
    <>
      <PageHeader title="Daily DPD snapshots" description="Written once by the nightly job and never modified, so historical reports always reproduce." />
      <ChartCard title="Overdue accounts by bucket, last 60 days" loading={trend.isLoading} className="mb-5" height={230}>
        <Lines data={pivot} x="date" series={overdueBuckets.map((b) => ({ key: b.code, name: b.label, color: bucketColor(b.code, b.color) }))} />
      </ChartCard>
      <DataTable
        endpoint="/api/dpd/snapshots"
        searchPlaceholder="Loan ID"
        rowKey="loanId"
        filters={{ businessDate: url.businessDate ?? bd, bucket: url.bucket }}
        defaultSort={{ sort: 'dpd', order: 'desc' }}
        onRowClick={(r) => nav(`/loans/${r.loanId}`)}
        toolbar={
          <>
            <Input type="date" className="h-9 w-[150px]" value={url.businessDate ?? bd} max={bd} onChange={(e) => setUrl({ businessDate: e.target.value })} aria-label="Snapshot date" />
            <FilterSelect value={url.bucket} onChange={(v) => setUrl({ bucket: v })} placeholder="All buckets" options={(lk.data?.buckets ?? []).map((b) => ({ value: b.code, label: b.label }))} />
          </>
        }
        emptyBody="The DPD job may not have run on that date. Check Scheduled jobs."
        columns={[
          { key: 'businessDate', header: 'Business date', sortable: true, cell: (r) => date(r.businessDate) },
          { key: 'loanNumber', header: 'Loan', sortable: true },
          { key: 'customerName', header: 'Customer' },
          { key: 'dpd', header: 'DPD', sortable: true, cell: (r) => <DpdBadge dpd={r.dpd} bucket={r.bucketCode} /> },
          { key: 'overdueEmiCount', header: 'Overdue EMIs', align: 'right' },
          { key: 'overdueAmount', header: 'Overdue', align: 'right', sortable: true, cell: (r) => <Money v={r.overdueAmount} /> },
          { key: 'outstandingPrincipal', header: 'POS', align: 'right', sortable: true, cell: (r) => <Money v={r.outstandingPrincipal} /> },
          { key: 'accountStatus', header: 'Status', cell: (r) => <StatusBadge status={r.accountStatus} /> },
        ]}
      />
    </>
  );
}
