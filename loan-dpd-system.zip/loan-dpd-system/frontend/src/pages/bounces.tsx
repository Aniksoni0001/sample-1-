import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { RotateCcw } from 'lucide-react';
import { api, newIdempotencyKey } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { date, inr, inrShort, label, num, pct } from '@/lib/format';
import { useAction, useGet, useUrlState } from '@/hooks/data';
import { Button, Checkbox, Field, Input, NativeSelect, Textarea } from '@/components/ui/base';
import { Dialog, DialogContent } from '@/components/ui/overlay';
import { DataTable, FilterSelect } from '@/components/DataTable';
import { DateRangeFilter, useRange } from '@/components/DateRange';
import { Money, PageHeader, Stat, StatGrid, StatusBadge } from '@/components/domain';

export const BOUNCE_REASONS = ['INSUFFICIENT_FUNDS', 'ACCOUNT_CLOSED', 'PAYMENT_STOPPED', 'INVALID_ACCOUNT', 'MANDATE_FAILURE', 'TECHNICAL_FAILURE', 'OTHER'];

export default function BouncesPage() {
  const { can } = useAuth();
  const nav = useNavigate();
  const [url, setUrl] = useUrlState();
  const r = useRange(url, 'last30');
  const stats = useQuery({ queryKey: ['/api/bounces/stats', r.from, r.to], queryFn: () => api.get('/api/bounces/stats', { from: r.from, to: r.to }) });
  const [reattempt, setReattempt] = React.useState<any>(null);
  const s = stats.data;
  return (
    <>
      <PageHeader title="Bounces" description="Returned NACH debits and cheques, their charges, and whether the money was recovered." actions={<DateRangeFilter state={url} set={setUrl} fallback="last30" />} />
      <StatGrid className="mb-5 grid-cols-2 md:grid-cols-5">
        <Stat label="Bounces" value={s ? num(s.bounces) : '…'} tone={s?.bounces ? 'risk' : undefined} />
        <Stat label="Bounce rate" value={s ? pct(s.bounceRatePct) : '…'} sub={s ? `of ${num(s.presentations)} presentations` : undefined} tone={s && s.bounceRatePct > 10 ? 'risk' : undefined} />
        <Stat label="Amount bounced" value={s ? inrShort(s.bounceAmount) : '…'} />
        <Stat label="Charges levied" value={s ? inr(s.bounceCharges, true) : '…'} />
        <Stat label="Recovered" value={s ? num(s.recovered) : '…'} sub={s?.byReason?.[0] ? `Top reason: ${label(s.byReason[0].bounceReason)}` : undefined} tone="paid" />
      </StatGrid>
      <DataTable
        endpoint="/api/bounces"
        searchPlaceholder="Bounce ID, loan, customer, reference"
        filters={{ reason: url.reason, recoveryStatus: url.recoveryStatus, dateFrom: r.from, dateTo: r.to }}
        defaultSort={{ sort: 'bounceDate', order: 'desc' }}
        onRowClick={(b) => nav(`/loans/${b.loanId}`)}
        toolbar={
          <>
            <FilterSelect value={url.reason} onChange={(v) => setUrl({ reason: v })} placeholder="Any reason" options={BOUNCE_REASONS.map((x) => ({ value: x, label: label(x) }))} />
            <FilterSelect value={url.recoveryStatus} onChange={(v) => setUrl({ recoveryStatus: v })} placeholder="Any recovery" options={['PENDING', 'PARTIAL', 'RECOVERED', 'WAIVED'].map((x) => ({ value: x, label: label(x) }))} />
          </>
        }
        columns={[
          { key: 'bounceNumber', header: 'Bounce ID', sortable: true, cell: (b) => <span className="font-medium text-ink">{b.bounceNumber}</span> },
          { key: 'bounceDate', header: 'Date', sortable: true, cell: (b) => date(b.bounceDate) },
          { key: 'loanNumber', header: 'Loan', sortable: true },
          { key: 'customerName', header: 'Customer', sortable: true },
          { key: 'installmentNo', header: 'EMI #', align: 'right' },
          { key: 'bounceReason', header: 'Reason', sortable: true, cell: (b) => label(b.bounceReason) },
          { key: 'bounceAmount', header: 'Amount', align: 'right', sortable: true, cell: (b) => <Money v={b.bounceAmount} /> },
          { key: 'bounceCharges', header: 'Charge', align: 'right', cell: (b) => <Money v={b.bounceCharges} /> },
          { key: 'loanBounceCount', header: 'On loan', align: 'right', cell: (b) => <span className={b.loanBounceCount >= 3 ? 'font-semibold text-risk' : ''}>{b.loanBounceCount}</span> },
          { key: 'recoveryStatus', header: 'Recovery', sortable: true, cell: (b) => <StatusBadge status={b.recoveryStatus} /> },
          {
            key: 'actions',
            header: '',
            cell: (b) =>
              can('bounces.write') && ['PENDING', 'PARTIAL'].includes(b.recoveryStatus) ? (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={(e) => {
                    e.stopPropagation();
                    setReattempt(b);
                  }}
                >
                  <RotateCcw /> Re-present
                </Button>
              ) : null,
          },
        ]}
      />
      {reattempt && <ReattemptDialog bounce={reattempt} onClose={() => setReattempt(null)} />}
    </>
  );
}

function ReattemptDialog({ bounce, onClose }: { bounce: any; onClose: () => void }) {
  const { user } = useAuth();
  const [d, setD] = React.useState(user!.businessDate);
  const [mode, setMode] = React.useState('NACH');
  const [ref, setRef] = React.useState('');
  const [key] = React.useState(newIdempotencyKey);
  const a = useAction(() => api.post(`/api/bounces/${bounce.id}/reattempt`, { presentationDate: d, paymentMode: mode, transactionReference: ref }, { 'Idempotency-Key': key }), {
    success: (r: any) => `${r.paymentNumber} presented; realise or bounce it once the bank responds`,
    onSuccess: onClose,
  });
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent title={`Re-present ${bounce.bounceNumber}`} description={`Creates a pending ${mode} collection for the unpaid part of EMI ${bounce.installmentNo ?? ''} on ${bounce.loanNumber}.`}>
        <div className="space-y-4">
          <Field label="Presentation date">
            <Input type="date" value={d} max={user!.businessDate} onChange={(e) => setD(e.target.value)} />
          </Field>
          <Field label="Mode">
            <NativeSelect value={mode} onChange={(e) => setMode(e.target.value)}>
              <option value="NACH">NACH</option>
              <option value="CHEQUE">Cheque</option>
              <option value="UPI">UPI autopay</option>
            </NativeSelect>
          </Field>
          <Field label="Mandate / cheque reference" required>
            <Input value={ref} onChange={(e) => setRef(e.target.value)} />
          </Field>
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button disabled={ref.trim().length < 3} loading={a.isPending} onClick={() => a.mutate(undefined)}>
              Re-present
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/** Record a bounce from a loan or a payment screen. */
export function BounceDialog({ open, onClose, loanId, paymentId, businessDate }: { open: boolean; onClose: () => void; loanId: number; paymentId?: number; businessDate?: string }) {
  const { user } = useAuth();
  const bd = businessDate ?? user!.businessDate;
  const [mode, setMode] = React.useState<'payment' | 'emi'>(paymentId ? 'payment' : 'emi');
  const [pid, setPid] = React.useState<string>(paymentId ? String(paymentId) : '');
  const [emiId, setEmiId] = React.useState('');
  const [amount, setAmount] = React.useState('');
  const [reason, setReason] = React.useState('INSUFFICIENT_FUNDS');
  const [d, setD] = React.useState(bd);
  const [ref, setRef] = React.useState('');
  const [charge, setCharge] = React.useState(true);
  const [remarks, setRemarks] = React.useState('');
  const payments = useGet<any[]>(!paymentId ? `/api/loans/${loanId}/payments` : null);
  const schedule = useGet<any[]>(`/api/loans/${loanId}/emi-schedule`);
  const presentable = (payments.data ?? []).filter((p) => ['SUCCESSFUL', 'PENDING', 'INITIATED'].includes(p.status) && ['NACH', 'CHEQUE', 'UPI', 'OTHER'].includes(p.paymentMode));
  const dueEmis = (schedule.data ?? []).filter((e) => e.remainingAmount > 0 && e.dueDate <= bd);
  const a = useAction(
    () =>
      api.post('/api/bounces', {
        loanId,
        bounceDate: d,
        bounceReason: reason,
        applyCharge: charge,
        remarks: remarks || null,
        paymentReference: ref || null,
        ...(mode === 'payment' ? { paymentId: Number(pid) } : { emiScheduleId: Number(emiId), amount: Number(amount) }),
      }),
    { success: (r: any) => `${r.bounceNumber} recorded; ${r.bounceCharges > 0 ? `${inr(r.bounceCharges)} charge added` : 'no charge'}`, onSuccess: onClose },
  );
  const valid = mode === 'payment' ? !!pid : !!emiId && Number(amount) > 0;
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent title="Record bounce" description="A bounce restores any dues the payment had cleared, adds the configured charge, and never counts as collection.">
        <div className="space-y-4">
          {!paymentId && (
            <div className="flex gap-4 text-sm">
              <label className="flex items-center gap-2">
                <input type="radio" checked={mode === 'payment'} onChange={() => setMode('payment')} /> A recorded payment came back
              </label>
              <label className="flex items-center gap-2">
                <input type="radio" checked={mode === 'emi'} onChange={() => setMode('emi')} /> Return file, no payment recorded
              </label>
            </div>
          )}
          {mode === 'payment' && !paymentId && (
            <Field label="Payment" required>
              <NativeSelect value={pid} onChange={(e) => setPid(e.target.value)}>
                <option value="">Select payment</option>
                {presentable.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.paymentNumber}, {p.paymentMode} {inr(p.amount)} on {date(p.paymentDate)} ({label(p.status)})
                  </option>
                ))}
              </NativeSelect>
            </Field>
          )}
          {mode === 'emi' && (
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Installment" required>
                <NativeSelect
                  value={emiId}
                  onChange={(e) => {
                    setEmiId(e.target.value);
                    const em = dueEmis.find((x) => String(x.id) === e.target.value);
                    if (em) setAmount(String(em.remainingAmount));
                  }}
                >
                  <option value="">Select EMI</option>
                  {dueEmis.map((e) => (
                    <option key={e.id} value={e.id}>
                      EMI {e.installmentNo}, due {date(e.dueDate)}, {inr(e.remainingAmount)}
                    </option>
                  ))}
                </NativeSelect>
              </Field>
              <Field label="Amount presented (₹)" required>
                <Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
              </Field>
            </div>
          )}
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Reason" required>
              <NativeSelect value={reason} onChange={(e) => setReason(e.target.value)}>
                {BOUNCE_REASONS.map((r) => (
                  <option key={r} value={r}>
                    {label(r)}
                  </option>
                ))}
              </NativeSelect>
            </Field>
            <Field label="Bounce date" required>
              <Input type="date" value={d} max={bd} onChange={(e) => setD(e.target.value)} />
            </Field>
          </div>
          {mode === 'emi' && (
            <Field label="Bank / mandate reference">
              <Input value={ref} onChange={(e) => setRef(e.target.value)} />
            </Field>
          )}
          <label className="flex items-center gap-2 text-sm">
            <Checkbox checked={charge} onCheckedChange={(v) => setCharge(!!v)} /> Apply bounce charge
          </label>
          <Field label="Remarks">
            <Textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} />
          </Field>
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="danger" disabled={!valid} loading={a.isPending} onClick={() => a.mutate(undefined)}>
              Record bounce
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
