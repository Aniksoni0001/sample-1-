import * as React from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { CheckCircle2, CircleSlash2, Download, FileUp, Plus, Printer, Undo2, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import { api, newIdempotencyKey } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { cn, date, dateTime, inr, label } from '@/lib/format';
import { useAction, useGet, useUrlState } from '@/hooks/data';
import { Button, Card, CardHeader, Field, Input, NativeSelect, Skeleton, Textarea } from '@/components/ui/base';
import { ConfirmDialog, Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/overlay';
import { DataTable, FilterSelect } from '@/components/DataTable';
import { DateRangeFilter, useRange } from '@/components/DateRange';
import { DpdBadge, ErrorState, KeyValues, Money, PageHeader, Stat, StatGrid, StatusBadge } from '@/components/domain';
import { SimpleTable } from './customers';
import { BounceDialog } from './bounces';

const MODES = ['UPI', 'NEFT', 'RTGS', 'IMPS', 'CASH', 'CHEQUE', 'NACH', 'OTHER'];

export function PaymentRegister() {
  const { can } = useAuth();
  const nav = useNavigate();
  const [url, setUrl] = useUrlState();
  const r = useRange(url, 'last30');
  return (
    <>
      <PageHeader
        title="Payments"
        description="Every receipt with its status. Failed, bounced and reversed payments never count as collected."
        actions={
          can('payments.write', 'payments.import') && (
            <Button asChild>
              <Link to="/payments/new">
                <Plus /> Record payment
              </Link>
            </Button>
          )
        }
      />
      <DataTable
        endpoint="/api/payments"
        searchPlaceholder="Payment ID, reference, loan, customer"
        filters={{ status: url.status, mode: url.mode, source: url.source, dateFrom: r.from, dateTo: r.to }}
        defaultSort={{ sort: 'paymentDate', order: 'desc' }}
        onRowClick={(row) => nav(`/payments/${row.id}`)}
        toolbar={
          <>
            <DateRangeFilter state={url} set={setUrl} fallback="last30" />
            <FilterSelect value={url.status} onChange={(v) => setUrl({ status: v })} placeholder="Any status" options={['SUCCESSFUL', 'PENDING', 'INITIATED', 'FAILED', 'REVERSED'].map((s) => ({ value: s, label: label(s) }))} />
            <FilterSelect value={url.mode} onChange={(v) => setUrl({ mode: v })} placeholder="Any mode" options={MODES.map((m) => ({ value: m, label: m }))} />
            <FilterSelect value={url.source} onChange={(v) => setUrl({ source: v })} placeholder="Any source" options={[{ value: 'MANUAL', label: 'Manual' }, { value: 'CSV_IMPORT', label: 'CSV import' }, { value: 'SYSTEM', label: 'NACH auto-debit' }]} />
          </>
        }
        columns={[
          { key: 'paymentNumber', header: 'Payment ID', sortable: true, cell: (p) => <span className="font-medium text-ink">{p.paymentNumber}</span> },
          { key: 'paymentDate', header: 'Date', sortable: true, cell: (p) => date(p.paymentDate) },
          { key: 'loanNumber', header: 'Loan', sortable: true },
          { key: 'customerName', header: 'Customer', sortable: true },
          { key: 'paymentMode', header: 'Mode', sortable: true },
          { key: 'transactionReference', header: 'Reference', cell: (p) => <span className="text-text-muted">{p.transactionReference ?? '—'}</span> },
          { key: 'amount', header: 'Amount', align: 'right', sortable: true, cell: (p) => <Money v={p.amount} className={cn(p.status !== 'SUCCESSFUL' && 'text-text-faint', ['FAILED', 'REVERSED'].includes(p.status) && 'line-through decoration-1')} /> },
          { key: 'status', header: 'Status', sortable: true, cell: (p) => <StatusBadge status={p.status} /> },
          { key: 'collectedByName', header: 'Collected by', cell: (p) => p.collectedByName ?? '—' },
        ]}
      />
    </>
  );
}

// ------------------------------------------------------------------ record
function LoanSearch({ value, onChange }: { value?: number; onChange: (id: number) => void }) {
  const [term, setTerm] = React.useState('');
  const [open, setOpen] = React.useState(false);
  const q = useQuery({ queryKey: ['loan-search', term], queryFn: () => api.get('/api/loans', { search: term, status: 'LIVE', pageSize: 8 }), enabled: term.length >= 2 });
  const sel = useGet<any>(value ? `/api/loans/${value}` : null);
  return (
    <Field label="Loan" required>
      <div className="relative">
        <Input
          placeholder="Loan ID, customer name or mobile"
          aria-label="Loan"
          value={open ? term : sel.data ? `${sel.data.loanNumber} — ${sel.data.customerName}` : term}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          onChange={(e) => setTerm(e.target.value)}
        />
        {open && term.length >= 2 && (
          <div className="absolute z-20 mt-1 w-full overflow-hidden rounded-md border border-line bg-white shadow-lg">
            {(q.data?.data ?? []).map((l: any) => (
              <button key={l.id} type="button" className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-sm hover:bg-canvas" onMouseDown={() => (onChange(l.id), setTerm(''), setOpen(false))}>
                <span>
                  <span className="font-medium">{l.loanNumber}</span> {l.customerName}
                </span>
                <DpdBadge dpd={l.dpd} bucket={l.bucketCode} />
              </button>
            ))}
            {q.data && q.data.data.length === 0 && <div className="px-3 py-2 text-[13px] text-text-muted">No live loan matches.</div>}
          </div>
        )}
      </div>
    </Field>
  );
}

export function RecordPayment() {
  const { can } = useAuth();
  return (
    <div className="max-w-6xl">
      <PageHeader back={{ to: '/payments', label: 'Payments' }} title="Record payment" />
      <Tabs defaultValue={can('payments.write') ? 'single' : 'import'}>
        <TabsList>
          {can('payments.write') && <TabsTrigger value="single">Single payment</TabsTrigger>}
          {can('payments.import') && <TabsTrigger value="import">Bulk CSV import</TabsTrigger>}
        </TabsList>
        <TabsContent value="single">
          <SinglePayment />
        </TabsContent>
        <TabsContent value="import">
          <BulkImport />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function SinglePayment() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [sp] = useSearchParams();
  const [loanId, setLoanId] = React.useState<number | undefined>(Number(sp.get('loanId')) || undefined);
  const [amount, setAmount] = React.useState('');
  const [paymentDate, setPaymentDate] = React.useState(user!.businessDate);
  const [mode, setMode] = React.useState('UPI');
  const [ref, setRef] = React.useState('');
  const [status, setStatus] = React.useState('SUCCESSFUL');
  const [remarks, setRemarks] = React.useState('');
  // one key per intended payment: double-clicks and retries can't post twice
  const [idemKey, setIdemKey] = React.useState(newIdempotencyKey);
  const loan = useGet<any>(loanId ? `/api/loans/${loanId}` : null);
  const l = loan.data;
  const needsRef = mode !== 'CASH';
  const presentable = mode === 'CHEQUE' || mode === 'NACH';

  const body = { loanId, amount: Number(amount), paymentDate, paymentMode: mode, transactionReference: ref || null, status: presentable ? status : 'SUCCESSFUL', remarks: remarks || null };
  const [debounced, setDebounced] = React.useState<any>(null);
  React.useEffect(() => {
    const t = setTimeout(() => setDebounced(loanId && Number(amount) > 0 ? { loanId, amount: Number(amount), paymentDate, paymentMode: mode, transactionReference: 'PREVIEW' } : null), 350);
    return () => clearTimeout(t);
  }, [loanId, amount, paymentDate, mode]);
  const preview = useQuery({ queryKey: ['pay-preview', debounced], queryFn: () => api.post('/api/payments/preview', debounced), enabled: !!debounced });

  const save = useAction(() => api.post('/api/payments', body, { 'Idempotency-Key': idemKey }), {
    success: (r: any) => (r.status === 'SUCCESSFUL' ? `${r.paymentNumber} recorded and allocated` : `${r.paymentNumber} recorded as ${label(r.status).toLowerCase()}`),
    onSuccess: (r: any) => {
      setIdemKey(newIdempotencyKey());
      nav(`/payments/${r.id}`);
    },
  });
  const valid = loanId && Number(amount) > 0 && (!needsRef || ref.trim().length >= 3) && paymentDate;
  const quick = l
    ? [
        ['Overdue + charges', Number(l.overdueAmount) + Number(l.overdueCharges)],
        ['Next EMI', Number(l.nextEmiAmount ?? 0)],
        ['Foreclose', Number(l.outstanding?.totalOutstanding ?? 0)],
      ].filter(([, v]) => (v as number) > 0)
    : [];

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_400px]">
      <Card>
        <CardHeader title="Payment" description="Posted atomically: allocation, balances and DPD update together, or not at all." />
        <div className="grid gap-4 p-5 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <LoanSearch value={loanId} onChange={setLoanId} />
          </div>
          {l && (
            <div className="grid grid-cols-2 gap-px overflow-hidden rounded-md border border-line bg-line sm:col-span-2 sm:grid-cols-4">
              <Stat label="Status" value={<DpdBadge dpd={l.dpd} bucket={l.bucketCode} />} />
              <Stat label="Overdue EMI" value={inr(l.overdueAmount)} tone={l.overdueAmount > 0 ? 'risk' : undefined} />
              <Stat label="Open charges" value={inr(l.overdueCharges)} />
              <Stat label="Total outstanding" value={inr(l.outstanding?.totalOutstanding)} />
            </div>
          )}
          <Field label="Amount (₹)" required>
            <Input type="number" step="0.01" min={0} value={amount} onChange={(e) => setAmount(e.target.value)} />
            {quick.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {quick.map(([k, v]) => (
                  <button key={k as string} type="button" className="rounded border border-line px-2 py-0.5 text-xs text-text-muted hover:border-ink-300 hover:text-ink" onClick={() => setAmount(String(Math.round((v as number) * 100) / 100))}>
                    {k}: {inr(v)}
                  </button>
                ))}
              </div>
            )}
          </Field>
          <Field label="Payment date" required hint="Can't be after the business date">
            <Input type="date" value={paymentDate} max={user!.businessDate} onChange={(e) => setPaymentDate(e.target.value)} />
          </Field>
          <Field label="Mode" required>
            <NativeSelect value={mode} onChange={(e) => setMode(e.target.value)}>
              {MODES.map((m) => (
                <option key={m}>{m}</option>
              ))}
            </NativeSelect>
          </Field>
          <Field label={mode === 'CHEQUE' ? 'Cheque number' : 'Transaction reference'} required={needsRef} hint={needsRef ? 'UTR / RRN / mandate reference; duplicates are rejected' : 'Optional for cash'}>
            <Input value={ref} onChange={(e) => setRef(e.target.value)} />
          </Field>
          {presentable && (
            <Field label="Status" className="sm:col-span-2" hint="Pending payments don't reduce dues until they're realised.">
              <NativeSelect value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="SUCCESSFUL">Credited now</option>
                <option value="PENDING">Presented, awaiting clearance</option>
              </NativeSelect>
            </Field>
          )}
          <Field label="Remarks" className="sm:col-span-2">
            <Textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} />
          </Field>
        </div>
        <div className="flex justify-end gap-2 border-t border-line px-5 py-3">
          <Button variant="secondary" onClick={() => history.back()}>
            Cancel
          </Button>
          <Button disabled={!valid || (preview.data && !preview.data.valid)} loading={save.isPending} onClick={() => save.mutate(undefined)}>
            Record {Number(amount) > 0 ? inr(amount) : 'payment'}
          </Button>
        </div>
      </Card>

      <Card className="self-start">
        <CardHeader title="Where this money goes" description="Calculated by the same allocation procedure, then rolled back." />
        <div className="p-5">
          {!debounced ? (
            <p className="text-[13px] text-text-muted">Choose a loan and enter an amount.</p>
          ) : preview.isLoading ? (
            <Skeleton className="h-32" />
          ) : preview.isError ? (
            <ErrorState error={preview.error} />
          ) : !preview.data.valid ? (
            <div className="rounded-md bg-risk-soft px-3 py-2 text-[13px] text-risk">{preview.data.message}</div>
          ) : (
            <>
              <ul className="divide-y divide-line text-sm">
                {preview.data.allocations.map((a: any, i: number) => (
                  <li key={i} className="flex justify-between py-1.5">
                    <span>
                      {a.installmentNo ? `EMI ${a.installmentNo} ${a.component.toLowerCase()}` : `${label(a.chargeType)} charge`}
                      {a.isAdvance && <span className="ml-1.5 rounded bg-ink-50 px-1 text-[11px] text-ink-500">advance</span>}
                    </span>
                    <Money v={a.amount} />
                  </li>
                ))}
              </ul>
              {preview.data.after && (
                <div className="mt-4 rounded-md bg-canvas px-3 py-2.5 text-[13px]">
                  <div className="flex items-center justify-between">
                    <span className="text-text-muted">After posting</span>
                    <DpdBadge dpd={preview.data.after.dpd} bucket={preview.data.after.bucketCode} />
                  </div>
                  <div className="mt-1 flex justify-between">
                    <span className="text-text-muted">Overdue left</span>
                    <Money v={Number(preview.data.after.overdueAmount) + Number(preview.data.after.overdueCharges)} />
                  </div>
                </div>
              )}
              {presentable && status === 'PENDING' && <p className="mt-3 text-xs text-text-faint">Shown as if credited. Pending payments allocate only when realised.</p>}
            </>
          )}
        </div>
      </Card>
    </div>
  );
}

function BulkImport() {
  const [file, setFile] = React.useState<File | null>(null);
  const [result, setResult] = React.useState<any>(null);
  const [busy, setBusy] = React.useState(false);
  const run = async (dryRun: boolean) => {
    if (!file) return;
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const r = await api.post(`/api/payments/import?dryRun=${dryRun}`, fd);
      setResult(r);
      if (dryRun) toast.message(`Validation: ${r.succeeded} OK, ${r.failed} with errors`);
      else toast.success(`${r.succeeded} payment(s) imported${r.failed ? `, ${r.failed} rejected` : ''}`);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Card>
      <CardHeader
        title="Import payments from CSV"
        description="Each row is posted in its own transaction; a bad row never affects the others. Validate first to see problems without posting."
        actions={
          <Button variant="secondary" size="sm" onClick={() => api.download('/api/payments/import/template')}>
            <Download /> Template
          </Button>
        }
      />
      <div className="space-y-4 p-5">
        <label className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-line px-6 py-10 text-center hover:border-ink-300">
          <FileUp className="h-7 w-7 text-text-faint" strokeWidth={1.5} />
          <span className="mt-2 text-sm font-medium">{file ? file.name : 'Choose a CSV file'}</span>
          <span className="text-xs text-text-faint">Columns: loan_number, amount, payment_date, payment_mode, transaction_reference, status, remarks. Max 2,000 rows.</span>
          <input type="file" accept=".csv,text/csv" className="sr-only" onChange={(e) => (setFile(e.target.files?.[0] ?? null), setResult(null))} />
        </label>
        <div className="flex gap-2">
          <Button variant="secondary" disabled={!file} loading={busy} onClick={() => run(true)}>
            Validate only
          </Button>
          <Button disabled={!file} loading={busy} onClick={() => run(false)}>
            Import payments
          </Button>
        </div>
        {result && (
          <>
            <StatGrid className="grid-cols-3">
              <Stat label="Rows" value={result.total} />
              <Stat label={result.dryRun ? 'Would import' : 'Imported'} value={result.succeeded} tone="paid" />
              <Stat label="Rejected" value={result.failed} tone={result.failed ? 'risk' : undefined} />
            </StatGrid>
            <SimpleTable
              rows={result.results.map((r: any) => ({ ...r, id: r.row }))}
              empty="Empty file."
              cols={[
                ['Row', (r) => r.row],
                ['Loan', (r) => r.loanNumber ?? '—'],
                ['Result', (r) => (r.status === 'OK' ? <span className="text-paid">{r.paymentNumber ?? 'Valid'}</span> : <span className="text-risk">Rejected</span>)],
                ['Message', (r) => <span className="text-text-muted">{r.message ?? ''}</span>],
              ]}
            />
          </>
        )}
      </div>
    </Card>
  );
}

// ------------------------------------------------------------------ detail
export function PaymentDetail() {
  const { id } = useParams();
  const { can, user } = useAuth();
  const q = useGet<any>(`/api/payments/${id}`);
  const [dlg, setDlg] = React.useState<null | 'reverse' | 'realize' | 'fail' | 'bounce'>(null);
  const [reason, setReason] = React.useState('');
  const reverse = useAction(() => api.post(`/api/payments/${id}/reverse`, { reason }), { success: 'Payment reversed; dues restored', onSuccess: () => setDlg(null) });
  const realize = useAction(() => api.post(`/api/payments/${id}/realize`), { success: 'Payment realised and allocated', onSuccess: () => setDlg(null) });
  const fail = useAction(() => api.post(`/api/payments/${id}/fail`, { reason }), { success: 'Payment marked failed', onSuccess: () => setDlg(null) });
  if (q.isError) return <ErrorState error={q.error} />;
  if (!q.data) return <Skeleton className="h-80" />;
  const p = q.data;
  const pending = ['PENDING', 'INITIATED'].includes(p.status);
  return (
    <div className="max-w-5xl">
      <PageHeader
        back={{ to: '/payments', label: 'Payments' }}
        title={
          <span className="flex items-center gap-3">
            {p.paymentNumber} <StatusBadge status={p.status} className="text-[13px]" />
          </span>
        }
        description={
          <>
            {inr(p.amount)} by {p.paymentMode} on {date(p.paymentDate)} for{' '}
            <Link className="text-ink-500 hover:underline" to={`/loans/${p.loanId}`}>
              {p.loanNumber}
            </Link>
          </>
        }
        actions={
          <>
            {(p.status === 'SUCCESSFUL' || p.status === 'REVERSED') && (
              <Button variant="secondary" onClick={() => api.download(`/api/payments/${id}/receipt`).catch((e) => toast.error(e.message))}>
                <Printer /> Receipt
              </Button>
            )}
            {pending && can('payments.reverse') && (
              <>
                <Button variant="success" onClick={() => setDlg('realize')}>
                  <CheckCircle2 /> Mark realised
                </Button>
                <Button variant="secondary" onClick={() => setDlg('fail')}>
                  <XCircle /> Mark failed
                </Button>
              </>
            )}
            {(p.status === 'SUCCESSFUL' || pending) && ['NACH', 'CHEQUE', 'UPI', 'OTHER'].includes(p.paymentMode) && can('bounces.write') && (
              <Button variant="secondary" onClick={() => setDlg('bounce')}>
                <CircleSlash2 /> Record bounce
              </Button>
            )}
            {p.status === 'SUCCESSFUL' && can('payments.reverse') && (
              <Button variant="danger" onClick={() => setDlg('reverse')}>
                <Undo2 /> Reverse
              </Button>
            )}
          </>
        }
      />
      <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
        <Card>
          <CardHeader title="Allocation" description={p.allocations.length ? 'How this payment was applied. Allocations are permanent; a reversal undoes them as a new event.' : 'Not allocated (payment is not credited).'} />
          <SimpleTable
            rows={p.allocations}
            empty="No allocation."
            cols={[
              ['Applied to', (a) => (a.installmentNo ? `EMI ${a.installmentNo} (due ${date(a.dueDate)})` : `${label(a.chargeType)} charge`)],
              ['Component', (a) => label(a.component)],
              ['Advance', (a) => (a.isAdvance ? 'Yes' : '')],
              ['Amount', (a) => inr(a.amount), true],
            ]}
          />
        </Card>
        <Card className="self-start">
          <CardHeader title="Details" />
          <div className="p-5">
            <KeyValues
              cols={2}
              items={[
                ['Customer', p.customerName],
                ['Reference', p.transactionReference],
                ['Collected by', p.collectedByName],
                ['Entered by', p.createdByName],
                ['Source', label(p.source)],
                ['Realised', dateTime(p.realizedAt)],
                ['Created', dateTime(p.createdAt)],
                ['Idempotent', p.idempotent ? 'Yes' : 'No'],
              ]}
            />
            {p.remarks && <p className="mt-4 rounded-md bg-canvas px-3 py-2 text-[13px] text-text-muted">{p.remarks}</p>}
            {p.reversalReason && (
              <p className="mt-3 rounded-md bg-risk-soft px-3 py-2 text-[13px] text-risk">
                Reversed {date(p.reversalDate)} by {p.reversedByName}: {p.reversalReason}
              </p>
            )}
            {p.bounceNumber && (
              <p className="mt-3 rounded-md bg-risk-soft px-3 py-2 text-[13px] text-risk">
                Bounced ({label(p.bounceReason)}), see <Link to={`/bounces?search=${p.bounceNumber}`} className="underline">{p.bounceNumber}</Link>
              </p>
            )}
          </div>
        </Card>
      </div>
      <ConfirmDialog open={dlg === 'reverse'} onOpenChange={(o) => !o && setDlg(null)} title={`Reverse ${p.paymentNumber}?`} description="The installments and charges it cleared become due again and DPD is recalculated immediately. The payment stays on record as reversed." confirmLabel="Reverse payment" danger loading={reverse.isPending} onConfirm={() => reverse.mutate(undefined)}>
        <Field label="Reason" required>
          <Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Credit not received in bank statement" />
        </Field>
      </ConfirmDialog>
      <ConfirmDialog open={dlg === 'realize'} onOpenChange={(o) => !o && setDlg(null)} title="Mark as realised?" description={`${inr(p.amount)} is credited and allocated to the loan now.`} confirmLabel="Mark realised" loading={realize.isPending} onConfirm={() => realize.mutate(undefined)} />
      <ConfirmDialog open={dlg === 'fail'} onOpenChange={(o) => !o && setDlg(null)} title="Mark as failed?" description="Use this for gateway failures. For returned NACH or cheques, record a bounce instead so the charge applies." confirmLabel="Mark failed" danger loading={fail.isPending} onConfirm={() => fail.mutate(undefined)}>
        <Field label="Reason" required>
          <Input value={reason} onChange={(e) => setReason(e.target.value)} />
        </Field>
      </ConfirmDialog>
      {dlg === 'bounce' && <BounceDialog open onClose={() => setDlg(null)} loanId={p.loanId} paymentId={p.id} businessDate={user!.businessDate} />}
    </div>
  );
}
