import * as React from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { FileBarChart } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { date, inr, label, num, pct } from '@/lib/format';
import { useLookups, useUrlState } from '@/hooks/data';
import { Card, Input, Skeleton } from '@/components/ui/base';
import { DataTable, FilterSelect, type Column } from '@/components/DataTable';
import { DateRangeFilter, useRange } from '@/components/DateRange';
import { ErrorState, PageHeader, StatusBadge } from '@/components/domain';

interface ReportDef {
  key: string;
  title: string;
  category: string;
  description: string;
  filters: string[];
  columns: { key: string; label: string; type?: 'money' | 'number' | 'date' | 'pct' | 'text' }[];
  requires: string[];
  paginated: boolean;
}

const useCatalogue = () => useQuery<ReportDef[]>({ queryKey: ['/api/reports'], queryFn: () => api.get('/api/reports'), staleTime: 300_000 });

export function ReportsCenter() {
  const q = useCatalogue();
  const groups = React.useMemo(() => {
    const m = new Map<string, ReportDef[]>();
    for (const r of q.data ?? []) m.set(r.category, [...(m.get(r.category) ?? []), r]);
    return [...m.entries()];
  }, [q.data]);
  return (
    <>
      <PageHeader title="Reports" description="Every report uses the same definitions as the dashboards, supports search, sorting and pagination, and exports to CSV, Excel or PDF." />
      {q.isError && <ErrorState error={q.error} />}
      {q.isLoading && <Skeleton className="h-64" />}
      <div className="space-y-6">
        {groups.map(([cat, reps]) => (
          <section key={cat}>
            <h2 className="mb-2 text-[15px] font-semibold text-text">{cat}</h2>
            <div className="grid gap-px overflow-hidden rounded-lg border border-line bg-line sm:grid-cols-2 xl:grid-cols-3">
              {reps.map((r) => (
                <Link key={r.key} to={`/reports/${r.key}`} className="group flex gap-3 bg-white px-4 py-3.5 hover:bg-ink-50/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ink-500">
                  <FileBarChart className="mt-0.5 h-5 w-5 shrink-0 text-ink-300 group-hover:text-ink" strokeWidth={1.75} />
                  <span>
                    <span className="block text-sm font-medium text-text group-hover:text-ink">{r.title}</span>
                    <span className="mt-0.5 block text-[13px] text-text-muted">{r.description}</span>
                  </span>
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </>
  );
}

function EntityPicker({ kind, value, onChange }: { kind: 'loan' | 'customer'; value?: string; onChange: (v: string | undefined) => void }) {
  const [term, setTerm] = React.useState('');
  const [open, setOpen] = React.useState(false);
  const endpoint = kind === 'loan' ? '/api/loans' : '/api/customers';
  const q = useQuery({ queryKey: ['pick', kind, term], queryFn: () => api.get(endpoint, { search: term, pageSize: 8 }), enabled: term.length >= 2 });
  const sel = useQuery({ queryKey: ['picked', kind, value], queryFn: () => api.get(`${endpoint}/${value}`), enabled: !!value });
  const text = (x: any) => (kind === 'loan' ? `${x.loanNumber} — ${x.customerName}` : `${x.fullName} (${x.customerCode})`);
  return (
    <div className="relative w-72">
      <Input
        placeholder={kind === 'loan' ? 'Find loan' : 'Find customer'}
        value={open ? term : sel.data ? text(sel.data) : term}
        onFocus={() => setOpen(true)}
        onBlur={() => setTimeout(() => setOpen(false), 150)}
        onChange={(e) => setTerm(e.target.value)}
        className="h-9"
      />
      {open && term.length >= 2 && (
        <div className="absolute z-20 mt-1 w-full overflow-hidden rounded-md border border-line bg-white shadow-lg">
          {(q.data?.data ?? []).map((x: any) => (
            <button key={x.id} className="block w-full px-3 py-2 text-left text-sm hover:bg-canvas" onMouseDown={() => (onChange(String(x.id)), setTerm(''), setOpen(false))}>
              {text(x)}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

const STATUS_KEYS = new Set(['status', 'recoveryStatus', 'accountStatus', 'entryType']);

export function ReportViewer() {
  const { key } = useParams();
  const cat = useCatalogue();
  const lk = useLookups();
  const { user } = useAuth();
  const [url, setUrl] = useUrlState();
  const def = cat.data?.find((r) => r.key === key);
  const r = useRange(url, key === 'monthly-collection' ? 'last30' : 'month');
  if (cat.isLoading) return <Skeleton className="h-64" />;
  if (!def) return <ErrorState error={new Error('Unknown report')} />;
  const has = (f: string) => def.filters.includes(f);
  const filters: Record<string, any> = {
    from: has('dateRange') ? (key === 'monthly-collection' && !url.preset ? undefined : r.from) : undefined,
    to: has('dateRange') ? r.to : undefined,
    asOf: has('asOf') ? url.asOf : undefined,
    productId: url.productId,
    branchId: url.branchId,
    executiveId: url.executiveId,
    state: url.state,
    bucket: url.bucket,
    status: url.status,
    mode: url.mode,
    loanId: url.loanId,
    customerId: url.customerId,
  };
  // movement-style reports default to "since yesterday's snapshot" unless a range is chosen
  if (['dpd-movement', 'roll-forward', 'roll-backward'].includes(def.key) && !url.preset) {
    filters.from = undefined;
    filters.to = undefined;
  }
  const missing = def.requires.filter((k) => !filters[k]);
  const columns: Column<any>[] = def.columns.map((c) => ({
    key: c.key,
    header: c.label,
    sortable: true,
    align: c.type === 'money' || c.type === 'number' || c.type === 'pct' ? 'right' : undefined,
    total: c.type === 'number' ? 'number' : 'money',
    cell: (row: any) => {
      const v = row[c.key];
      if (c.type === 'money') return inr(v);
      if (c.type === 'number') return num(v);
      if (c.type === 'pct') return pct(v);
      if (c.type === 'date') return date(v);
      if (STATUS_KEYS.has(c.key)) return <StatusBadge status={v} />;
      if (typeof v === 'string' && /^[A-Z_]{3,}$/.test(v) && !/\d/.test(v) && !['B1_30', 'B31_60', 'B61_89', 'B90P'].includes(v)) return label(v);
      return v ?? '—';
    },
  }));

  return (
    <>
      <PageHeader back={{ to: '/reports', label: 'Reports' }} title={def.title} description={`${def.description} Business date ${date(user!.businessDate)}.`} />
      <Card className="mb-3 flex flex-wrap items-center gap-2 px-3 py-2.5">
        {has('dateRange') && <DateRangeFilter state={url} set={setUrl} fallback="month" />}
        {has('asOf') && (
          <label className="flex items-center gap-2 text-[13px] text-text-muted">
            As of
            <Input type="date" className="h-9 w-[150px]" value={url.asOf ?? user!.businessDate} max={user!.businessDate} onChange={(e) => setUrl({ asOf: e.target.value === user!.businessDate ? undefined : e.target.value })} />
          </label>
        )}
        {has('loan') && <EntityPicker kind="loan" value={url.loanId} onChange={(v) => setUrl({ loanId: v })} />}
        {has('customer') && <EntityPicker kind="customer" value={url.customerId} onChange={(v) => setUrl({ customerId: v })} />}
        {has('product') && <FilterSelect value={url.productId} onChange={(v) => setUrl({ productId: v })} placeholder="All products" options={(lk.data?.products ?? []).map((p) => ({ value: p.id, label: p.name }))} />}
        {has('branch') && <FilterSelect value={url.branchId} onChange={(v) => setUrl({ branchId: v })} placeholder="All branches" options={(lk.data?.branches ?? []).map((b) => ({ value: b.id, label: b.name }))} />}
        {has('executive') && <FilterSelect value={url.executiveId} onChange={(v) => setUrl({ executiveId: v })} placeholder="All executives" options={(lk.data?.executives ?? []).map((e) => ({ value: e.id, label: e.fullName }))} />}
        {has('state') && <FilterSelect value={url.state} onChange={(v) => setUrl({ state: v })} placeholder="All states" options={(lk.data?.states ?? []).map((s) => ({ value: s, label: s }))} />}
        {has('bucket') && <FilterSelect value={url.bucket} onChange={(v) => setUrl({ bucket: v })} placeholder="All buckets" options={(lk.data?.buckets ?? []).map((b) => ({ value: b.code, label: b.label }))} />}
        {has('loanStatus') && <FilterSelect value={url.status} onChange={(v) => setUrl({ status: v })} placeholder="Any loan status" options={['LIVE', 'DRAFT', 'APPROVED', 'DISBURSED', 'ACTIVE', 'OVERDUE', 'CLOSED', 'WRITTEN_OFF', 'CANCELLED'].map((s) => ({ value: s, label: label(s) }))} />}
        {has('paymentStatus') && <FilterSelect value={url.status} onChange={(v) => setUrl({ status: v })} placeholder="Any status" options={['SUCCESSFUL', 'PENDING', 'INITIATED', 'FAILED', 'REVERSED'].map((s) => ({ value: s, label: label(s) }))} />}
        {has('emiStatus') && <FilterSelect value={url.status} onChange={(v) => setUrl({ status: v })} placeholder="Any status" options={['UPCOMING', 'DUE', 'PARTIALLY_PAID', 'PAID', 'OVERDUE', 'BOUNCED', 'WAIVED'].map((s) => ({ value: s, label: label(s) }))} />}
        {has('mode') && <FilterSelect value={url.mode} onChange={(v) => setUrl({ mode: v })} placeholder="Any mode" options={['UPI', 'NEFT', 'RTGS', 'IMPS', 'CASH', 'CHEQUE', 'NACH', 'OTHER'].map((m) => ({ value: m, label: m }))} />}
      </Card>
      {missing.length > 0 ? (
        <Card className="px-5 py-10 text-center text-sm text-text-muted">Choose a {missing[0] === 'loanId' ? 'loan' : 'customer'} to run this report.</Card>
      ) : (
        <DataTable endpoint={`/api/reports/${def.key}`} columns={columns} filters={filters} showTotals rowKey="__row" searchPlaceholder="Search this report" initialPageSize={50} emptyTitle="No rows for these filters" />
      )}
    </>
  );
}
