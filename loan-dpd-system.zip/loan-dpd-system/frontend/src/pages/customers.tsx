import { Link, useNavigate, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Pencil, Plus } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { date, inr, inrShort, label, num } from '@/lib/format';
import { applyServerErrors, useAction, useGet, useLookups, useUrlState } from '@/hooks/data';
import { Button, Card, CardHeader, Field, Input, NativeSelect, Skeleton } from '@/components/ui/base';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/overlay';
import { DataTable, FilterSelect } from '@/components/DataTable';
import { DpdBadge, EmptyState, ErrorState, KeyValues, Money, PageHeader, Stat, StatGrid, StatusBadge } from '@/components/domain';

export function CustomerList() {
  const { can } = useAuth();
  const nav = useNavigate();
  const [url, setUrl] = useUrlState();
  const lk = useLookups();
  return (
    <>
      <PageHeader
        title="Customers"
        description="Borrowers with their loans and current overdue position."
        actions={
          can('customers.write') && (
            <Button asChild>
              <Link to="/customers/new">
                <Plus /> Add customer
              </Link>
            </Button>
          )
        }
      />
      <DataTable
        endpoint="/api/customers"
        searchPlaceholder="Name, customer ID, mobile or PAN"
        filters={{ status: url.status, state: url.state, city: url.city, hasOverdue: url.hasOverdue }}
        onRowClick={(r) => nav(`/customers/${r.id}`)}
        toolbar={
          <>
            <FilterSelect value={url.status} onChange={(v) => setUrl({ status: v })} placeholder="Any status" options={['ACTIVE', 'INACTIVE', 'BLOCKED'].map((s) => ({ value: s, label: label(s) }))} />
            <FilterSelect value={url.state} onChange={(v) => setUrl({ state: v })} placeholder="Any state" options={(lk.data?.states ?? []).map((s) => ({ value: s, label: s }))} />
            <FilterSelect value={url.hasOverdue} onChange={(v) => setUrl({ hasOverdue: v })} placeholder="Overdue or not" options={[{ value: 'true', label: 'Has overdue' }]} />
          </>
        }
        columns={[
          { key: 'customerCode', header: 'Customer ID', sortable: true, cell: (r) => <span className="font-medium text-ink">{r.customerCode}</span> },
          { key: 'fullName', header: 'Name', sortable: true },
          { key: 'mobile', header: 'Mobile', cell: (r) => <span className="tabular-nums">{r.mobile}</span> },
          { key: 'city', header: 'Location', sortable: true, cell: (r) => `${r.city ?? '—'}, ${r.state ?? ''}` },
          { key: 'loanCount', header: 'Loans', align: 'right' },
          { key: 'totalOverdue', header: 'Overdue', align: 'right', sortable: true, cell: (r) => (r.totalOverdue > 0 ? <Money v={r.totalOverdue} className="text-risk" /> : <span className="text-text-faint">—</span>) },
          { key: 'maxDpd', header: 'Worst DPD', sortable: true, cell: (r) => <DpdBadge dpd={r.maxDpd} /> },
          { key: 'status', header: 'Status', cell: (r) => <StatusBadge status={r.status} /> },
        ]}
      />
    </>
  );
}

export function CustomerDetail() {
  const { id } = useParams();
  const { can } = useAuth();
  const nav = useNavigate();
  const c = useGet<any>(`/api/customers/${id}`);
  const payments = useGet<any[]>(can('payments.read') ? `/api/customers/${id}/payments` : null);
  const activities = useGet<any[]>(can('collections.read') ? `/api/customers/${id}/collections` : null);
  const bounces = useGet<any[]>(can('bounces.read') ? `/api/customers/${id}/bounces` : null);
  if (c.isError) return <ErrorState error={c.error} onRetry={() => c.refetch()} />;
  if (!c.data) return <Skeleton className="h-64 w-full" />;
  const d = c.data;
  return (
    <>
      <PageHeader
        back={{ to: '/customers', label: 'Customers' }}
        title={d.fullName}
        description={`${d.customerCode} — customer since ${date(d.createdAt)}`}
        actions={
          <>
            <StatusBadge status={d.status} />
            {can('customers.write') && (
              <Button variant="secondary" asChild>
                <Link to={`/customers/${id}/edit`}>
                  <Pencil /> Edit
                </Link>
              </Button>
            )}
            {can('loans.write') && (
              <Button asChild>
                <Link to={`/loans/new?customerId=${id}`}>
                  <Plus /> New loan
                </Link>
              </Button>
            )}
          </>
        }
      />
      <StatGrid className="mb-5 grid-cols-2 md:grid-cols-5">
        <Stat label="Loans" value={num(d.summary.totalLoans)} sub={`${d.summary.activeLoans} live`} />
        <Stat label="Outstanding principal" value={inrShort(d.summary.outstandingPrincipal)} />
        <Stat label="Total overdue" value={inr(d.summary.totalOverdue)} tone={d.summary.totalOverdue > 0 ? 'risk' : undefined} />
        <Stat label="Worst DPD" value={d.summary.maxDpd} tone={d.summary.maxDpd > 30 ? 'risk' : d.summary.maxDpd > 0 ? 'due' : undefined} />
        <Stat label="Monthly income" value={inr(d.monthlyIncome, true)} sub={d.occupation} />
      </StatGrid>
      <Card className="mb-5">
        <CardHeader title="Profile" />
        <div className="p-5">
          <KeyValues
            cols={4}
            items={[
              ['Mobile', d.mobile],
              ['Email', d.email],
              ['Date of birth', d.dateOfBirth?.includes('X') ? d.dateOfBirth : date(d.dateOfBirth)],
              ['Gender', label(d.gender)],
              ['PAN', d.pan],
              ['Aadhaar', d.aadhaarMasked],
              ['Address', d.addressLine],
              ['City / PIN', `${d.city ?? '—'} ${d.pincode ?? ''}`],
              ['State', d.state],
              ['Occupation', d.occupation],
              ['Created by', d.createdByName],
            ]}
          />
        </div>
      </Card>
      <Tabs defaultValue="loans">
        <TabsList>
          <TabsTrigger value="loans">Loans ({d.loans.length})</TabsTrigger>
          {can('payments.read') && <TabsTrigger value="payments">Payment history</TabsTrigger>}
          {can('collections.read') && <TabsTrigger value="collections">Collection history</TabsTrigger>}
          {can('bounces.read') && <TabsTrigger value="bounces">Bounces</TabsTrigger>}
        </TabsList>
        <TabsContent value="loans">
          <SimpleTable
            rows={d.loans}
            onRowClick={(r) => nav(`/loans/${r.id}`)}
            empty="No loans yet."
            cols={[
              ['Loan ID', (r) => <span className="font-medium text-ink">{r.loanNumber}</span>],
              ['Product', (r) => r.productName],
              ['Principal', (r) => <Money v={r.principalAmount} />, true],
              ['EMI', (r) => <Money v={r.emiAmount} />, true],
              ['POS', (r) => <Money v={r.outstandingPrincipal} />, true],
              ['Overdue', (r) => <Money v={Number(r.overdueAmount) + Number(r.overdueCharges)} />, true],
              ['DPD', (r) => <DpdBadge dpd={r.dpd} bucket={r.bucketCode} />],
              ['Next due', (r) => date(r.nextEmiDueDate)],
              ['Status', (r) => <StatusBadge status={r.status} />],
            ]}
          />
        </TabsContent>
        <TabsContent value="payments">
          <SimpleTable
            rows={payments.data}
            loading={payments.isLoading}
            onRowClick={(r) => nav(`/payments/${r.id}`)}
            empty="No payments recorded."
            cols={[
              ['Payment', (r) => r.paymentNumber],
              ['Date', (r) => date(r.paymentDate)],
              ['Loan', (r) => r.loanNumber],
              ['Mode', (r) => r.paymentMode],
              ['Reference', (r) => r.transactionReference ?? '—'],
              ['Amount', (r) => <Money v={r.amount} />, true],
              ['Status', (r) => <StatusBadge status={r.status} />],
            ]}
          />
        </TabsContent>
        <TabsContent value="collections">
          <SimpleTable
            rows={activities.data}
            loading={activities.isLoading}
            empty="No collection activity logged."
            cols={[
              ['Date', (r) => date(r.activityDate)],
              ['Loan', (r) => r.loanNumber],
              ['Executive', (r) => r.executiveName],
              ['Type', (r) => label(r.activityType)],
              ['Result', (r) => label(r.contactResult)],
              ['Promise', (r) => (r.ptpAmount ? `${inr(r.ptpAmount)} by ${date(r.ptpDate)}` : '—')],
              ['Notes', (r) => <span className="block max-w-xs truncate">{r.notes ?? '—'}</span>],
            ]}
          />
        </TabsContent>
        <TabsContent value="bounces">
          <SimpleTable
            rows={bounces.data}
            loading={bounces.isLoading}
            empty="No bounces. Good sign."
            cols={[
              ['Bounce', (r) => r.bounceNumber],
              ['Date', (r) => date(r.bounceDate)],
              ['Loan', (r) => r.loanNumber],
              ['Reason', (r) => label(r.bounceReason)],
              ['Amount', (r) => <Money v={r.bounceAmount} />, true],
              ['Charge', (r) => <Money v={r.bounceCharges} />, true],
              ['Recovery', (r) => <StatusBadge status={r.recoveryStatus} />],
            ]}
          />
        </TabsContent>
      </Tabs>
    </>
  );
}

/** Small client-side table for already-loaded detail lists. */
export function SimpleTable<T extends Record<string, any>>({
  rows,
  cols,
  loading,
  empty,
  onRowClick,
  footer,
}: {
  rows?: T[];
  cols: [string, (r: T) => React.ReactNode, boolean?][];
  loading?: boolean;
  empty: string;
  onRowClick?: (r: T) => void;
  footer?: React.ReactNode;
}) {
  return (
    <div className="overflow-x-auto rounded-lg border border-line bg-white">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-line bg-canvas/60 text-left text-[13px] text-text-muted">
            {cols.map(([h, , right]) => (
              <th key={h} className={`whitespace-nowrap px-3 py-2 font-medium ${right ? 'text-right' : ''}`}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {loading
            ? Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>
                  {cols.map(([h]) => (
                    <td key={h} className="px-3 py-2.5">
                      <Skeleton className="h-4 w-20" />
                    </td>
                  ))}
                </tr>
              ))
            : (rows ?? []).map((r, i) => (
                <tr key={r.id ?? i} onClick={onRowClick ? () => onRowClick(r) : undefined} className={`border-b border-line/70 last:border-0 ${onRowClick ? 'cursor-pointer hover:bg-ink-50/50' : ''}`}>
                  {cols.map(([h, f, right]) => (
                    <td key={h} className={`whitespace-nowrap px-3 py-2 ${right ? 'text-right tabular-nums' : ''}`}>
                      {f(r)}
                    </td>
                  ))}
                </tr>
              ))}
        </tbody>
        {footer}
      </table>
      {!loading && (rows ?? []).length === 0 && <EmptyState title={empty} />}
    </div>
  );
}

const customerSchema = z.object({
  fullName: z.string().trim().min(2, 'Enter the full name'),
  mobile: z.string().regex(/^[6-9]\d{9}$/, '10-digit mobile starting 6–9'),
  email: z.string().email('Invalid email').or(z.literal('')).optional(),
  dateOfBirth: z.string().optional(),
  gender: z.string().optional(),
  pan: z
    .string()
    .transform((v) => v.toUpperCase())
    .pipe(z.string().regex(/^([A-Z]{5}\d{4}[A-Z])?$/, 'Format ABCDE1234F'))
    .optional(),
  aadhaar: z.string().regex(/^(\d{12}|\d{4})?$/, '12 digits (only last 4 are stored)').optional(),
  addressLine: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  pincode: z.string().regex(/^([1-9]\d{5})?$/, '6-digit PIN').optional(),
  occupation: z.string().optional(),
  monthlyIncome: z.string().optional(),
  status: z.enum(['ACTIVE', 'INACTIVE', 'BLOCKED']),
});
type CustomerValues = z.infer<typeof customerSchema>;

const STATES = ['Andhra Pradesh', 'Bihar', 'Chhattisgarh', 'Delhi', 'Gujarat', 'Haryana', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Odisha', 'Punjab', 'Rajasthan', 'Tamil Nadu', 'Telangana', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal'];

export function CustomerFormPage() {
  const { id } = useParams();
  const nav = useNavigate();
  const existing = useGet<any>(id ? `/api/customers/${id}` : null);
  if (id && !existing.data) return existing.isError ? <ErrorState error={existing.error} /> : <Skeleton className="h-64" />;
  return <CustomerForm id={id} initial={existing.data} onDone={(cid) => nav(`/customers/${cid}`)} />;
}

function CustomerForm({ id, initial, onDone }: { id?: string; initial?: any; onDone: (id: number) => void }) {
  const form = useForm<CustomerValues>({
    resolver: zodResolver(customerSchema),
    defaultValues: initial
      ? {
          fullName: initial.fullName,
          mobile: initial.mobile,
          email: initial.email ?? '',
          dateOfBirth: initial.dateOfBirth?.includes('X') ? undefined : initial.dateOfBirth ?? '',
          gender: initial.gender ?? '',
          pan: initial.pan ?? '',
          aadhaar: '',
          addressLine: initial.addressLine ?? '',
          city: initial.city ?? '',
          state: initial.state ?? '',
          pincode: initial.pincode ?? '',
          occupation: initial.occupation ?? '',
          monthlyIncome: initial.monthlyIncome?.toString() ?? '',
          status: initial.status,
        }
      : { status: 'ACTIVE' },
  });
  const save = useAction(
    (v: CustomerValues) => {
      const body: any = { ...v };
      for (const key of Object.keys(body)) if (body[key] === '') body[key] = null;
      if (id && !v.aadhaar) delete body.aadhaar; // keep stored value when not re-entered
      body.monthlyIncome = v.monthlyIncome ? Number(v.monthlyIncome) : null;
      return id ? api.put(`/api/customers/${id}`, body) : api.post('/api/customers', body);
    },
    { success: id ? 'Customer updated' : 'Customer created', invalidate: ['/api/customers'], onSuccess: (r: any) => onDone(r.id) },
  );
  const e = form.formState.errors;
  const submit = form.handleSubmit((v) => save.mutate(v, { onError: (err) => applyServerErrors(err, form.setError) }));
  return (
    <div className="max-w-4xl">
      <PageHeader back={{ to: id ? `/customers/${id}` : '/customers', label: id ? 'Customer' : 'Customers' }} title={id ? 'Edit customer' : 'Add customer'} />
      <form onSubmit={submit} noValidate>
        <Card>
          <CardHeader title="Identity" description="Only the last four Aadhaar digits are ever stored." />
          <div className="grid gap-4 p-5 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Full name" required error={e.fullName?.message} className="lg:col-span-2">
              <Input {...form.register('fullName')} aria-invalid={!!e.fullName} />
            </Field>
            <Field label="Status" error={e.status?.message}>
              <NativeSelect {...form.register('status')}>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
                <option value="BLOCKED">Blocked</option>
              </NativeSelect>
            </Field>
            <Field label="Mobile" required error={e.mobile?.message}>
              <Input inputMode="numeric" maxLength={10} {...form.register('mobile')} aria-invalid={!!e.mobile} />
            </Field>
            <Field label="Email" error={e.email?.message}>
              <Input type="email" {...form.register('email')} />
            </Field>
            <Field label="Date of birth" error={e.dateOfBirth?.message}>
              <Input type="date" {...form.register('dateOfBirth')} />
            </Field>
            <Field label="Gender">
              <NativeSelect {...form.register('gender')}>
                <option value="">Not specified</option>
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </NativeSelect>
            </Field>
            <Field label="PAN" error={e.pan?.message}>
              <Input className="uppercase" maxLength={10} {...form.register('pan')} />
            </Field>
            <Field label="Aadhaar" error={e.aadhaar?.message} hint={initial?.aadhaarMasked ? `On file: ${initial.aadhaarMasked}` : 'Optional'}>
              <Input inputMode="numeric" maxLength={12} autoComplete="off" {...form.register('aadhaar')} />
            </Field>
          </div>
        </Card>
        <Card className="mt-5">
          <CardHeader title="Address and income" />
          <div className="grid gap-4 p-5 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Address" className="sm:col-span-2 lg:col-span-3">
              <Input {...form.register('addressLine')} />
            </Field>
            <Field label="City">
              <Input {...form.register('city')} />
            </Field>
            <Field label="State">
              <NativeSelect {...form.register('state')}>
                <option value="">Select state</option>
                {STATES.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </NativeSelect>
            </Field>
            <Field label="PIN code" error={e.pincode?.message}>
              <Input inputMode="numeric" maxLength={6} {...form.register('pincode')} />
            </Field>
            <Field label="Occupation">
              <Input {...form.register('occupation')} />
            </Field>
            <Field label="Monthly income (₹)">
              <Input type="number" min={0} step="100" {...form.register('monthlyIncome')} />
            </Field>
          </div>
        </Card>
        <div className="mt-5 flex justify-end gap-2">
          <Button type="button" variant="secondary" onClick={() => history.back()}>
            Cancel
          </Button>
          <Button type="submit" loading={save.isPending}>
            {id ? 'Save changes' : 'Create customer'}
          </Button>
        </div>
      </form>
    </div>
  );
}
