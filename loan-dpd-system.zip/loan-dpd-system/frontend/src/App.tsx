import { lazy, type ReactNode } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { ShieldOff } from 'lucide-react';
import { useAuth } from './lib/auth';
import { Layout } from './components/Layout';
import { LoginPage, ForgotPasswordPage, ResetPasswordPage } from './pages/auth';

const P = {
  Dashboard: lazy(() => import('./pages/Dashboard')),
  Profile: lazy(() => import('./pages/auth').then((m) => ({ default: m.ProfilePage }))),
  CustomerList: lazy(() => import('./pages/customers').then((m) => ({ default: m.CustomerList }))),
  CustomerDetail: lazy(() => import('./pages/customers').then((m) => ({ default: m.CustomerDetail }))),
  CustomerForm: lazy(() => import('./pages/customers').then((m) => ({ default: m.CustomerFormPage }))),
  LoanRegister: lazy(() => import('./pages/loans').then((m) => ({ default: m.LoanRegister }))),
  LoanCreate: lazy(() => import('./pages/loans').then((m) => ({ default: m.LoanCreate }))),
  LoanDetail: lazy(() => import('./pages/loans').then((m) => ({ default: m.LoanDetail }))),
  Emi: lazy(() => import('./pages/emi')),
  Payments: lazy(() => import('./pages/payments').then((m) => ({ default: m.PaymentRegister }))),
  RecordPayment: lazy(() => import('./pages/payments').then((m) => ({ default: m.RecordPayment }))),
  PaymentDetail: lazy(() => import('./pages/payments').then((m) => ({ default: m.PaymentDetail }))),
  Bounces: lazy(() => import('./pages/bounces')),
  Dpd: lazy(() => import('./pages/dpd').then((m) => ({ default: m.DpdPortfolio }))),
  DpdAccounts: lazy(() => import('./pages/dpd').then((m) => ({ default: m.DpdAccounts }))),
  Snapshots: lazy(() => import('./pages/dpd').then((m) => ({ default: m.DpdSnapshots }))),
  CollectionDesk: lazy(() => import('./pages/collections').then((m) => ({ default: m.CollectionDashboard }))),
  Assignments: lazy(() => import('./pages/collections').then((m) => ({ default: m.AccountAssignment }))),
  Activities: lazy(() => import('./pages/collections').then((m) => ({ default: m.Activities }))),
  Ptp: lazy(() => import('./pages/collections').then((m) => ({ default: m.PromiseToPay }))),
  Reports: lazy(() => import('./pages/reports').then((m) => ({ default: m.ReportsCenter }))),
  Report: lazy(() => import('./pages/reports').then((m) => ({ default: m.ReportViewer }))),
  Users: lazy(() => import('./pages/admin').then((m) => ({ default: m.UsersPage }))),
  Roles: lazy(() => import('./pages/admin').then((m) => ({ default: m.RolesPage }))),
  Config: lazy(() => import('./pages/admin').then((m) => ({ default: m.ConfigPage }))),
  Jobs: lazy(() => import('./pages/admin').then((m) => ({ default: m.JobsPage }))),
  Audit: lazy(() => import('./pages/admin').then((m) => ({ default: m.AuditPage }))),
};

function NoAccess() {
  return (
    <div className="mx-auto max-w-md py-24 text-center">
      <ShieldOff className="mx-auto h-10 w-10 text-text-faint" strokeWidth={1.5} />
      <h1 className="mt-4 text-lg font-semibold">You don't have access to this page</h1>
      <p className="mt-1 text-sm text-text-muted">Ask an administrator to add the permission to your role.</p>
    </div>
  );
}

function Guard({ perm, children }: { perm?: string[]; children: ReactNode }) {
  const { can } = useAuth();
  if (perm && !can(...perm)) return <NoAccess />;
  return <>{children}</>;
}

/** Collection executives land on their desk; everyone else on the dashboard. */
function Home() {
  const { user, can } = useAuth();
  if (user?.role === 'COLLECTION_EXECUTIVE') return <Navigate to="/collections" replace />;
  if (!can('dashboard.read')) return <Navigate to="/loans" replace />;
  return <P.Dashboard />;
}

function RequireAuth({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading)
    return (
      <div className="flex h-screen items-center justify-center bg-canvas text-sm text-text-muted" role="status">
        Restoring your session…
      </div>
    );
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname + loc.search }} />;
  return <>{children}</>;
}

export function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      <Route
        element={
          <RequireAuth>
            <Layout />
          </RequireAuth>
        }
      >
        <Route index element={<Home />} />
        <Route path="profile" element={<P.Profile />} />
        <Route path="customers" element={<Guard perm={['customers.read']}><P.CustomerList /></Guard>} />
        <Route path="customers/new" element={<Guard perm={['customers.write']}><P.CustomerForm /></Guard>} />
        <Route path="customers/:id" element={<Guard perm={['customers.read']}><P.CustomerDetail /></Guard>} />
        <Route path="customers/:id/edit" element={<Guard perm={['customers.write']}><P.CustomerForm /></Guard>} />
        <Route path="loans" element={<Guard perm={['loans.read']}><P.LoanRegister /></Guard>} />
        <Route path="loans/new" element={<Guard perm={['loans.write']}><P.LoanCreate /></Guard>} />
        <Route path="loans/:id/edit" element={<Guard perm={['loans.write']}><P.LoanCreate /></Guard>} />
        <Route path="loans/:id" element={<Guard perm={['loans.read']}><P.LoanDetail /></Guard>} />
        <Route path="emi" element={<Guard perm={['loans.read']}><P.Emi /></Guard>} />
        <Route path="payments" element={<Guard perm={['payments.read']}><P.Payments /></Guard>} />
        <Route path="payments/new" element={<Guard perm={['payments.write', 'payments.import']}><P.RecordPayment /></Guard>} />
        <Route path="payments/:id" element={<Guard perm={['payments.read']}><P.PaymentDetail /></Guard>} />
        <Route path="bounces" element={<Guard perm={['bounces.read']}><P.Bounces /></Guard>} />
        <Route path="dpd" element={<Guard perm={['dpd.read']}><P.Dpd /></Guard>} />
        <Route path="dpd/accounts" element={<Guard perm={['dpd.read']}><P.DpdAccounts /></Guard>} />
        <Route path="dpd/snapshots" element={<Guard perm={['dpd.read']}><P.Snapshots /></Guard>} />
        <Route path="collections" element={<Guard perm={['collections.read']}><P.CollectionDesk /></Guard>} />
        <Route path="collections/assignments" element={<Guard perm={['collections.read']}><P.Assignments /></Guard>} />
        <Route path="collections/activities" element={<Guard perm={['collections.read']}><P.Activities /></Guard>} />
        <Route path="collections/ptp" element={<Guard perm={['collections.read']}><P.Ptp /></Guard>} />
        <Route path="reports" element={<Guard perm={['reports.read']}><P.Reports /></Guard>} />
        <Route path="reports/:key" element={<Guard perm={['reports.read']}><P.Report /></Guard>} />
        <Route path="admin/users" element={<Guard perm={['users.read']}><P.Users /></Guard>} />
        <Route path="admin/roles" element={<Guard perm={['users.read', 'roles.manage']}><P.Roles /></Guard>} />
        <Route path="admin/config" element={<Guard perm={['config.manage']}><P.Config /></Guard>} />
        <Route path="admin/jobs" element={<Guard perm={['jobs.read']}><P.Jobs /></Guard>} />
        <Route path="jobs" element={<Navigate to="/admin/jobs" replace />} />
        <Route path="admin/audit" element={<Guard perm={['audit.read']}><P.Audit /></Guard>} />
        <Route path="*" element={<div className="py-24 text-center text-text-muted">Page not found.</div>} />
      </Route>
    </Routes>
  );
}
