import { useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { api, ApiError, type Query } from '@/lib/api';

/** URL-backed page state: filters, page, sort survive refresh and back/forward. */
export function useUrlState<T extends Record<string, string | undefined>>(defaults: T = {} as T) {
  const [sp, setSp] = useSearchParams();
  const state = useMemo(() => {
    const o: Record<string, string | undefined> = { ...defaults };
    sp.forEach((v, k) => (o[k] = v));
    return o as T & Record<string, string | undefined>;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sp]);
  const set = useCallback(
    (patch: Record<string, string | number | undefined | null>, opts: { resetPage?: boolean } = { resetPage: true }) => {
      setSp(
        (prev) => {
          const next = new URLSearchParams(prev);
          for (const [k, v] of Object.entries(patch)) {
            if (v === undefined || v === null || v === '') next.delete(k);
            else next.set(k, String(v));
          }
          if (opts.resetPage && !('page' in patch)) next.delete('page');
          return next;
        },
        { replace: true },
      );
    },
    [setSp],
  );
  return [state, set] as const;
}

export interface Page<T> {
  data: T[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  totals?: Record<string, number> | null;
}

export function useList<T = any>(endpoint: string, params: Query, enabled = true) {
  return useQuery<Page<T>>({
    queryKey: [endpoint, params],
    queryFn: () => api.get<Page<T>>(endpoint, params),
    placeholderData: keepPreviousData,
    enabled,
  });
}

export function useGet<T = any>(path: string | null, params?: Query) {
  return useQuery<T>({ queryKey: [path, params], queryFn: () => api.get<T>(path!, params), enabled: !!path });
}

export interface Lookups {
  products: { id: number; code: string; name: string; minAmount: number; maxAmount: number; minTenureMonths: number; maxTenureMonths: number; defaultRate: number; processingFeePct: number; isActive: boolean }[];
  branches: { id: number; code: string; name: string; city: string; state: string }[];
  executives: { id: number; fullName: string }[];
  roles: { id: number; code: string; name: string }[];
  buckets: { code: string; label: string; minDpd: number; maxDpd: number | null; sortOrder: number; color: string }[];
  states: string[];
  businessDate: string;
  companyName: string;
}
export const useLookups = () => useQuery<Lookups>({ queryKey: ['lookups'], queryFn: () => api.get('/api/lookups'), staleTime: 60_000 });

/** Mutation with toast feedback and cache invalidation. */
export function useAction<TVars = any, TRes = any>(fn: (v: TVars) => Promise<TRes>, opts: { success?: string | ((r: TRes) => string); invalidate?: string[]; onSuccess?: (r: TRes) => void } = {}) {
  const qc = useQueryClient();
  return useMutation<TRes, ApiError, TVars>({
    mutationFn: fn,
    onSuccess: (r) => {
      if (opts.success) toast.success(typeof opts.success === 'function' ? opts.success(r) : opts.success);
      // invalidate everything by default: financial actions ripple through many screens
      if (opts.invalidate) for (const k of opts.invalidate) qc.invalidateQueries({ predicate: (q) => String(q.queryKey[0]).startsWith(k) });
      else qc.invalidateQueries();
      opts.onSuccess?.(r);
    },
    onError: (e) => toast.error(e.message),
  });
}

/** Map API validation details onto react-hook-form fields. */
export function applyServerErrors(err: unknown, setError: (name: any, e: { message: string }) => void) {
  if (err instanceof ApiError && err.details) for (const d of err.details) if (d.path) setError(d.path, { message: d.message });
}
