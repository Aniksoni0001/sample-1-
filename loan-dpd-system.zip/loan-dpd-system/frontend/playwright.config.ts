import { defineConfig } from '@playwright/test';

/**
 * End-to-end tests drive the real UI against the real API and a seeded database.
 * Start the stack first (docker compose up, or backend + `npm run dev`), then:
 *   E2E_BASE_URL=http://localhost:5173 npm run test:e2e
 * Set CHROME_PATH to use an installed Chrome instead of Playwright's bundled browser.
 */
export default defineConfig({
  testDir: './e2e',
  timeout: 60_000,
  fullyParallel: false,
  workers: 1,
  reporter: [['list']],
  use: {
    baseURL: process.env.E2E_BASE_URL ?? 'http://localhost:5173',
    viewport: { width: 1440, height: 900 },
    trace: 'retain-on-failure',
    launchOptions: process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH, args: ['--no-sandbox'] } : {},
  },
});
