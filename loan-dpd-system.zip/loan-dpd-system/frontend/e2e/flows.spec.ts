import { expect, test, type Page } from '@playwright/test';

/**
 * Full business journey through the UI on the seeded demo database:
 * login → create customer → create, approve and disburse a loan → see the
 * schedule → record a payment → record a bounce → run the DPD job → check the
 * DPD dashboard → export a report.
 */
const PASSWORD = 'Demo@12345';
const uniq = Date.now().toString().slice(-6);
const mobile = `9${uniq}${uniq.slice(0, 3)}`;
const pan = `QAZPE${uniq.slice(0, 4)}K`;

async function login(page: Page, user: string) {
  await page.goto('/login');
  await page.getByLabel('Email').fill(`${user}@demo.local`);
  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByText('Business date')).toBeVisible();
}

test.describe.serial('collections journey', () => {
  let loanUrl = '';

  test('rejects a wrong password', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('Email').fill('finance@demo.local');
    await page.getByLabel('Password').fill('nope-nope-1');
    await page.getByRole('button', { name: 'Sign in' }).click();
    await expect(page.getByRole('alert')).toContainText('Invalid email or password');
  });

  test('creates a customer', async ({ page }) => {
    await login(page, 'finance');
    await page.goto('/customers/new');
    await page.getByLabel('Full name').fill(`E2E Customer ${uniq}`);
    await page.getByLabel('Mobile').fill(mobile);
    await page.getByLabel('PAN').fill(pan);
    await page.getByLabel('Aadhaar').fill('123456789012');
    await page.getByLabel('City').fill('Patna');
    await page.getByLabel('State').selectOption('Bihar');
    await page.getByRole('button', { name: 'Create customer' }).click();
    await expect(page.getByRole('heading', { name: `E2E Customer ${uniq}` })).toBeVisible();
    await expect(page.getByText('XXXX-XXXX-9012')).toBeVisible();
  });

  test('creates, approves and disburses a loan with its schedule', async ({ page }) => {
    await login(page, 'finance');
    await page.goto('/loans/new');
    await page.getByPlaceholder('Search by name, ID or mobile').fill(`E2E Customer ${uniq}`);
    await page.getByRole('button', { name: new RegExp(`E2E Customer ${uniq}`) }).click();
    await page.getByLabel('Product').selectOption({ label: 'Two-Wheeler Loan' });
    await page.getByLabel('Principal (₹)').fill('100000');
    await page.getByLabel('Annual interest rate (%)').fill('18');
    await page.getByLabel('Tenure (months)').fill('12');
    await expect(page.getByText('₹9,168')).toBeVisible(); // live EMI calculator
    await page.getByRole('button', { name: 'Save draft' }).click();
    await expect(page.getByText('Draft', { exact: true })).toBeVisible();
    loanUrl = page.url();

    await page.getByRole('button', { name: 'Approve' }).click();
    await page.getByRole('button', { name: 'Approve loan' }).click();
    await expect(page.getByText('Approved', { exact: true })).toBeVisible();

    await page.getByRole('button', { name: 'Disburse' }).click();
    await page.getByRole('button', { name: /Disburse ₹/ }).click();
    await expect(page.getByText('Disbursed', { exact: true }).first()).toBeVisible();

    await page.getByRole('tab', { name: 'Repayment schedule' }).click();
    await expect(page.locator('table tbody tr')).toHaveCount(12);
    await expect(page.getByRole('cell', { name: '₹1,00,000.00' }).first()).toBeVisible();
  });

  test('records a payment with an allocation preview', async ({ page }) => {
    await login(page, 'finance');
    const id = loanUrl.split('/').pop();
    await page.goto(`/payments/new?loanId=${id}`);
    await page.getByLabel('Amount (₹)').fill('2500');
    await page.getByLabel('Transaction reference').fill(`UTR${uniq}`);
    await expect(page.getByText('Where this money goes')).toBeVisible();
    await expect(page.getByText(/EMI 1 interest/)).toBeVisible();
    await page.getByRole('button', { name: /Record ₹2,500/ }).click();
    await expect(page.getByText('Successful', { exact: true })).toBeVisible();
    await expect(page.getByRole('cell', { name: /EMI 1/ }).first()).toBeVisible();
  });

  test('records a bounce of that payment', async ({ page }) => {
    await login(page, 'finance');
    await page.goto('/payments');
    await page.getByLabel('Search').fill(`UTR${uniq}`);
    await page.getByRole('cell', { name: `UTR${uniq}` }).click();
    await page.getByRole('button', { name: 'Record bounce' }).click();
    await page.getByRole('dialog').getByRole('button', { name: 'Record bounce' }).click();
    await expect(page.getByText('Failed', { exact: true })).toBeVisible();
    await expect(page.getByText(/Bounced \(Insufficient funds\)/)).toBeVisible();
  });

  test('runs the DPD job and shows the DPD dashboard', async ({ page }) => {
    await login(page, 'admin');
    await page.goto('/admin/jobs');
    await page.getByRole('button', { name: 'Run DPD now' }).click();
    await page.getByRole('button', { name: 'Run now' }).click();
    await expect(page.getByText(/DPD processed for|Run failed/)).toBeVisible();
    await page.goto('/dpd');
    await expect(page.getByText('Bucket position')).toBeVisible();
    await expect(page.getByRole('row', { name: /Total/ })).toBeVisible();
    await page.getByRole('row', { name: /^90\+ DPD \d/ }).click();
    await expect(page).toHaveURL(/\/dpd\/accounts\?.*bucket=B90P/);
  });

  test('exports a report', async ({ page }) => {
    await login(page, 'analyst');
    await page.goto('/reports/overdue');
    await expect(page.getByText('Total (all pages)')).toBeVisible();
    await page.getByRole('button', { name: 'Export' }).click();
    const download = page.waitForEvent('download');
    await page.getByRole('menuitem', { name: 'Excel' }).click();
    expect((await download).suggestedFilename()).toMatch(/^overdue_.*\.xlsx$/);
  });

  test('a collection executive only sees their own accounts', async ({ page }) => {
    await login(page, 'exec1');
    await expect(page).toHaveURL(/\/collections$/);
    await expect(page.getByRole('heading', { name: 'My collection desk' })).toBeVisible();
    await page.goto('/admin/users');
    await expect(page.getByText("You don't have access to this page")).toBeVisible();
  });
});
